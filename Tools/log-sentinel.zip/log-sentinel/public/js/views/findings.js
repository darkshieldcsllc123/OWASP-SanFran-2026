import { h, mount, button, ago, clock, num, sevBadge, emptyState, debounce, cap, modal, confirmDialog, toast, richText, icon, SEVERITIES, segmented, field } from '../ui.js';
import { api } from '../api.js';
import { S } from '../app.js';

const STATUS_FILTERS = [
  { value: 'open,acknowledged', label: 'Open and acknowledged' },
  { value: 'open', label: 'Open' },
  { value: 'acknowledged', label: 'Acknowledged' },
  { value: 'muted', label: 'Muted' },
  { value: 'resolved', label: 'Resolved' },
  { value: 'all', label: 'All' },
];

export default {
  async render(root, params, ctx) {
    if (params[0]) return renderDetail(root, params[0], ctx);
    return renderList(root, ctx);
  },
};

function statusChip(st) {
  const cls = { open: 'chip-bad', acknowledged: 'chip-accent', muted: '', resolved: 'chip-ok' }[st] || '';
  return h('span', { class: `chip ${cls}` }, cap(st));
}

async function renderList(root, ctx) {
  const f = {
    status: ctx.query.get('status') || 'open,acknowledged',
    severity: ctx.query.get('severity') || '',
    source: '',
    q: '',
  };
  const tableHost = h('div');
  const statusSel = h('select', { class: 'input select', 'aria-label': 'Status' }, STATUS_FILTERS.map((o) => h('option', { value: o.value, selected: o.value === f.status }, o.label)));
  const sevSel = h('select', { class: 'input select', 'aria-label': 'Minimum severity' },
    h('option', { value: '' }, 'Any severity'), SEVERITIES.slice(0, 4).map((s) => h('option', { value: s, selected: s === f.severity }, `${cap(s)}${s === 'critical' ? '' : ' and above'}`)));
  const srcSel = h('select', { class: 'input select', 'aria-label': 'Source' }, h('option', { value: '' }, 'All sources'),
    S.config.sources.map((s) => h('option', { value: s.id }, s.name)), h('option', { value: 'metrics' }, 'Metric thresholds'));
  const search = h('input', { class: 'input search', type: 'search', placeholder: 'Search titles, explanations, evidence', 'aria-label': 'Search findings' });
  const load = async () => {
    const qs = new URLSearchParams();
    if (f.status) qs.set('status', f.status);
    if (f.severity) qs.set('severity', f.severity);
    if (f.source) qs.set('source', f.source);
    if (f.q) qs.set('q', f.q);
    try {
      const list = await api.get(`/api/findings?${qs}`);
      mount(tableHost, list.length ? h('div', { class: 'panel panel-flush' }, h('div', { class: 'table-wrap' }, h('table', { class: 'table' },
        h('thead', null, h('tr', null, h('th', null, 'Severity'), h('th', null, 'Finding'), h('th', { class: 'num' }, 'Reports'), h('th', null, 'Last seen'), h('th', null, 'Status'))),
        h('tbody', null, list.map((x) => h('tr', { class: 'clickable finding-row', tabindex: '0', onclick: () => ctx.navigate(`#/findings/${x.id}`), onkeydown: (e) => { if (e.key === 'Enter') ctx.navigate(`#/findings/${x.id}`); } },
          h('td', null, sevBadge(x.severity)),
          h('td', null, h('div', { class: 'cell-title' }, x.title),
            h('div', { class: 'cell-sub' }, [x.sourceName || 'metrics', x.category, x.investigated ? 'investigated' : null, x.chatCount ? `${x.chatCount} message${x.chatCount === 1 ? '' : 's'}` : null].filter(Boolean).join(', '))),
          h('td', { class: 'num' }, num(x.occurrences)),
          h('td', null, ago(x.lastSeen)),
          h('td', null, statusChip(x.status)))))))) : h('div', { class: 'panel' }, emptyState(
        f.status === 'open,acknowledged' && !f.q && !f.severity ? 'No open findings' : 'Nothing matches these filters',
        f.status === 'open,acknowledged' ? 'When the agent spots a problem it appears here, with evidence and a suggested next step.' : 'Try a different status or clear the search.')));
    } catch (e) { mount(tableHost, h('p', { class: 'result result-error' }, e.message)); }
  };
  statusSel.addEventListener('change', () => { f.status = statusSel.value; load(); });
  sevSel.addEventListener('change', () => { f.severity = sevSel.value; load(); });
  srcSel.addEventListener('change', () => { f.source = srcSel.value; load(); });
  search.addEventListener('input', debounce(() => { f.q = search.value.trim(); load(); }, 250));
  mount(root,
    h('div', { class: 'page-head' },
      h('div', null, h('h1', null, 'Findings'), h('p', { class: 'lede' }, 'Problems the agent reported. Each one is merged with later reports of the same issue.')),
      h('div', { class: 'tools' }, button('Clear resolved', async () => {
        if (!await confirmDialog('Clear resolved findings?', 'Resolved findings are removed permanently. Open, acknowledged and muted findings stay.', { confirm: 'Clear resolved' })) return;
        const r = await api.post('/api/findings/clear', { status: 'resolved' });
        toast(`Removed ${r.removed} resolved finding${r.removed === 1 ? '' : 's'}`, 'ok');
        load();
      }, { kind: 'ghost', icon: 'trash' }))),
    h('div', { class: 'filters' }, statusSel, sevSel, srcSel, search),
    tableHost);
  await load();
  ctx.on('finding', debounce(load, 500));
}

async function renderDetail(root, id, ctx) {
  let f;
  const draw = async () => {
    try { f = await api.get(`/api/findings/${encodeURIComponent(id)}`); } catch (e) {
      mount(root, h('div', { class: 'panel' }, emptyState('Finding not found', e.message, h('a', { class: 'btn btn-sm', href: '#/findings' }, 'Back to findings'))));
      return;
    }
    const busy = (S.status?.investigating || []).includes(f.id) || f.investigation?.status === 'running';
    const setStatus = (st, note) => api.post(`/api/findings/${f.id}/status`, { status: st, note }).then(draw);
    const actionsRow = h('div', { class: 'row' },
      f.status !== 'acknowledged' && f.status !== 'resolved' ? button('Acknowledge', () => setStatus('acknowledged'), { small: true }) : null,
      f.status !== 'resolved' ? button('Resolve', () => setStatus('resolved'), { small: true, icon: 'check' }) : button('Reopen', () => setStatus('open'), { small: true }),
      f.status !== 'muted' ? button('Mute', () => setStatus('muted'), { small: true, title: 'Keep tracking it but stop alerting' }) : button('Unmute', () => setStatus('open'), { small: true }),
      button(busy ? 'Investigating…' : f.investigation ? 'Investigate again' : 'Investigate', async () => {
        await api.post(`/api/findings/${f.id}/investigate`);
        toast('Investigation started. Results appear on this page.', 'info');
        setTimeout(draw, 400);
      }, { small: true, icon: 'search', disabled: busy }),
      button('Mark as expected', () => expectedDialog(f, draw), { small: true }),
      button(null, async () => {
        if (!await confirmDialog('Delete this finding?', 'It is removed permanently. If the problem happens again the agent reports it as new.', { confirm: 'Delete' })) return;
        await api.del(`/api/findings/${f.id}`);
        ctx.navigate('#/findings');
      }, { small: true, kind: 'ghost', icon: 'trash', title: 'Delete finding' }));

    const inv = f.investigation;
    const related = [];
    try { (await api.get('/api/actions')).filter((a) => a.findingId === f.id).forEach((a) => related.push(a)); } catch { /* optional */ }

    const chatList = h('div', { class: 'chat' }, (f.chat || []).map((m) => h('div', { class: `msg msg-${m.role}` },
      m.role === 'assistant' ? richText(m.text) : h('div', { style: { whiteSpace: 'pre-wrap' } }, m.text),
      h('div', { class: 'msg-meta' }, `${m.role === 'user' ? 'You' : m.role === 'error' ? 'Error' : m.provider || 'Agent'}, ${clock(m.t)}`))));
    const ask = h('textarea', { class: 'input textarea', rows: 2, placeholder: 'Ask a follow-up, e.g. "Which hosts are affected?" or "What command would confirm this?"', 'aria-label': 'Question about this finding' });
    const sendQ = async () => {
      const q = ask.value.trim();
      if (!q) return;
      chatList.appendChild(h('div', { class: 'msg msg-user' }, h('div', { style: { whiteSpace: 'pre-wrap' } }, q), h('div', { class: 'msg-meta' }, 'You, sending…')));
      ask.value = '';
      try { await api.post(`/api/findings/${f.id}/chat`, { message: q }); } catch (e) { toast(e.message, 'error'); }
      await draw();
    };
    ask.addEventListener('keydown', (e) => { if (e.key === 'Enter' && (e.ctrlKey || e.metaKey)) { e.preventDefault(); sendQ(); } });

    mount(root,
      h('p', { style: { margin: '0 0 8px' } }, h('a', { href: '#/findings' }, 'Findings')),
      h('div', { class: 'detail-head' }, sevBadge(f.severity), h('h1', null, f.title), statusChip(f.status)),
      actionsRow,
      h('div', { class: 'split', style: { marginTop: '16px', gridTemplateColumns: 'minmax(0,1.6fr) minmax(0,1fr)' } },
        h('div', null,
          h('div', { class: 'panel' },
            h('div', { class: 'section-label' }, 'What is happening'),
            h('p', { class: 'prose' }, f.explanation || '—'),
            f.latestNote && f.latestNote !== f.explanation ? [h('div', { class: 'section-label' }, 'Latest report'), h('p', { class: 'prose' }, f.latestNote)] : null,
            f.likelyCause ? [h('div', { class: 'section-label' }, 'Likely cause'), h('p', { class: 'prose' }, f.likelyCause)] : null,
            f.suggestedAction ? [h('div', { class: 'section-label' }, 'Suggested next step'), h('p', { class: 'prose' }, f.suggestedAction)] : null,
            f.evidence?.length ? [h('div', { class: 'section-label' }, 'Evidence'), h('ul', { class: 'evidence' }, f.evidence.map((e) => h('li', null, e)))] : null),
          inv ? h('div', { class: 'panel' },
            h('div', { class: 'panel-head' }, h('h2', null, 'Investigation'),
              h('div', { class: 'tools' }, h('span', { class: `chip ${inv.status === 'done' ? 'chip-ok' : inv.status === 'failed' ? 'chip-bad' : 'chip-accent'}` }, inv.status === 'running' ? 'Running' : cap(inv.status)),
                h('span', { class: 'subtle' }, `${inv.provider || ''}${inv.finishedAt ? `, ${clock(inv.finishedAt)}` : ''}`))),
            inv.status === 'failed' ? h('p', { class: 'result result-error' }, inv.error) : null,
            inv.conclusion ? [h('div', { class: 'section-label' }, 'Conclusion'), h('p', { class: 'prose' }, inv.conclusion)] : null,
            inv.rootCause ? [h('div', { class: 'section-label' }, 'Root cause'), h('p', { class: 'prose' }, inv.rootCause)] : null,
            inv.evidence?.length ? [h('div', { class: 'section-label' }, 'Evidence found'), h('ul', { class: 'evidence' }, inv.evidence.map((e) => h('li', null, e)))] : null,
            inv.steps?.length ? [h('div', { class: 'section-label' }, `Steps taken (${inv.steps.length})`),
              h('ol', { class: 'steps' }, inv.steps.map((s) => h('li', null,
                h('div', null, h('span', { class: 'step-tool' }, s.tool), s.args ? h('code', { style: { marginLeft: '8px' } }, JSON.stringify(s.args)) : null),
                s.why ? h('div', { class: 'subtle', style: { fontSize: '13px' } }, s.why) : null,
                h('details', { class: 'more' }, h('summary', null, 'Result'), h('pre', { class: 'code' }, s.result)))))] : null) : null,
          related.length ? h('div', { class: 'panel' }, h('div', { class: 'panel-head' }, h('h2', null, 'Actions for this finding'), h('div', { class: 'tools' }, h('a', { href: '#/actions' }, 'All actions'))),
            h('ul', { class: 'feed' }, related.map((a) => h('li', { class: 'feed-item' }, h('span', { class: 'feed-time' }, clock(a.createdAt)),
              h('div', null, h('code', null, a.type === 'run_command' ? a.command : `write ${a.path}`), h('div', { class: 'feed-meta' }, h('span', null, cap(a.status)), a.result?.exitCode != null ? h('span', null, `exit ${a.result.exitCode}`) : null)))))) : null,
          h('div', { class: 'panel' },
            h('div', { class: 'panel-head' }, h('h2', null, 'Ask about this finding'), h('p', null, `Answered by ${S.status?.provider?.label || 'the agent'} using the evidence above.`)),
            chatList,
            h('div', { class: 'row', style: { alignItems: 'flex-end', flexWrap: 'nowrap' } }, ask, button('Ask', sendQ, { kind: 'primary', icon: 'chat' })),
            h('div', { class: 'hint' }, 'Ctrl+Enter sends.'))),
        h('div', null,
          h('div', { class: 'panel' },
            h('dl', { class: 'kv' },
              h('dt', null, 'Source'), h('dd', null, f.sourceId ? h('a', { href: `#/sources/${f.sourceId}` }, f.sourceName) : (f.sourceName || '—')),
              h('dt', null, 'Category'), h('dd', null, cap(f.category)),
              h('dt', null, 'Reports'), h('dd', null, num(f.occurrences)),
              h('dt', null, 'First seen'), h('dd', null, `${clock(f.firstSeen)} (${ago(f.firstSeen)})`),
              h('dt', null, 'Last seen'), h('dd', null, `${clock(f.lastSeen)} (${ago(f.lastSeen)})`),
              f.confidence != null ? [h('dt', null, 'Confidence'), h('dd', null, `${Math.round(f.confidence * 100)}%`)] : null,
              h('dt', null, 'Reported by'), h('dd', null, f.origin === 'threshold' ? 'Metric threshold' : [f.provider ? S.providers.find((p) => p.id === f.provider)?.label || f.provider : 'Agent', f.model ? `, ${f.model}` : '']),
              f.fingerprints?.length ? [h('dt', null, 'Patterns'), h('dd', null, h('code', null, f.fingerprints.join(', ')))] : null)),
          h('div', { class: 'panel' }, h('div', { class: 'panel-head' }, h('h2', null, 'History')),
            h('ul', { class: 'feed' }, (f.history || []).slice().reverse().map((x) => h('li', { class: 'feed-item' }, h('span', { class: 'feed-time' }, clock(x.t)), h('div', null, x.text))))))));
  };
  await draw();
  ctx.on('finding', debounce((e) => { if (!e || !e.finding || e.finding.id === id) draw(); }, 500));
  ctx.on('status', debounce(() => {
    const running = (S.status?.investigating || []).includes(id);
    if (f && running !== (f.investigation?.status === 'running')) draw();
  }, 800));
}

function expectedDialog(f, after) {
  const st = { type: 'ignore', note: '', scope: 'source', pattern: '' };
  const body = h('div', { class: 'stack' },
    h('p', null, 'Teach the agent that this is normal. A rule is added to Knowledge, built from the log pattern behind this finding.'),
    field('What should happen next time', segmented(st, 'type', [
      { value: 'ignore', label: 'Stop reporting it' },
      { value: 'tip', label: 'Keep it, with my note' },
    ], { label: 'Rule type' }), 'Stop reporting adds an ignore rule and mutes this finding. Keeping it adds a tip the agent reads whenever the pattern shows up.'),
    field('Why it is expected', (() => { const t = h('textarea', { class: 'input textarea', rows: 3, placeholder: 'e.g. Nightly backup restarts the service at 02:00; these errors stop within five minutes.' }); t.addEventListener('input', () => { st.note = t.value; }); return t; })()),
    f.sourceId ? field('Applies to', segmented(st, 'scope', [{ value: 'source', label: `Only ${f.sourceName}` }, { value: 'global', label: 'All sources' }], { label: 'Scope' })) : null,
    h('details', { class: 'more' }, h('summary', null, 'Use my own pattern instead'),
      field('Text to match', (() => { const i = h('input', { class: 'input mono', placeholder: 'Leave blank to use the pattern the agent saw' }); i.addEventListener('input', () => { st.pattern = i.value; }); return i; })(),
        'Plain text, matched anywhere in the line.')));
  modal({
    title: 'Mark as expected',
    body,
    actions: [
      { label: 'Cancel' },
      { label: 'Add rule', kind: 'primary', onClick: async () => {
        try {
          const r = await api.post(`/api/findings/${f.id}/expected`, { type: st.type, note: st.note, scope: st.scope, pattern: st.pattern || undefined });
          toast(`${r.rules.length} rule${r.rules.length === 1 ? '' : 's'} added to Knowledge`, 'ok', { action: { label: 'View', fn: () => { location.hash = '#/knowledge'; } } });
          after();
          return true;
        } catch (e) { toast(e.message, 'error'); return false; }
      } },
    ],
  });
}
