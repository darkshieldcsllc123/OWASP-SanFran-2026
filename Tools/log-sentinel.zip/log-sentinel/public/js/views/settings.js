import { h, mount, button, input, select, checkbox, listInput, field, cap, num, clock, ago, toast, icon, copyText, modal, confirmDialog, resultLine, segmented } from '../ui.js';
import { api } from '../api.js';
import { S, sectionEditor, localPref } from '../app.js';

const TABS = [['access', 'Access'], ['server', 'Server'], ['data', 'Data'], ['backup', 'Backup'], ['appearance', 'Appearance'], ['about', 'About']];

export default {
  async render(root, params, ctx) {
    let tab = TABS.some((t) => t[0] === params[0]) ? params[0] : 'access';
    const editors = {
      access: sectionEditor(ctx, 'access', { label: 'Access settings' }),
      server: sectionEditor(ctx, 'server', { label: 'Server settings' }),
      data: sectionEditor(ctx, 'retention', { label: 'Data settings' }),
    };
    const tabsEl = h('div', { class: 'tabs', role: 'tablist' });
    const body = h('div');
    const drawTabs = () => mount(tabsEl, TABS.map(([id, label]) => h('button', {
      class: 'tab', role: 'tab', 'aria-selected': tab === id ? 'true' : 'false',
      onclick: () => { tab = id; history.replaceState(null, '', `#/settings/${id}`); drawTabs(); draw(); },
    }, label)));
    const draw = () => mount(body, ({ access, server, data, backup, appearance, about })[tab](editors, ctx));
    mount(root, h('div', { class: 'page-head' }, h('div', null, h('h1', null, 'Settings'), h('p', { class: 'lede' }, 'Who can reach Log Sentinel, how it reads files, and how long it keeps history.'))), tabsEl, body);
    drawTabs();
    draw();
  },
};

async function applyAndRestart(ed) {
  if (ed && ed.dirty()) await ed.save();
  const a = S.config.access;
  const remote = !['127.0.0.1', 'localhost', '[::1]', '::1'].includes(location.hostname);
  if (a.mode === 'local' && remote) {
    const ok = await confirmDialog('Switch to this computer only?', 'You are connected from another device. After the switch, Log Sentinel can only be opened on the computer it runs on, so this page will stop responding.', { confirm: 'Switch anyway' });
    if (!ok) return;
  }
  const r = await api.post('/api/system/apply-access');
  const host = r.mode === 'local' ? '127.0.0.1' : location.hostname;
  const target = `${r.https ? 'https' : 'http'}://${host.includes(':') && !host.startsWith('[') ? `[${host}]` : host}:${r.port}/#/settings/access`;
  modal({
    title: 'Restarting the listener',
    body: h('div', null, h('p', null, 'Log Sentinel is reopening its network listener with the new settings. This page moves to the new address in a moment.'),
      h('p', null, 'If it does not load, open ', h('a', { href: target }, target), '. If the port was busy, the server console shows the one it picked.')),
    actions: [{ label: 'Open now', kind: 'primary', onClick: () => { location.href = target; } }],
  });
  setTimeout(() => {
    if (location.href.split('#')[0] === target.split('#')[0]) location.reload(); else location.href = target;
  }, 1800);
}

function access({ access: ed }) {
  const d = ed.draft;
  const choice = h('div', { class: 'access-choice', role: 'radiogroup', 'aria-label': 'Who can open Log Sentinel' });
  const detail = h('div');
  const opts = [
    { value: 'local', name: 'This computer only', desc: 'Listens on 127.0.0.1. Nothing else on the network can reach it. The simplest and safest setup.' },
    { value: 'network', name: 'Other devices on my network', desc: 'Listens on the network so you can watch a server from your desktop or phone. An access token is always required.' },
  ];
  opts.forEach((o) => {
    const id = `acc-${o.value}`;
    const inp = h('input', { type: 'radio', name: 'access-mode', id, value: o.value, checked: d.mode === o.value });
    inp.addEventListener('change', () => { d.mode = o.value; drawDetail(); ed.check(); });
    choice.appendChild(h('div', { class: 'aut-opt' }, inp, h('label', { for: id }, h('span', { class: 'aut-name' }, o.name), h('span', { class: 'aut-desc' }, o.desc))));
  });

  const tokenBox = h('div', { class: 'token-box' });
  const drawToken = (t) => mount(tokenBox,
    h('code', null, t || '••••••••••••••••'),
    t ? button('Copy', () => copyText(t), { small: true, icon: 'copy' }) : button('Show', async () => { const r = await api.get('/api/system/token'); drawToken(r.token); }, { small: true, icon: 'eye' }),
    button('Make a new token', async () => {
      if (!await confirmDialog('Replace the access token?', 'Every other browser signed in with the old token is signed out. This browser stays signed in.', { confirm: 'Replace token' })) return;
      const r = await api.post('/api/system/token/rotate');
      drawToken(r.token);
      toast('New token created', 'ok');
    }, { small: true, kind: 'ghost' }));

  function drawDetail() {
    const sys = S.system;
    const lan = sys.lan || [];
    const firewall = sys.platform === 'win32' ? 'Windows may ask to allow Node.js through the firewall the first time. Allow it on private networks only.'
      : sys.platform === 'darwin' ? 'macOS may ask whether node can accept incoming connections. Allow it.'
        : `If a firewall is active, open the port, for example: sudo ufw allow from 192.168.1.0/24 to any port ${S.system.port}`;
    const certRes = resultLine();
    mount(detail, d.mode === 'local'
      ? h('div', { class: 'panel' }, h('div', { class: 'panel-head' }, h('h2', null, 'This computer only')),
        checkbox(d, 'requireToken', 'Require the access token here too', { hint: 'Useful on a shared computer where other users could open the page.' }),
        d.requireToken || d.tokenSet ? h('div', { style: { marginTop: '10px' } }, field('Access token', tokenBox)) : null,
        h('details', { class: 'more' }, h('summary', null, 'Extra host names'),
          field('Accept these names in the address bar', listInput(d, 'allowedHosts', { rows: 2, placeholder: 'mybox.local' }), 'Only localhost and 127.0.0.1 are accepted by default, which blocks DNS-rebinding attacks from web pages.')))
      : h('div', { class: 'panel' }, h('div', { class: 'panel-head' }, h('h2', null, 'Other devices on my network')),
        h('div', { class: 'fields' },
          field('Listen on', select(d, 'bindAddress', [{ value: '0.0.0.0', label: 'All network interfaces' }, ...lan.map((a) => ({ value: a.address, label: `${a.address} (${a.iface}) only` }))]), 'Choose one address to stay off other networks, such as a VPN or a public interface.'),
          field('Access token', tokenBox, 'Anyone opening Log Sentinel from another device is asked for this. It is also printed in the server console at start-up.', { wide: true }),
          field('Only allow these addresses', listInput(d, 'allowedIps', { rows: 3, placeholder: '192.168.1.0/24\n10.0.0.15' }), 'Optional. One address or CIDR range per line. This computer is always allowed.', { wide: true })),
        h('div', { class: 'section-label' }, 'Encryption (HTTPS)'),
        h('p', { class: 'subtle' }, 'Without HTTPS the token and log excerpts travel unencrypted over the network. On a trusted home or office LAN that may be acceptable; anywhere else, turn it on.'),
        checkbox(d, 'https.enabled', 'Serve over HTTPS'),
        h('div', { class: 'fields', style: { marginTop: '10px' } },
          field('Certificate file (PEM)', input(d, 'https.certPath', { mono: true, placeholder: '/etc/ssl/certs/sentinel.pem' })),
          field('Private key file (PEM)', input(d, 'https.keyPath', { mono: true, placeholder: '/etc/ssl/private/sentinel.key' }))),
        sys.openssl ? h('div', { class: 'row', style: { marginTop: '10px' } }, button('Create a self-signed certificate', async () => {
          const r = await api.post('/api/system/generate-cert');
          d.https.certPath = r.certPath;
          d.https.keyPath = r.keyPath;
          d.https.enabled = true;
          drawDetail();
          ed.check();
          certRes.set('ok', 'Created. Browsers will warn that it is self-signed the first time; accept it once per device.');
        }, { small: true })) : h('p', { class: 'hint' }, 'OpenSSL was not found on this computer, so a certificate cannot be created here. Use one from your organisation or a tool such as mkcert.'),
        certRes,
        h('p', { class: 'hint' }, firewall)));
  }
  if (d.tokenSet) drawToken(null);
  else mount(tokenBox, h('span', { class: 'subtle' }, 'Created when you apply these settings, then shown here.'));
  drawDetail();
  return h('div', null,
    h('div', { class: 'panel' }, h('div', { class: 'panel-head' }, h('h2', null, 'Open Log Sentinel at')),
      h('ul', { class: 'url-list' }, (S.system.urls || []).map((u) => h('li', null, h('span', { class: 'subtle', style: { minWidth: '150px' } }, u.label), h('code', null, u.url), button(null, () => copyText(u.url), { small: true, kind: 'ghost', icon: 'copy', title: 'Copy address' }))))),
    h('h2', { style: { margin: '20px 0 10px' } }, 'Who can open it'),
    choice, h('div', { style: { marginTop: '16px' } }, detail),
    h('div', { class: 'row' }, button('Apply and restart the listener', () => applyAndRestart(ed), { kind: 'primary', icon: 'refresh' }),
      h('span', { class: 'subtle' }, 'Saves these settings and reopens the listener in a second. The agent keeps running.')),
    ed.bar);
}

function server({ server: ed }) {
  const d = ed.draft;
  return h('div', null,
    h('div', { class: 'panel' }, h('div', { class: 'panel-head' }, h('h2', null, 'Listener')),
      h('div', { class: 'fields' },
        field('Preferred port', input(d, 'port', { type: 'number', min: 1, max: 65535 }), `Currently ${S.system.port}. If it is taken, the next free port is used. Command-line --port wins over this.`),
        field('Public address for links', input(d, 'publicUrl', { mono: true, placeholder: `http://${S.system.hostname}:${S.system.port}` }), 'Used in Slack, Discord and Teams messages so the alert links back to the finding.'),
        h('div', { class: 'field' }, checkbox(d, 'openBrowser', 'Open a browser when the server starts', { hint: 'Skipped automatically on Linux servers without a desktop.' }))),
      h('div', { class: 'row', style: { marginTop: '12px' } }, button('Apply and restart the listener', () => applyAndRestart(ed), { icon: 'refresh' }))),
    h('div', { class: 'panel' }, h('div', { class: 'panel-head' }, h('h2', null, 'Reading files')),
      h('div', { class: 'fields' },
        field('Check for new lines every (seconds)', input(d, 'pollIntervalSec', { type: 'number', min: 0.5, step: 0.5 }), 'Polling works the same on every OS and on network shares.'),
        field('Look for new files every (seconds)', input(d, 'rescanSec', { type: 'number', min: 2 }), 'Picks up rotated files and new files matching a pattern.'),
        field('Max read per file per check (KB)', input(d, 'maxReadKbPerPoll', { type: 'number', min: 64 })),
        field('Max backlog per file (MB)', input(d, 'maxBacklogMb', { type: 'number', min: 1 }), 'If a file grows faster than this between checks, the oldest part is skipped and noted in the activity log.'))),
    ed.bar);
}

function data({ data: ed }) {
  const d = ed.draft;
  return h('div', null,
    h('div', { class: 'panel' }, h('div', { class: 'panel-head' }, h('h2', null, 'History')),
      h('p', { class: 'subtle' }, 'Everything is stored as JSON files in ', h('code', null, S.system.dataDir), '. Metric storage is set on the Metrics page.'),
      h('div', { class: 'fields' },
        field('Keep resolved findings for (days)', input(d, 'findingsDays', { type: 'number', min: 1 })),
        field('Most findings kept', input(d, 'maxFindings', { type: 'number', min: 100 })),
        field('Activity entries kept', input(d, 'activityItems', { type: 'number', min: 50 }), 'The full prompt and reply are kept for the newest 60.'),
        field('Actions kept', input(d, 'actionsKept', { type: 'number', min: 50 })))),
    ed.bar);
}

function backup() {
  const res = resultLine();
  const file = h('input', { type: 'file', accept: '.json,application/json', class: 'input' });
  return h('div', null,
    h('div', { class: 'panel' }, h('div', { class: 'panel-head' }, h('h2', null, 'Export settings')),
      h('p', null, 'Download connections, sources, knowledge, metrics, alerts and agent settings as one JSON file.'),
      h('div', { class: 'row' },
        h('a', { class: 'btn btn-primary', href: '/api/config/export?secrets=0', download: 'log-sentinel-config.json' }, 'Export without secrets'),
        button('Export with keys and tokens', async () => {
          // Fetched with the app's request header (a plain link cannot export secrets), then saved as a file.
          const data = await api.get('/api/config/export?secrets=1');
          const url = URL.createObjectURL(new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' }));
          const a = h('a', { href: url, download: 'log-sentinel-config-with-secrets.json' });
          document.body.appendChild(a);
          a.click();
          a.remove();
          setTimeout(() => URL.revokeObjectURL(url), 2000);
        })),
      h('p', { class: 'hint' }, 'The version with secrets contains API keys, webhook URLs and the access token in plain text. Store it like a password.')),
    h('div', { class: 'panel' }, h('div', { class: 'panel-head' }, h('h2', null, 'Import settings')),
      h('p', null, 'Replaces each section found in the file. Secrets missing from the file keep their current values.'),
      h('div', { class: 'row' }, file, button('Import', async () => {
        const f = file.files[0];
        if (!f) { res.set('error', 'Choose a file first.'); return; }
        let obj;
        try { obj = JSON.parse(await f.text()); } catch { res.set('error', 'That file is not valid JSON.'); return; }
        if (!await confirmDialog('Import these settings?', 'Current settings in the sections found in the file are replaced.', { confirm: 'Import', kind: 'primary' })) return;
        await api.post('/api/config/import', obj);
        res.set('ok', 'Imported. Reloading…');
        setTimeout(() => location.reload(), 900);
      }, { kind: 'primary' })), res));
}

function appearance() {
  const st = { theme: localPref('theme') || 'system' };
  return h('div', { class: 'panel' }, h('div', { class: 'panel-head' }, h('h2', null, 'Theme')),
    h('p', { class: 'subtle' }, 'Saved in this browser only.'),
    segmented(st, 'theme', [{ value: 'system', label: 'Match the system' }, { value: 'light', label: 'Light' }, { value: 'dark', label: 'Dark' }], {
      label: 'Theme',
      onChange: (v) => {
        localPref('theme', v);
        if (v === 'system') delete document.documentElement.dataset.theme; else document.documentElement.dataset.theme = v;
      },
    }));
}

function about() {
  const s = S.system;
  return h('div', { class: 'panel' }, h('div', { class: 'panel-head' }, h('h2', null, `Log Sentinel ${s.version}`)),
    h('dl', { class: 'kv' },
      h('dt', null, 'Computer'), h('dd', null, s.hostname),
      h('dt', null, 'System'), h('dd', null, `${s.os} (${s.arch})`),
      h('dt', null, 'Node.js'), h('dd', null, s.node),
      h('dt', null, 'Listening on'), h('dd', null, `${s.host}:${s.port}${s.https ? ', HTTPS' : ''}`),
      h('dt', null, 'Data folder'), h('dd', null, h('code', null, s.dataDir)),
      h('dt', null, 'Commands run with'), h('dd', null, s.shell),
      h('dt', null, 'Process'), h('dd', null, `pid ${s.pid}, started ${clock(s.startedAt)} (${ago(s.startedAt)})`)),
    h('p', { class: 'hint', style: { marginTop: '12px' } }, 'No external packages. Stop it with Ctrl+C in its console; state is saved on exit.'));
}
