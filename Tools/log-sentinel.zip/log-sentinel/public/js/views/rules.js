// Shared editor for knowledge rules (global on Knowledge, per-source on a source page).
import { h, mount, button, icon, LEVELS, cap } from '../ui.js';

export const RULE_TYPES = [
  { value: 'ignore', label: 'Ignore', help: 'Drop matching lines before the agent sees them (known noise).' },
  { value: 'always', label: 'Always report', help: 'Send matching lines to the agent even below the reporting level.' },
  { value: 'severity', label: 'Set level', help: 'Treat matching lines as a different level (for example, raise "disk quota" to critical).' },
  { value: 'tip', label: 'Tip', help: 'Attach your note to the prompt whenever matching lines appear.' },
];

let seq = 0;
const newId = () => `r_${Date.now().toString(36)}${(seq++).toString(36)}`;

/**
 * rules: array (mutated in place). opts.sources: [{id,name}] to offer a scope column.
 * opts.onChange: called after any edit (lets the page re-check its save bar).
 */
export function rulesEditor(rules, { sources = null, onChange = () => {} } = {}) {
  const host = h('div', { class: 'rules' });
  const changed = () => { host.dispatchEvent(new Event('ls-change', { bubbles: true })); onChange(); };

  function row(r, i) {
    const typeSel = h('select', { class: 'input select', 'aria-label': 'Rule type' },
      RULE_TYPES.map((t) => h('option', { value: t.value, selected: r.type === t.value }, t.label)));
    const levelSel = h('select', { class: 'input select', 'aria-label': 'Level', hidden: r.type !== 'severity', style: { width: '110px' } },
      LEVELS.map((l) => h('option', { value: l, selected: r.level === l }, cap(l))));
    typeSel.addEventListener('change', () => { r.type = typeSel.value; levelSel.hidden = r.type !== 'severity'; typeSel.className = `input select type-${r.type}`; changed(); });
    typeSel.className = `input select type-${r.type}`;
    levelSel.addEventListener('change', () => { r.level = levelSel.value; changed(); });
    const pat = h('input', { class: 'input mono', value: r.pattern, placeholder: r.regex ? 'regular expression' : 'text to match', 'aria-label': 'Pattern', spellcheck: 'false' });
    pat.addEventListener('input', () => { r.pattern = pat.value; changed(); });
    const rx = h('input', { type: 'checkbox', checked: r.regex, 'aria-label': 'Pattern is a regular expression', title: 'Regular expression' });
    rx.addEventListener('change', () => { r.regex = rx.checked; pat.placeholder = r.regex ? 'regular expression' : 'text to match'; changed(); });
    const note = h('input', { class: 'input', value: r.note, placeholder: 'Why — the agent reads this', 'aria-label': 'Note' });
    note.addEventListener('input', () => { r.note = note.value; changed(); });
    const en = h('input', { type: 'checkbox', checked: r.enabled !== false, 'aria-label': 'Rule enabled', title: 'Enabled' });
    en.addEventListener('change', () => { r.enabled = en.checked; changed(); });
    let scope = null;
    if (sources) {
      scope = h('select', { class: 'input select', 'aria-label': 'Applies to' },
        h('option', { value: '' }, 'All sources'),
        sources.map((s) => h('option', { value: s.id, selected: (r.sources || [])[0] === s.id }, s.name)));
      scope.addEventListener('change', () => { r.sources = scope.value ? [scope.value] : []; changed(); });
    }
    return h('tr', { class: 'rule-row' },
      h('td', { style: { width: '36px' } }, en),
      h('td', { style: { width: '150px' } }, h('div', { class: 'row', style: { flexWrap: 'nowrap' } }, typeSel), levelSel),
      h('td', null, h('div', { class: 'row', style: { flexWrap: 'nowrap' } }, pat, h('label', { class: 'row subtle', style: { gap: '4px', flexWrap: 'nowrap', fontSize: '12px' } }, rx, 're'))),
      h('td', null, note),
      sources ? h('td', { style: { width: '160px' } }, scope) : null,
      h('td', { style: { width: '40px' } }, h('button', { class: 'icon-btn', type: 'button', 'aria-label': 'Delete rule', onclick: () => { rules.splice(i, 1); render(); changed(); } }, icon('trash', 16))));
  }

  function render() {
    mount(host,
      rules.length
        ? h('div', { class: 'table-wrap' }, h('table', { class: 'table' },
          h('thead', null, h('tr', null, h('th', null, 'On'), h('th', null, 'Type'), h('th', null, 'Matches'), h('th', null, 'Note for the agent'), sources ? h('th', null, 'Applies to') : null, h('th', null, ''))),
          h('tbody', null, rules.map(row))))
        : h('p', { class: 'subtle' }, 'No rules yet.'),
      h('div', { class: 'row', style: { marginTop: '10px' } },
        RULE_TYPES.map((t) => button(`Add ${t.label.toLowerCase()} rule`, () => {
          rules.push({ id: newId(), enabled: true, type: t.value, pattern: '', regex: false, caseSensitive: false, level: 'critical', note: '', sources: [] });
          render();
          changed();
          host.querySelector('tbody tr:last-child input.mono')?.focus();
        }, { small: true, icon: 'plus', title: t.help }))));
  }
  render();
  host.refresh = render;
  return host;
}

export function ruleTypeHelp() {
  return h('dl', { class: 'kv', style: { marginBottom: '12px' } },
    RULE_TYPES.map((t) => [h('dt', { class: `type-${t.value}` }, t.label), h('dd', null, t.help)]));
}
