import { h, mount, button, input, select, checkbox, field, cap, num, bytes, ago, toast, icon, resultLine, confirmDialog, richText } from '../ui.js';
import { api } from '../api.js';
import { S, sectionEditor } from '../app.js';

const open = new Set();
const modelCache = {};

const KEY_LINKS = {
  anthropic: ['Anthropic Console', 'https://console.anthropic.com/'],
  openai: ['OpenAI API keys', 'https://platform.openai.com/api-keys'],
  gemini: ['Google AI Studio', 'https://aistudio.google.com/apikey'],
};
const CLI_INFO = {
  claudeCode: {
    install: 'https://code.claude.com/docs/en/setup',
    signin: 'Uses Claude Code\'s own sign-in. Run claude once in a terminal on this computer and sign in, or set ANTHROPIC_API_KEY before starting Log Sentinel.',
    model: 'sonnet, opus, haiku, or a full model id',
    readonly: 'claude -p "…" --output-format json --permission-mode dontAsk --allowedTools Read,Grep,Glob --disallowedTools Bash,Edit,Write,…',
    full: 'claude -p "…" --output-format json --permission-mode bypassPermissions',
  },
  geminiCli: {
    install: 'https://github.com/google-gemini/gemini-cli',
    signin: 'Uses Gemini CLI\'s own sign-in. Run gemini once in a terminal and sign in, or set GEMINI_API_KEY before starting Log Sentinel.',
    model: 'pro, flash, or a model id',
    readonly: 'gemini -p "…" -o json --approval-mode plan   (prompt on stdin)',
    full: 'gemini -p "…" -o json --approval-mode yolo',
  },
  antigravity: {
    install: 'https://antigravity.google/cli',
    signin: 'Uses agy\'s own sign-in (your Google account). Run agy once in a terminal and sign in. On Linux servers without a desktop session, setting GEMINI_API_KEY avoids keyring prompts.',
    model: 'run "agy models" to list the slugs you can use',
    readonly: 'agy -p "…" --output-format json --mode plan',
    full: 'agy -p "…" --output-format json --dangerously-skip-permissions',
  },
  codex: {
    install: 'https://github.com/openai/codex',
    signin: 'Uses Codex\'s own sign-in. Run codex once in a terminal and sign in with ChatGPT, or set CODEX_API_KEY before starting Log Sentinel.',
    model: 'a model id available to your account',
    readonly: 'codex exec --json --skip-git-repo-check --ephemeral --sandbox read-only -C <log folder> -   (prompt on stdin)',
    full: 'codex exec --json … --dangerously-bypass-approvals-and-sandbox -',
  },
};
const OLLAMA_SUGGEST = ['qwen3:8b', 'qwen2.5:7b', 'llama3.1:8b', 'llama3.2', 'gemma3:12b', 'gemma3:4b', 'mistral', 'phi4', 'gpt-oss:20b', 'deepseek-r1:8b'];

export default {
  async render(root, params, ctx) {
    const ed = sectionEditor(ctx, 'providers', { label: 'Connections', onSaved: () => ctx.rerender() });
    const d = ed.draft;
    const active = S.config.agent.provider;
    if (!open.size) open.add(active);

    const useFor = async (id) => {
      if (ed.dirty()) await ed.save();
      const r = await api.put('/api/config/agent', { ...S.config.agent, provider: id });
      S.config.agent = r.section;
      toast(`The agent now uses ${S.providers.find((p) => p.id === id)?.label}`, 'ok');
      ctx.rerender();
    };

    function card(id, bodyFn, sub) {
      const p = S.providers.find((x) => x.id === id);
      const isActive = active === id;
      const body = h('div', { class: 'provider-body', hidden: !open.has(id) });
      const toggle = () => {
        if (open.has(id)) open.delete(id); else open.add(id);
        body.hidden = !open.has(id);
        head.setAttribute('aria-expanded', String(open.has(id)));
        if (!body.hidden && !body.firstChild) mount(body, bodyFn());
      };
      const head = h('div', { class: 'provider-head', role: 'button', tabindex: '0', 'aria-expanded': String(open.has(id)), onclick: (e) => { if (!e.target.closest('.btn')) toggle(); }, onkeydown: (e) => { if ((e.key === 'Enter' || e.key === ' ') && e.target === head) { e.preventDefault(); toggle(); } } },
        h('span', { class: 'chev', 'aria-hidden': 'true' }, icon('chev', 16)),
        h('h3', null, p.label),
        p.experimental ? h('span', { class: 'chip chip-warn' }, 'Experimental') : null,
        isActive ? h('span', { class: 'chip chip-accent' }, 'Used by the agent') : null,
        sub ? h('span', { class: 'subtle' }, sub) : null,
        h('div', { class: 'tools' }, isActive ? null : button('Use for the agent', () => useFor(id), { small: true })));
      if (open.has(id)) mount(body, bodyFn());
      return h('section', { class: ['provider', isActive && 'is-active'] }, head, body);
    }

    // ---- Ollama ------------------------------------------------------------------
    function ollamaBody() {
      const c = d.ollama;
      const res = resultLine();
      const listHost = h('div');
      const pullHost = h('div');
      const infoHost = h('div', { class: 'hint' });
      const modelSel = h('select', { class: 'input select', 'aria-label': 'Model' });
      const fillModels = () => {
        const models = modelCache.ollama || [];
        const ids = models.map((m) => m.id);
        if (c.model && !ids.includes(c.model)) ids.unshift(c.model);
        mount(modelSel, h('option', { value: '' }, ids.length ? 'Choose a model' : 'No models yet — pull one below'), ids.map((m) => h('option', { value: m, selected: m === c.model }, m)));
      };
      modelSel.addEventListener('change', () => { c.model = modelSel.value; showInfo(); ed.check(); });
      const showInfo = async () => {
        if (!c.model) { infoHost.textContent = ''; return; }
        try {
          const i = await api.post('/api/ollama/show', { model: c.model, config: c });
          infoHost.textContent = [i.params, i.quant, i.contextLength ? `supports up to ${num(i.contextLength)} tokens of context` : null, (i.capabilities || []).join(', ')].filter(Boolean).join(', ');
        } catch { infoHost.textContent = ''; }
      };
      const loadModels = async (quiet) => {
        try {
          const r = await api.post('/api/providers/ollama/models', { config: c });
          modelCache.ollama = r.models;
          fillModels();
          mount(listHost, r.models.length ? h('ul', { class: 'model-list' }, r.models.map((m) => h('li', null,
            h('span', { class: 'model-name', title: m.id }, m.id),
            h('span', { class: 'subtle' }, [m.params, m.quant].filter(Boolean).join(', ')),
            h('span', { class: 'subtle' }, bytes(m.size)),
            m.id === c.model ? h('span', { class: 'chip chip-accent' }, 'Selected') : button('Use', () => { c.model = m.id; fillModels(); showInfo(); ed.check(); loadModels(true); }, { small: true }),
            button(null, async () => {
              if (!await confirmDialog(`Delete ${m.id}?`, `This removes the model from the Ollama server and frees ${bytes(m.size)}.`, { confirm: 'Delete model' })) return;
              await api.post('/api/ollama/delete', { model: m.id, config: c });
              if (c.model === m.id) c.model = '';
              loadModels(true);
            }, { small: true, kind: 'ghost', icon: 'trash', title: `Delete ${m.id}` })))) : h('p', { class: 'subtle' }, 'No models installed on this Ollama server yet.'));
          if (!quiet) res.set('ok', `${r.models.length} model${r.models.length === 1 ? '' : 's'} installed`);
        } catch (e) { if (!quiet) res.set('error', e.message); mount(listHost); }
      };
      const pullName = h('input', { class: 'input mono', placeholder: 'e.g. qwen3:8b', list: 'ollama-suggest', 'aria-label': 'Model to pull' });
      const drawPulls = () => {
        const list = Object.values(S.pulls).sort((a, b) => b.startedAt - a.startedAt);
        mount(pullHost, list.map((p) => {
          const pct = p.total ? Math.round((p.completed / p.total) * 100) : p.state === 'done' ? 100 : 0;
          return h('div', { style: { marginTop: '10px' } },
            h('div', { class: 'row' }, h('code', null, p.model), h('span', { class: `subtle ${p.state === 'error' ? 'result-error' : ''}` }, p.state === 'pulling' ? `${p.status}${p.total ? `, ${bytes(p.completed)} of ${bytes(p.total)}` : ''}` : p.state === 'done' ? 'Downloaded' : p.state === 'cancelled' ? 'Cancelled' : p.status),
              h('span', { class: 'spacer' }), p.state === 'pulling' ? button('Cancel', () => api.post('/api/ollama/pull/cancel', { model: p.model }), { small: true, kind: 'ghost' }) : null),
            h('div', { class: 'progress', role: 'progressbar', 'aria-valuenow': pct, 'aria-valuemin': 0, 'aria-valuemax': 100, 'aria-label': `Pulling ${p.model}` }, h('div', { class: 'progress-fill', style: { width: `${pct}%` } })));
        }));
      };
      ctx.on('pull', (p) => { drawPulls(); if (p.state === 'done') loadModels(true); });
      drawPulls();
      fillModels();
      setTimeout(() => { loadModels(true); showInfo(); }, 0);
      return h('div', null,
        h('div', { class: 'fields', style: { marginTop: '14px' } },
          field('Server URL', input(c, 'baseUrl', { mono: true, placeholder: 'http://127.0.0.1:11434' }), 'Ollama on this computer or anywhere on your network.'),
          field('Model', modelSel, infoHost),
          field('Context window (num_ctx)', input(c, 'numCtx', { type: 'number', min: 2048, step: 1024 }), 'Ollama silently cuts prompts longer than this. Larger windows use more memory.'),
          field('Temperature', input(c, 'temperature', { type: 'number', min: 0, max: 2, step: 0.1 }), 'Low values keep the analysis consistent.')),
        h('details', { class: 'more' }, h('summary', null, 'More options'),
          h('div', { class: 'fields' },
            field('Keep the model loaded for', input(c, 'keepAlive', { placeholder: '10m' }), 'e.g. 10m, 1h, or -1 to keep it in memory.'),
            field('Thinking', select(c, 'think', [{ value: '', label: "Model's default" }, { value: 'off', label: 'Off (faster, fewer tokens)' }]),
              'For reasoning models such as qwen3 or deepseek-r1. With thinking on, part of the reply budget goes to thinking before the answer.'),
            field('Request timeout (seconds)', input(c, 'timeoutSec', { type: 'number', min: 10 })))),
        h('div', { class: 'row', style: { marginTop: '12px' } },
          button('Test connection', async () => {
            res.set('info', 'Connecting…');
            try { const r = await api.post('/api/providers/ollama/test', { config: c }); res.set('ok', `${r.message} (${r.latencyMs} ms)`); loadModels(true); } catch (e) { res.set('error', e.message); }
          }, { kind: 'primary' }),
          button('Refresh models', () => loadModels(false), { icon: 'refresh' }),
          testPromptButton('ollama', () => c, res)),
        res,
        h('div', { class: 'section-label' }, 'Installed models'), listHost,
        h('div', { class: 'section-label' }, 'Pull a model'),
        h('div', { class: 'input-group', style: { maxWidth: '520px' } }, pullName, button('Pull model', async () => {
          const m = pullName.value.trim();
          if (!m) { toast('Type a model name first, for example qwen3:8b', 'error'); return; }
          await api.post('/api/ollama/pull', { model: m, config: c });
          pullName.value = '';
        }, { kind: 'primary', icon: 'plus' })),
        h('datalist', { id: 'ollama-suggest' }, OLLAMA_SUGGEST.map((m) => h('option', { value: m }))),
        h('div', { class: 'hint' }, 'Downloads continue on the server if you leave this page. Names come from the ', h('a', { href: 'https://ollama.com/library', target: '_blank', rel: 'noopener noreferrer' }, 'Ollama library'), '.'),
        pullHost);
    }

    // ---- cloud APIs --------------------------------------------------------------
    function apiBody(id) {
      const c = d[id];
      const res = resultLine();
      const keyStatus = h('div', { class: 'hint' });
      const drawKeyStatus = () => {
        const saved = String(c.apiKey || '').startsWith('••');
        keyStatus.textContent = saved ? `A key is saved on the server (ending ${String(c.apiKey).slice(-4)}). Paste a new one to replace it.`
          : c.apiKey ? 'Not saved yet.'
            : c.apiKeyEnvSet ? `Using the ${c.apiKeyEnv} environment variable from the server.`
              : `No key yet. Paste one, or set ${c.apiKeyEnv || 'an environment variable'} before starting Log Sentinel.`;
      };
      drawKeyStatus();
      const key = input(c, 'apiKey', { type: 'password', mono: true, placeholder: 'Paste your API key', onChange: drawKeyStatus, autocomplete: 'new-password' });
      key.addEventListener('focus', () => key.select());
      const modelInput = input(c, 'model', { mono: true, list: `models-${id}`, placeholder: 'Load models or type an id' });
      const dl = h('datalist', { id: `models-${id}` });
      const fillDl = () => mount(dl, (modelCache[id] || []).map((m) => h('option', { value: m.id }, m.name || m.id)));
      fillDl();
      const loadModels = async () => {
        res.set('info', 'Loading models…');
        try {
          const r = await api.post(`/api/providers/${id}/models`, { config: c });
          modelCache[id] = r.models;
          fillDl();
          res.set('ok', `${r.models.length} models available. Click the Model field to pick one.`);
          if (!c.model && r.models[0]) { /* leave the choice to the user */ }
        } catch (e) { res.set('error', e.message); }
      };
      const [linkText, linkHref] = KEY_LINKS[id];
      return h('div', null,
        h('div', { class: 'fields', style: { marginTop: '14px' } },
          field('API key', h('div', null, key, keyStatus), h('span', null, 'Create one in ', h('a', { href: linkHref, target: '_blank', rel: 'noopener noreferrer' }, linkText), '. Keys are stored in data/config.json on the server and never sent back to the browser.')),
          field('Model', h('div', null, modelInput, dl), 'The model that reads your logs. Larger models catch subtler problems; smaller ones cost less per cycle.')),
        h('details', { class: 'more' }, h('summary', null, 'More options'),
          h('div', { class: 'fields' },
            field('Key from environment variable', input(c, 'apiKeyEnv', { mono: true }), 'Used when no key is pasted above.'),
            field('Base URL', input(c, 'baseUrl', { mono: true }), id === 'openai' ? 'Point this at any OpenAI-compatible server (LM Studio, vLLM, OpenRouter, Azure-style gateways).' : 'Change only for a proxy or gateway.'),
            field('Temperature', input(c, 'temperature', { type: 'number', step: 0.1, min: 0, max: 2, placeholder: 'provider default' }), 'Leave empty: some newer models only accept their default.'),
            field('Timeout (seconds)', input(c, 'timeoutSec', { type: 'number', min: 10 })),
            id === 'openai' ? field('Organization', input(c, 'organization', { mono: true, placeholder: 'optional' })) : null,
            id === 'openai' ? field('Token limit parameter', select(c, 'tokenParam', ['max_completion_tokens', 'max_tokens']), 'Older or compatible servers may need max_tokens. Retried automatically on errors.') : null,
            id === 'openai' ? h('div', { class: 'field' }, checkbox(c, 'jsonMode', 'Ask for JSON mode', { hint: 'Turned off automatically if the server rejects it.' })) : null,
            id === 'anthropic' ? field('API version header', input(c, 'apiVersion', { mono: true })) : null)),
        h('div', { class: 'row', style: { marginTop: '12px' } },
          button('Test connection', async () => {
            res.set('info', 'Checking the key…');
            try { const r = await api.post(`/api/providers/${id}/test`, { config: c }); res.set('ok', `${r.message} (${r.latencyMs} ms)`); } catch (e) { res.set('error', e.message); }
          }, { kind: 'primary' }),
          button('Load models', loadModels, { icon: 'refresh' }),
          testPromptButton(id, () => c, res)),
        res);
    }

    // ---- CLIs ----------------------------------------------------------------------
    function cliBody(id) {
      const c = d[id];
      const info = CLI_INFO[id];
      const p = S.providers.find((x) => x.id === id);
      const res = resultLine();
      const win = S.system.platform === 'win32';
      return h('div', null,
        h('p', { class: 'subtle', style: { marginTop: '12px' } }, info.signin),
        h('div', { class: 'fields', style: { marginTop: '10px' } },
          field('Command or full path', input(c, 'command', { mono: true, placeholder: p.defaultBin }), h('span', null, 'Found on PATH by default. ', h('a', { href: info.install, target: '_blank', rel: 'noopener noreferrer' }, 'Install instructions'), '.')),
          field('Model', input(c, 'model', { mono: true, placeholder: 'CLI default' }), `Optional: ${info.model}.`),
          field('Timeout (seconds)', input(c, 'timeoutSec', { type: 'number', min: 30 }), 'Coding agents can take a minute or more per run, longer when investigating.'),
          id === 'claudeCode' ? field('Max turns', input(c, 'maxTurns', { type: 'number', min: 1 }), 'Caps tool use in one run.') : null,
          id === 'antigravity' ? field('Send the prompt', select(c, 'promptVia', [{ value: 'auto', label: 'Automatically (argument when short)' }, { value: 'arg', label: 'As the -p argument' }, { value: 'stdin', label: 'On standard input' }])) : null,
          id === 'antigravity' ? h('div', { class: 'field' }, checkbox(c, 'ptyWrap', 'Run inside a pseudo-terminal', { hint: win ? 'Not available on Windows.' : 'Uses the system "script" command. Try this if agy prints nothing.' })) : null),
        h('details', { class: 'more' }, h('summary', null, 'How it is run, and advanced options'),
          h('p', null, 'Read-only, Propose and Allowlist levels:'), h('pre', { class: 'code' }, info.readonly),
          h('p', null, 'Full access:'), h('pre', { class: 'code' }, info.full),
          h('p', { class: 'subtle' }, 'Remediation actions the agent requests still go through the Actions queue and your autonomy rules. Only Full access lets the CLI change files on its own.'),
          h('div', { class: 'fields' },
            field('Extra arguments', input(c, 'extraArgs', { mono: true, placeholder: '--verbose' }), 'Appended to the command.', { wide: true }),
            field('Replace the arguments entirely', input(c, 'argsOverride', { mono: true, placeholder: id === 'codex' ? 'exec --json --skip-git-repo-check -C {cwd} -o {outfile} -m {model} -' : '-p {prompt} --output-format json --model {model}' }),
              'For CLI versions with different flags. Placeholders: {prompt} (otherwise sent on stdin), {model}, {cwd}, {outfile}, {dirs}. An empty {model} drops the flag before it.', { wide: true }))),
        h('div', { class: 'row', style: { marginTop: '12px' } },
          button('Detect', async () => {
            res.set('info', 'Looking for the command…');
            try {
              const r = await api.post(`/api/providers/${id}/detect`, { config: c });
              res.set(r.ok ? 'ok' : 'error', r.ok ? `${r.message}, at ${r.path}` : r.message);
            } catch (e) { res.set('error', e.message); }
          }, { kind: 'primary', icon: 'search' }),
          testPromptButton(id, () => c, res)),
        res);
    }

    const cliCallout = h('div', { class: 'callout' },
      h('p', null, h('strong', null, 'Gemini CLI or Antigravity CLI? '), 'Google is moving people from Gemini CLI to Antigravity CLI (agy). Since June 18, 2026, Google AI Pro and Ultra subscribers and free individual accounts are served by Antigravity CLI. Gemini CLI keeps working for paid Gemini API keys and Gemini Code Assist Standard or Enterprise licences, and still gets updates.'),
      h('p', null, 'Use whichever your Google account can sign in to. Gemini CLI has the more established headless mode and is the safer choice when you have it. Antigravity CLI is marked experimental here: its headless mode has had runs that hang or print nothing without a terminal. Most of that is fixed in recent versions, so keep agy updated. Log Sentinel stops any run that exceeds the timeout.'),
      h('p', null, 'If you only have a Gemini API key, the Gemini API connection under Cloud APIs is the simplest option.'));

    mount(root,
      h('div', { class: 'page-head' }, h('div', null, h('h1', null, 'Connections'),
        h('p', { class: 'lede' }, 'Set up the models Log Sentinel can use. All calls go through the local server, so keys stay on this machine and the browser never needs cross-origin access.'))),
      h('div', { class: 'provider-group-title' }, h('h2', null, 'On your own hardware'), h('p', null, 'Logs never leave your network.')),
      card('ollama', ollamaBody, d.ollama.model ? d.ollama.model : 'no model chosen'),
      h('div', { class: 'provider-group-title' }, h('h2', null, 'Cloud APIs'), h('p', null, 'Log excerpts are sent to the provider for analysis.')),
      ['anthropic', 'openai', 'gemini'].map((id) => card(id, () => apiBody(id), d[id].model || (d[id].apiKeySet || d[id].apiKeyEnvSet ? 'key set, no model chosen' : 'not set up'))),
      h('div', { class: 'provider-group-title' }, h('h2', null, 'Coding-agent CLIs'), h('p', null, 'Run headless on this computer with their own sign-in. During investigations they open the log files themselves.')),
      cliCallout,
      ['claudeCode', 'geminiCli', 'antigravity', 'codex'].map((id) => card(id, () => cliBody(id), d[id].model || 'default model')),
      ed.bar);
  },
};

function testPromptButton(id, getConfig, res) {
  return button('Test prompt', async () => {
    res.set('info', id === 'ollama' || ['anthropic', 'openai', 'gemini'].includes(id) ? 'Asking the model…' : 'Running the CLI (this can take a minute)…');
    try {
      const r = await api.post(`/api/providers/${id}/prompt`, { config: getConfig() });
      res.set('ok', `Replied in ${(r.durationMs / 1000).toFixed(1)} s${r.usage ? `, ${num(r.usage.input)} in / ${num(r.usage.output)} out tokens` : ''}: ${String(r.text).trim().slice(0, 400)}`);
    } catch (e) { res.set('error', e.message); }
  }, { icon: 'chat' });
}
