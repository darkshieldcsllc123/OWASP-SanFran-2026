import { h, mount, button, input, select, checkbox, textarea, listInput, field, cap, num, bytes, ago, clock, toast, icon, LEVELS, SEVERITIES, emptyState, debounce, segmented, resultLine } from '../ui.js';
import { api } from '../api.js';
import { S, sectionEditor } from '../app.js';
import { timeChart } from '../chart.js';

const AGGS = [
  { value: '', label: 'Default for this metric' }, { value: 'count', label: 'Count' }, { value: 'rate', label: 'Per minute' },
  { value: 'sum', label: 'Sum' }, { value: 'avg', label: 'Average' }, { value: 'p95', label: '95th percentile' },
  { value: 'max', label: 'Maximum' }, { value: 'min', label: 'Minimum' }, { value: 'last', label: 'Latest value' },
];
const RANGES = [{ value: 15, label: '15 min' }, { value: 60, label: '1 h' }, { value: 360, label: '6 h' }, { value: 1440, label: '24 h' }, { value: 2880, label: '48 h' }];
const SUGGESTED = [
  { title: 'Errors by source', query: { metric: 'log.lines', levels: ['error', 'critical'], groupBy: 'source', agg: 'count', rangeMin: 360 } },
  { title: 'Warnings by source', query: { metric: 'log.lines', levels: ['warn'], groupBy: 'source', agg: 'count', rangeMin: 360 } },
  { title: 'HTTP requests by status', query: { metric: 'http.requests', groupBy: 'status_class', agg: 'count', rangeMin: 360 } },
  { title: 'Response time, 95th percentile', query: { metric: 'http.response_time', groupBy: 'source', agg: 'p95', rangeMin: 360 } },
  { title: 'CPU', query: { metric: 'host.cpu_percent', groupBy: 'none', agg: 'avg', rangeMin: 360 } },
  { title: 'Memory used', query: { metric: 'host.mem_used_percent', groupBy: 'none', agg: 'avg', rangeMin: 360 } },
];
let seq = 0;
const nid = (p) => `${p}_${Date.now().toString(36)}${(seq++).toString(36)}`;

export default {
  async render(root, params, ctx) {
    const ed = sectionEditor(ctx, 'metrics', { label: 'Metrics settings' });
    const d = ed.draft;
    let catalog = [];
    let overview = {};
    const loadMeta = async () => {
      try { [catalog, overview] = await Promise.all([api.get('/api/metrics/catalog'), api.get('/api/metrics/overview')]); } catch (e) { toast(e.message, 'error'); }
    };
    await loadMeta();
    const TABS = [['explore', 'Explore'], ['dashboard', 'Dashboard'], ['definitions', 'From logs'], ['scrapers', 'Scrapers'], ['thresholds', 'Thresholds'], ['host', 'Host and storage']];
    let tab = params[0] && TABS.some((t) => t[0] === params[0]) ? params[0] : 'explore';
    const tabsEl = h('div', { class: 'tabs', role: 'tablist' });
    const body = h('div');
    const changed = () => { root.dispatchEvent(new Event('ls-change')); };

    const drawTabs = () => mount(tabsEl, TABS.map(([id, label]) => h('button', {
      class: 'tab', role: 'tab', 'aria-selected': tab === id ? 'true' : 'false',
      onclick: () => { tab = id; history.replaceState(null, '', `#/metrics/${id}`); drawTabs(); drawBody(); },
    }, label)));

    // ---------------------------------------------------------------- explore
    const q = { metric: ctx.query.get('metric') || 'log.lines', sources: [], levels: [], filter: '', rangeMin: 60, agg: '', groupBy: '*' };
    function explore() {
      const chartHost = h('div', { style: { minHeight: '320px' } });
      const filtersHost = h('div', { class: 'stack' });
      const metricSel = h('select', { class: 'input select', 'aria-label': 'Metric' });
      const fill = () => {
        mount(metricSel, catalog.length ? catalog.map((m) => h('option', { value: m.name, selected: m.name === q.metric }, `${m.name}  (${m.kind}${m.unit ? `, ${m.unit}` : ''})`))
          : h('option', { value: q.metric }, q.metric));
      };
      fill();
      metricSel.addEventListener('change', () => { q.metric = metricSel.value; q.sources = []; q.levels = []; q.groupBy = '*'; q.filter = ''; drawFilters(); run(); });
      const run = debounce(async () => {
        try {
          const r = await api.post('/api/metrics/query', { ...q, sources: q.sources.length ? q.sources : undefined, levels: q.levels.length ? q.levels : undefined });
          mount(chartHost, timeChart(r, { height: 300 }),
            h('p', { class: 'subtle', style: { marginTop: '6px' } }, `${r.totalSeries} series, ${r.agg} per ${r.step / 60000 >= 60 ? `${r.step / 3600000} h` : `${r.step / 60000} min`}${r.totalSeries > r.series.length ? `, showing the top ${r.series.length}` : ''}.`));
        } catch (e) { mount(chartHost, h('p', { class: 'result result-error' }, e.message)); }
      }, 150);
      function chips(values, selected, label) {
        return h('div', { class: 'row', role: 'group', 'aria-label': label }, values.map((v) => {
          const id = `c-${label}-${v}`.replace(/[^\w-]/g, '_');
          const inp = h('input', { type: 'checkbox', id, checked: selected.includes(v) });
          inp.addEventListener('change', () => { const i = selected.indexOf(v); if (inp.checked && i < 0) selected.push(v); if (!inp.checked && i >= 0) selected.splice(i, 1); run(); });
          return h('label', { class: 'chip', for: id, style: { cursor: 'pointer' } }, inp, v);
        }));
      }
      function drawFilters() {
        const m = catalog.find((x) => x.name === q.metric) || { labels: {} };
        const keys = Object.keys(m.labels);
        mount(filtersHost,
          h('div', { class: 'row' },
            segmented(q, 'rangeMin', RANGES, { label: 'Time range', onChange: run }),
            select(q, 'agg', AGGS, { onChange: run, width: 'auto' }),
            select(q, 'groupBy', [{ value: '*', label: 'Every series' }, { value: 'none', label: 'Total' }, ...keys.map((k) => ({ value: k, label: `By ${k}` }))], { onChange: run, width: 'auto' })),
          m.labels.source ? field('Sources', chips(m.labels.source, q.sources, 'sources')) : null,
          m.labels.level ? field('Levels', chips(LEVELS.filter((l) => m.labels.level.includes(l)), q.levels, 'levels')) : null,
          field('Label filter', input(q, 'filter', { mono: true, placeholder: keys.length ? `${keys[0]}=${m.labels[keys[0]][0] || 'value'}` : 'label=value, other~regex', onChange: debounce(run, 400) }),
            `Comma-separated. Use = and != for exact matches, ~ and !~ for regular expressions.${keys.length ? ` Labels here: ${keys.join(', ')}.` : ''}`));
      }
      drawFilters();
      run();
      return h('div', null,
        h('div', { class: 'panel' },
          h('div', { class: 'panel-head' }, h('div', { style: { minWidth: '280px', flex: 1 } }, metricSel),
            h('div', { class: 'tools' }, button('Add to dashboard', () => {
              const title = window.prompt('Name for this chart', q.metric);
              if (!title) return;
              d.panels.push({ id: nid('pa'), title, query: JSON.parse(JSON.stringify(q)) });
              changed();
              toast('Added. Save changes to keep it on the dashboard.', 'ok');
            }, { icon: 'plus' }))),
          filtersHost, h('hr', { class: 'rule' }), chartHost),
        catalog.length ? null : h('p', { class: 'subtle' }, 'No metrics recorded yet. Log metrics appear as soon as a source reads new lines; host metrics within 15 seconds.'));
    }

    // ---------------------------------------------------------------- dashboard
    function dashboard() {
      const grid = h('div', { class: 'grid-2' });
      const draw = async () => {
        if (!d.panels.length) {
          mount(grid, h('div', { class: 'panel', style: { gridColumn: '1 / -1' } }, emptyState('No charts on the dashboard', 'Add charts from Explore, or start with a useful set.',
            button('Add suggested charts', () => { SUGGESTED.forEach((s) => d.panels.push({ id: nid('pa'), title: s.title, query: s.query })); changed(); draw(); toast('Added. Save changes to keep them.', 'ok'); }, { kind: 'primary' }))));
          return;
        }
        const res = await api.post('/api/metrics/batch', { queries: d.panels.map((p) => p.query) });
        mount(grid, d.panels.map((p, i) => h('div', { class: 'panel' },
          h('div', { class: 'panel-head' }, h('h2', null, p.title),
            h('div', { class: 'tools' },
              h('a', { href: `#/metrics/explore?metric=${encodeURIComponent(p.query.metric)}`, class: 'linkish' }, 'Explore'),
              h('button', { class: 'icon-btn', 'aria-label': `Remove ${p.title}`, onclick: () => { d.panels.splice(i, 1); changed(); draw(); } }, icon('trash', 16)))),
          res[i]?.error ? h('p', { class: 'result result-error' }, res[i].error) : timeChart(res[i], { height: 200 }))));
      };
      draw();
      ctx.every(60000, () => { if (tab === 'dashboard') draw(); });
      return grid;
    }

    // ---------------------------------------------------------------- log-derived definitions
    function definitions() {
      const list = h('div');
      const draw = () => mount(list, d.definitions.length ? d.definitions.map((def, i) => {
        const res = resultLine();
        const sample = h('div');
        const valueFields = h('div', { class: 'fields', style: { marginTop: '14px' } });
        const drawValue = () => mount(valueFields, def.type === 'value' ? [
          field('Value from field', input(def, 'valueField', { mono: true, placeholder: 'request_time' }), 'A JSON or access-log field…'),
          field('…or value pattern', input(def, 'valueRegex', { mono: true, placeholder: 'took (?<value>\\d+)ms' }), 'First group, or a group named value.'),
          field('Multiply by', input(def, 'scale', { type: 'number', step: 'any', placeholder: '1' }), 'e.g. 1000 to turn seconds into ms'),
          field('Unit', input(def, 'unit', { placeholder: 'ms' })),
        ] : []);
        drawValue();
        return h('div', { class: 'panel' },
          h('div', { class: 'panel-head' }, h('h2', null, def.name || 'New metric'),
            h('div', { class: 'tools' }, checkbox(def, 'enabled', 'On'), h('button', { class: 'icon-btn', 'aria-label': 'Delete metric', onclick: () => { d.definitions.splice(i, 1); changed(); draw(); } }, icon('trash', 16)))),
          h('div', { class: 'fields' },
            field('Metric name', input(def, 'name', { mono: true, placeholder: 'payments.failures' })),
            field('Measure', select(def, 'type', [{ value: 'count', label: 'Count matching lines' }, { value: 'value', label: 'A number inside each line' }], { onChange: drawValue })),
            field('Lines that contain', input(def, 'match', { mono: true, placeholder: 'payment (failed|declined)' }), 'A regular expression. Leave empty to use every line.'),
            field('From source', select({ v: (def.sources || [])[0] || '' }, 'v', [{ value: '', label: 'All sources' }, ...S.config.sources.map((s) => ({ value: s.id, label: s.name }))], { onChange: (v) => { def.sources = v ? [v] : []; } })),
            field('Only at level', select(def, 'minLevel', [{ value: '', label: 'Any level' }, ...LEVELS.map((l) => ({ value: l, label: `${cap(l)} and above` }))])),
            field('Split by', input(def, 'groupBy', { mono: true, placeholder: 'status, path, or a named group' }), 'Optional. A field or named group; up to 50 values, the rest become "other".')),
          valueFields,
          h('div', { class: 'row', style: { marginTop: '12px' } }, button('Test on recent lines', async () => {
            res.set('info', 'Scanning…');
            const r = await api.post('/api/metrics/definitions/test', { definition: def });
            res.set(r.matched ? 'ok' : 'info', `${r.matched} of ${r.scanned} recent lines match.`);
            mount(sample, r.samples.length ? h('table', { class: 'table compact' }, h('thead', null, h('tr', null, h('th', null, 'Line'), def.type === 'value' ? h('th', { class: 'num' }, 'Value') : null, def.groupBy ? h('th', null, def.groupBy) : null)),
              h('tbody', null, r.samples.map((s) => h('tr', null, h('td', null, h('code', null, s.line)), def.type === 'value' ? h('td', { class: 'num' }, s.value ?? '—') : null, def.groupBy ? h('td', null, s.group ?? '—') : null)))) : null);
          }, { small: true, icon: 'search' })), res, sample);
      }) : h('div', { class: 'panel' }, emptyState('No custom log metrics', 'Every source already records lines per level, and web access logs record requests by status and response time. Add your own to count specific events or graph numbers inside your logs.')));
      draw();
      return h('div', null, h('p', { class: 'subtle' }, 'Turn log lines into numbers: count events (failed logins, payment errors) or extract values (durations, queue sizes).'),
        list, button('Add a log metric', () => { d.definitions.push({ id: nid('de'), enabled: true, name: '', type: 'count', match: '', sources: [], groupBy: '', valueField: '', valueRegex: '', unit: '' }); changed(); draw(); }, { icon: 'plus' }));
    }

    // ---------------------------------------------------------------- scrapers
    function scrapers() {
      const list = h('div');
      const status = new Map((overview.scrapers || []).map((s) => [s.id, s]));
      const draw = () => mount(list, d.scrapers.length ? d.scrapers.map((sc, i) => {
        const res = resultLine();
        const sample = h('div');
        const typeFields = h('div', { class: 'fields', style: { marginTop: '14px' } });
        const drawType = () => mount(typeFields,
          sc.type === 'prometheus' ? [
            field('Metrics URL', input(sc, 'url', { mono: true, placeholder: 'http://localhost:9100/metrics' }), null, { wide: true }),
            field('Only metrics matching', input(sc, 'include', { mono: true, placeholder: '^(node_load1|node_filesystem_avail_bytes)$' }), 'A regular expression on the metric name. Keeps storage small; up to 300 values per scrape.', { wide: true }),
            field('Request headers', textarea(sc, 'headers', { rows: 2, mono: true, placeholder: 'Authorization: Bearer …' }), 'One per line, or a JSON object. Stored on the server and masked here.', { wide: true }),
          ] : sc.type === 'json' ? [
            field('URL', input(sc, 'url', { mono: true, placeholder: 'http://localhost:8080/health' }), 'Or leave empty and use a file path.'),
            field('File path', input(sc, 'path', { mono: true, placeholder: '/var/run/myapp/stats.json' })),
            field('Values to read', textarea(sc, 'fields', { rows: 3, mono: true, placeholder: 'queue_depth = queue.depth\nworkers = pool.active' }), 'One per line: name = path (dots and [0] for arrays). Leave empty to read every number.', { wide: true }),
            field('Request headers', textarea(sc, 'headers', { rows: 2, mono: true }), null, { wide: true }),
          ] : sc.type === 'csv' ? [
            field('CSV file', input(sc, 'path', { mono: true, placeholder: 'C:\\perflogs\\counters.csv' }), 'The header row and the last row are read each time.', { wide: true }),
            field('Columns', textarea(sc, 'fields', { rows: 3, mono: true, placeholder: 'cpu = % Processor Time\nqueue = Disk Queue Length' }), 'name = column header. Leave empty to read every numeric column.', { wide: true }),
            field('Delimiter', input(sc, 'delimiter', { placeholder: ',', width: '80px' })),
          ] : [
            field('Command', input(sc, 'command', { mono: true, placeholder: S.system.platform === 'win32' ? 'powershell -NoProfile -Command "(Get-Counter \'\\Memory\\Available MBytes\').CounterSamples.CookedValue"' : "df -P / | awk 'NR==2{print $5+0}'" }),
              'Output can be a single number, "name value" lines, JSON, or Prometheus text. Runs on this server with your permissions.', { wide: true }),
          ]);
        drawType();
        const st = status.get(sc.id);
        return h('div', { class: 'panel' },
          h('div', { class: 'panel-head' }, h('h2', null, sc.name || 'New scraper'),
            st ? h('span', { class: `chip ${st.ok ? 'chip-ok' : st.error ? 'chip-bad' : ''}` }, st.ok ? `${st.count} values, ${ago(st.lastRun)}` : st.error ? 'Failing' : 'Not run yet') : null,
            h('div', { class: 'tools' }, checkbox(sc, 'enabled', 'On'), h('button', { class: 'icon-btn', 'aria-label': 'Delete scraper', onclick: () => { d.scrapers.splice(i, 1); changed(); draw(); } }, icon('trash', 16)))),
          st?.error ? h('p', { class: 'result result-error' }, st.error) : null,
          h('div', { class: 'fields' },
            field('Name', input(sc, 'name', { placeholder: 'node exporter' })),
            field('Type', select(sc, 'type', [{ value: 'prometheus', label: 'Prometheus endpoint' }, { value: 'json', label: 'JSON (URL or file)' }, { value: 'csv', label: 'CSV file' }, { value: 'command', label: 'Command output' }], { onChange: drawType })),
            field('Every (seconds)', input(sc, 'intervalSec', { type: 'number', min: 5 })),
            field('Name prefix', input(sc, 'prefix', { mono: true, placeholder: 'defaults to the name' }), 'Metric names start with this.')),
          typeFields,
          h('div', { class: 'row', style: { marginTop: '12px' } }, button('Test', async () => {
            res.set('info', 'Running…');
            try {
              const r = await api.post('/api/metrics/scrapers/test', { scraper: sc });
              res.set('ok', `Read ${r.count} value${r.count === 1 ? '' : 's'}.`);
              mount(sample, r.sample.length ? h('table', { class: 'table compact' }, h('tbody', null, r.sample.map((p) => h('tr', null, h('td', null, h('code', null, p.name)), h('td', null, Object.entries(p.labels || {}).map(([k, v]) => `${k}=${v}`).join(', ')), h('td', { class: 'num' }, num(p.value, 3)))))) : null);
            } catch (e) { res.set('error', e.message); mount(sample); }
          }, { small: true, icon: 'play' })), res, sample);
      }) : h('div', { class: 'panel' }, emptyState('No scrapers', 'Pull numbers from outside the logs: a Prometheus exporter, a JSON health endpoint, a CSV written by a performance tool, or any command that prints numbers.')));
      draw();
      return h('div', null, list, button('Add a scraper', () => { d.scrapers.push({ id: nid('sc'), enabled: true, name: '', type: 'prometheus', url: '', intervalSec: 60, prefix: '' }); changed(); draw(); }, { icon: 'plus' }));
    }

    // ---------------------------------------------------------------- thresholds
    function thresholds() {
      const list = h('div');
      const status = new Map((overview.thresholds || []).map((s) => [s.id, s]));
      const dl = h('datalist', { id: 'metric-names' }, catalog.map((m) => h('option', { value: m.name })));
      const draw = () => mount(list, d.thresholds.length ? d.thresholds.map((th, i) => {
        const st = status.get(th.id);
        return h('div', { class: 'panel' },
          h('div', { class: 'panel-head' }, h('h2', null, th.name || 'New threshold'),
            st && st.checkedAt ? h('span', { class: `chip ${st.breached ? 'chip-bad' : 'chip-ok'}` }, `${st.breached ? 'Breached' : 'OK'}: ${st.value == null ? 'no data' : num(st.value, 2)}`) : null,
            h('div', { class: 'tools' }, checkbox(th, 'enabled', 'On'), h('button', { class: 'icon-btn', 'aria-label': 'Delete threshold', onclick: () => { d.thresholds.splice(i, 1); changed(); draw(); } }, icon('trash', 16)))),
          h('div', { class: 'fields' },
            field('Name', input(th, 'name', { placeholder: 'API errors spike' })),
            field('Metric', input(th, 'metric', { mono: true, list: 'metric-names', placeholder: 'log.lines' })),
            field('Label filter', input(th, 'filter', { mono: true, placeholder: 'source=API server, level~error|critical' })),
            field('Measure', select(th, 'agg', AGGS.slice(1))),
            field('Over the last (minutes)', input(th, 'windowMin', { type: 'number', min: 1 })),
            field('Breached when', h('div', { class: 'inline-field' }, select(th, 'op', ['>', '>=', '<', '<='], { width: '80px' }), input(th, 'value', { type: 'number', step: 'any' }))),
            field('Severity', select(th, 'severity', SEVERITIES.slice(0, 4).map((s) => ({ value: s, label: cap(s) })))),
            field('Note for whoever is alerted', input(th, 'note', { placeholder: 'Check the payments dashboard first' }))),
          h('div', { style: { marginTop: '8px' } }, checkbox(th, 'autoResolve', 'Resolve the finding automatically when the value is back within the limit')));
      }) : h('div', { class: 'panel' }, emptyState('No thresholds', 'A threshold raises a finding and an alert when a metric crosses a limit, without waiting for the agent. Example: more than 50 errors in 5 minutes on one source.')));
      draw();
      return h('div', null, dl, list, button('Add a threshold', () => { d.thresholds.push({ id: nid('th'), enabled: true, name: '', metric: 'log.lines', filter: 'level~error|critical', agg: 'count', windowMin: 5, op: '>', value: 50, severity: 'high', autoResolve: true, note: '' }); changed(); draw(); }, { icon: 'plus' }));
    }

    // ---------------------------------------------------------------- host & storage
    function host() {
      const hs = overview.host || {};
      return h('div', null,
        h('div', { class: 'panel' }, h('div', { class: 'panel-head' }, h('h2', null, `${hs.hostname || 'This host'}`), h('p', null, hs.platform || '')),
          h('div', { class: 'stat-row' },
            hstat(hs.cpuPct != null ? `${Math.round(hs.cpuPct)}%` : '—', `CPU, ${hs.cores || '?'} cores`),
            hstat(`${Math.round(hs.memUsedPct || 0)}%`, `memory of ${bytes(hs.memTotal)}`),
            hs.load1 != null ? hstat(hs.load1.toFixed(2), 'load, 1 min') : null,
            (hs.disks || []).map((dk) => hstat(`${Math.round(dk.usedPct)}%`, `${dk.path}, ${bytes(dk.free)} free`)),
            hstat(bytes(hs.appRss), 'used by Log Sentinel'))),
        h('div', { class: 'panel' }, h('div', { class: 'panel-head' }, h('h2', null, 'Collection')),
          h('div', { class: 'fields' },
            h('div', { class: 'field' }, checkbox(d, 'host.enabled', 'Record CPU, memory and disk usage'), checkbox(d, 'builtIn.levels', 'Count log lines per source and level'), checkbox(d, 'builtIn.http', 'Record HTTP status and response time from access logs')),
            field('Host sample every (seconds)', input(d, 'host.intervalSec', { type: 'number', min: 5 })),
            field('Extra disks to watch', listInput(d, 'host.diskPaths', { rows: 2, placeholder: S.system.platform === 'win32' ? 'D:\\' : '/data' }), 'The folders of your log sources are always included.'))),
        h('div', { class: 'panel' }, h('div', { class: 'panel-head' }, h('h2', null, 'Anomaly detection'), h('p', null, 'Flags error and 4xx/5xx counts that jump far above their recent average. Anomalies are shown to the agent.')),
          h('div', { class: 'fields' },
            h('div', { class: 'field' }, checkbox(d, 'anomaly.enabled', 'Detect anomalies')),
            field('Sensitivity (standard deviations)', input(d, 'anomaly.sigma', { type: 'number', min: 1, step: 0.5 }), 'Lower finds more.'),
            field('Ignore counts below', input(d, 'anomaly.minValue', { type: 'number', min: 1 })),
            field('History needed (buckets)', input(d, 'anomaly.minBuckets', { type: 'number', min: 5 })))),
        h('div', { class: 'panel' }, h('div', { class: 'panel-head' }, h('h2', null, 'Storage')),
          h('div', { class: 'fields' },
            field('Bucket size (seconds)', input(d, 'bucketSec', { type: 'number', min: 10 }), 'Resolution of every series.'),
            field('Keep for (hours)', input(d, 'retentionHours', { type: 'number', min: 1 })))));
    }

    function drawBody() {
      const views = { explore, dashboard, definitions, scrapers, thresholds, host };
      mount(body, views[tab]());
    }

    mount(root,
      h('div', { class: 'page-head' }, h('div', null, h('h1', null, 'Metrics'), h('p', { class: 'lede' }, 'Numbers from your logs, this host and anything you scrape, with filters by source, level and label.')),
        h('div', { class: 'tools' }, button('Reload data', async () => { await loadMeta(); drawBody(); }, { icon: 'refresh', kind: 'ghost' }))),
      tabsEl, body, ed.bar);
    drawTabs();
    drawBody();
  },
};

function hstat(v, k) {
  return h('div', { class: 'stat' }, h('div', { class: 'stat-v' }, v), h('div', { class: 'stat-k' }, k));
}
