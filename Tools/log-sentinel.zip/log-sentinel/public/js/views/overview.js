import { h, mount, button, ago, clock, num, bytes, sevBadge, emptyState, debounce, cap, segmented } from '../ui.js';
import { api } from '../api.js';
import { S, startAgent, providerLabel, runCycleNow } from '../app.js';
import { timeChart } from '../chart.js';

export default {
  async render(root, params, ctx) {
    const lamps = h('div', { class: 'annunciator', role: 'group', 'aria-label': 'Open findings by severity' });
    const setupHost = h('div');
    const agentHost = h('div', { class: 'panel' });
    const chartHost = h('div');
    const sourcesHost = h('div');
    const findingsHost = h('div');
    const activityHost = h('ul', { class: 'feed' });
    const hostHost = h('div', { class: 'stat-row' });
    const range = { min: 60 };

    mount(root,
      h('div', { class: 'page-head' }, h('div', null, h('h1', null, 'Overview'),
        h('p', { class: 'lede' }, 'What the agent is watching right now and what needs your attention.'))),
      setupHost,
      lamps,
      h('div', { class: 'split', style: { marginTop: '16px' } },
        h('div', null,
          agentHost,
          h('div', { class: 'panel' }, h('div', { class: 'panel-head' }, h('h2', null, 'Errors per minute'),
            h('div', { class: 'tools' }, segmented(range, 'min', [{ value: 60, label: '1 h' }, { value: 360, label: '6 h' }, { value: 1440, label: '24 h' }], { label: 'Time range', onChange: loadChart }))),
          chartHost),
          h('div', { class: 'panel panel-flush' }, h('div', { class: 'panel-head' }, h('h2', null, 'Log sources'), h('div', { class: 'tools' }, h('a', { href: '#/sources' }, 'Manage sources'))), sourcesHost)),
        h('div', null,
          h('div', { class: 'panel' }, h('div', { class: 'panel-head' }, h('h2', null, 'Open findings'), h('div', { class: 'tools' }, h('a', { href: '#/findings' }, 'All findings'))), findingsHost),
          h('div', { class: 'panel' }, h('div', { class: 'panel-head' }, h('h2', null, 'This host')), hostHost),
          h('div', { class: 'panel' }, h('div', { class: 'panel-head' }, h('h2', null, 'Agent activity'), h('div', { class: 'tools' }, h('a', { href: '#/agent' }, 'Full log'))), activityHost))));

    function renderSetup() {
      const c = S.config;
      const prov = S.providers.find((p) => p.id === c.agent.provider);
      const pc = c.providers[c.agent.provider] || {};
      const keyOk = !['anthropic', 'openai', 'gemini'].includes(c.agent.provider) || pc.apiKeySet || pc.apiKeyEnvSet;
      const steps = [
        { done: (prov?.kind === 'cli' || !!pc.model) && keyOk, title: 'Connect a model', text: 'Ollama, a cloud API, or a coding-agent CLI.', href: '#/connections', cta: 'Open Connections' },
        { done: c.sources.some((s) => s.path), title: 'Point it at your logs', text: 'A file, a folder, or a pattern such as /var/log/nginx/*.log.', href: '#/sources/new', cta: 'Add a log source' },
        { done: !!(c.knowledge.notes || '').trim() || c.knowledge.rules.length > 0 || c.sources.some((s) => (s.notes || '').trim()), title: 'Tell it about your systems', text: 'What normal looks like, known noise, and what matters most.', href: '#/knowledge', cta: 'Write notes' },
        { done: !!S.status?.running, title: 'Start watching', text: 'The agent checks new log activity on a schedule and when errors spike.', action: startAgent, cta: 'Start watching' },
      ];
      if (steps.every((s) => s.done)) { mount(setupHost); return; }
      mount(setupHost, h('div', { class: 'panel' },
        h('div', { class: 'panel-head' }, h('h2', null, 'Set up in four steps')),
        h('ol', { class: 'setup' }, steps.map((s) => h('li', { class: s.done ? 'done' : '' },
          h('div', null, h('div', { class: 'setup-title' }, s.title), h('div', { class: 'setup-text' }, s.text)),
          s.done ? h('span', { class: 'chip chip-ok' }, 'Done') : s.action ? button(s.cta, s.action, { kind: 'primary', small: true }) : h('a', { class: 'btn btn-sm', href: s.href }, s.cta))))));
    }

    function renderLamps() {
      const b = S.status?.counts?.bySeverity || {};
      mount(lamps, ['critical', 'high', 'medium', 'low'].map((sev) => {
        const n = b[sev] || 0;
        return h('a', { class: ['ann-lamp', `ann-${sev}`, n > 0 && 'lit'], href: `#/findings?severity=${sev}`, 'aria-label': `${cap(sev)}: ${n} open` },
          h('span', { class: 'ann-label' }, cap(sev)),
          h('span', { class: 'ann-count' }, String(n)),
          h('span', { class: 'ann-sub' }, n === 0 ? 'clear' : `open finding${n === 1 ? '' : 's'}`));
      }));
    }

    function renderAgent() {
      const st = S.status;
      if (!st) return;
      const state = !st.running ? 'Stopped' : st.busy ? cap(st.phase) : 'Watching';
      mount(agentHost,
        h('div', { class: 'panel-head' }, h('h2', null, 'Agent'),
          h('div', { class: 'tools' },
            button('Run a cycle now', runCycleNow, { small: true, icon: 'refresh' }),
            st.running ? null : button('Start watching', startAgent, { small: true, kind: 'primary', icon: 'play' }))),
        h('p', { class: 'prose', style: { marginBottom: '12px' } }, st.lastSummary || (st.running ? 'Waiting for the first cycle.' : 'The agent is not running.')),
        st.lastError ? h('div', { class: 'callout callout-danger' }, h('p', null, h('strong', null, 'Last cycle failed: '), st.lastError)) : null,
        h('div', { class: 'stat-row' },
          stat(state, 'State'),
          stat(`${providerLabel(st.provider?.id)}`, st.provider?.model || 'model'),
          stat(st.lastCycleAt ? ago(st.lastCycleAt) : 'never', 'Last cycle'),
          stat(num(st.pending?.patterns || 0), 'Patterns queued'),
          stat(num(st.cycles), 'Cycles since start')));
    }

    async function loadChart() {
      try {
        const q = await api.post('/api/metrics/query', { metric: 'log.lines', levels: ['error', 'critical'], rangeMin: range.min, groupBy: 'source', agg: 'count' });
        if (q.step > 60000) q.series.forEach((s) => s.points.forEach((p) => { if (p[1] != null) p[1] = p[1] / (q.step / 60000); }));
        q.kind = q.step > 60000 ? 'gauge' : q.kind;
        mount(chartHost, timeChart(q, { height: 200, style: 'line' }));
      } catch (e) { mount(chartHost, h('p', { class: 'subtle' }, e.message)); }
    }

    function renderSources() {
      const list = S.sources || [];
      if (!list.length) {
        mount(sourcesHost, h('div', { style: { padding: '0 18px 8px' } }, emptyState('No log sources yet', 'Add a file, folder or pattern to start collecting.', h('a', { class: 'btn btn-primary btn-sm', href: '#/sources/new' }, 'Add a log source'))));
        return;
      }
      mount(sourcesHost, h('div', { class: 'table-wrap' }, h('table', { class: 'table' },
        h('thead', null, h('tr', null, h('th', null, 'Source'), h('th', { class: 'num' }, 'Files'), h('th', { class: 'num' }, 'Lines'), h('th', { class: 'num' }, 'Errors'), h('th', { class: 'num' }, 'Warnings'), h('th', null, 'Last line'))),
        h('tbody', null, list.map((s) => h('tr', { class: 'clickable', onclick: () => ctx.navigate(`#/sources/${s.id}`) },
          h('td', null, h('span', { class: 'source-health' },
            h('span', { class: ['health-dot', !s.enabled ? 'health-idle' : s.error ? 'health-bad' : 'health-ok'], 'aria-hidden': 'true' }),
            h('span', { class: 'cell-title' }, s.name)),
          s.error ? h('div', { class: 'cell-sub', style: { color: 'var(--crit)' } }, s.error) : !s.enabled ? h('div', { class: 'cell-sub' }, 'Paused')
            : !s.lines ? h('div', { class: 'cell-sub' }, 'No new lines yet. Open the source to analyze what is already there.') : null),
          h('td', { class: 'num' }, num(s.files)),
          h('td', { class: 'num' }, num(s.lines)),
          h('td', { class: 'num' }, num((s.byLevel?.error || 0) + (s.byLevel?.critical || 0))),
          h('td', { class: 'num' }, num(s.byLevel?.warn || 0)),
          h('td', null, s.lastLineAt ? ago(s.lastLineAt) : '—')))))));
    }

    async function loadFindings() {
      try {
        const list = await api.get('/api/findings?status=open,acknowledged&limit=8');
        mount(findingsHost, list.length
          ? h('table', { class: 'table compact' }, h('tbody', null, list.map((f) => h('tr', { class: 'clickable', onclick: () => ctx.navigate(`#/findings/${f.id}`) },
            h('td', { style: { width: '96px' } }, sevBadge(f.severity)),
            h('td', null, h('div', { class: 'cell-title' }, f.title), h('div', { class: 'cell-sub' }, `${f.sourceName || 'metrics'}, ${f.occurrences} report${f.occurrences === 1 ? '' : 's'}, last ${ago(f.lastSeen)}`))))))
          : emptyState('Nothing open', S.status?.running ? 'The agent has not reported any problems.' : 'Findings appear here once the agent is running.'));
      } catch (e) { mount(findingsHost, h('p', { class: 'subtle' }, e.message)); }
    }

    async function loadActivity() {
      try {
        const items = await api.get('/api/activity?limit=10');
        mount(activityHost, items.length ? items.map(feedItem) : h('li', { class: 'subtle' }, 'No activity yet.'));
      } catch { /* shown elsewhere */ }
    }

    async function loadHost() {
      try {
        const o = await api.get('/api/metrics/overview');
        const hst = o.host || {};
        mount(hostHost,
          stat(hst.cpuPct != null ? `${Math.round(hst.cpuPct)}%` : '—', 'CPU'),
          stat(`${Math.round(hst.memUsedPct || 0)}%`, `Memory of ${bytes(hst.memTotal)}`),
          (hst.disks || []).slice(0, 3).map((d) => h('div', { class: 'stat', title: d.path }, h('div', { class: 'stat-v' }, `${Math.round(d.usedPct)}%`), h('div', { class: 'stat-k' }, `Disk ${shortPath(d.path)}, ${bytes(d.free)} free`))),
          o.anomalies?.length ? stat(String(o.anomalies.length), 'Metric anomalies (1 h)') : null);
      } catch { /* optional */ }
    }

    renderSetup();
    renderLamps();
    renderAgent();
    renderSources();
    loadChart();
    loadFindings();
    loadActivity();
    loadHost();
    ctx.on('status', () => { renderLamps(); renderAgent(); });
    ctx.on('config', renderSetup);
    ctx.on('sources', renderSources);
    ctx.on('finding', debounce(loadFindings, 600));
    ctx.on('activity', debounce(loadActivity, 400));
    ctx.every(60000, loadChart);
    ctx.every(15000, loadHost);
  },
};

function shortPath(p) {
  const parts = String(p).split(/[\\/]/).filter(Boolean);
  return parts.length > 2 ? `…${p.includes('\\') ? '\\' : '/'}${parts.slice(-2).join(p.includes('\\') ? '\\' : '/')}` : p;
}

function stat(v, k) {
  return h('div', { class: 'stat' }, h('div', { class: 'stat-v' }, v), h('div', { class: 'stat-k' }, k));
}

export function feedItem(e) {
  const meta = [];
  if (e.provider) meta.push(e.model ? `${e.provider}, ${e.model}` : e.provider);
  if (e.tokens && (e.tokens.input || e.tokens.output)) meta.push(`${num(e.tokens.input)} in / ${num(e.tokens.output)} out tokens`);
  if (e.durationMs) meta.push(`${(e.durationMs / 1000).toFixed(1)} s`);
  if (e.count > 1) meta.push(`${e.count} quiet cycles in a row`);
  return h('li', { class: ['feed-item', `st-${e.status}`] },
    h('span', { class: 'feed-time' }, clock(e.t)),
    h('div', null,
      h('div', { class: 'feed-title' }, e.title),
      e.detail ? h('div', { class: 'feed-detail' }, e.detail) : null,
      meta.length ? h('div', { class: 'feed-meta' }, meta.map((m) => h('span', null, m))) : null));
}
