import { h, mount, button, input, select, checkbox, textarea, field, cap, num, bytes, ago, clock, modal, toast, icon, LEVELS, emptyState, debounce, confirmDialog, levelTag, resultLine } from '../ui.js';
import { api } from '../api.js';
import { S, sectionEditor, watchCycleResult } from '../app.js';
import { rulesEditor, ruleTypeHelp } from './rules.js';
import { PRESETS, applyPreset } from '../presets.js';

const FORMATS = [
  { value: 'auto', label: 'Detect automatically' },
  { value: 'plain', label: 'Plain text lines' },
  { value: 'json', label: 'JSON lines' },
  { value: 'access', label: 'Web access log (nginx / Apache combined)' },
  { value: 'syslog', label: 'Syslog' },
  { value: 'custom', label: 'Custom regular expression' },
];

function examples() {
  const p = S.system.platform;
  if (p === 'win32') return ['C:\\inetpub\\logs\\LogFiles\\**\\*.log', 'C:\\ProgramData\\MyApp\\logs', 'D:\\services\\api\\logs\\app-*.log'];
  if (p === 'darwin') return ['/var/log/system.log', '~/Library/Logs/MyApp', '/usr/local/var/log/nginx/*.log'];
  return ['/var/log/nginx/*.log', '/var/log/syslog', '/opt/myapp/logs/**/*.log'];
}

export default {
  async render(root, params, ctx) {
    if (params[0]) return renderEditor(root, params[0], ctx);
    return renderList(root, ctx);
  },
};

function renderList(root, ctx) {
  const body = h('div');
  const draw = () => {
    const status = new Map((S.sources || []).map((s) => [s.id, s]));
    mount(body, S.config.sources.length ? h('div', { class: 'panel panel-flush' }, h('div', { class: 'table-wrap' }, h('table', { class: 'table' },
      h('thead', null, h('tr', null, h('th', null, 'Source'), h('th', null, 'Path'), h('th', { class: 'num' }, 'Files'), h('th', { class: 'num' }, 'Lines read'), h('th', { class: 'num' }, 'Errors'), h('th', null, 'Last line'), h('th', null, 'Notes'))),
      h('tbody', null, S.config.sources.map((s) => {
        const st = status.get(s.id) || {};
        return h('tr', { class: 'clickable', tabindex: '0', onclick: () => ctx.navigate(`#/sources/${s.id}`), onkeydown: (e) => { if (e.key === 'Enter') ctx.navigate(`#/sources/${s.id}`); } },
          h('td', null, h('span', { class: 'source-health' }, h('span', { class: ['health-dot', !s.enabled ? 'health-idle' : st.error ? 'health-bad' : 'health-ok'], 'aria-hidden': 'true' }), h('span', { class: 'cell-title' }, s.name)),
            st.error ? h('div', { class: 'cell-sub', style: { color: 'var(--crit)' } }, st.error) : !s.enabled ? h('div', { class: 'cell-sub' }, 'Paused') : null),
          h('td', null, h('code', null, s.path || '—')),
          h('td', { class: 'num' }, num(st.files)),
          h('td', { class: 'num' }, num(st.lines)),
          h('td', { class: 'num' }, num((st.byLevel?.error || 0) + (st.byLevel?.critical || 0))),
          h('td', null, st.lastLineAt ? ago(st.lastLineAt) : '—'),
          h('td', null, (s.notes || '').trim() || (s.rules || []).length ? h('span', { class: 'chip chip-accent' }, `${(s.notes || '').trim() ? 'notes' : ''}${(s.notes || '').trim() && s.rules.length ? ', ' : ''}${s.rules.length ? `${s.rules.length} rule${s.rules.length === 1 ? '' : 's'}` : ''}`) : h('span', { class: 'subtle' }, 'none')));
      }))))) : h('div', { class: 'panel' }, emptyState('No log sources yet', 'A source is a file, a folder, or a pattern that matches log files. Point it at the logs you want watched; you choose where they live.',
      h('a', { class: 'btn btn-primary', href: '#/sources/new' }, 'Add a log source'))));
  };
  mount(root,
    h('div', { class: 'page-head' }, h('div', null, h('h1', null, 'Log sources'), h('p', { class: 'lede' }, 'The files Log Sentinel tails. New lines are parsed, grouped into patterns and handed to the agent each cycle.')),
      h('div', { class: 'tools' }, h('a', { class: 'btn btn-primary', href: '#/sources/new' }, icon('plus', 17), h('span', null, 'Add a log source')))),
    body);
  draw();
  ctx.on('sources', draw);
  ctx.on('config', draw);
}

function renderEditor(root, id, ctx) {
  const ed = sectionEditor(ctx, 'sources', {
    label: 'Log source',
    onSaved: () => { if (isNew) { isNew = false; history.replaceState(null, '', `#/sources/${src.id}`); } },
    onDiscard: () => (id === 'new' ? ctx.navigate('#/sources') : ctx.rerender()),
  });
  let isNew = id === 'new';
  let src = isNew ? null : ed.draft.find((s) => s.id === id);
  if (!src && !isNew) {
    mount(root, h('div', { class: 'panel' }, emptyState('Source not found', 'It may have been deleted.', h('a', { class: 'btn btn-sm', href: '#/sources' }, 'Back to sources'))));
    return;
  }
  if (isNew) {
    src = {
      id: `src_${Date.now().toString(36)}`, enabled: true, name: '', path: '', recursive: false, include: '*', exclude: '*.gz, *.zip, *.bz2, *.xz, *.7z, *.tar',
      format: 'auto', customRegex: '', encoding: 'auto', multiline: true, startAt: 'end', minLevel: '', notes: '', rules: [],
    };
    // The new source joins the draft on the first edit, so an untouched form is not "unsaved".
    const adopt = () => { if (isNew && !ed.draft.includes(src)) ed.draft.push(src); };
    for (const ev of ['input', 'change', 'ls-change']) root.addEventListener(ev, adopt, true);
  }
  const check = resultLine();
  const fileList = h('div');
  const testPath = async () => {
    check.set('info', 'Looking for files…');
    try {
      const r = await api.post('/api/sources/test', { source: src });
      if (!r.count) { check.set('error', r.error || 'No matching files'); mount(fileList); return; }
      const sk = r.skipped || [];
      check.set('ok', `Found ${r.count} file${r.count === 1 ? '' : 's'}${r.count >= 500 ? ' (showing the newest 500)' : ''}.${sk.length ? ` Skipped ${sk.length} binary file${sk.length === 1 ? '' : 's'} (${sk.slice(0, 3).join(', ')}${sk.length > 3 ? ', …' : ''}).` : ''}`);
      mount(fileList, h('ul', { class: 'file-list' }, r.files.map((f) => h('li', null, h('span', { class: 'fpath', title: f.path }, f.path), h('span', null, bytes(f.size)), h('span', { class: 'subtle' }, ago(f.mtime))))));
    } catch (e) { check.set('error', e.message); }
  };
  const pathInput = input(src, 'path', { placeholder: examples()[0], mono: true });
  pathInput.addEventListener('change', () => { if (!src.name && src.path) { src.name = guessName(src.path); nameInput.value = src.name; } testPath(); preview.refresh(); });
  const nameInput = input(src, 'name', { placeholder: 'e.g. API server' });
  const customField = field('Line pattern (regular expression)', input(src, 'customRegex', { mono: true, placeholder: '^(?<ts>\\S+ \\S+) \\[(?<level>\\w+)\\] (?<msg>.*)$' }),
    'Named groups: ts, level and msg are understood; any other named group becomes a field you can graph on the Metrics page.', { wide: true });
  customField.hidden = src.format !== 'custom';
  const preview = previewPanel(src, { ensureSaved: async () => { if (ed.dirty()) await ed.save(); } });
  const includeInput = input(src, 'include', { mono: true });
  const notesBox = textarea(src, 'notes', { rows: 6, placeholder: 'e.g. This is the public API (Node.js, 4 instances behind nginx).\n- "ECONNRESET from payments-gw" happens a few times an hour and is retried; only care if more than 20 in 5 minutes.\n- Anything mentioning "ledger" is high severity.\n- Deploys happen weekdays 14:00–15:00 UTC and cause a burst of 503s for about a minute.' });
  const rulesBox = rulesEditor(src.rules, { onChange: () => ed.check() });
  const presetSel = h('select', { class: 'input select', 'aria-label': 'Start from a preset', style: { width: 'auto' } },
    h('option', { value: '' }, 'Add a preset…'), PRESETS.map((p) => h('option', { value: p.id }, p.name)));
  presetSel.addEventListener('change', () => {
    const p = PRESETS.find((x) => x.id === presetSel.value);
    presetSel.value = '';
    if (!p) return;
    const changes = applyPreset(src, p);
    notesBox.value = src.notes;
    includeInput.value = src.include;
    rulesBox.refresh();
    ed.check();
    preview.refresh();
    if (changes.length) {
      toast(`${p.name}: ${changes.join(', ')}. Edit the lines in [brackets], then save.`, 'ok', { timeout: 7000 });
      if (src.path) testPath();
    } else toast(`${p.name} is already applied.`, 'info');
  });

  mount(root,
    h('p', { style: { margin: '0 0 8px' } }, h('a', { href: '#/sources' }, 'Log sources')),
    h('div', { class: 'page-head' }, h('div', null, h('h1', null, isNew ? 'Add a log source' : src.name || 'Log source')),
      h('div', { class: 'tools' }, isNew ? null : button('Delete source', async () => {
        if (!await confirmDialog('Delete this source?', 'Log Sentinel stops reading these files. Findings already reported are kept.', { confirm: 'Delete source' })) return;
        const i = ed.draft.findIndex((s) => s.id === src.id);
        ed.draft.splice(i, 1);
        await ed.save();
        ctx.navigate('#/sources');
      }, { kind: 'ghost', icon: 'trash' }))),
    h('div', { class: 'panel' },
      h('div', { class: 'panel-head' }, h('h2', null, 'Where the logs are')),
      h('div', { class: 'fields' },
        field('Name', nameInput, 'Shown in findings and alerts.'),
        h('div', { class: 'field', style: { justifyContent: 'flex-end' } }, checkbox(src, 'enabled', 'Watch this source'))),
      h('div', { class: 'fields', style: { marginTop: '14px' } },
        field('Path, folder or pattern', h('div', { class: 'input-group' }, pathInput, button('Browse', () => browse(src.path, (p) => { src.path = p; pathInput.value = p; pathInput.dispatchEvent(new Event('input', { bubbles: true })); pathInput.dispatchEvent(new Event('change')); }), { icon: 'folder' })),
          h('span', null, 'Examples: ', examples().map((e, i) => [i ? ', ' : '', h('code', null, e)]), '. ', h('code', null, '**'), ' matches any folder depth. Paths are on the computer running Log Sentinel.'), { wide: true })),
      h('div', { class: 'row', style: { marginTop: '10px' } }, button('Check path', testPath, { icon: 'search' })),
      check, fileList,
      h('details', { class: 'more' }, h('summary', null, 'Folder and file options'),
        h('div', { class: 'fields' },
          h('div', { class: 'field' }, checkbox(src, 'recursive', 'Include subfolders', { hint: 'For a folder path. Patterns with ** always search subfolders.' })),
          field('File names to include', includeInput, 'Comma-separated, e.g. *.log, *.txt'),
          field('File names to skip', input(src, 'exclude', { mono: true }), 'Compressed rotations are skipped by default.')))),
    h('div', { class: 'panel' },
      h('div', { class: 'panel-head' }, h('h2', null, 'How to read them')),
      h('div', { class: 'fields' },
        field('Format', select(src, 'format', FORMATS, { onChange: (v) => { customField.hidden = v !== 'custom'; } })),
        field('Reporting level', select(src, 'minLevel', [{ value: '', label: `Agent default (${cap(S.config.agent.minLevel)} and above)` }, ...LEVELS.map((l) => ({ value: l, label: `${cap(l)} and above` }))]), 'Lines below this are counted for metrics but not sent to the agent.'),
        field('When first added', select(src, 'startAt', [{ value: 'end', label: 'Start from new lines only' }, { value: 'beginning', label: 'Read existing content too' }]), 'Reading existing content is capped by the backlog limit in Settings.'),
        field('Text encoding', select(src, 'encoding', [{ value: 'auto', label: 'Detect (UTF-8 or UTF-16)' }, { value: 'utf8', label: 'UTF-8' }, { value: 'utf16le', label: 'UTF-16 LE (common on Windows)' }, { value: 'latin1', label: 'Latin-1' }])),
        customField,
        h('div', { class: 'field field-wide' }, checkbox(src, 'multiline', 'Keep stack traces together', { hint: 'Indented lines and "at …" / "Caused by:" lines join the line above them.' })))),
    h('div', { class: 'panel' },
      h('div', { class: 'panel-head' }, h('h2', null, 'What the agent should know about this log'), h('p', null, 'Sent with every cycle that includes this source.'),
        h('div', { class: 'tools' }, presetSel)),
      notesBox,
      h('div', { class: 'section-label' }, 'Rules for this source'),
      ruleTypeHelp(),
      rulesBox),
    preview.el,
    ed.bar);
  if (src.path) testPath();
  ctx.every(5000, () => { if (preview.live()) preview.refresh(); });
  root.addEventListener('input', debounce(() => preview.refresh(), 900));
}

function guessName(p) {
  const parts = p.replace(/\\/g, '/').split('/').filter((x) => x && !/[*?]/.test(x));
  const last = parts[parts.length - 1] || 'logs';
  return last.replace(/\.(log|txt|out)$/i, '').replace(/[-_.]+/g, ' ').replace(/\b\w/g, (c) => c.toUpperCase()) || 'Logs';
}

// Send what is already in the file(s) to the agent. Normally only new lines are read.
async function analyzeExisting(src, opts, ensureSaved) {
  if (!src.path) throw new Error('Set a path first.');
  await ensureSaved();
  const stop = watchCycleResult();
  let r;
  try { r = await api.post(`/api/sources/${encodeURIComponent(src.id)}/backfill`, { file: opts.file || undefined, allFiles: opts.allFiles }); } catch (e) { stop(); throw e; }
  const from = r.files.length === 1 ? r.files[0] : `${r.files.length} files`;
  const cut = r.truncated ? ' (the newest part of large files)' : '';
  if (!r.queued) {
    stop();
    toast(`Read ${num(r.lines)} lines from ${from}${cut}, but none are at ${cap(r.minLevel)} or above and no rule marks them, so there is nothing for the agent to analyze. Add a preset or rules, or lower the Reporting level.`, 'info', { timeout: 15000 });
    return;
  }
  const msg = `Read ${num(r.lines)} lines from ${from}${cut}. ${num(r.queued)} go to the agent as ${r.patterns} pattern${r.patterns === 1 ? '' : 's'}.`;
  if (r.cycle === 'started') toast(`${msg} Analyzing now; the result appears here when it's done.`, 'info', { timeout: 8000 });
  else if (r.cycle === 'queued') toast(`${msg} A cycle is already running, so they'll be analyzed in the next one.`, 'info', { timeout: 10000 });
}

function previewPanel(src, { ensureSaved = async () => {} } = {}) {
  const opts = { lines: 200, q: '', level: '', onlyAgent: false, file: '', allFiles: false, live: false };
  const host = h('div', { class: 'logview', 'aria-live': 'off' });
  const meta = h('div', { class: 'subtle', style: { fontSize: '12.5px', margin: '6px 0' } });
  const fileSel = h('select', { class: 'input select', 'aria-label': 'File', style: { maxWidth: '360px' } });
  fileSel.addEventListener('change', () => {
    opts.allFiles = fileSel.value === '*';
    opts.file = opts.allFiles ? '' : fileSel.value;
    refresh();
  });
  const help = h('div');
  const q = h('input', { class: 'input', type: 'search', placeholder: 'Filter text', 'aria-label': 'Filter preview', style: { maxWidth: '220px' } });
  q.addEventListener('input', debounce(() => { opts.q = q.value; refresh(); }, 300));
  const lvl = h('select', { class: 'input select', 'aria-label': 'Minimum level', style: { width: 'auto' } }, h('option', { value: '' }, 'All levels'), LEVELS.slice(2).map((l) => h('option', { value: l }, `${cap(l)} and above`)));
  lvl.addEventListener('change', () => { opts.level = lvl.value; refresh(); });
  const agentOnly = checkbox(opts, 'onlyAgent', 'Only what the agent sees', { onChange: refresh });
  const liveBox = checkbox(opts, 'live', 'Refresh every 5 s');
  let seq = 0;
  async function refresh() {
    if (!src.path) { mount(host, h('p', { style: { padding: '12px' } }, 'Set a path to see a preview.')); return; }
    const my = ++seq;
    try {
      const r = await api.post('/api/sources/preview', { source: src, ...opts });
      if (my !== seq) return;
      if (!r.records || !r.files?.length) { mount(help); host.hidden = false; mount(host, h('p', { style: { padding: '12px' } }, r.error || 'No files')); return; }
      const multi = r.files.length > 1;
      mount(fileSel,
        multi ? h('option', { value: '*', selected: r.allFiles }, `All ${r.files.length} files, newest first`) : null,
        r.files.slice(0, 100).map((f) => h('option', { value: f.path, title: f.path, selected: !r.allFiles && f.path === r.file }, `${baseName(f.path)} (${bytes(f.size)}, ${ago(f.mtime)})`)));
      fileSel.hidden = false;
      meta.textContent = describe(r, opts);
      const explained = r.records.length ? null : emptyHelp(r, opts, multi);
      mount(help, explained);
      host.hidden = !!explained;
      mount(host, r.records.length ? r.records.map((x) => h('div', { class: ['logline', x.toAgent ? 'to-agent' : 'dim', x.ignored && 'ignored'], title: `pattern ${x.fp.id}: ${x.fp.template}` },
        h('span', null, levelTag(x.level)),
        h('span', { class: 'raw' }, x.raw),
        h('span', { class: 'marks' },
          x.file ? h('span', { class: 'chip', title: x.file }, baseName(x.file)) : null,
          x.ignored ? h('span', { class: 'chip' }, 'ignored') : null,
          x.always ? h('span', { class: 'chip chip-bad' }, 'always') : null,
          x.matched.length && !x.ignored && !x.always ? h('span', { class: 'chip chip-accent' }, `${x.matched.length} rule${x.matched.length === 1 ? '' : 's'}`) : null)))
        : h('p', { style: { padding: '12px' } }, 'No lines match.'));
      if (opts.live) host.scrollTop = host.scrollHeight;
    } catch (e) { mount(host, h('p', { class: 'result result-error', style: { padding: '12px' } }, e.message)); }
  }
  const el = h('div', { class: 'panel' },
    h('div', { class: 'panel-head' }, h('h2', null, 'Preview'),
      h('p', null, 'The agent reads lines as they are added to a file. To analyze what is already there, use Analyze existing lines.'),
      h('div', { class: 'tools' },
        button('Refresh', refresh, { small: true, icon: 'refresh' }),
        button('Analyze existing lines', () => analyzeExisting(src, opts, ensureSaved), { small: true, kind: 'primary', icon: 'play', title: 'Send the lines already in the selected file (or all files) to the agent now' }))),
    h('div', { class: 'filters' }, fileSel, q, lvl, agentOnly, liveBox),
    meta, help, host);
  setTimeout(refresh, 50);
  return { el, refresh, live: () => opts.live };
}

const baseName = (p) => String(p).split(/[\\/]/).pop();
const LEVEL_ORDER = ['critical', 'error', 'warn', 'info', 'debug', 'trace'];

function breakdown(byLevel) {
  return LEVEL_ORDER.filter((l) => byLevel[l]).map((l) => `${num(byLevel[l])} ${l}`).join(', ') || 'none';
}

// One line saying what was read and what the agent would get from it.
function describe(r, opts) {
  const s = r.stats;
  const where = r.allFiles ? `${s.files.length} file${s.files.length === 1 ? '' : 's'}${s.notScanned ? ` (${s.notScanned} older not read)` : ''}` : baseName(r.file);
  const scope = s.truncated ? `the last ${bytes(s.bytes)} of ${where}` : where;
  const filtered = opts.onlyAgent || opts.level || opts.q;
  const shown = filtered ? `Showing ${num(r.records.length)}${r.matchedTotal > r.records.length ? ` newest of ${num(r.matchedTotal)}` : ''} matching. ` : '';
  return `${shown}Read ${num(s.records)} records from ${scope}: ${breakdown(s.byLevel)}. ${num(s.toAgent)} would go to the agent (${cap(r.minLevel)} and above, plus always-report rules)${s.ignored ? `, ${num(s.ignored)} removed by ignore rules` : ''}. Blue edge = sent to the agent. Unsaved changes on this page are applied.`;
}

// When a filter leaves nothing, explain why and what to do about it.
function emptyHelp(r, opts, multi) {
  const s = r.stats;
  if (!(opts.onlyAgent || opts.level)) return null;
  const tips = [];
  if (multi && !r.allFiles) tips.push('Choose "All files" above to include older logs, where past problems usually are.');
  if (s.ignoredHigh) tips.push(`${num(s.ignoredHigh)} line${s.ignoredHigh === 1 ? ' is' : 's are'} at ${cap(r.minLevel)} or above, but your ignore rules remove ${s.ignoredHigh === 1 ? 'it' : 'them'}.`);
  tips.push('Use a preset, or add Set level / Always report rules, for important lines that have no level of their own.');
  tips.push(`Lower the Reporting level above to see more. Info sends almost everything and uses more tokens per cycle.`);
  return h('div', { class: 'callout' },
    h('p', null, h('strong', null, 'Nothing here would be sent to the agent. '),
      `Every record read is below ${cap(r.minLevel)} and no rule marks it. For a healthy log this is expected: the agent only hears about lines that look like problems, and quiet cycles cost no tokens.`),
    h('ul', { style: { margin: '6px 0 0', paddingLeft: '18px' } }, tips.map((t) => h('li', null, t))));
}

/** Folder browser on the server's file system. onPick(path) */
export function browse(start, onPick) {
  const st = { path: start ? start.replace(/[*?].*$/, '').replace(/[\\/][^\\/]*$/, '') || start : '' };
  const list = h('ul', { class: 'browser-list' });
  const pathBox = h('input', { class: 'input mono', 'aria-label': 'Folder path' });
  const err = h('div', { class: 'result result-error' });
  let current = null;
  let m;
  async function go(p) {
    err.textContent = '';
    try {
      const r = await api.post('/api/system/browse', { path: p || undefined });
      current = r;
      pathBox.value = r.path;
      mount(list,
        r.parent != null ? h('li', null, h('button', { type: 'button', onclick: () => go(r.parent) }, icon('up', 16), '..')) : null,
        r.entries.length ? r.entries.map((e) => h('li', null, h('button', { type: 'button', class: e.dir ? '' : 'is-file', onclick: () => (e.dir ? go(e.path) : pick(e.path)), title: e.dir ? 'Open folder' : 'Use this file' },
          icon(e.dir ? 'folder' : 'file', 16), e.name, e.dir ? null : h('span', { class: 'bsize' }, `${bytes(e.size)}, ${ago(e.mtime)}`)))) : h('li', { class: 'subtle', style: { padding: '8px 12px' } }, 'Empty folder'));
    } catch (e) { err.textContent = e.message; }
  }
  const pick = (p) => { onPick(p); m.close(); };
  pathBox.addEventListener('keydown', (e) => { if (e.key === 'Enter') { e.preventDefault(); go(pathBox.value); } });
  m = modal({
    title: 'Choose a log file or folder',
    wide: true,
    body: h('div', null,
      h('p', { class: 'subtle' }, 'Browsing the computer that runs Log Sentinel. Pick a file, or open a folder and use it as a whole or with a pattern.'),
      h('div', { class: 'browser' }, h('div', { class: 'browser-path' }, pathBox, button('Go', () => go(pathBox.value), { small: true })), list), err),
    actions: [
      { label: 'Cancel' },
      { label: 'Use folder, *.log files', onClick: () => { if (!current?.path) return false; onPick(joinPattern(current.path, '*.log')); return true; } },
      { label: 'Use this folder', kind: 'primary', onClick: () => { if (!current?.path) return false; onPick(current.path); return true; } },
    ],
  });
  go(st.path);
}

function joinPattern(dir, pat) {
  const sep = dir.includes('\\') && !dir.includes('/') ? '\\' : '/';
  return dir.endsWith(sep) ? dir + pat : dir + sep + pat;
}
