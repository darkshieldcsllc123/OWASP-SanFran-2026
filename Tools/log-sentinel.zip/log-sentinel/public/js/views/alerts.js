import { h, mount, button, input, select, checkbox, textarea, field, cap, toast, icon, SEVERITIES, emptyState, resultLine } from '../ui.js';
import { api } from '../api.js';
import { S, sectionEditor, localPref } from '../app.js';

const TYPES = {
  slack: { label: 'Slack', help: 'In Slack, create an app with Incoming Webhooks turned on, add it to a channel, and copy the webhook URL (https://hooks.slack.com/services/…).' },
  discord: { label: 'Discord', help: 'In the Discord channel settings, open Integrations, Webhooks, create one and copy its URL.' },
  teams: { label: 'Microsoft Teams', help: 'In Teams, add the Workflows app to the channel and choose "Post to a channel when a webhook request is received". Copy the URL it gives you. Messages are sent as Adaptive Cards.' },
  webhook: { label: 'Generic webhook', help: 'Any URL that accepts a JSON POST. The body includes event, severity, title, text, source, findingId and a link.' },
};
const KINDS = [
  ['finding', 'New findings'], ['escalation', 'Severity raised'], ['regression', 'Issue came back'],
  ['action_pending', 'Action needs approval'], ['threshold', 'Threshold breached'], ['threshold_clear', 'Threshold cleared'],
];
let seq = 0;

export default {
  async render(root, params, ctx) {
    const ed = sectionEditor(ctx, 'alerts', { label: 'Alerts' });
    const d = ed.draft;
    const list = h('div');
    const changed = () => root.dispatchEvent(new Event('ls-change'));
    const prefs = { desktop: !!localPref('desktopNotify') };

    const drawChannels = () => mount(list, d.channels.length ? d.channels.map((ch, i) => {
      const res = resultLine();
      const t = TYPES[ch.type] || TYPES.webhook;
      const url = input(ch, 'url', { type: 'password', mono: true, placeholder: 'https://…', autocomplete: 'new-password' });
      url.addEventListener('focus', () => url.select());
      ch.kinds = ch.kinds || [];
      const kinds = h('div', { class: 'row', role: 'group', 'aria-label': 'Send for' }, KINDS.map(([k, label]) => {
        const id = `k-${ch.id}-${k}`;
        const inp = h('input', { type: 'checkbox', id, checked: !ch.kinds.length || ch.kinds.includes(k) });
        inp.addEventListener('change', () => {
          const all = KINDS.map((x) => x[0]);
          let cur = ch.kinds.length ? ch.kinds.slice() : all.slice();
          if (inp.checked) cur = [...new Set([...cur, k])]; else cur = cur.filter((x) => x !== k);
          ch.kinds = cur.length === all.length ? [] : cur;
          changed();
        });
        return h('label', { class: 'chip', for: id, style: { cursor: 'pointer' } }, inp, label);
      }));
      return h('div', { class: 'panel' },
        h('div', { class: 'panel-head' }, h('h2', null, ch.name || t.label), h('span', { class: 'chip' }, t.label),
          h('div', { class: 'tools' }, checkbox(ch, 'enabled', 'On'), h('button', { class: 'icon-btn', 'aria-label': 'Remove channel', onclick: () => { d.channels.splice(i, 1); changed(); drawChannels(); } }, icon('trash', 16)))),
        h('p', { class: 'subtle' }, t.help),
        h('div', { class: 'fields' },
          field('Name', input(ch, 'name', { placeholder: `${t.label} #ops-alerts` })),
          field('Webhook URL', url, String(ch.url || '').startsWith('••') ? 'Saved on the server. Paste a new URL to replace it.' : 'Webhook URLs work like passwords; they are stored on the server and masked here.'),
          field('Send for severity', select(ch, 'minSeverity', SEVERITIES.map((s) => ({ value: s, label: `${cap(s)}${s === 'critical' ? ' only' : s === 'info' ? ' and everything above' : ' and above'}` })))),
          ch.type === 'webhook' ? field('Method', select(ch, 'method', ['POST', 'PUT'])) : null,
          ch.type === 'webhook' ? field('Headers', textarea(ch, 'headers', { rows: 2, mono: true, placeholder: 'Authorization: Bearer …' }), 'One per line, or a JSON object.', { wide: true }) : null,
          field('Send for', kinds, null, { wide: true })),
        h('div', { class: 'row', style: { marginTop: '12px' } }, button('Send a test', async () => {
          res.set('info', 'Sending…');
          try { await api.post('/api/alerts/test', { channel: ch }); res.set('ok', 'Sent. Check the channel.'); } catch (e) { res.set('error', e.message); }
        }, { small: true, icon: 'play' })), res);
    }) : h('div', { class: 'panel' }, emptyState('No outside channels', 'Alerts already appear in this app. Add a channel to also send them to chat or another system.')));

    const desktopBox = checkbox(prefs, 'desktop', 'Also show desktop notifications from this browser when the tab is in the background', {
      onChange: async (v) => {
        if (v && 'Notification' in window && Notification.permission !== 'granted') {
          const p = await Notification.requestPermission();
          if (p !== 'granted') { toast('The browser blocked notifications. Allow them in the site settings.', 'error'); prefs.desktop = false; desktopBox.querySelector('input').checked = false; return; }
        }
        localPref('desktopNotify', v);
      },
    });

    mount(root,
      h('div', { class: 'page-head' }, h('div', null, h('h1', null, 'Alerts'), h('p', { class: 'lede' }, 'How you hear about new findings, actions waiting for approval and threshold breaches.'))),
      h('div', { class: 'panel' },
        h('div', { class: 'panel-head' }, h('h2', null, 'In this app')),
        h('div', { class: 'fields' },
          h('div', { class: 'field' }, checkbox(d, 'inApp.enabled', 'Show alerts in the bell menu and as pop-ups')),
          field('Minimum severity', select(d, 'inApp.minSeverity', SEVERITIES.slice().reverse().map((s) => ({ value: s, label: `${cap(s)} and above` })))),
          field('Most messages per channel in 10 minutes', input(d, 'rateLimitPer10Min', { type: 'number', min: 1 }), 'Protects chat channels during an incident.')),
        h('div', { class: 'section-label' }, 'Alert on'),
        h('div', { class: 'row' },
          checkbox(d, 'notifyOn.newFinding', 'New findings'), checkbox(d, 'notifyOn.escalation', 'Severity raised'), checkbox(d, 'notifyOn.regression', 'Issue came back'),
          checkbox(d, 'notifyOn.actionPending', 'Action needs approval'), checkbox(d, 'notifyOn.threshold', 'Threshold breached or cleared')),
        h('div', { style: { marginTop: '8px' } }, desktopBox),
        h('p', { class: 'hint' }, 'To put a link to the finding in chat messages, set the public address under ', h('a', { href: '#/settings/server' }, 'Settings, Server'), '.')),
      h('div', { class: 'panel-head', style: { marginTop: '24px' } }, h('h2', null, 'Other channels'),
        h('div', { class: 'tools' }, Object.entries(TYPES).map(([k, t]) => button(`Add ${t.label}`, () => {
          d.channels.push({ id: `ch_${Date.now().toString(36)}${seq++}`, type: k, name: '', url: '', enabled: true, minSeverity: 'high', kinds: [], method: 'POST', headers: '' });
          changed();
          drawChannels();
        }, { small: true, icon: 'plus' })))),
      list,
      ed.bar);
    drawChannels();
  },
};
