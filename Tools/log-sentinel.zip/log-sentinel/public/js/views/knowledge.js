import { h, mount, button, textarea, field, cap, num, levelTag, resultLine } from '../ui.js';
import { api } from '../api.js';
import { S, sectionEditor } from '../app.js';
import { rulesEditor, ruleTypeHelp } from './rules.js';

const OUTLINE = `## Environment
What these systems are, how many instances, what depends on what.

## What normal looks like
Expected background errors, traffic patterns, scheduled jobs (backups, deploys, cron) and when they run.

## What matters most
Errors that always deserve attention, customer-facing paths, data-integrity signals.

## Known noise
Messages that look alarming but are harmless, and why.

## How to judge severity
When something is critical vs. high for this team. Who gets woken up, and for what.
`;

export default {
  async render(root, params, ctx) {
    const ed = sectionEditor(ctx, 'knowledge', { label: 'Knowledge' });
    const d = ed.draft;
    const notes = textarea(d, 'notes', { rows: 16, placeholder: 'Describe your systems in plain language. The agent reads this before every analysis.' });
    const counter = h('span', { class: 'subtle' });
    const budget = () => {
      const tokens = Math.ceil((d.notes || '').length / 3.5);
      const max = Math.floor((S.config.agent.contextTokens || 8000) * 0.3);
      counter.textContent = `About ${num(tokens)} tokens. Up to ${num(max)} fit in each request (30% of the context window); longer notes are cut off at the end.`;
      counter.style.color = tokens > max ? 'var(--crit)' : '';
    };
    notes.addEventListener('input', budget);
    budget();

    // tester
    const t = { line: '', sourceId: S.config.sources[0]?.id || '' };
    const lineBox = h('textarea', { class: 'input textarea mono', rows: 3, placeholder: '2026-10-16T14:02:11Z ERROR [db] connection to db-2 refused after 5000ms', 'aria-label': 'Log line to test' });
    lineBox.addEventListener('input', () => { t.line = lineBox.value; });
    const srcSel = h('select', { class: 'input select', 'aria-label': 'Test against source' },
      h('option', { value: '' }, 'No source (global rules only)'), S.config.sources.map((s) => h('option', { value: s.id, selected: s.id === t.sourceId }, s.name)));
    srcSel.addEventListener('change', () => { t.sourceId = srcSel.value; });
    const out = h('div');
    const res = resultLine();
    const runTest = async () => {
      if (!t.line.trim()) { res.set('error', 'Paste a log line first.'); return; }
      res.clear();
      const r = await api.post('/api/knowledge/test', { line: t.line, sourceId: t.sourceId, rules: d.rules });
      const verdict = r.ignored ? ['error', 'Filtered out by an ignore rule. The agent will not see this line.']
        : r.always ? ['ok', 'Sent to the agent (an always-report rule matched).']
          : r.toAgent ? ['ok', `Sent to the agent (level ${r.level} is at or above ${r.minLevel}).`]
            : ['info', `Counted, but not sent: level ${r.level} is below the reporting level (${r.minLevel}).`];
      res.set(verdict[0], verdict[1]);
      mount(out, h('dl', { class: 'kv', style: { marginTop: '10px' } },
        h('dt', null, 'Level'), h('dd', null, levelTag(r.level)),
        h('dt', null, 'Message'), h('dd', null, h('code', null, r.msg)),
        Object.keys(r.fields || {}).length ? [h('dt', null, 'Fields'), h('dd', null, h('code', null, JSON.stringify(r.fields)))] : null,
        h('dt', null, 'Pattern'), h('dd', null, h('code', null, r.fingerprint.template), h('span', { class: 'subtle' }, ` (${r.fingerprint.id})`)),
        h('dt', null, 'Rules matched'), h('dd', null, r.matched.length ? h('ul', { style: { margin: 0, paddingLeft: '18px' } }, r.matched.map((m) => h('li', null, h('strong', { class: `type-${m.type}` }, cap(m.type === 'severity' ? `set level ${m.level}` : m.type)), ` "${m.pattern}"`, m.note ? ` — ${m.note}` : ''))) : 'none')));
    };

    const perSource = S.config.sources.length
      ? h('table', { class: 'table compact' }, h('tbody', null, S.config.sources.map((s) => h('tr', null,
        h('td', null, h('a', { href: `#/sources/${s.id}` }, s.name)),
        h('td', null, (s.notes || '').trim() ? `${(s.notes || '').trim().split(/\s+/).length} words of notes` : h('span', { class: 'subtle' }, 'no notes')),
        h('td', null, s.rules.length ? `${s.rules.length} rule${s.rules.length === 1 ? '' : 's'}` : h('span', { class: 'subtle' }, 'no rules'))))))
      : h('p', { class: 'subtle' }, 'Add a log source to write notes about it.');

    mount(root,
      h('div', { class: 'page-head' }, h('div', null, h('h1', null, 'Knowledge'),
        h('p', { class: 'lede' }, 'What you know about these systems that the logs do not say. The agent follows this guidance over its own assumptions when it decides what is a problem and how serious it is.'))),
      h('div', { class: 'panel' },
        h('div', { class: 'panel-head' }, h('h2', null, 'Notes for every source'),
          h('div', { class: 'tools' }, (d.notes || '').trim() ? null : button('Start from an outline', () => { d.notes = OUTLINE; notes.value = OUTLINE; budget(); ed.check(); }, { small: true }))),
        notes, h('div', { class: 'hint' }, counter)),
      h('div', { class: 'panel' },
        h('div', { class: 'panel-head' }, h('h2', null, 'Rules'), h('p', null, 'Applied to every line as it is read, before the agent sees anything.')),
        ruleTypeHelp(),
        rulesEditor(d.rules, { sources: S.config.sources, onChange: () => ed.check() })),
      h('div', { class: 'grid-2' },
        h('div', { class: 'panel' },
          h('div', { class: 'panel-head' }, h('h2', null, 'Test a line')),
          h('p', { class: 'subtle' }, 'See how a line is parsed and what your rules do with it, including unsaved changes.'),
          lineBox, h('div', { class: 'row', style: { marginTop: '8px' } }, srcSel, button('Test', runTest, { kind: 'primary' })), res, out),
        h('div', { class: 'panel' },
          h('div', { class: 'panel-head' }, h('h2', null, 'Notes on each source')),
          h('p', { class: 'subtle' }, 'Source-specific notes and rules live on each source page and are only sent when that source has activity.'),
          perSource)),
      ed.bar);
  },
};
