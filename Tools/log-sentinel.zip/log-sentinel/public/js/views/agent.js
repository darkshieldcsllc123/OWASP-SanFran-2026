import { h, mount, button, input, select, checkbox, textarea, listInput, field, cap, num, modal, toast, LEVELS, SEVERITIES, debounce, clock } from '../ui.js';
import { api } from '../api.js';
import { S, sectionEditor, startAgent, runCycleNow } from '../app.js';
import { feedItem } from './overview.js';

const AUTONOMY = [
  { value: 'read_only', level: 1, name: 'Read-only', desc: 'Watches and reports. Never asks to change anything; advice goes into findings.' },
  { value: 'propose', level: 2, name: 'Propose', desc: 'May request commands or file changes. Each one waits for you to approve it.' },
  { value: 'allowlist', level: 3, name: 'Allowlist', desc: 'Runs actions that match your allowlist automatically. Everything else waits for approval.' },
  { value: 'full', level: 4, name: 'Full access', desc: 'Runs actions without asking, and coding-agent CLIs get write permissions. Use on systems you can rebuild.' },
];

export default {
  async render(root, params, ctx) {
    const ed = sectionEditor(ctx, 'agent', { label: 'Agent settings', onSaved: () => renderAll() });
    const d = ed.draft;
    const controls = h('div', { class: 'panel' });
    const settingsHost = h('div');
    const feed = h('ul', { class: 'feed' });

    mount(root,
      h('div', { class: 'page-head' }, h('div', null, h('h1', null, 'Agent'),
        h('p', { class: 'lede' }, 'Choose the model that does the analysis, how often it runs, how much it may read per request, and what it is allowed to change.'))),
      controls, settingsHost,
      h('div', { class: 'panel' }, h('div', { class: 'panel-head' }, h('h2', null, 'Activity'), h('p', null, 'Every cycle, model call and investigation. Open an entry to see the exact prompt and reply.')), feed),
      ed.bar);

    function renderControls() {
      const st = S.status || {};
      mount(controls,
        h('div', { class: 'panel-head' }, h('h2', null, st.running ? (st.busy ? cap(st.phase) : 'Watching') : 'Stopped'),
          h('div', { class: 'tools' },
            button('Preview next prompt', previewPrompt, { icon: 'eye' }),
            button('Run a cycle now', runCycleNow, { icon: 'refresh' }),
            st.running ? button('Stop', () => api.post('/api/agent/stop'), { icon: 'stop' }) : button('Start watching', startAgent, { kind: 'primary', icon: 'play' }))),
        h('div', { class: 'stat-row' },
          stat(st.provider?.label || '—', st.provider?.model || 'model'),
          stat(num(st.tokensLastHour || 0), st.hourlyTokenCap ? `tokens in the last hour, of ${num(st.hourlyTokenCap)}` : 'tokens in the last hour'),
          stat(num(st.effectiveContext || 0), 'context window used'),
          stat(num(st.pending?.patterns || 0), `patterns queued (${num(st.pending?.lines || 0)} lines)`)),
        st.lastError ? h('div', { class: 'callout callout-danger' }, h('p', null, h('strong', null, 'Last cycle failed: '), st.lastError)) : null);
    }

    function renderAll() {
      const provs = S.providers.map((p) => {
        const pc = S.config.providers[p.id] || {};
        const ready = p.kind === 'cli' ? true : !!pc.model;
        return { value: p.id, label: `${p.label}${p.kind === 'cli' ? ' (CLI)' : ''}${pc.model ? ` — ${pc.model}` : ready ? '' : ' — no model chosen'}${p.experimental ? ' (experimental)' : ''}` };
      });
      const ollamaCtx = Number(S.config.providers.ollama.numCtx) || 8192;
      const ctxNote = h('div', { class: 'hint' });
      const updateCtxNote = () => {
        const parts = [`Each request holds up to ${num(d.contextTokens)} tokens: your notes, known issues, metric signals and as many log patterns as fit, plus room for a ${num(d.maxOutputTokens)}-token reply.`];
        if (d.provider === 'ollama' && Number(d.contextTokens) > ollamaCtx) parts.push(`Ollama is set to a ${num(ollamaCtx)}-token window on the Connections page, so ${num(ollamaCtx)} is used. Raise "Context window" there too.`);
        ctxNote.textContent = parts.join(' ');
      };
      updateCtxNote();

      const autHost = h('div', { class: 'autonomy', role: 'radiogroup', 'aria-label': 'Autonomy level' });
      const autExtra = h('div');
      const renderAutExtra = () => {
        mount(autExtra,
          d.autonomy === 'full' ? h('div', { class: 'callout callout-danger' }, h('p', null, h('strong', null, 'Full access is on. '), 'Commands run as the user that started Log Sentinel, without approval. Coding-agent CLIs run with their own permission checks turned off (for example Claude Code with bypassPermissions, Codex with --dangerously-bypass-approvals-and-sandbox, Gemini CLI in yolo mode).')) : null,
          d.autonomy === 'read_only' ? null : h('div', { class: 'fields', style: { marginTop: '14px' } },
            d.autonomy === 'allowlist' ? field('Allowed commands', listInput(d, 'allowCommands', { placeholder: 'systemctl restart nginx\nsystemctl status *\nre:^docker (ps|logs) ' }),
              'One per line. * matches anything; prefix with re: for a regular expression. Commands that chain (; && |) or redirect still need approval unless the pattern is a regex.', { wide: true }) : null,
            d.autonomy === 'allowlist' ? field('Writable folders', listInput(d, 'writableRoots', { placeholder: '/etc/myapp/conf.d' }), 'File writes inside these folders run automatically. A backup of any replaced file is kept next to it.', { wide: true }) : null,
            field('Always ask for these', listInput(d, 'denyCommands', { rows: 4 }), 'Commands matching these patterns always wait for approval, even with full access. The defaults cover deleting from /, formatting disks, shutdowns and dropping databases.', { wide: true }),
            field('Command timeout (seconds)', input(d, 'actionTimeoutSec', { type: 'number', min: 5 })),
            field('Default working folder', input(d, 'actionCwd', { placeholder: 'first log folder', mono: true }), `Commands run through ${S.system.shell}.`)));
      };
      AUTONOMY.forEach((a) => {
        const id = `aut-${a.value}`;
        const inp = h('input', { type: 'radio', name: 'autonomy', id, value: a.value, checked: d.autonomy === a.value });
        inp.addEventListener('change', async () => {
          if (a.value === 'full' && !d.fullAccessAcknowledged) {
            const ok = await confirmFull();
            if (!ok) { autHost.querySelector(`#aut-${d.autonomy}`).checked = true; return; }
            d.fullAccessAcknowledged = true;
          }
          d.autonomy = a.value;
          renderAutExtra();
          ed.check();
        });
        autHost.appendChild(h('div', { class: 'aut-opt', dataset: { level: a.level } }, inp,
          h('label', { for: id }, h('span', { class: 'aut-scale', 'aria-hidden': 'true' }, h('i'), h('i'), h('i'), h('i')),
            h('span', { class: 'aut-name' }, a.name), h('span', { class: 'aut-desc' }, a.desc))));
      });
      renderAutExtra();

      mount(settingsHost,
        h('div', { class: 'panel' },
          h('div', { class: 'panel-head' }, h('h2', null, 'Model'), h('p', null, 'Set up keys, models and CLIs on ', h('a', { href: '#/connections' }, 'Connections'), '.')),
          h('div', { class: 'fields' },
            field('The agent uses', select(d, 'provider', provs, { onChange: updateCtxNote }), 'Coding-agent CLIs can also open the log files themselves during investigations.', { wide: true }))),
        h('div', { class: 'panel' },
          h('div', { class: 'panel-head' }, h('h2', null, 'Schedule and budget')),
          h('div', { class: 'fields' },
            field('Run every (seconds)', input(d, 'intervalSec', { type: 'number', min: 15 }), 'Quiet cycles with nothing to report skip the model call.'),
            field('Run early after this many errors', input(d, 'triggerLines', { type: 'number', min: 0 }), '0 turns this off. Errors and always-report lines count.'),
            field('Reporting level', select(d, 'minLevel', LEVELS.map((l) => ({ value: l, label: `${cap(l)} and above` }))), 'Lines below this level are counted but not sent. Sources and rules can override it.'),
            field('Context window (tokens)', input(d, 'contextTokens', { type: 'number', min: 2000, step: 1000, onChange: updateCtxNote }), ctxNote),
            field('Max reply (tokens)', input(d, 'maxOutputTokens', { type: 'number', min: 256, step: 256, onChange: updateCtxNote }), 'Thinking models spend part of this before answering.'),
            field('Hourly token cap', input(d, 'hourlyTokenCap', { type: 'number', min: 0, step: 10000 }), '0 means no cap. Cycles pause when the last hour reaches it.'),
            field('When patterns do not fit', select(d, 'overflow', [{ value: 'chunk', label: 'Split into several requests' }, { value: 'truncate', label: 'Send the most important only' }])),
            field('Max requests per cycle', input(d, 'maxChunks', { type: 'number', min: 1, max: 10 }), 'Used when splitting.'),
            field('Re-alert cooldown (minutes)', input(d, 'cooldownMin', { type: 'number', min: 0 }), 'An issue that comes back within this time does not alert again.')),
          h('div', { style: { marginTop: '10px' } }, checkbox(d, 'includeMetrics', 'Include metric anomalies, threshold breaches and host stats in the prompt'))),
        h('div', { class: 'panel' },
          h('div', { class: 'panel-head' }, h('h2', null, 'Autonomy'), h('p', null, 'What the agent may change on this machine. Every requested action is recorded on the Actions page.')),
          autHost, autExtra),
        h('div', { class: 'panel' },
          h('div', { class: 'panel-head' }, h('h2', null, 'Investigations')),
          h('p', { class: 'subtle' }, 'For serious findings the agent can dig further: search the log files, read around a timestamp and query metrics before writing its conclusion.'),
          h('div', { class: 'fields' },
            h('div', { class: 'field' }, checkbox(d, 'investigate.enabled', 'Allow investigations'), checkbox(d, 'investigate.auto', 'Start them automatically', { hint: 'Otherwise use the Investigate button on a finding.' })),
            field('Automatically for', select(d, 'investigate.minSeverity', SEVERITIES.slice(0, 4).map((s) => ({ value: s, label: `${cap(s)}${s === 'critical' ? '' : ' and above'}` })))),
            field('Max tool calls', input(d, 'investigate.maxSteps', { type: 'number', min: 1, max: 20 }), 'Each tool call is one more model request.'))),
        h('div', { class: 'panel' },
          h('div', { class: 'panel-head' }, h('h2', null, 'Extra instructions'), h('p', null, 'Applies to every request. Notes about specific logs belong on ', h('a', { href: '#/knowledge' }, 'Knowledge'), '.')),
          textarea(d, 'extraInstructions', { rows: 4, placeholder: 'e.g. We are a payments company: anything touching card authorisation is at least high severity. Write findings for an on-call engineer who may be half awake.' })));
    }

    async function loadFeed() {
      try {
        const items = await api.get('/api/activity?limit=150');
        mount(feed, items.length ? items.map((e) => {
          const li = feedItem(e);
          if (e.hasDetail) li.querySelector('.feed-title').appendChild(h('button', { class: 'linkish', style: { marginLeft: '10px' }, onclick: () => showDetail(e.id) }, 'Prompt and reply'));
          return li;
        }) : h('li', { class: 'subtle' }, 'Nothing yet. Start watching or run a cycle.'));
      } catch (e) { mount(feed, h('li', { class: 'result result-error' }, e.message)); }
    }

    renderControls();
    renderAll();
    loadFeed();
    ctx.on('status', renderControls);
    ctx.on('activity', debounce(loadFeed, 400));
  },
};

function stat(v, k) {
  return h('div', { class: 'stat' }, h('div', { class: 'stat-v' }, v), h('div', { class: 'stat-k' }, k));
}

function confirmFull() {
  return new Promise((resolve) => {
    let done = false;
    const st = { ack: false };
    const box = checkbox(st, 'ack', 'I understand the agent can run commands and change files without asking me.');
    modal({
      title: 'Turn on full access?',
      body: h('div', { class: 'stack' },
        h('p', null, 'With full access the agent runs the commands and file changes it decides on, immediately. Commands on your always-ask list still wait for approval. Coding-agent CLIs run with their own permission prompts disabled.'),
        h('p', null, 'Use it on systems you can restore, and keep the always-ask list in place.'), box),
      actions: [
        { label: 'Cancel', onClick: () => { done = true; resolve(false); } },
        { label: 'Turn on full access', kind: 'danger', onClick: () => {
          if (!st.ack) { toast('Tick the box to confirm first.', 'error'); return false; }
          done = true; resolve(true); return true;
        } },
      ],
      onClose: () => { if (!done) resolve(false); },
    });
  });
}

async function previewPrompt() {
  const p = await api.post('/api/agent/preview');
  const tabs = h('div', { class: 'tabs', role: 'tablist' });
  const pane = h('pre', { class: 'code', style: { maxHeight: '60vh' } });
  const parts = [{ label: 'Instructions', text: p.system }, ...p.chunks.map((c, i) => ({ label: p.chunks.length > 1 ? `Request ${i + 1} (${c.items} patterns)` : `Request (${c.items} patterns)`, text: c.user }))];
  parts.forEach((part, i) => {
    const t = h('button', { class: 'tab', role: 'tab', 'aria-selected': i === 1 ? 'true' : 'false', onclick: () => {
      tabs.querySelectorAll('.tab').forEach((x) => x.setAttribute('aria-selected', 'false'));
      t.setAttribute('aria-selected', 'true');
      pane.textContent = part.text;
    } }, part.label);
    tabs.appendChild(t);
  });
  pane.textContent = parts[1]?.text || parts[0].text;
  modal({
    title: 'Next prompt preview',
    wide: true,
    body: h('div', null,
      h('p', { class: 'subtle' }, `${p.provider.label}${p.provider.model ? `, ${p.provider.model}` : ''}. About ${num(p.tokens)} tokens in total, context window ${num(p.contextTokens)}. ${p.patterns} pattern${p.patterns === 1 ? '' : 's'} queued${p.omitted ? `, ${p.omitted} would be left out` : ''}. Nothing is sent by previewing.`),
      tabs, pane),
    actions: [{ label: 'Close' }],
  });
}

async function showDetail(id) {
  const r = await api.get(`/api/activity/${id}`);
  modal({
    title: r.entry.title,
    wide: true,
    body: h('div', null,
      h('p', { class: 'subtle' }, `${clock(r.entry.t)}${r.entry.provider ? `, ${r.entry.provider}` : ''}${r.entry.model ? `, ${r.entry.model}` : ''}`),
      r.detail ? [h('div', { class: 'section-label' }, 'Sent'), h('pre', { class: 'code' }, r.detail.prompt), h('div', { class: 'section-label' }, 'Received'), h('pre', { class: 'code' }, r.detail.response)]
        : h('p', null, 'The full text of older entries is not kept.')),
    actions: [{ label: 'Close' }],
  });
}
