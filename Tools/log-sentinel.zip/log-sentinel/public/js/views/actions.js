import { h, mount, button, clock, cap, emptyState, debounce, duration } from '../ui.js';
import { api } from '../api.js';
import { S } from '../app.js';

const AUT_TEXT = {
  read_only: 'The agent is read-only, so it cannot request actions. Change the autonomy level on the Agent page to allow proposals.',
  propose: 'Every action the agent requests waits here for you to approve it.',
  allowlist: 'Actions on your allowlist run automatically. Everything else waits here for approval.',
  full: 'Actions run immediately. Commands on the always-ask list still wait here.',
};

export default {
  async render(root, params, ctx) {
    const pendingHost = h('div');
    const historyHost = h('div');
    const load = async () => {
      let list;
      try { list = await api.get('/api/actions'); } catch (e) { mount(pendingHost, h('p', { class: 'result result-error' }, e.message)); return; }
      const pending = list.filter((a) => a.status === 'pending');
      const rest = list.filter((a) => a.status !== 'pending');
      mount(pendingHost, pending.length
        ? pending.map((a) => h('div', { class: 'panel' },
          h('div', { class: 'panel-head' },
            h('h2', null, a.type === 'run_command' ? 'Run a command' : `${a.mode === 'append' ? 'Append to' : 'Write'} a file`),
            h('div', { class: 'tools' }, h('span', { class: 'subtle' }, `${clock(a.createdAt)}${a.provider ? `, requested by ${a.provider}` : ''}`))),
          a.type === 'run_command'
            ? h('pre', { class: 'code' }, h('code', null, a.command))
            : [h('p', null, h('code', null, a.path)), h('pre', { class: 'code' }, h('code', null, a.content))],
          a.cwd ? h('p', { class: 'subtle' }, `Working folder: ${a.cwd}`) : null,
          a.reason ? h('p', null, h('strong', null, 'Why: '), a.reason) : null,
          a.findingId ? h('p', null, 'For finding: ', h('a', { href: `#/findings/${a.findingId}` }, a.findingTitle || 'view')) : null,
          h('p', { class: 'subtle' }, `Waiting because: ${a.decisionReason}`),
          h('div', { class: 'row' },
            button('Approve and run', () => api.post(`/api/actions/${a.id}/approve`).then(load), { kind: 'primary', icon: 'play' }),
            button('Reject', () => api.post(`/api/actions/${a.id}/reject`).then(load), { icon: 'x' }))))
        : h('div', { class: 'panel' }, emptyState('Nothing waiting for approval', AUT_TEXT[S.config.agent.autonomy])));
      mount(historyHost, rest.length ? h('div', { class: 'panel panel-flush' }, h('div', { class: 'panel-head' }, h('h2', null, 'History')),
        h('div', { class: 'table-wrap' }, h('table', { class: 'table' },
          h('thead', null, h('tr', null, h('th', null, 'When'), h('th', null, 'Action'), h('th', null, 'Status'), h('th', null, 'Result'))),
          h('tbody', null, rest.map((a) => h('tr', null,
            h('td', { style: { whiteSpace: 'nowrap' } }, clock(a.createdAt)),
            h('td', null, h('code', null, a.type === 'run_command' ? a.command : `${a.mode} ${a.path}`),
              a.findingId ? h('div', { class: 'cell-sub' }, h('a', { href: `#/findings/${a.findingId}` }, a.findingTitle || 'finding')) : null,
              h('div', { class: 'cell-sub' }, a.decisionReason)),
            h('td', null, h('span', { class: `chip ${a.status === 'done' ? 'chip-ok' : a.status === 'failed' ? 'chip-bad' : a.status === 'running' ? 'chip-accent' : ''}` }, cap(a.status)), a.autoApproved ? h('div', { class: 'cell-sub' }, 'auto-approved') : null),
            h('td', null, a.result ? h('details', { class: 'more' },
              h('summary', null, `${a.result.exitCode != null ? `exit ${a.result.exitCode}` : ''}${a.result.durationMs ? `, ${duration(a.result.durationMs)}` : ''}${a.result.error ? `, ${a.result.error}` : ''}` || 'Output'),
              h('pre', { class: 'code' }, [a.result.stdout, a.result.stderr].filter(Boolean).join('\n--- stderr ---\n') || '(no output)')) : '—'))))))) : null);
    };
    mount(root,
      h('div', { class: 'page-head' }, h('div', null, h('h1', null, 'Actions'),
        h('p', { class: 'lede' }, AUT_TEXT[S.config.agent.autonomy], ' ', h('a', { href: '#/agent' }, 'Change autonomy')))),
      pendingHost, historyHost);
    await load();
    ctx.on('action', debounce(load, 300));
  },
};
