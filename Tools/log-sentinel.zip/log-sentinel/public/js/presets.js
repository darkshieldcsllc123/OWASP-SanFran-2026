// Ready-made notes and rules for common logs. Applying one fills empty notes (or appends),
// adds rules that are not already present, and can suggest which files to include.

const OLLAMA_NOTES = `This is the Ollama server log (server.log, older runs in server-1.log, server-2.log, ...).

## This machine (edit to match)
- GPU: [e.g. NVIDIA RTX 4070, 12 GB VRAM, or "none, CPU only"]
- Models normally used: [e.g. qwen3:8b]
- Who calls Ollama: Log Sentinel (this monitor) from 127.0.0.1 once per cycle, plus [e.g. Open WebUI, scripts, nothing else]

## How to read this log
- Structured lines: time=... level=INFO|WARN|ERROR source=file.go:123 msg="...".
- Request lines: [GIN] date | status | duration | client IP | METHOD "/api/path".
- Lines starting with llama_model_loader:, print_info:, load_tensors:, llama_context: or ggml_ are printed while a model loads. They are normal unless they mention failed, error or out of memory.
- POST /api/chat from 127.0.0.1 at each cycle is Log Sentinel itself. GET /api/tags, /api/version, /api/ps and HEAD / are health checks. Do not report these unless they fail.

## Normal, not findings
- Startup lines: "Listening on", "server config", "inference compute", GPU discovery.
- A model loading again after a quiet period. Models unload after about 5 minutes idle by default.
- Slow loads that finish ("llama runner started in N seconds"), even a minute or more on first use.
- A single "context canceled": the client disconnected or the user stopped generation.
- Long request durations for large generations, especially on CPU.

## Report these
- Model fails to load or crashes (high; critical if every request fails): out of memory, cudaMalloc failed, unable to allocate, CUDA error, error loading model, "model requires more system memory", "timed out waiting for llama runner to start", "llama runner process has terminated". On Windows, exit status 0xc0000409 or 0xc0000005 means the runner crashed (often GPU driver or memory). On Linux, "signal: killed" usually means the system ran out of memory.
- Wrong hardware (high if a GPU is listed above): "no compatible GPUs were discovered", "inference compute" with library=cpu, or "offloaded X/Y layers to GPU" where X is less than Y (partial offload, much slower; medium). Name the model and the layer counts. Full offload (X equals Y) is normal.
- Prompts cut short (medium): WARN "truncating input prompt" limit=N prompt=M means the context window (num_ctx) was smaller than the prompt, so the model never saw part of it. If it lines up with Log Sentinel's POST /api/chat, say so: raise num_ctx on the Connections page or lower the agent's context window.
- Model thrashing (medium): the same models loading and unloading within a few minutes, or "gpu VRAM usage didn't recover within timeout". Too many models are competing for VRAM. Suggest OLLAMA_MAX_LOADED_MODELS, a longer keep_alive, or a smaller model.
- Failed requests: status 500 (high if repeated, critical if every /api/chat or /api/generate fails). A 404 or "not found, try pulling it first" is low: a client asked for a model that isn't installed; name the model.
- Download problems (medium): manifest errors, "max retries exceeded", DNS or TLS errors reaching registry.ollama.ai. "no space left on device" is critical.
- Server cannot start (critical): "address already in use" or "Only one usage of each socket address" means another process holds port 11434. A "panic:" followed by a goroutine trace is also critical.
- Model needs a newer Ollama (low): "unknown model architecture" or a message that it requires a newer version.

## Severity
critical = Ollama is down or every request fails. high = a model cannot run, or runs on CPU when a GPU is expected. medium = slower or lower-quality results. low = one-off client mistakes.
Always include the model name, the numbers (layers offloaded, GiB needed vs available, limit vs prompt) and the time.`;

const SETUPAPI_NOTES = `This is the Windows driver installation log (setupapi.dev.log).

## How to read this log
- Each install is a section that starts with ">>>  [Device Install ..." and ends with "<<<  [Exit status: ...]". Indented lines belong to the section above them.
- Lines starting with "!!!" are errors. Lines starting with a single "!" are warnings.
- "Exit status: SUCCESS" is a completed install. "Exit status: FAILURE(0x...)" is a failed one.

## Report these
- Failed installs (high): name the device (the text in the [Device Install ...] header), the hardware ID if shown, and the error code.
- The same device failing or reinstalling repeatedly (high): points to a bad or incompatible driver.
- Unsigned or blocked drivers (medium).
- Single warnings during an install that ends in SUCCESS are usually harmless (low or no finding).`;

export const PRESETS = [
  {
    id: 'ollama',
    name: 'Ollama server log',
    include: 'server*.log',
    notes: OLLAMA_NOTES,
    rules: [
      { type: 'severity', level: 'critical', regex: true, pattern: 'panic:|address already in use|Only one usage of each socket address|no space left on device', note: 'Ollama is down or cannot start' },
      { type: 'severity', level: 'error', regex: true, pattern: 'out of memory|cudaMalloc failed|failed to allocate|unable to allocate|CUDA error|error loading model|runner process has terminated|timed out waiting for llama runner|requires more system memory', note: 'Model failed to load or crashed' },
      { type: 'severity', level: 'error', regex: true, pattern: '^\\[GIN\\][^|]*\\| 5\\d\\d \\|', note: 'API request failed (status 5xx)' },
      { type: 'severity', level: 'warn', regex: true, pattern: '^\\[GIN\\][^|]*\\| 4\\d\\d \\|', note: 'Client error (status 4xx), e.g. a model that is not installed' },
      { type: 'always', regex: true, pattern: 'offloaded \\d+/\\d+ layers|no compatible GPUs|"inference compute"', note: 'GPU use: flag CPU fallback or partial offload. Turn this rule off on a machine without a GPU.' },
      { type: 'ignore', regex: true, pattern: 'key with type not found|key not found', note: 'Model-loader noise' },
    ],
  },
  {
    id: 'setupapi',
    name: 'Windows driver installs (setupapi.dev.log)',
    include: 'setupapi*.log',
    notes: SETUPAPI_NOTES,
    rules: [
      { type: 'severity', level: 'error', regex: true, pattern: '^!!!', note: 'setupapi error line' },
      { type: 'severity', level: 'error', regex: true, pattern: 'Exit status: FAILURE', note: 'Driver install failed' },
      { type: 'severity', level: 'warn', regex: true, pattern: '^!\\s', note: 'setupapi warning line' },
    ],
  },
];

let seq = 0;
/** Apply a preset to a source draft. Returns a short summary of what changed. */
export function applyPreset(src, preset) {
  const changes = [];
  const notes = (src.notes || '').trim();
  if (!notes) { src.notes = preset.notes; changes.push('notes added'); } else if (!notes.includes(preset.notes.split('\n')[0])) {
    src.notes = `${notes}\n\n${preset.notes}`;
    changes.push('notes added below yours');
  }
  src.rules = src.rules || [];
  let added = 0;
  for (const r of preset.rules) {
    if (src.rules.some((x) => x.pattern === r.pattern && x.type === r.type)) continue;
    src.rules.push({ id: `r_${Date.now().toString(36)}${(seq++).toString(36)}`, enabled: true, caseSensitive: false, sources: [], level: 'error', note: '', ...r });
    added++;
  }
  if (added) changes.push(`${added} rule${added === 1 ? '' : 's'} added`);
  if (preset.include && (!src.include || src.include.trim() === '*')) {
    src.include = preset.include;
    changes.push(`files limited to ${preset.include}`);
  }
  return changes;
}
