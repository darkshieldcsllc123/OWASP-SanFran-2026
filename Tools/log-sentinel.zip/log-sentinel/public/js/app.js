// App shell: state, live events, routing, status bar, sign-in.
import { api, setAuthHandler } from './api.js';
import { h, mount, icon, toast, ago, until, compact, clone, button, debounce, cap, confirmDialog } from './ui.js';

import overview from './views/overview.js';
import findings from './views/findings.js';
import actions from './views/actions.js';
import agent from './views/agent.js';
import sources from './views/sources.js';
import knowledge from './views/knowledge.js';
import metrics from './views/metrics.js';
import connections from './views/connections.js';
import alerts from './views/alerts.js';
import settings from './views/settings.js';

export const S = { config: null, status: null, providers: [], system: null, sources: [], notifications: [], pulls: {}, ready: false };

const VIEWS = { overview, findings, actions, agent, sources, knowledge, metrics, connections, alerts, settings };
const NAV = [
  [['overview', 'Overview'], ['findings', 'Findings'], ['actions', 'Actions']],
  [['agent', 'Agent'], ['sources', 'Log sources'], ['knowledge', 'Knowledge'], ['metrics', 'Metrics']],
  [['connections', 'Connections'], ['alerts', 'Alerts'], ['settings', 'Settings']],
];

// ---- tiny event hub ------------------------------------------------------------------
const hub = new Map();
export function on(type, fn) {
  if (!hub.has(type)) hub.set(type, new Set());
  hub.get(type).add(fn);
  return () => hub.get(type)?.delete(fn);
}
export function emit(type, data) {
  for (const fn of hub.get(type) || []) { try { fn(data); } catch (e) { console.error(e); } }
}

export function providerLabel(id) {
  return S.providers.find((p) => p.id === id)?.label || id;
}

// ---- section editor: a draft of one config section with a sticky save bar -------------------
export function sectionEditor(ctx, section, { onSaved, label, onDiscard } = {}) {
  const draft = clone(S.config[section]);
  let saved = JSON.stringify(S.config[section]);
  const bar = h('div', { class: 'savebar', hidden: true, role: 'region', 'aria-label': 'Unsaved changes' });
  const ed = {
    draft,
    bar,
    dirty: () => JSON.stringify(draft) !== saved,
    check: () => { bar.hidden = !ed.dirty(); },
    async save() {
      const r = await api.put(`/api/config/${section}`, draft);
      S.config[section] = r.section;
      saved = JSON.stringify(r.section);
      if (Array.isArray(draft)) draft.splice(0, draft.length, ...clone(r.section));
      else { for (const k of Object.keys(draft)) delete draft[k]; Object.assign(draft, clone(r.section)); }
      ed.check();
      toast(`${label || cap(section)} saved`, 'ok', { timeout: 2200 });
      onSaved && onSaved(r);
      return r;
    },
    discard() {
      const fresh = clone(S.config[section]);
      if (Array.isArray(draft)) draft.splice(0, draft.length, ...fresh);
      else { for (const k of Object.keys(draft)) delete draft[k]; Object.assign(draft, fresh); }
      ed.check();
      if (onDiscard) onDiscard(); else ctx.rerender();
    },
  };
  mount(bar, h('span', { class: 'savebar-text' }, 'You have unsaved changes'),
    button('Discard', () => ed.discard(), { kind: 'ghost' }),
    button('Save changes', () => ed.save(), { kind: 'primary' }));
  ctx.dirtyChecks.push(ed.dirty);
  ctx.root.addEventListener('input', debounce(ed.check, 120));
  ctx.root.addEventListener('change', debounce(ed.check, 60));
  ctx.root.addEventListener('ls-change', ed.check);
  return ed;
}

// ---- routing -------------------------------------------------------------------------
let current = null;
let viewHost;
let lastHash = '';
let suppressHash = false;

function makeCtx(params) {
  const offs = [];
  const timers = [];
  const ctx = {
    params,
    root: null,
    dirtyChecks: [],
    on: (type, fn) => { offs.push(on(type, fn)); },
    every: (ms, fn) => { timers.push(setInterval(fn, ms)); },
    navigate: (hash) => { location.hash = hash; },
    rerender: () => route(true),
    dispose: () => { offs.forEach((f) => f()); timers.forEach((t) => clearInterval(t)); },
    isDirty: () => ctx.dirtyChecks.some((f) => f()),
  };
  return ctx;
}

async function route(force) {
  if (suppressHash) { suppressHash = false; return; }
  const hash = location.hash || '#/overview';
  const [pathPart, queryPart] = hash.split('?');
  const [name, ...params] = pathPart.replace(/^#\/?/, '').split('/').map(decodeURIComponent);
  const view = VIEWS[name] || overview;
  if (!force && current && current.ctx.isDirty() && hash !== lastHash) {
    const leave = await confirmDialog('Leave without saving?', 'You have changes on this page that are not saved yet.', { confirm: 'Leave page' });
    if (!leave) { suppressHash = true; location.hash = lastHash; return; }
  }
  lastHash = hash;
  if (current) current.ctx.dispose();
  const ctx = makeCtx(params);
  ctx.query = new URLSearchParams(queryPart || '');
  const root = h('div', { class: `view view-${name || 'overview'}` });
  ctx.root = root;
  current = { view, ctx, name };
  mount(viewHost, root);
  document.querySelectorAll('.nav-link').forEach((a) => a.setAttribute('aria-current', a.dataset.view === (VIEWS[name] ? name : 'overview') ? 'page' : 'false'));
  document.body.classList.remove('nav-open');
  try {
    await view.render(root, params, ctx);
  } catch (e) {
    console.error(e);
    mount(root, h('div', { class: 'panel error-panel' }, h('h2', null, 'This page failed to load'), h('p', null, e.message)));
  }
  if (!force) { viewHost.scrollTop = 0; window.scrollTo(0, 0); }
}

window.addEventListener('beforeunload', (e) => {
  if (current && current.ctx.isDirty()) { e.preventDefault(); e.returnValue = ''; }
});

// ---- status bar ----------------------------------------------------------------------
let bar;
const navBadges = {};

let nextEl = null;
const AUT_SHORT = { read_only: 'Read-only', propose: 'Propose', allowlist: 'Allowlist', full: 'Full access' };
const nextText = (st) => (st.running && !st.busy && st.nextCycleAt ? `Next cycle in ${until(st.nextCycleAt)}` : st.running ? '' : 'Not watching');

function renderStatusBar() {
  if (!bar || !S.status) return;
  const st = S.status;
  const focusKey = bar.contains(document.activeElement) ? document.activeElement.dataset.key : null;
  nextEl = h('span', null, nextText(st));
  const failed = st.lastError && !st.busy;
  const state = !st.running ? 'stopped' : st.busy ? 'busy' : failed ? 'failed' : 'watching';
  const stateText = { stopped: 'Stopped', busy: cap(st.phase || 'working'), failed: 'Last cycle failed', watching: 'Watching' }[state];
  const cap1 = st.hourlyTokenCap || 0;
  const pct = cap1 ? Math.min(100, (st.tokensLastHour / cap1) * 100) : 0;
  const unread = S.notifications.filter((n) => !n.read).length;
  const model = st.provider?.model ? st.provider.model : 'no model chosen';
  mount(bar,
    h('button', { class: 'icon-btn menu-btn', 'aria-label': 'Menu', dataset: { key: 'menu' }, onclick: () => document.body.classList.toggle('nav-open') }, icon('menu')),
    h('div', { class: `watch watch-${state}`, title: st.lastError || '' },
      h('span', { class: 'lamp', 'aria-hidden': 'true' }),
      h('span', { class: 'watch-text' }, stateText)),
    h('a', { class: 'wb-seg wb-provider', href: '#/connections', title: 'Model used by the agent' },
      h('span', { class: 'wb-strong' }, st.provider?.label || '—'), h('span', { class: 'wb-dim' }, model)),
    h('a', { class: `wb-seg wb-autonomy aut-${st.autonomy}`, href: '#/agent', title: `Autonomy: ${st.autonomyLabel || ''}` }, AUT_SHORT[st.autonomy] || ''),
    h('span', { class: 'wb-seg wb-next' },
      nextEl,
      st.pending && st.pending.patterns ? h('span', { class: 'wb-dim' }, `${st.pending.patterns} pattern${st.pending.patterns === 1 ? '' : 's'} queued`) : null),
    cap1 ? h('span', { class: 'wb-seg wb-tokens', title: `${st.tokensLastHour.toLocaleString()} of ${cap1.toLocaleString()} tokens used in the last hour` },
      h('span', { class: 'wb-dim' }, 'Tokens/h'),
      h('span', { class: 'meter', role: 'meter', 'aria-valuenow': Math.round(pct), 'aria-valuemin': 0, 'aria-valuemax': 100, 'aria-label': 'Hourly token budget used' },
        h('span', { class: ['meter-fill', pct > 85 && 'meter-hot'], style: { width: `${pct}%` } })),
      h('span', null, compact(st.tokensLastHour))) : null,
    h('span', { class: 'wb-spacer' }),
    st.pendingActions ? h('a', { class: 'wb-approvals', href: '#/actions', dataset: { key: 'approvals' } }, `${st.pendingActions} awaiting approval`) : null,
    st.running
      ? button('Stop', () => api.post('/api/agent/stop').then((s) => { S.status = s; renderStatusBar(); }), { icon: 'stop', small: true, kind: 'ghost' })
      : button('Start watching', startAgent, { icon: 'play', small: true, kind: 'primary' }),
    h('button', { class: 'icon-btn bell', 'aria-label': `Notifications${unread ? `, ${unread} unread` : ''}`, dataset: { key: 'bell' }, onclick: toggleNotifications },
      icon('alerts'), unread ? h('span', { class: 'bell-count' }, unread > 9 ? '9+' : String(unread)) : null));
  const toggleBtn = bar.querySelector('.btn');
  if (toggleBtn) toggleBtn.dataset.key = 'toggle';
  if (focusKey) bar.querySelector(`[data-key="${focusKey}"]`)?.focus();
  // nav badges
  const c = st.counts || {};
  const open = (c.bySeverity?.critical || 0) + (c.bySeverity?.high || 0);
  setBadge('findings', open, (c.bySeverity?.critical || 0) ? 'crit' : 'high');
  setBadge('actions', st.pendingActions || 0, 'accent');
}

// Show the outcome of the next cycle as a toast, since the request itself returns immediately.
// Start watching before sending the request: a quiet cycle can finish before the response arrives.
// Returns a function that stops watching.
export function watchCycleResult() {
  let timer;
  const off = on('activity', (e) => {
    if (!['llm', 'quiet', 'error'].includes(e.type)) return;
    stop();
    const kind = e.status === 'error' ? 'error' : e.type === 'llm' ? 'ok' : 'info';
    const action = e.type === 'llm'
      ? { label: 'See findings', fn: () => { location.hash = '#/findings'; } }
      : { label: 'Activity', fn: () => { location.hash = '#/agent'; } };
    toast(`${e.title}${e.detail ? `. ${e.detail}` : ''}`, kind, { timeout: 15000, action });
  });
  const stop = () => { off(); clearTimeout(timer); };
  timer = setTimeout(stop, 15 * 60e3);
  return stop;
}

export async function runCycleNow() {
  const stop = watchCycleResult();
  let r;
  try { r = await api.post('/api/agent/run'); } catch (e) { stop(); throw e; }
  if (r.busy) { toast('A cycle is already running. Its result will appear here when it finishes.', 'info'); return; }
  const p = r.pending || {};
  if (p.patterns) toast(`Analyzing ${p.patterns} pattern${p.patterns === 1 ? '' : 's'} from ${(p.lines || 0).toLocaleString()} new lines with ${S.status?.provider?.label || 'the model'}…`, 'info', { timeout: 4000 });
}

export async function startAgent() {
  const st = S.status;
  const p = S.config.providers[S.config.agent.provider];
  const prov = S.providers.find((x) => x.id === S.config.agent.provider);
  if (prov && prov.kind !== 'cli' && !p.model) {
    toast(`Choose a ${prov.label} model on the Connections page first.`, 'error', { action: { label: 'Open Connections', fn: () => { location.hash = '#/connections'; } } });
    return;
  }
  if (!S.config.sources.some((s) => s.enabled && s.path)) {
    toast('Add a log source first so the agent has something to watch.', 'error', { action: { label: 'Add a source', fn: () => { location.hash = '#/sources'; } } });
    return;
  }
  S.status = await api.post('/api/agent/start');
  renderStatusBar();
  toast(`Watching with ${st?.provider?.label || 'the agent'}`, 'ok', { timeout: 2500 });
}

function setBadge(view, n, kind) {
  const el = navBadges[view];
  if (!el) return;
  el.hidden = !n;
  el.textContent = n > 99 ? '99+' : String(n);
  el.className = `nav-badge badge-${kind}`;
}

let notifPanel = null;
function toggleNotifications() {
  if (notifPanel) { notifPanel.remove(); notifPanel = null; return; }
  notifPanel = h('div', { class: 'notif-panel', role: 'dialog', 'aria-label': 'Notifications' },
    h('div', { class: 'notif-head' }, h('strong', null, 'Notifications'),
      S.notifications.length ? h('button', { class: 'linkish', onclick: () => { api.post('/api/notifications/read'); S.notifications.forEach((n) => { n.read = true; }); renderStatusBar(); notifPanel?.remove(); notifPanel = null; } }, 'Mark all read') : null),
    S.notifications.length
      ? h('ul', { class: 'notif-list' }, S.notifications.slice(0, 30).map((n) => h('li', { class: ['notif', !n.read && 'unread'] },
        h('a', { href: n.findingId ? `#/findings/${n.findingId}` : n.actionId ? '#/actions' : '#/overview', onclick: () => { notifPanel?.remove(); notifPanel = null; } },
          h('span', { class: `sev-dot dot-${n.severity}`, 'aria-hidden': 'true' }),
          h('span', { class: 'notif-body' }, h('span', { class: 'notif-title' }, n.title), h('span', { class: 'notif-meta' }, `${kindLabel(n.kind)}, ${ago(n.t)}`))))))
      : h('p', { class: 'notif-empty' }, 'Nothing yet. New findings and approval requests show up here.'));
  document.body.appendChild(notifPanel);
  setTimeout(() => document.addEventListener('mousedown', function close(e) {
    if (notifPanel && !notifPanel.contains(e.target) && !e.target.closest('.bell')) { notifPanel.remove(); notifPanel = null; document.removeEventListener('mousedown', close); }
  }), 0);
}

function kindLabel(k) {
  return { finding: 'New finding', escalation: 'Severity raised', regression: 'Came back', action_pending: 'Needs approval', threshold: 'Threshold breached', threshold_clear: 'Threshold cleared', test: 'Test' }[k] || k;
}

// ---- live events ---------------------------------------------------------------------
let es;
function connectEvents() {
  if (es) es.close();
  es = new EventSource('/api/events');
  const j = (fn) => (e) => { try { fn(JSON.parse(e.data)); } catch (err) { console.error(err); } };
  es.addEventListener('hello', () => { document.body.classList.remove('offline'); });
  es.addEventListener('status', j((s) => { S.status = s; renderStatusBar(); emit('status', s); }));
  es.addEventListener('activity', j((a) => emit('activity', a)));
  es.addEventListener('finding', j((f) => emit('finding', f)));
  es.addEventListener('action', j((a) => emit('action', a)));
  es.addEventListener('sources', j((s) => { S.sources = s; emit('sources', s); }));
  es.addEventListener('anomaly', j((a) => emit('anomaly', a)));
  es.addEventListener('pull', j((p) => { S.pulls[p.model] = p; emit('pull', p); }));
  es.addEventListener('config', j(async () => {
    try { S.config = await api.get('/api/config'); emit('config', S.config); } catch { /* ignore */ }
  }));
  es.addEventListener('notification', j((n) => {
    S.notifications.unshift(n);
    renderStatusBar();
    const sevKind = n.severity === 'critical' || n.severity === 'high' ? 'error' : 'info';
    toast(`${kindLabel(n.kind)}: ${n.title}`, sevKind, { timeout: 7000, action: n.findingId ? { label: 'Open', fn: () => { location.hash = `#/findings/${n.findingId}`; } } : n.actionId ? { label: 'Review', fn: () => { location.hash = '#/actions'; } } : null });
    if (document.hidden && 'Notification' in window && Notification.permission === 'granted' && localPref('desktopNotify')) {
      try { new Notification(`Log Sentinel: ${kindLabel(n.kind)}`, { body: n.title, tag: n.id }); } catch { /* unsupported */ }
    }
    emit('notification', n);
  }));
  es.onerror = () => { document.body.classList.add('offline'); };
}

export function localPref(k, v) {
  try {
    if (v === undefined) return JSON.parse(localStorage.getItem(`ls.${k}`) || 'null');
    localStorage.setItem(`ls.${k}`, JSON.stringify(v));
  } catch { /* storage unavailable */ }
  return v;
}

// ---- boot ----------------------------------------------------------------------------
function shell() {
  const rail = h('aside', { class: 'rail' },
    h('a', { class: 'brand', href: '#/overview' },
      h('span', { class: 'brand-mark', 'aria-hidden': 'true', html: '<svg viewBox="0 0 32 32" width="26" height="26"><rect width="32" height="32" rx="6" fill="currentColor"/><path d="M5 18h5l3-8 4 13 3-9 2 4h5" fill="none" stroke="var(--rail)" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"/></svg>' }),
      h('span', { class: 'brand-name' }, 'Log Sentinel')),
    h('nav', { 'aria-label': 'Main' }, NAV.map((group) => h('ul', { class: 'nav-group' }, group.map(([id, label]) => {
      const badge = h('span', { class: 'nav-badge', hidden: true });
      navBadges[id] = badge;
      return h('li', null, h('a', { class: 'nav-link', href: `#/${id}`, dataset: { view: id } }, icon(id), h('span', null, label), badge));
    })))),
    h('div', { class: 'rail-foot' }, h('span', null, S.system?.hostname || ''), h('span', null, `v${S.system?.version || ''}`)));
  bar = h('header', { class: 'watchbar' });
  viewHost = h('main', { class: 'viewhost', id: 'main', tabindex: '-1' });
  mount(document.getElementById('app'),
    h('a', { class: 'skip', href: '#main', onclick: (e) => { e.preventDefault(); viewHost.focus(); } }, 'Skip to content'),
    h('div', { class: 'app' }, rail, h('div', { class: 'main-col' }, bar, h('div', { class: 'offline-note', role: 'alert' }, 'Lost connection to the server. Retrying…'), viewHost)));
}

function loginScreen(message) {
  const tokenInput = h('input', { class: 'input mono', type: 'password', autocomplete: 'current-password', placeholder: 'Paste the access token', 'aria-label': 'Access token' });
  const err = h('p', { class: 'login-error', role: 'alert' }, message || '');
  const submit = async (e) => {
    e.preventDefault();
    try {
      await api.post('/api/auth/login', { token: tokenInput.value.trim() });
      boot();
    } catch (ex) { err.textContent = ex.message; tokenInput.select(); }
  };
  mount(document.getElementById('app'), h('div', { class: 'login' },
    h('form', { class: 'login-card', onsubmit: submit },
      h('div', { class: 'brand login-brand' }, h('span', { class: 'brand-name' }, 'Log Sentinel')),
      h('h1', null, 'Sign in'),
      h('p', null, 'This server is shared on the network, so it needs its access token. The token is printed in the server console when it starts, and shown under Settings, Access on the host computer.'),
      tokenInput, err,
      h('button', { class: 'btn btn-primary', type: 'submit' }, 'Sign in'))));
  setTimeout(() => tokenInput.focus(), 30);
}

async function boot() {
  let auth;
  try { auth = await api.get('/api/auth/status'); } catch (e) {
    mount(document.getElementById('app'), h('div', { class: 'boot' }, e.message));
    setTimeout(boot, 3000);
    return;
  }
  if (auth.required && !auth.authenticated) { loginScreen(); return; }
  const st = await api.get('/api/state');
  Object.assign(S, st, { ready: true });
  S.pulls = Object.fromEntries((st.pulls || []).map((p) => [p.model, p]));
  shell();
  renderStatusBar();
  connectEvents();
  setInterval(() => { if (nextEl && S.status) nextEl.textContent = nextText(S.status); }, 1000);
  window.addEventListener('hashchange', () => route(false));
  if (!location.hash || location.hash === '#/' || location.hash === '#') location.hash = st.firstRun || !st.config.sources.length ? '#/overview' : '#/overview';
  route(false);
}

// Theme: system by default; Settings > Appearance stores an override per browser.
const theme = localPref('theme');
if (theme === 'light' || theme === 'dark') document.documentElement.dataset.theme = theme;

setAuthHandler(() => { if (es) es.close(); loginScreen('Your session ended. Sign in again.'); });
boot();
