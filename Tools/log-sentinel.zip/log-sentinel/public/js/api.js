// Thin fetch wrapper. Every mutating request carries the CSRF header the server expects.
let onAuthRequired = () => {};
export function setAuthHandler(fn) { onAuthRequired = fn; }

async function request(method, url, body) {
  const opts = { method, headers: { 'x-ls-client': '1' }, credentials: 'same-origin' };
  if (body !== undefined) {
    opts.headers['content-type'] = 'application/json';
    opts.body = JSON.stringify(body);
  }
  let res;
  try {
    res = await fetch(url, opts);
  } catch {
    throw new Error('Cannot reach the Log Sentinel server. Is it still running?');
  }
  const text = await res.text();
  let data = null;
  try { data = text ? JSON.parse(text) : null; } catch { data = text; }
  if (res.status === 401 && data && data.auth) {
    onAuthRequired();
    throw new Error('Sign in required');
  }
  if (!res.ok) {
    const msg = (data && data.error) || (typeof data === 'string' ? data : '') || res.statusText;
    const e = new Error(msg);
    e.status = res.status;
    throw e;
  }
  return data;
}

export const api = {
  get: (u) => request('GET', u),
  post: (u, b = {}) => request('POST', u, b),
  put: (u, b = {}) => request('PUT', u, b),
  del: (u) => request('DELETE', u),
};
