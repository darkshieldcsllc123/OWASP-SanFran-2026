// DOM helpers, form controls, modals, toasts and formatters. No frameworks.

/** h('div', { class: 'x', onclick: fn }, child, [children], 'text') */
export function h(tag, attrs, ...children) {
  const el = tag === 'svg' || tag === 'path' || tag === 'circle' || tag === 'line' || tag === 'rect' || tag === 'g' || tag === 'polyline' || tag === 'text'
    ? document.createElementNS('http://www.w3.org/2000/svg', tag)
    : document.createElement(tag);
  if (attrs && (typeof attrs !== 'object' || attrs instanceof Node || Array.isArray(attrs))) {
    children.unshift(attrs);
    attrs = null;
  }
  for (const [k, v] of Object.entries(attrs || {})) {
    if (v == null || v === false) continue;
    if (k === 'class') el.setAttribute('class', Array.isArray(v) ? v.filter(Boolean).join(' ') : v);
    else if (k === 'style' && typeof v === 'object') Object.assign(el.style, v);
    else if (k === 'dataset') Object.assign(el.dataset, v);
    else if (k.startsWith('on') && typeof v === 'function') el.addEventListener(k.slice(2).toLowerCase(), v);
    else if (k === 'value' && 'value' in el) el.value = v;
    else if (k === 'checked' || k === 'disabled' || k === 'selected' || k === 'open') el[k] = !!v;
    else if (k === 'html') el.innerHTML = v; // only ever used with static strings
    else el.setAttribute(k, v === true ? '' : v);
  }
  append(el, children);
  return el;
}

function append(el, children) {
  for (const c of children) {
    if (c == null || c === false || c === true) continue;
    if (Array.isArray(c)) append(el, c);
    else el.appendChild(c instanceof Node ? c : document.createTextNode(String(c)));
  }
}

export function clear(el) { while (el.firstChild) el.removeChild(el.firstChild); return el; }
export function mount(el, ...children) { clear(el); append(el, children); return el; }

// ---- icons (static SVG markup) ----------------------------------------------------
const ICONS = {
  overview: '<path d="M4 14a8 8 0 1 1 16 0"/><path d="M12 14l4-5"/><path d="M4 18h16"/>',
  findings: '<path d="M12 3l9.5 17h-19z"/><path d="M12 10v4"/><path d="M12 17.5v.01"/>',
  actions: '<path d="M4 6h16v12H4z"/><path d="M7 10l3 2-3 2"/><path d="M12 15h5"/>',
  agent: '<circle cx="12" cy="12" r="8"/><circle cx="12" cy="12" r="3"/><path d="M12 4v3M12 17v3M4 12h3M17 12h3"/>',
  sources: '<path d="M6 3h8l4 4v14H6z"/><path d="M14 3v4h4"/><path d="M9 12h6M9 15h6M9 18h4"/>',
  knowledge: '<path d="M5 4h10a4 4 0 0 1 4 4v12H9a4 4 0 0 1-4-4z"/><path d="M5 16a4 4 0 0 1 4-4h10"/>',
  metrics: '<path d="M4 20V10M10 20V4M16 20v-7M22 20H2"/>',
  connections: '<path d="M9 7V3M15 7V3"/><path d="M6 7h12v4a6 6 0 0 1-12 0z"/><path d="M12 17v4"/>',
  alerts: '<path d="M6 16V11a6 6 0 1 1 12 0v5l2 2H4z"/><path d="M10 21h4"/>',
  settings: '<path d="M4 6h10M18 6h2M4 12h4M12 12h8M4 18h12M20 18h0"/><circle cx="16" cy="6" r="2"/><circle cx="10" cy="12" r="2"/><circle cx="18" cy="18" r="2"/>',
  folder: '<path d="M3 6h6l2 2h10v11H3z"/>',
  file: '<path d="M6 3h8l4 4v14H6z"/><path d="M14 3v4h4"/>',
  check: '<path d="M5 12l5 5 9-10"/>',
  x: '<path d="M6 6l12 12M18 6L6 18"/>',
  play: '<path d="M7 5l12 7-12 7z"/>',
  stop: '<path d="M6 6h12v12H6z"/>',
  refresh: '<path d="M20 12a8 8 0 1 1-2.3-5.6"/><path d="M20 4v5h-5"/>',
  plus: '<path d="M12 5v14M5 12h14"/>',
  trash: '<path d="M4 7h16M10 11v6M14 11v6M6 7l1 13h10l1-13M9 7V4h6v3"/>',
  up: '<path d="M6 15l6-6 6 6"/>',
  copy: '<path d="M8 8h11v11H8z"/><path d="M5 16V5h11"/>',
  eye: '<path d="M2 12s4-7 10-7 10 7 10 7-4 7-10 7S2 12 2 12z"/><circle cx="12" cy="12" r="3"/>',
  search: '<circle cx="11" cy="11" r="6"/><path d="M16 16l5 5"/>',
  chat: '<path d="M4 5h16v11H9l-5 4z"/>',
  menu: '<path d="M4 7h16M4 12h16M4 17h16"/>',
  chev: '<path d="M9 6l6 6-6 6"/>',
};

export function icon(name, size = 18) {
  const s = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
  s.setAttribute('viewBox', '0 0 24 24');
  s.setAttribute('width', size);
  s.setAttribute('height', size);
  s.setAttribute('fill', 'none');
  s.setAttribute('stroke', 'currentColor');
  s.setAttribute('stroke-width', '1.8');
  s.setAttribute('stroke-linecap', 'round');
  s.setAttribute('stroke-linejoin', 'round');
  s.setAttribute('aria-hidden', 'true');
  s.setAttribute('class', 'icon');
  s.innerHTML = ICONS[name] || '';
  return s;
}

// ---- formatting -------------------------------------------------------------------
export function ago(t) {
  if (!t) return '—';
  const s = Math.round((Date.now() - t) / 1000);
  if (s < 5) return 'just now';
  if (s < 60) return `${s}s ago`;
  if (s < 3600) return `${Math.round(s / 60)} min ago`;
  if (s < 86400) return `${Math.round(s / 3600)} h ago`;
  return `${Math.round(s / 86400)} d ago`;
}
export function until(t) {
  if (!t) return '—';
  const s = Math.max(0, Math.round((t - Date.now()) / 1000));
  if (s < 60) return `${s}s`;
  return `${Math.floor(s / 60)}m ${String(s % 60).padStart(2, '0')}s`;
}
export function clock(t) {
  if (!t) return '';
  const d = new Date(t);
  const today = new Date().toDateString() === d.toDateString();
  return today ? d.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' })
    : d.toLocaleString([], { month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' });
}
export function bytes(n) {
  if (n == null || !Number.isFinite(n)) return '—';
  const u = ['B', 'KB', 'MB', 'GB', 'TB'];
  let i = 0;
  while (n >= 1024 && i < u.length - 1) { n /= 1024; i++; }
  return `${n.toFixed(n >= 10 || i === 0 ? 0 : 1)} ${u[i]}`;
}
export function num(n, digits = 0) {
  if (n == null || !Number.isFinite(Number(n))) return '—';
  return Number(n).toLocaleString(undefined, { maximumFractionDigits: digits });
}
export function compact(n) {
  if (n == null || !Number.isFinite(n)) return '—';
  if (Math.abs(n) >= 1e6) return `${(n / 1e6).toFixed(1)}M`;
  if (Math.abs(n) >= 1e4) return `${Math.round(n / 1e3)}k`;
  if (Math.abs(n) >= 1e3) return `${(n / 1e3).toFixed(1)}k`;
  return Number.isInteger(n) ? String(n) : n.toFixed(Math.abs(n) < 10 ? 2 : 1);
}
export function duration(ms) {
  if (ms == null) return '';
  if (ms < 1000) return `${ms} ms`;
  if (ms < 60000) return `${(ms / 1000).toFixed(1)} s`;
  return `${Math.floor(ms / 60000)}m ${Math.round((ms % 60000) / 1000)}s`;
}

export const SEVERITIES = ['critical', 'high', 'medium', 'low', 'info'];
export const LEVELS = ['trace', 'debug', 'info', 'warn', 'error', 'critical'];
export const cap = (s) => (s ? s[0].toUpperCase() + s.slice(1) : '');

export function sevBadge(sev) {
  return h('span', { class: `sev sev-${sev}` }, h('span', { class: 'sev-dot', 'aria-hidden': 'true' }), cap(sev));
}
export function levelTag(level) {
  return h('span', { class: `lvl lvl-${level}` }, level);
}

// ---- deep get / set ----------------------------------------------------------------
export function getPath(obj, p) {
  return p.split('.').reduce((o, k) => (o == null ? undefined : o[k]), obj);
}
export function setPath(obj, p, v) {
  const ks = p.split('.');
  let o = obj;
  for (let i = 0; i < ks.length - 1; i++) { if (o[ks[i]] == null) o[ks[i]] = {}; o = o[ks[i]]; }
  o[ks[ks.length - 1]] = v;
}
export const clone = (o) => JSON.parse(JSON.stringify(o));

// ---- form controls bound to an object ------------------------------------------------
let fieldSeq = 0;
const fid = () => `f${++fieldSeq}`;

/** Text/number/password input bound to obj[path]. */
export function input(obj, path, { type = 'text', placeholder = '', min, max, step, onChange, list, width, autocomplete = 'off', mono } = {}) {
  const v = getPath(obj, path);
  const el = h('input', {
    type, placeholder, min, max, step, list, autocomplete, spellcheck: 'false',
    class: ['input', mono && 'mono'], value: v == null ? '' : String(v), style: width ? { width } : null,
  });
  el.addEventListener('input', () => {
    let val = el.value;
    if (type === 'number') val = val === '' ? '' : Number(val);
    setPath(obj, path, val);
    onChange && onChange(val);
  });
  return el;
}

export function textarea(obj, path, { rows = 4, placeholder = '', onChange, mono } = {}) {
  const el = h('textarea', { rows, placeholder, spellcheck: mono ? 'false' : 'true', class: ['input', 'textarea', mono && 'mono'] });
  el.value = getPath(obj, path) ?? '';
  el.addEventListener('input', () => { setPath(obj, path, el.value); onChange && onChange(el.value); });
  return el;
}

/** options: [{ value, label }] or ['a','b'] */
export function select(obj, path, options, { onChange, width } = {}) {
  const cur = getPath(obj, path);
  const el = h('select', { class: 'input select', style: width ? { width } : null },
    options.map((o) => {
      const op = typeof o === 'object' ? o : { value: o, label: o };
      return h('option', { value: op.value, selected: String(op.value) === String(cur ?? '') }, op.label);
    }));
  el.addEventListener('change', () => {
    const op = options.find((o) => String(typeof o === 'object' ? o.value : o) === el.value);
    const val = op && typeof op === 'object' && typeof op.value === 'number' ? Number(el.value) : el.value;
    setPath(obj, path, val);
    onChange && onChange(val);
  });
  return el;
}

export function checkbox(obj, path, label, { onChange, hint } = {}) {
  const id = fid();
  const el = h('input', { type: 'checkbox', id, checked: !!getPath(obj, path) });
  el.addEventListener('change', () => { setPath(obj, path, el.checked); onChange && onChange(el.checked); });
  return h('label', { class: 'check', for: id }, el, h('span', null, label, hint ? h('small', { class: 'hint' }, hint) : null));
}

/** Comma/newline separated list bound to an array. */
export function listInput(obj, path, { placeholder = '', rows = 3, onChange, mono = true } = {}) {
  const el = h('textarea', { rows, placeholder, class: ['input', 'textarea', mono && 'mono'], spellcheck: 'false' });
  el.value = (getPath(obj, path) || []).join('\n');
  el.addEventListener('input', () => {
    const arr = el.value.split('\n').map((s) => s.trim()).filter(Boolean);
    setPath(obj, path, arr);
    onChange && onChange(arr);
  });
  return el;
}

export function field(label, control, hint, { wide } = {}) {
  return h('div', { class: ['field', wide && 'field-wide'] },
    h('label', { class: 'field-label' }, label),
    control,
    hint ? h('div', { class: 'hint' }, hint) : null);
}

export function button(label, onClick, { kind = 'secondary', icon: ic, title, disabled, small, type = 'button' } = {}) {
  const b = h('button', { type, class: ['btn', `btn-${kind}`, small && 'btn-sm'], title, disabled }, ic ? icon(ic, small ? 15 : 17) : null, label ? h('span', null, label) : null);
  if (onClick) {
    b.addEventListener('click', async (e) => {
      if (b.dataset.busy) return;
      const r = onClick(e, b);
      if (r && typeof r.then === 'function') {
        b.dataset.busy = '1';
        b.classList.add('is-busy');
        b.disabled = true;
        try { await r; } catch (err) { toast(err.message, 'error'); } finally {
          delete b.dataset.busy;
          b.classList.remove('is-busy');
          b.disabled = !!disabled;
        }
      }
    });
  }
  return b;
}

/** Inline result line under a test button. */
export function resultLine() {
  const el = h('div', { class: 'result', role: 'status', 'aria-live': 'polite' });
  el.set = (kind, text) => {
    el.className = `result result-${kind}`;
    mount(el, kind === 'ok' ? icon('check', 15) : kind === 'error' ? icon('x', 15) : null, h('span', null, text));
  };
  el.clear = () => { el.className = 'result'; clear(el); };
  return el;
}

// ---- toasts ---------------------------------------------------------------------------
let toastHost;
export function toast(text, kind = 'info', { timeout = 4500, action } = {}) {
  if (!toastHost) { toastHost = h('div', { class: 'toasts', role: 'status', 'aria-live': 'polite' }); document.body.appendChild(toastHost); }
  const t = h('div', { class: `toast toast-${kind}` }, h('span', { class: 'toast-text' }, text),
    action ? h('button', { class: 'toast-action', onclick: () => { action.fn(); t.remove(); } }, action.label) : null,
    h('button', { class: 'toast-close', 'aria-label': 'Dismiss', onclick: () => t.remove() }, icon('x', 14)));
  toastHost.appendChild(t);
  if (timeout) setTimeout(() => t.remove(), timeout);
  return t;
}

// ---- modal ----------------------------------------------------------------------------
export function modal({ title, body, actions = [], wide, onClose }) {
  const prev = document.activeElement;
  const close = () => {
    wrap.remove();
    document.removeEventListener('keydown', onKey);
    if (prev && prev.focus) prev.focus();
    onClose && onClose();
  };
  const onKey = (e) => { if (e.key === 'Escape') close(); };
  const dialog = h('div', { class: ['modal', wide && 'modal-wide'], role: 'dialog', 'aria-modal': 'true', 'aria-label': title },
    h('div', { class: 'modal-head' }, h('h2', null, title), h('button', { class: 'icon-btn', 'aria-label': 'Close', onclick: close }, icon('x'))),
    h('div', { class: 'modal-body' }, body),
    actions.length ? h('div', { class: 'modal-foot' }, actions.map((a) => button(a.label, async (e, b) => {
      const r = await a.onClick?.(e, b);
      if (r !== false) close();
    }, { kind: a.kind || 'secondary' }))) : null);
  const wrap = h('div', { class: 'modal-wrap', onmousedown: (e) => { if (e.target === wrap) close(); } }, dialog);
  document.body.appendChild(wrap);
  document.addEventListener('keydown', onKey);
  setTimeout(() => (dialog.querySelector('input, textarea, select, .btn-primary') || dialog.querySelector('button'))?.focus(), 30);
  return { close, el: dialog };
}

export function confirmDialog(title, text, { confirm = 'Confirm', kind = 'danger' } = {}) {
  return new Promise((resolve) => {
    let done = false;
    modal({
      title,
      body: h('p', null, text),
      actions: [
        { label: 'Cancel', onClick: () => { done = true; resolve(false); } },
        { label: confirm, kind, onClick: () => { done = true; resolve(true); } },
      ],
      onClose: () => { if (!done) resolve(false); },
    });
  });
}

// ---- small renderers --------------------------------------------------------------------

/** Safe mini-markdown for model replies: paragraphs, `code`, ```blocks```, **bold**, lists. */
export function richText(text) {
  const root = h('div', { class: 'rich' });
  const parts = String(text || '').split(/```[a-zA-Z0-9_-]*\n?/);
  parts.forEach((part, i) => {
    if (i % 2 === 1) { root.appendChild(h('pre', { class: 'code' }, h('code', null, part.replace(/\n$/, '')))); return; }
    const blocks = part.split(/\n{2,}/).filter((b) => b.trim());
    for (const b of blocks) {
      const lines = b.split('\n');
      if (lines.every((l) => /^\s*([-*]|\d+\.)\s+/.test(l))) {
        const ordered = /^\s*\d+\./.test(lines[0]);
        root.appendChild(h(ordered ? 'ol' : 'ul', null, lines.map((l) => h('li', null, inline(l.replace(/^\s*([-*]|\d+\.)\s+/, ''))))));
      } else if (/^#{1,4}\s/.test(lines[0])) {
        root.appendChild(h('h4', null, inline(lines[0].replace(/^#+\s/, ''))));
        if (lines.length > 1) root.appendChild(h('p', null, inline(lines.slice(1).join('\n'))));
      } else {
        root.appendChild(h('p', null, inline(b)));
      }
    }
  });
  return root;
}

function inline(s) {
  const out = [];
  const re = /(`[^`]+`|\*\*[^*]+\*\*)/g;
  let last = 0;
  let m;
  while ((m = re.exec(s))) {
    if (m.index > last) out.push(s.slice(last, m.index));
    const t = m[0];
    out.push(t.startsWith('`') ? h('code', null, t.slice(1, -1)) : h('strong', null, t.slice(2, -2)));
    last = m.index + t.length;
  }
  if (last < s.length) out.push(s.slice(last));
  return out;
}

export function emptyState(title, text, action) {
  return h('div', { class: 'empty' }, h('h3', null, title), text ? h('p', null, text) : null, action || null);
}

export function copyText(text) {
  const done = () => toast('Copied to clipboard', 'ok', { timeout: 1800 });
  if (navigator.clipboard && window.isSecureContext) return navigator.clipboard.writeText(text).then(done);
  const ta = h('textarea', { style: { position: 'fixed', opacity: '0' } });
  ta.value = text;
  document.body.appendChild(ta);
  ta.select();
  try { document.execCommand('copy'); done(); } catch { toast('Copy failed — select the text manually', 'error'); }
  ta.remove();
  return Promise.resolve();
}

export function debounce(fn, ms) {
  let t;
  return (...a) => { clearTimeout(t); t = setTimeout(() => fn(...a), ms); };
}

/** Segmented control (radio group) bound to obj[path]. */
export function segmented(obj, path, options, { onChange, label } = {}) {
  const name = fid();
  const wrap = h('div', { class: 'seg', role: 'radiogroup', 'aria-label': label || path });
  for (const o of options) {
    const id = fid();
    const inp = h('input', { type: 'radio', name, id, value: o.value, checked: String(getPath(obj, path)) === String(o.value) });
    inp.addEventListener('change', () => { setPath(obj, path, o.value); onChange && onChange(o.value); });
    wrap.appendChild(h('span', { class: 'seg-item' }, inp, h('label', { for: id }, o.label)));
  }
  return wrap;
}
