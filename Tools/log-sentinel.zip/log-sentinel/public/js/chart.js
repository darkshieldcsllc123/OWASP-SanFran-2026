// Hand-built SVG charts: time-series line/bar with crosshair tooltip, legend and table view; sparklines.
import { h, clock, compact, num, clear } from './ui.js';

const NS = 'http://www.w3.org/2000/svg';
const svgEl = (tag, attrs = {}) => {
  const e = document.createElementNS(NS, tag);
  for (const [k, v] of Object.entries(attrs)) if (v != null) e.setAttribute(k, v);
  return e;
};

// Validated categorical order (see app.css --s1..--s6). Color follows the series key, not its rank.
const SLOTS = 6;
const colorMemo = new Map();
export function seriesColor(key) {
  if (!colorMemo.has(key)) colorMemo.set(key, `var(--s${(colorMemo.size % SLOTS) + 1})`);
  return colorMemo.get(key);
}

function niceStep(range, ticks) {
  const raw = range / Math.max(1, ticks);
  const mag = 10 ** Math.floor(Math.log10(raw || 1));
  const n = raw / mag;
  return (n <= 1 ? 1 : n <= 2 ? 2 : n <= 5 ? 5 : 10) * mag;
}

export function seriesName(s) {
  const entries = Object.entries(s.labels || {});
  if (!entries.length) return s.name || 'total';
  return entries.map(([k, v]) => (entries.length === 1 ? v : `${k}=${v}`)).join(', ');
}

function fmtVal(v, unit) {
  if (v == null) return '—';
  if (unit === 'bytes') {
    const u = ['B', 'KB', 'MB', 'GB', 'TB'];
    let i = 0; let n = v;
    while (Math.abs(n) >= 1024 && i < u.length - 1) { n /= 1024; i++; }
    return `${n.toFixed(n >= 10 || i === 0 ? 0 : 1)} ${u[i]}`;
  }
  if (unit === '%') return `${num(v, 1)}%`;
  return `${compact(v)}${unit && unit !== 'bytes' ? ` ${unit}` : ''}`;
}

/**
 * Time-series chart. data = { series: [{ key, labels, points: [[t, v]] }], kind, unit, step }
 * Returns an element that redraws on resize.
 */
export function timeChart(data, { height = 220, style = 'auto', title } = {}) {
  const series = data.series || [];
  const wrap = h('div', { class: 'chart' });
  const legend = h('div', { class: 'chart-legend' });
  const plot = h('div', { class: 'chart-plot', style: { height: `${height}px` } });
  const tableHost = h('div', { class: 'chart-table', hidden: true });
  const tip = h('div', { class: 'chart-tip', hidden: true, role: 'tooltip' });
  let showTable = false;
  const toggle = h('button', { type: 'button', class: 'linkish chart-toggle', onclick: () => {
    showTable = !showTable;
    plot.hidden = showTable;
    tableHost.hidden = !showTable;
    toggle.textContent = showTable ? 'Show chart' : 'Show table';
    if (showTable) renderTable();
  } }, 'Show table');

  if (!series.length || series.every((s) => s.points.every((p) => p[1] == null))) {
    wrap.appendChild(h('div', { class: 'chart-empty', style: { height: `${height}px` } }, 'No data in this range yet.'));
    return wrap;
  }
  wrap.append(h('div', { class: 'chart-head' }, title ? h('span', { class: 'chart-title' }, title) : null, legend, toggle), plot, tableHost, tip);

  // Named entities keep their colour across charts; an unlabelled total always takes the first slot.
  const col = (s) => (Object.keys(s.labels || {}).length ? seriesColor(s.key) : 'var(--s1)');
  if (series.length > 1) {
    for (const s of series) {
      legend.appendChild(h('span', { class: 'legend-item' }, h('span', { class: 'swatch', style: { background: col(s) } }), seriesName(s)));
    }
  }
  const asBars = style === 'bar' || (style === 'auto' && data.kind === 'counter' && series.length === 1);

  function renderTable() {
    const times = series[0].points.map((p) => p[0]).slice(-40).reverse();
    tableHost.replaceChildren(h('table', { class: 'table compact' },
      h('thead', null, h('tr', null, h('th', null, 'Time'), series.map((s) => h('th', { class: 'num' }, seriesName(s))))),
      h('tbody', null, times.map((t) => h('tr', null, h('td', null, clock(t)),
        series.map((s) => h('td', { class: 'num' }, fmtVal(s.points.find((p) => p[0] === t)?.[1], data.unit))))))));
  }

  function draw() {
    const W = Math.max(280, plot.clientWidth || 600);
    const H = height;
    const m = { l: 48, r: 12, t: 10, b: 24 };
    const iw = W - m.l - m.r;
    const ih = H - m.t - m.b;
    const xs = series[0].points.map((p) => p[0]);
    const t0 = xs[0];
    const t1 = xs[xs.length - 1];
    let vmax = -Infinity;
    let vmin = Infinity;
    for (const s of series) for (const [, v] of s.points) if (v != null) { vmax = Math.max(vmax, v); vmin = Math.min(vmin, v); }
    if (!Number.isFinite(vmax)) { vmax = 1; vmin = 0; }
    let lo = 0;
    if (!asBars && vmin > 0 && vmin > vmax * 0.6 && data.unit !== '%') lo = vmin - (vmax - vmin) * 0.3;
    if (data.unit === '%' && vmax <= 100) vmax = Math.max(vmax, 10);
    const stepY = niceStep((vmax - lo) || 1, 4);
    lo = Math.floor(lo / stepY) * stepY;
    const hi = Math.max(lo + stepY, Math.ceil(vmax / stepY) * stepY);
    const x = (t) => m.l + (t1 === t0 ? iw / 2 : ((t - t0) / (t1 - t0)) * iw);
    const y = (v) => m.t + ih - ((v - lo) / (hi - lo)) * ih;
    const svg = svgEl('svg', { width: W, height: H, viewBox: `0 0 ${W} ${H}`, role: 'img', 'aria-label': title || 'Time series chart' });
    // grid + y ticks
    for (let v = lo; v <= hi + stepY / 2; v += stepY) {
      svg.appendChild(svgEl('line', { x1: m.l, x2: W - m.r, y1: y(v), y2: y(v), class: v === lo ? 'axis' : 'grid' }));
      const tx = svgEl('text', { x: m.l - 6, y: y(v) + 4, 'text-anchor': 'end', class: 'tick' });
      tx.textContent = fmtVal(v, data.unit).replace(/ (B|KB|MB|GB|TB)$/, '$1');
      svg.appendChild(tx);
    }
    // x ticks
    const nT = Math.max(2, Math.min(6, Math.floor(iw / 110)));
    const span = t1 - t0;
    for (let i = 0; i <= nT; i++) {
      const t = t0 + (span * i) / nT;
      const tx = svgEl('text', { x: x(t), y: H - 6, 'text-anchor': i === 0 ? 'start' : i === nT ? 'end' : 'middle', class: 'tick' });
      const d = new Date(t);
      tx.textContent = span > 36 * 3600e3 ? d.toLocaleDateString([], { month: 'short', day: 'numeric' }) + ' ' + d.toLocaleTimeString([], { hour: '2-digit' })
        : d.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
      svg.appendChild(tx);
    }
    // marks
    if (asBars) {
      const s = series[0];
      const bw = Math.max(1, iw / Math.max(1, s.points.length) - 2);
      for (const [t, v] of s.points) {
        if (!v) continue;
        const bx = x(t) - bw / 2;
        const by = y(v);
        const bh = y(lo) - by;
        const r = Math.min(2, bw / 2, bh);
        svg.appendChild(svgEl('path', {
          d: `M${bx},${y(lo)} V${by + r} Q${bx},${by} ${bx + r},${by} H${bx + bw - r} Q${bx + bw},${by} ${bx + bw},${by + r} V${y(lo)} Z`,
          fill: col(s), class: 'bar',
        }));
      }
    } else {
      for (const s of series) {
        let d = '';
        let pen = false;
        let lastPt = null;
        for (const [t, v] of s.points) {
          if (v == null) { pen = false; continue; }
          d += `${pen ? 'L' : 'M'}${x(t).toFixed(1)},${y(v).toFixed(1)}`;
          pen = true;
          lastPt = [t, v];
        }
        svg.appendChild(svgEl('path', { d, fill: 'none', stroke: col(s), 'stroke-width': 2, 'stroke-linejoin': 'round', 'stroke-linecap': 'round' }));
        if (lastPt) svg.appendChild(svgEl('circle', { cx: x(lastPt[0]), cy: y(lastPt[1]), r: 3, fill: col(s), class: 'endpoint' }));
      }
    }
    // hover layer
    const cross = svgEl('line', { y1: m.t, y2: m.t + ih, class: 'cross', visibility: 'hidden' });
    svg.appendChild(cross);
    const hit = svgEl('rect', { x: m.l, y: m.t, width: iw, height: ih, fill: 'transparent' });
    svg.appendChild(hit);
    const move = (ev) => {
      const r = svg.getBoundingClientRect();
      const px = ev.clientX - r.left;
      const rel = Math.max(0, Math.min(1, (px - m.l) / iw));
      const t = t0 + rel * (t1 - t0);
      let idx = 0;
      let best = Infinity;
      xs.forEach((tt, i) => { const dd = Math.abs(tt - t); if (dd < best) { best = dd; idx = i; } });
      const tx = x(xs[idx]);
      cross.setAttribute('x1', tx);
      cross.setAttribute('x2', tx);
      cross.setAttribute('visibility', 'visible');
      const rows = series.map((s) => ({ s, v: s.points[idx]?.[1] })).sort((a, b) => (b.v ?? -Infinity) - (a.v ?? -Infinity)).slice(0, 8);
      tip.replaceChildren(h('div', { class: 'tip-time' }, clock(xs[idx])),
        rows.map(({ s, v }) => h('div', { class: 'tip-row' }, h('span', { class: 'swatch', style: { background: col(s) } }),
          h('span', { class: 'tip-name' }, seriesName(s)), h('span', { class: 'tip-val' }, fmtVal(v, data.unit)))));
      tip.hidden = false;
      const pr = plot.getBoundingClientRect();
      const wr = wrap.getBoundingClientRect();
      let left = pr.left - wr.left + tx + 12;
      if (left + 220 > wr.width) left = pr.left - wr.left + tx - 232;
      tip.style.left = `${Math.max(0, left)}px`;
      tip.style.top = `${pr.top - wr.top + 8}px`;
    };
    hit.addEventListener('mousemove', move);
    hit.addEventListener('mouseleave', () => { tip.hidden = true; cross.setAttribute('visibility', 'hidden'); });
    clear(plot).appendChild(svg);
  }

  const ro = new ResizeObserver(() => { if (!plot.hidden) draw(); });
  ro.observe(plot);
  requestAnimationFrame(draw);
  return wrap;
}

/** Tiny inline trend line for tables. values: number[] */
export function sparkline(values, { width = 96, height = 22, color = 'var(--accent)', label } = {}) {
  const svg = svgEl('svg', { width, height, viewBox: `0 0 ${width} ${height}`, class: 'spark', role: 'img', 'aria-label': label || 'trend' });
  const vals = values.map((v) => v ?? 0);
  const max = Math.max(1, ...vals);
  const n = vals.length;
  if (n < 2) return svg;
  const pts = vals.map((v, i) => `${((i / (n - 1)) * (width - 2) + 1).toFixed(1)},${(height - 2 - (v / max) * (height - 4)).toFixed(1)}`);
  svg.appendChild(svgEl('polyline', { points: pts.join(' '), fill: 'none', stroke: color, 'stroke-width': 1.5, 'stroke-linejoin': 'round' }));
  return svg;
}
