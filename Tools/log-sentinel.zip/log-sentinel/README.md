# Log Sentinel

An autonomous log-monitoring agent you run yourself. It tails your log files, groups new lines into patterns, and hands them to the model you choose together with what you know about your systems. The model reports problems as findings. Log Sentinel also gathers metrics from your logs, this host, and anything you scrape.

- **No dependencies.** It needs Node.js 18.15 or newer and nothing from npm. The UI is plain HTML and JavaScript served by the same process.
- **Any model:**
  - Ollama (local), with connection tests, a model list, and model pulls with live progress.
  - The Claude, ChatGPT (or any OpenAI-compatible server) and Gemini APIs.
  - Coding-agent CLIs: Claude Code, Gemini CLI, Antigravity CLI, Codex CLI.
- **Runs in the Node server.** It keeps watching with the browser closed. The browser shows live state over Server-Sent Events.
- **Any OS.** You point it at the files: a file, a folder, or a glob such as `/var/log/nginx/*.log` or `C:\inetpub\logs\**\*.log`.

## Start

```
./start.sh            # macOS / Linux
start.bat             # Windows (double-click works)
node server.js        # anywhere
```

The server tries port 8787, takes the next free port if that one is busy, prints the address and opens a browser. Options:

- `--port 9000`: preferred port
- `--no-open`: don't open a browser
- `--data /path/to/data`: where settings and history live (default `./data`)
- `--host 127.0.0.1`: bind-address override

A first-run checklist on the Overview page walks through the four steps:

1. **Connect a model**
2. **Point it at your logs**
3. **Tell it about your systems**
4. **Start watching**

## New lines vs. what's already in a file

Log Sentinel follows files as they grow, like `tail -f`. When you add a source it starts at the end of each file, so each cycle sees only lines written since the last one. A file that isn't being written to gives the agent nothing, and those quiet cycles don't call the model at all.

To analyze what's already in a file, press **Analyze existing lines** on the source page. It reads the selected file, or every file with "All files" chosen: up to 8 MB of one file, or 16 MB across all of them. It queues the problem lines and runs a cycle right away. The model is told these lines are history, so it reports when things happened and whether they look resolved.

After you press **Run a cycle now** or **Analyze existing lines**, the result appears on screen when the cycle finishes. The full prompt and reply are on the Agent page.

## Checking what the agent will see

The **Preview** at the bottom of each source page shows the source's lines after parsing and rules:

- **Only what the agent sees** filters to the lines that would be sent. A healthy log often sends nothing, because the agent only hears about lines at the reporting level or above. When that happens the preview says so and shows a level breakdown.
- **All files** reads every file in the source, newest first, with each line tagged by file. Past problems are usually in older rotated files.
- Binary files in a log folder are skipped automatically: databases, Windows `.evtx` event logs, images.
- **Add a preset** fills in notes and rules for common logs. The current presets are the Ollama server log and Windows driver installs. Many important lines in these logs carry no level of their own, so without the rules they would never reach the agent.

## How a cycle works

1. **Tail.** Each source is polled (every 2 s by default). Polling behaves the same on every OS and on network shares.
   - A byte cursor per file survives restarts.
   - Rotation and truncation are detected.
   - UTF-8 and UTF-16 files are both read.
   - Stack traces stay attached to the line that started them.
2. **Parse.** Formats are detected automatically: plain text, JSON lines, nginx/Apache combined access logs and syslog. You can also give your own regex with named groups.
3. **Apply your rules.** Rules run before the agent sees anything:
   - `ignore`: known noise.
   - `always report`: something that matters even at INFO.
   - `set level`: raise or lower a line's severity.
   - `tip`: a note that is attached to the prompt whenever the pattern appears.
4. **Fingerprint.** Numbers, IDs, IPs and timestamps are masked, so 10,000 copies of one error become one pattern with a count and two sample lines.
5. **Build the prompt within the context window you set.** Each prompt contains:
   - your notes, global and per source
   - the rules that matched
   - known open issues, so the model doesn't report duplicates
   - results of recent actions
   - metric anomalies, threshold breaches and host stats
   - the patterns, most important first

   If the patterns don't fit, they are split across several requests or trimmed. You choose which.
6. **Merge findings.** The model replies with JSON findings: severity, explanation, evidence, likely cause and suggested action. These are merged into stable issues that track occurrences, escalations and regressions.
7. **Investigate.** For serious findings the agent can dig further. API models get read-only tools: `list_files`, `tail`, `grep`, `around`, `metric`, `host`. CLI agents open the log folders with their own tools.
8. **Alert.** Alerts appear in the app, and optionally in Slack, Discord, Teams or a generic webhook.

Quiet cycles skip the model call. A burst of errors triggers a cycle early. An hourly token cap pauses cycles if usage runs away.

## Autonomy levels

| Level | What the agent may do |
|---|---|
| **Read-only** (default) | Report findings only. |
| **Propose** | Request commands or file writes. Each one waits on the Actions page for your approval. |
| **Allowlist** | Commands matching your allowlist, and writes inside your writable folders, run automatically. Everything else waits for approval. A chained or redirected command (`;`, `&&`, `\|`, `>`) waits even if its prefix is allowed. |
| **Full access** | Actions run immediately. Coding-agent CLIs run with their own permission prompts turned off. You must confirm this level explicitly. |

At every level, commands on the **always-ask list** wait for a human. It is a best-effort pattern list: the defaults cover recursive deletes, disk formatting, shutdowns, permission resets, firewall flushes, piping downloads into a shell, and `DROP DATABASE`. Coding-agent CLIs get write permissions only while investigating at Full access; routine cycles always run them read-only. Replaced files are backed up as `.bak-<timestamp>`. Every action, with its output, is recorded on the Actions page.

## Connections

| Connection | Notes |
|---|---|
| Ollama | Set the server URL, test it, pick or delete installed models, and pull new ones with progress. The pull keeps running on the server if you leave the page. Set the context window (`num_ctx`) to at least the agent's context window. For reasoning models (qwen3, deepseek-r1), **Thinking: Off** under More options makes replies faster; with thinking on, raise **Max reply** on the Agent page so the model doesn't run out of tokens before answering. |
| Claude API | API key, or the `ANTHROPIC_API_KEY` environment variable. Models are listed from the API. |
| ChatGPT API | API key, or `OPENAI_API_KEY`. Change the base URL to use LM Studio, vLLM, OpenRouter or another OpenAI-compatible server. |
| Gemini API | API key, or `GEMINI_API_KEY`. |
| Claude Code | `claude -p`, prompt on stdin, `--output-format json`. Read-only levels use `--permission-mode dontAsk --allowedTools Read,Grep,Glob`. Full access uses `--permission-mode bypassPermissions`. |
| Gemini CLI | `gemini -p`, prompt on stdin, `-o json`. Read-only levels use `--approval-mode plan`. Full access uses `--approval-mode yolo`. |
| Antigravity CLI (experimental) | `agy -p … --output-format json`. Read-only levels use `--mode plan`. Full access uses `--dangerously-skip-permissions`. |
| Codex CLI | `codex exec --json --skip-git-repo-check --ephemeral`, prompt on stdin. Read-only levels use `--sandbox read-only`. Full access uses `--dangerously-bypass-approvals-and-sandbox`. |

CLIs use their own sign-in, so sign in once in a terminal on the same machine. Each CLI card has:

- **Detect**: finds the command and shows its version.
- **Test prompt**: runs one short prompt.
- **Replace the arguments**: a template with `{prompt}`, `{model}`, `{cwd}`, `{outfile}` and `{dirs}` placeholders, for CLI versions whose flags differ.

**Gemini CLI or Antigravity CLI?** Since June 18, 2026, Google AI Pro/Ultra subscribers and free individual accounts are served by Antigravity CLI. Gemini CLI continues for paid Gemini API keys and Code Assist Standard/Enterprise licences. Use whichever your account can sign in to.

Gemini CLI has the more established headless mode. Antigravity is marked experimental because some versions hang or print nothing when there is no terminal. If that happens:

- Update agy.
- Raise its timeout. Log Sentinel stops any run that exceeds it.
- On macOS or Linux, try the "pseudo-terminal" option on its card.

If you only have a Gemini API key, the Gemini API connection is simpler.

API keys and webhook URLs are stored in `data/config.json` with owner-only permissions where the OS supports it. They are masked whenever the browser asks for settings.

## Access

Configure this under **Settings → Access**:

- **This computer only** (default). Listens on 127.0.0.1. Host-header checking blocks DNS-rebinding attacks from web pages.
- **Other devices on my network.** Listens on all interfaces or one chosen address. An access token is always required; it is shown in Settings and printed in the console at start-up.
  - Optional IP/CIDR allowlist.
  - Optional HTTPS with your own certificate. A self-signed one can be created if OpenSSL is installed.

**Apply and restart the listener** switches modes without stopping the agent. State-changing requests must carry a custom header and a same-origin check, which guards against cross-site requests. Starting with `--host` on a non-loopback address always requires the token, whatever the mode.

**Who is trusted:**

- In local mode without a token, anyone logged in to this computer can use Log Sentinel. On a shared machine, turn on **Require the access token here too**.
- The agent's own investigation tools stay inside your log sources, with symlinks resolved. A single-file source only exposes that file and its rotated copies.
- Coding-agent CLIs enforce their own read scope. In read-only mode Codex can read any file the server's user can read, so run Log Sentinel as a user with only the access it needs.
- Log lines are untrusted input. At every level the model can only report or request actions; it cannot run them by itself unless you choose Allowlist or Full access.

## Metrics

- **From logs:**
  - Lines per source and level.
  - HTTP requests by status class, and response time for access logs.
  - Your own definitions: count lines matching a regex, or extract a number. Either can be split by a field or a named group.
- **Host:** CPU, memory, load, and disk usage for every log folder plus any extra paths you add.
- **Scrapers:**
  - Prometheus endpoints, with an include regex.
  - JSON from a URL or file.
  - CSV files (header row plus last row).
  - Any command that prints numbers, `key value` lines, JSON or Prometheus text.
- **Explore** with filters for source, level, label (`status_class=5xx, path~^/api`), time range, aggregation and grouping. Save charts to the dashboard.
- **Thresholds** raise findings and alerts directly, without the model. They can resolve themselves once the value is back within the limit.
- **Anomaly detection** flags error and 4xx/5xx counts that jump far above their recent baseline, and feeds them to the agent.

## Files

```
server.js            HTTP server, routes, port selection, SSE
lib/config.js        settings store, secret masking
lib/logs.js          path/glob resolution, tailing, batching, read-only agent tools
lib/parse.js         line parsing, level detection, fingerprints, rules
lib/agent.js         cycles, prompt building, investigations, follow-up chat
lib/findings.js      issue store and dedupe
lib/actions.js       autonomy policy and execution
lib/metrics.js       series store, queries, host stats, scrapers, thresholds, anomalies
lib/alerts.js        in-app, Slack, Discord, Teams and webhook delivery
lib/auth.js          access token, host and IP checks, CSRF guard
lib/providers/       Ollama + cloud APIs (api.js), coding-agent CLIs (cli.js)
public/              the single-page app (no build step)
data/                created on first run: config, cursors, findings, actions, metrics, activity
```

## Troubleshooting

- **"Path does not exist" or "Permission denied" on a source.** The server reads files as the user that started it. On Linux, add that user to the `adm` group to read `/var/log`.
- **Ollama answers but findings miss things.** Raise the Ollama context window and the agent's context window together. Add ignore rules for noise so more of the window goes to what matters.
- **A CLI is "not found".** Services often start with a shorter `PATH`. Put the full path in the CLI's Command field.
- **A corporate proxy blocks the cloud APIs.** Node's built-in `fetch` does not use `HTTPS_PROXY` by default. On recent Node versions (24 and newer), start with `NODE_USE_ENV_PROXY=1`.
- **Ports.** The port actually in use is printed at start-up and written to `data/runtime.json`.
