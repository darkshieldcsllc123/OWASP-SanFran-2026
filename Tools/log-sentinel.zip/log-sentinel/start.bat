@echo off
rem Log Sentinel launcher (Windows). Usage: start.bat [--port 8787] [--no-open] [--data .\data]
setlocal
cd /d "%~dp0"

where node >nul 2>nul
if errorlevel 1 (
  echo Node.js 18.15 or newer is required. Install it from https://nodejs.org and run this again.
  pause
  exit /b 1
)

title Log Sentinel
rem server.js checks the Node version itself and explains if it is too old.
node server.js %*
if errorlevel 1 pause
endlocal
