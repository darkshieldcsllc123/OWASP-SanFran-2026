#!/usr/bin/env node
'use strict';
// Log Sentinel — zero-dependency Node server.
// Serves the single-page app, proxies model APIs (so the browser never hits CORS),
// tails log files, runs the monitoring agent, and streams live updates over SSE.

const [NODE_MAJOR, NODE_MINOR] = process.versions.node.split('.').map(Number);
if (NODE_MAJOR < 18 || (NODE_MAJOR === 18 && NODE_MINOR < 15)) {
  console.error(`Log Sentinel needs Node.js 18.15 or newer (found ${process.versions.node}). Get it from https://nodejs.org`);
  process.exit(1);
}

const http = require('http');
const https = require('https');
const fs = require('fs');
const path = require('path');
const os = require('os');
const { spawn } = require('child_process');

const { bus, readJson, writeJson, which, lanAddresses, escapeRe, expandHome, uid, runProcess, IS_WIN } = require('./lib/util');
const { ConfigStore, newToken, fixRule } = require('./lib/config');
const { LogManager, resolveFiles } = require('./lib/logs');
const { MetricsManager } = require('./lib/metrics');
const { FindingsStore } = require('./lib/findings');
const { ActionManager } = require('./lib/actions');
const { Alerts } = require('./lib/alerts');
const { Agent } = require('./lib/agent');
const { createAuth } = require('./lib/auth');
const { parseLine, fingerprint, compileRules, applyRules, compileCustom } = require('./lib/parse');
const providers = require('./lib/providers');

const ROOT = __dirname;
const PUBLIC = path.join(ROOT, 'public');
const PKG = readJson(path.join(ROOT, 'package.json'), { version: '0.0.0' });

// ---- command line --------------------------------------------------------------
const argv = process.argv.slice(2);
const arg = (name) => {
  const i = argv.findIndex((a) => a === `--${name}` || a.startsWith(`--${name}=`));
  if (i === -1) return undefined;
  const a = argv[i];
  return a.includes('=') ? a.split('=').slice(1).join('=') : (argv[i + 1] && !argv[i + 1].startsWith('--') ? argv[i + 1] : true);
};
if (arg('help')) {
  console.log(`Usage: node server.js [--port 8787] [--host 127.0.0.1] [--data ./data] [--no-open]
  --port   preferred port (the next free port is used if it is taken)
  --host   bind address override (normally set on Settings > Access)
  --data   data folder (config, findings, metrics)
  --no-open  do not open a browser`);
  process.exit(0);
}
const DATA_DIR = path.resolve(expandHome(String(arg('data') || process.env.LS_DATA_DIR || path.join(ROOT, 'data'))));
fs.mkdirSync(DATA_DIR, { recursive: true });

// ---- components ----------------------------------------------------------------
const config = new ConfigStore(DATA_DIR);
const logs = new LogManager({ config, dataDir: DATA_DIR });
const metrics = new MetricsManager({ config, dataDir: DATA_DIR, logs });
logs.onRecord = (rec) => metrics.onRecord(rec);
const findings = new FindingsStore({ dataDir: DATA_DIR, config });
const actions = new ActionManager({ dataDir: DATA_DIR, config, logs });
const alerts = new Alerts({ config });
const agent = new Agent({ config, logs, metrics, findings, actions, alerts, dataDir: DATA_DIR });
const isLoopbackHost = (hst) => hst === '127.0.0.1' || hst === '::1' || hst === 'localhost' || /^127\./.test(hst || '');
const auth = createAuth(config, { boundExternally: () => currentHost != null && !isLoopbackHost(currentHost) });
const STARTED = Date.now();

// ---- live events (Server-Sent Events) -------------------------------------------
const clients = new Set();
function broadcast(type, data) {
  const msg = `event: ${type}\ndata: ${JSON.stringify(data)}\n\n`;
  for (const res of clients) { try { res.write(msg); } catch { clients.delete(res); } }
}
agent.on('status', (s) => broadcast('status', s));
agent.on('activity', (e) => broadcast('activity', e));
findings.on('change', (e) => { broadcast('finding', e); });
actions.on('change', (e) => { broadcast('action', e); agent.emitStatus(); });
alerts.on('notification', (n) => broadcast('notification', n));
metrics.on('anomaly', (a) => broadcast('anomaly', a));
bus.on('activity-note', (n) => agent.log({ type: 'info', status: n.level || 'info', title: n.text }));
setInterval(() => {
  if (!clients.size) return;
  broadcast('status', agent.status());
  broadcast('sources', logs.sourceStatus());
}, 4000);
setInterval(() => { for (const res of clients) { try { res.write(': ping\n\n'); } catch { /* closed */ } } }, 20000);

// ---- Ollama pulls (run server-side, progress streamed to every open tab) -----------
const pulls = new Map();
let pullBroadcastAt = 0;
function pullUpdate(p, force) {
  const now = Date.now();
  if (!force && now - pullBroadcastAt < 250) return;
  pullBroadcastAt = now;
  const { ctrl, ...pub } = p;
  broadcast('pull', pub);
}

// ---- helpers ----------------------------------------------------------------------
class HttpError extends Error {
  constructor(status, message) { super(message); this.status = status; }
}

function send(res, status, body, headers = {}) {
  if (res.headersSent) return;
  const isJson = typeof body !== 'string' && !Buffer.isBuffer(body);
  res.writeHead(status, { 'content-type': isJson ? 'application/json; charset=utf-8' : 'text/plain; charset=utf-8', 'cache-control': 'no-store', ...headers });
  res.end(isJson ? JSON.stringify(body) : body);
}

function readBody(req, limit = 10 * 1024 * 1024) {
  return new Promise((resolve, reject) => {
    let size = 0;
    const chunks = [];
    req.on('data', (c) => {
      size += c.length;
      if (size > limit) { reject(new HttpError(413, 'Request body too large')); req.destroy(); return; }
      chunks.push(c);
    });
    req.on('end', () => {
      if (!chunks.length) return resolve({});
      try { resolve(JSON.parse(Buffer.concat(chunks).toString('utf8'))); } catch { reject(new HttpError(400, 'Body is not valid JSON')); }
    });
    req.on('error', reject);
  });
}

let currentPort = null;
let currentHost = null;
let currentHttps = false;
let server = null;
let opensslPath;

function urls() {
  const proto = currentHttps ? 'https' : 'http';
  const list = [];
  if (currentHost === '0.0.0.0' || currentHost === '::') {
    list.push({ label: 'This computer', url: `${proto}://127.0.0.1:${currentPort}` });
    for (const a of lanAddresses()) list.push({ label: `Network (${a.iface})`, url: `${proto}://${a.address}:${currentPort}` });
  } else {
    const h = currentHost.includes(':') ? `[${currentHost}]` : currentHost;
    list.push({ label: currentHost === '127.0.0.1' ? 'This computer' : 'Address', url: `${proto}://${h}:${currentPort}` });
  }
  return list;
}

function systemInfo() {
  if (opensslPath === undefined) opensslPath = which('openssl');
  return {
    version: PKG.version,
    platform: process.platform,
    os: `${os.type()} ${os.release()}`,
    arch: process.arch,
    node: process.versions.node,
    hostname: os.hostname(),
    homedir: os.homedir(),
    sep: path.sep,
    dataDir: DATA_DIR,
    pid: process.pid,
    startedAt: STARTED,
    port: currentPort,
    host: currentHost,
    https: currentHttps,
    urls: urls(),
    lan: lanAddresses(),
    openssl: !!opensslPath,
    shell: IS_WIN ? 'cmd.exe' : '/bin/sh',
  };
}

function afterConfigChange(section) {
  if (section === 'sources' || section === 'knowledge') logs.reload();
  if (section === 'metrics' || section === 'sources') metrics.reload();
  if (section === 'agent' || section === 'providers') agent.emitStatus();
  broadcast('config', { section });
}

// Build a regex rule from a fingerprint template ("Timeout after #ms to <ip>").
function templateToRegex(t) {
  let re = escapeRe(t);
  const map = [
    ['"<str>"', '"[^"]*"'], ["'<str>'", "'[^']*'"], ['<ts>', '.+?'], ['<uuid>', '[0-9a-fA-F-]{36}'], ['<ip6>', '[0-9a-fA-F:]+'],
    ['<ip>', '[0-9.]+(?::\\d+)?'], ['<email>', '\\S+@\\S+'], ['<hex>', '(?:0x)?[0-9a-fA-F]+'], ['<id>', '[A-Za-z0-9_-]+'], ['#', '\\d+(?:\\.\\d+)?'],
  ];
  for (const [a, b] of map) re = re.split(a).join(b);
  return re.replace(/ /g, '\\s+');
}

function findSource(id) {
  const s = config.get().sources.find((x) => x.id === id);
  if (!s) throw new HttpError(404, 'Source not found');
  return s;
}

// ---- routes ------------------------------------------------------------------------
const routes = [];
function route(method, pattern, handler, opts = {}) {
  const keys = [];
  const re = new RegExp('^' + pattern.replace(/:(\w+)/g, (_, k) => { keys.push(k); return '([^/]+)'; }) + '$');
  routes.push({ method, re, keys, handler, opts });
}

// auth
route('GET', '/api/auth/status', (req) => ({ required: auth.tokenRequired(), authenticated: auth.authenticated(req), mode: config.get().access.mode }), { public: true });
route('POST', '/api/auth/login', (req, res, body) => {
  const r = auth.login(req, String(body.token || '').trim());
  if (!r.ok) throw new HttpError(r.status, r.message);
  res.setHeader('Set-Cookie', auth.cookie(String(body.token).trim(), currentHttps));
  return { ok: true };
}, { public: true });
route('POST', '/api/auth/logout', (req, res) => { res.setHeader('Set-Cookie', auth.clearCookie()); return { ok: true }; }, { public: true });

// state + config
route('GET', '/api/state', () => ({
  version: PKG.version,
  config: config.public(),
  status: agent.status(),
  providers: providers.catalog(),
  system: systemInfo(),
  counts: findings.counts(),
  sources: logs.sourceStatus(),
  notifications: alerts.recent.slice(0, 40),
  pulls: [...pulls.values()].map(({ ctrl, ...p }) => p),
  firstRun: config.firstRun,
}));
route('GET', '/api/config', () => config.public());
route('PUT', '/api/config/:section', (req, res, body, p) => {
  const before = config.get().server.port;
  const out = config.setSection(p.section, body);
  afterConfigChange(p.section);
  // Keep the browser that made this change signed in once a token becomes required.
  if (p.section === 'access' && auth.tokenRequired()) res.setHeader('Set-Cookie', auth.cookie(config.get().access.token, currentHttps));
  return { section: out, restartRequired: p.section === 'access' || (p.section === 'server' && config.get().server.port !== before) };
});
route('GET', '/api/config/export', (req, res, body, p, u) => {
  const withSecrets = u.searchParams.get('secrets') === '1';
  if (withSecrets && req.headers['x-ls-client'] !== '1') throw new HttpError(403, 'Exporting secrets needs the request header; use the Backup page.');
  const data = config.export(withSecrets);
  res.setHeader('content-disposition', `attachment; filename="log-sentinel-config.json"`);
  return data;
});
route('POST', '/api/config/import', (req, res, body) => {
  const out = config.import(body);
  for (const s of ['sources', 'knowledge', 'metrics', 'agent']) afterConfigChange(s);
  return { config: out };
});

// providers
const providerConfig = (id, body) => config.resolveProviderDraft(id, body && body.config);
route('POST', '/api/providers/:id/test', async (req, res, body, p) => providers.get(p.id).test(providerConfig(p.id, body)));
route('POST', '/api/providers/:id/models', async (req, res, body, p) => ({ models: await providers.get(p.id).listModels(providerConfig(p.id, body)) }));
route('POST', '/api/providers/:id/detect', async (req, res, body, p) => {
  const prov = providers.get(p.id);
  if (!prov.detect) throw new HttpError(400, 'Not a CLI provider');
  return prov.detect(providerConfig(p.id, body));
});
route('POST', '/api/providers/:id/prompt', async (req, res, body, p) => {
  const prov = providers.get(p.id);
  const c = providerConfig(p.id, body);
  const t0 = Date.now();
  const r = await prov.chat(c, {
    system: 'You are a connectivity test for a log monitoring tool. Follow the instruction exactly.',
    messages: [{ role: 'user', content: String(body.prompt || 'Reply with exactly this JSON object and nothing else: {"ok": true, "message": "hello from the model"}') }],
    json: body.json !== false,
    maxTokens: 512,
    autonomy: 'read_only',
    cwd: os.homedir(),
  });
  return { text: r.text, usage: r.usage, model: r.model, durationMs: Date.now() - t0 };
});

// ollama
route('POST', '/api/ollama/pull', (req, res, body) => {
  const model = String(body.model || '').trim();
  if (!model) throw new HttpError(400, 'Model name is required (for example llama3.2 or qwen2.5:7b)');
  if (pulls.get(model)?.state === 'pulling') return { already: true };
  const c = providerConfig('ollama', body);
  const p = { model, state: 'pulling', status: 'starting', completed: 0, total: 0, startedAt: Date.now(), ctrl: new AbortController() };
  pulls.set(model, p);
  pullUpdate(p, true);
  providers.get('ollama').pull(c, model, (ev) => {
    p.status = ev.status;
    if (ev.total) { p.total = ev.total; p.completed = ev.completed || 0; }
    pullUpdate(p);
  }, p.ctrl.signal).then(() => {
    p.state = 'done'; p.status = 'success'; p.completed = p.total;
    agent.log({ type: 'info', status: 'ok', title: `Ollama pulled ${model}` });
  }).catch((e) => {
    p.state = p.ctrl.signal.aborted ? 'cancelled' : 'error';
    p.status = p.ctrl.signal.aborted ? 'cancelled' : e.message;
  }).finally(() => {
    pullUpdate(p, true);
    setTimeout(() => { if (pulls.get(model) === p) pulls.delete(model); }, 5 * 60e3);
  });
  return { started: true };
});
route('POST', '/api/ollama/pull/cancel', (req, res, body) => {
  const p = pulls.get(String(body.model || ''));
  if (p && p.state === 'pulling') p.ctrl.abort();
  return { ok: true };
});
route('POST', '/api/ollama/delete', async (req, res, body) => providers.get('ollama').remove(providerConfig('ollama', body), String(body.model)));
route('POST', '/api/ollama/show', async (req, res, body) => providers.get('ollama').show(providerConfig('ollama', body), String(body.model)));

// sources
route('POST', '/api/sources/test', async (req, res, body) => {
  const r = await resolveFiles(body.source || {}, 500);
  return { count: r.files.length, error: r.error, files: r.files.slice(0, 60), skipped: r.skipped || [] };
});
route('POST', '/api/sources/preview', async (req, res, body) => {
  const src = body.source || findSource(body.sourceId);
  return logs.preview(src, { file: body.file, lines: Math.min(Number(body.lines) || 200, 1000), q: body.q, level: body.level, onlyAgent: !!body.onlyAgent, allFiles: !!body.allFiles });
});
route('GET', '/api/sources/status', () => logs.sourceStatus());
route('POST', '/api/sources/:id/backfill', async (req, res, body, p) => {
  const src = findSource(p.id);
  if (!src.enabled) throw new HttpError(400, 'This source is paused. Turn on "Watch this source" and save first.');
  const r = await logs.backfill(src, { file: body.file, allFiles: !!body.allFiles });
  let cycle = 'none';
  if (r.queued > 0) {
    if (agent.busy) cycle = 'queued';
    else { agent.runCycle({ reason: 'existing lines' }).catch(() => { /* logged */ }); cycle = 'started'; }
  }
  agent.log({ type: 'info', status: 'info', title: `Read ${r.lines.toLocaleString()} existing lines from ${r.files.join(', ')}`, detail: r.queued ? `${r.queued.toLocaleString()} queued for the agent (${r.newPatterns} new patterns).` : `None at ${r.minLevel} or above or matched by an always-report rule, so nothing was queued.` });
  return { ...r, cycle };
});

// knowledge rule tester
route('POST', '/api/knowledge/test', (req, res, body) => {
  const c = config.get();
  const src = c.sources.find((s) => s.id === body.sourceId) || null;
  const line = String(body.line || '');
  const rules = body.rules || c.knowledge.rules;
  const rec = { ...parseLine(line.split('\n')[0], src?.format, src ? compileCustom(src) : null), raw: line };
  const compiled = compileRules([...(rules || []), ...((src?.rules) || []).map((r) => ({ ...r, sources: [] }))], src?.id);
  const d = applyRules(rec, compiled);
  if (d.level) rec.level = d.level;
  const minLevel = src?.minLevel || c.agent.minLevel || 'warn';
  const { levelRank } = require('./lib/util');
  const all = [...(rules || []), ...((src?.rules) || [])];
  return {
    level: rec.level,
    ts: rec.ts,
    msg: rec.msg,
    fields: rec.fields,
    fingerprint: fingerprint(rec.msg),
    ignored: d.ignored,
    always: d.always,
    toAgent: !d.ignored && (d.always || levelRank(rec.level) >= levelRank(minLevel)),
    minLevel,
    matched: d.matched.map((id) => all.find((r) => r.id === id)).filter(Boolean),
  };
});

// agent
route('GET', '/api/agent/status', () => agent.status());
route('POST', '/api/agent/start', () => { agent.start(); return agent.status(); });
route('POST', '/api/agent/stop', () => { agent.stop(); return agent.status(); });
route('POST', '/api/agent/run', () => {
  if (agent.busy) return { busy: true };
  const pending = logs.pendingSummary(); // read before the cycle drains it
  agent.runCycle({ reason: 'manual' }).catch(() => { /* logged */ });
  return { started: true, pending };
});
route('POST', '/api/agent/preview', () => agent.previewPrompt());
route('GET', '/api/activity', (req, res, body, p, u) => agent.activity.slice(0, Math.min(Number(u.searchParams.get('limit')) || 200, 1000)));
route('GET', '/api/activity/:id', (req, res, body, p) => {
  const e = agent.activity.find((x) => x.id === p.id);
  if (!e) throw new HttpError(404, 'Activity entry not found');
  return { entry: e, detail: agent.details.get(p.id) || null };
});

// findings
route('GET', '/api/findings', (req, res, body, p, u) => findings.list(Object.fromEntries(u.searchParams)));
route('GET', '/api/findings/:id', (req, res, body, p) => {
  const f = findings.get(p.id);
  if (!f) throw new HttpError(404, 'Finding not found');
  return f;
});
route('POST', '/api/findings/:id/status', (req, res, body, p) => findings.setStatus(p.id, body.status, body.note));
route('POST', '/api/findings/:id/investigate', (req, res, body, p) => {
  if (!findings.get(p.id)) throw new HttpError(404, 'Finding not found');
  if (agent.investigating.has(p.id)) return { already: true };
  agent.investigate(p.id).catch(() => { /* recorded on the finding */ });
  return { started: true };
});
route('POST', '/api/findings/:id/chat', async (req, res, body, p) => agent.followUp(p.id, body.message));
route('POST', '/api/findings/:id/expected', (req, res, body, p) => {
  const f = findings.get(p.id);
  if (!f) throw new HttpError(404, 'Finding not found');
  const c = config.get();
  const type = ['ignore', 'tip', 'severity'].includes(body.type) ? body.type : 'tip';
  let patterns = [];
  if (body.pattern) patterns = [{ pattern: String(body.pattern), regex: !!body.regex }];
  else {
    for (const fp of f.fingerprints || []) {
      let reg = f.sourceId ? logs.fps.get(`${f.sourceId}|${fp}`) : null;
      if (!reg) for (const [k, v] of logs.fps) if (k.endsWith('|' + fp)) { reg = v; break; }
      if (reg && reg.template) patterns.push({ pattern: templateToRegex(reg.template), regex: true });
    }
  }
  if (!patterns.length) throw new HttpError(400, 'This finding has no known log pattern. Enter a pattern to match instead.');
  const note = String(body.note || `Expected behaviour (from finding "${f.title}")`);
  const rules = patterns.slice(0, 5).map((x) => fixRule({
    type, pattern: x.pattern, regex: x.regex, note, level: body.level || 'info', sources: f.sourceId && body.scope !== 'global' ? [f.sourceId] : [], createdFrom: f.id,
  }));
  c.knowledge.rules.push(...rules);
  config.save();
  afterConfigChange('knowledge');
  findings.setStatus(p.id, type === 'ignore' ? 'muted' : f.status === 'open' ? 'acknowledged' : f.status, `Marked as expected: ${rules.length} ${type} rule${rules.length === 1 ? '' : 's'} added`);
  return { rules };
});
route('DELETE', '/api/findings/:id', (req, res, body, p) => { findings.remove(p.id); return { ok: true }; });
route('POST', '/api/findings/clear', (req, res, body) => ({ removed: findings.clear(body.status || 'resolved') }));

// actions
route('GET', '/api/actions', (req, res, body, p, u) => actions.list({ status: u.searchParams.get('status') || undefined }));
route('POST', '/api/actions/:id/approve', (req, res, body, p) => actions.approve(p.id, body.note));
route('POST', '/api/actions/:id/reject', (req, res, body, p) => actions.reject(p.id, body.note));

// metrics
route('GET', '/api/metrics/catalog', () => metrics.catalog());
route('POST', '/api/metrics/query', (req, res, body) => metrics.query(body || {}));
route('POST', '/api/metrics/batch', (req, res, body) => (body.queries || []).slice(0, 24).map((q) => {
  try { return metrics.query(q); } catch (e) { return { error: e.message }; }
}));
route('GET', '/api/metrics/overview', () => ({
  host: metrics.lastHost || metrics.hostNow(),
  anomalies: metrics.anomalies.slice(-30).reverse(),
  thresholds: metrics.thresholdStatus(),
  scrapers: metrics.scraperStatus(),
}));
route('POST', '/api/metrics/scrapers/test', async (req, res, body) => {
  const s = { ...(body.scraper || {}) };
  const saved = (config.get().metrics.scrapers || []).find((x) => x.id === s.id);
  if (saved && typeof s.headers === 'string' && s.headers.startsWith('••')) s.headers = saved.headers;
  return metrics.testScraper(s);
});
route('POST', '/api/metrics/definitions/test', async (req, res, body) => {
  const d = body.definition || {};
  const c = config.get();
  const srcs = d.sources && d.sources.length ? c.sources.filter((s) => d.sources.includes(s.id)) : c.sources.filter((s) => s.enabled);
  let re = null;
  let vre = null;
  try { if (d.match) re = new RegExp(d.matchRegex === false ? escapeRe(d.match) : d.match, 'i'); } catch (e) { throw new HttpError(400, `Match pattern: ${e.message}`); }
  try { if (d.valueRegex) vre = new RegExp(d.valueRegex); } catch (e) { throw new HttpError(400, `Value pattern: ${e.message}`); }
  const samples = [];
  let scanned = 0;
  let matched = 0;
  for (const s of srcs.slice(0, 5)) {
    const pv = await logs.preview(s, { lines: 600 }).catch(() => ({ records: [] }));
    for (const r of pv.records) {
      scanned++;
      if (d.levels && d.levels.length && !d.levels.includes(r.level)) continue;
      const m = re ? r.raw.match(re) : [r.raw];
      if (!m) continue;
      matched++;
      let value = null;
      if (d.type === 'value') {
        if (d.valueField && r.fields && r.fields[d.valueField] != null) value = Number(r.fields[d.valueField]);
        else if (vre) { const vm = r.raw.match(vre); if (vm) value = Number(vm.groups?.value ?? vm[1] ?? vm[0]); } else value = Number(m.groups?.value ?? m[1]);
      }
      const group = d.groupBy ? (r.fields?.[d.groupBy] ?? m.groups?.[d.groupBy] ?? (d.groupBy === 'level' ? r.level : null)) : null;
      if (samples.length < 12) samples.push({ source: s.name, line: r.raw.slice(0, 300), value, group });
    }
  }
  return { scanned, matched, samples };
});

// alerts
route('POST', '/api/alerts/test', async (req, res, body) => {
  const ch = { ...(body.channel || {}) };
  const saved = (config.get().alerts.channels || []).find((x) => x.id === ch.id);
  if (saved) {
    if (String(ch.url || '').startsWith('••')) ch.url = saved.url;
    if (String(ch.headers || '').startsWith('••')) ch.headers = saved.headers;
  }
  if (!ch.url) throw new HttpError(400, 'Webhook URL is required');
  return alerts.test(ch);
});
route('GET', '/api/notifications', () => alerts.recent);
route('POST', '/api/notifications/read', () => { alerts.markRead(); return { ok: true }; });

// system
route('GET', '/api/system/info', () => systemInfo());
route('POST', '/api/system/apply-access', () => {
  setTimeout(() => restartListening().catch((e) => console.error('[server] restart failed:', e.message)), 400);
  const c = config.get();
  const https = !!(c.access.https?.enabled && c.access.https.certPath && c.access.https.keyPath);
  return { ok: true, restarting: true, port: preferredPort(), https, mode: c.access.mode };
});
route('GET', '/api/system/token', () => ({ token: config.get().access.token }), { secret: true });
route('POST', '/api/system/token/rotate', (req, res) => {
  const c = config.get();
  c.access.token = newToken();
  config.save();
  res.setHeader('Set-Cookie', auth.cookie(c.access.token, currentHttps));
  // Revoked browsers must not keep receiving live updates; open tabs reconnect with their cookie.
  setTimeout(() => { for (const r of clients) { try { r.end(); } catch { /* closed */ } } clients.clear(); }, 200);
  return { token: c.access.token };
});
route('POST', '/api/system/generate-cert', async () => {
  const bin = which('openssl');
  if (!bin) throw new HttpError(400, 'OpenSSL was not found on this machine. Create a certificate another way and enter the file paths instead.');
  const dir = path.join(DATA_DIR, 'tls');
  fs.mkdirSync(dir, { recursive: true });
  const key = path.join(dir, 'key.pem');
  const cert = path.join(dir, 'cert.pem');
  const sans = ['DNS:localhost', 'IP:127.0.0.1', `DNS:${os.hostname()}`, ...lanAddresses().map((a) => `IP:${a.address}`)].join(',');
  const r = await runProcess(bin, ['req', '-x509', '-newkey', 'rsa:2048', '-nodes', '-keyout', key, '-out', cert, '-days', '825',
    '-subj', '/CN=Log Sentinel', '-addext', `subjectAltName=${sans}`], { timeoutMs: 60000 });
  if (r.code !== 0) throw new HttpError(500, `openssl failed: ${(r.stderr || r.error || '').slice(-400)}`);
  return { certPath: cert, keyPath: key };
});
route('POST', '/api/system/browse', async (req, res, body) => {
  let p = body.path ? path.resolve(expandHome(String(body.path))) : null;
  if (!p) {
    if (IS_WIN) {
      const drives = [];
      for (const L of 'CDEFGHIJKLMNOPQRSTUVWXYZ') if (fs.existsSync(`${L}:\\`)) drives.push({ name: `${L}:\\`, path: `${L}:\\`, dir: true });
      return { path: '', parent: null, entries: drives };
    }
    p = '/';
  }
  let st;
  try { st = await fs.promises.stat(p); } catch { throw new HttpError(404, `Not found: ${p}`); }
  if (!st.isDirectory()) p = path.dirname(p);
  let ents;
  try { ents = await fs.promises.readdir(p, { withFileTypes: true }); } catch (e) { throw new HttpError(403, `Cannot read ${p}: ${e.code || e.message}`); }
  const entries = [];
  for (const e of ents.slice(0, 2000)) {
    const full = path.join(p, e.name);
    if (e.isDirectory()) entries.push({ name: e.name, path: full, dir: true });
    else if (e.isFile() || e.isSymbolicLink()) {
      let size = null;
      let mtime = null;
      try { const s = await fs.promises.stat(full); size = s.size; mtime = s.mtimeMs; } catch { /* broken link */ }
      entries.push({ name: e.name, path: full, dir: false, size, mtime });
    }
  }
  entries.sort((a, b) => (a.dir === b.dir ? a.name.localeCompare(b.name) : a.dir ? -1 : 1));
  const parent = path.dirname(p) !== p ? path.dirname(p) : (IS_WIN ? '' : null);
  return { path: p, parent, entries };
});

// SSE stream
route('GET', '/api/events', (req, res) => {
  res.writeHead(200, { 'content-type': 'text/event-stream', 'cache-control': 'no-store', connection: 'keep-alive', 'x-accel-buffering': 'no' });
  res.write(`retry: 3000\nevent: hello\ndata: ${JSON.stringify({ t: Date.now() })}\n\n`);
  clients.add(res);
  req.on('close', () => clients.delete(res));
  return undefined;
}, { stream: true });

// ---- request handling ----------------------------------------------------------------
const MIME = {
  '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.css': 'text/css; charset=utf-8',
  '.svg': 'image/svg+xml', '.png': 'image/png', '.ico': 'image/x-icon', '.json': 'application/json', '.woff2': 'font/woff2',
};

function serveStatic(req, res, pathname) {
  let rel;
  try { rel = decodeURIComponent(pathname); } catch { return send(res, 400, 'Bad path'); }
  if (rel === '/' || rel === '/index.html') rel = '/index.html';
  else if (!path.extname(rel)) return send(res, 404, 'Not found');
  const file = path.join(PUBLIC, path.normalize(rel).replace(/^([/\\])+/, ''));
  if (!file.startsWith(PUBLIC)) return send(res, 403, 'Forbidden');
  fs.readFile(file, (err, data) => {
    if (err) return send(res, 404, 'Not found');
    res.writeHead(200, { 'content-type': MIME[path.extname(file)] || 'application/octet-stream', 'cache-control': 'no-cache' });
    res.end(data);
  });
}

async function handle(req, res) {
  res.setHeader('X-Content-Type-Options', 'nosniff');
  res.setHeader('X-Frame-Options', 'DENY');
  res.setHeader('Referrer-Policy', 'no-referrer');
  res.setHeader('Content-Security-Policy', "default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline'; img-src 'self' data:; connect-src 'self'; frame-ancestors 'none'; base-uri 'none'; form-action 'self'");
  if (!auth.ipAllowed(req)) return send(res, 403, 'Your address is not on the allowed list.');
  if (!auth.hostAllowed(req)) return send(res, 421, 'This server only answers on localhost. Switch Settings > Access to "Other devices" to reach it by another name.');
  let u;
  try { u = new URL(req.url, 'http://local'); } catch { return send(res, 400, 'Bad URL'); }
  if (!u.pathname.startsWith('/api/')) return serveStatic(req, res, u.pathname);

  const r = routes.find((x) => x.method === req.method && x.re.test(u.pathname));
  if (!r) return send(res, 404, { error: `No route for ${req.method} ${u.pathname}` });
  if (!r.opts.public && !auth.authenticated(req)) return send(res, 401, { error: 'Not signed in', auth: true });
  if (!auth.csrfOk(req)) return send(res, 403, { error: 'Missing or cross-site request header' });
  if (r.opts.secret && req.headers['x-ls-client'] !== '1') return send(res, 403, { error: 'Missing request header' });
  const m = u.pathname.match(r.re);
  const params = {};
  try {
    r.keys.forEach((k, i) => {
      try { params[k] = decodeURIComponent(m[i + 1]); } catch { throw new HttpError(400, 'Malformed URL'); }
    });
    const body = ['POST', 'PUT', 'PATCH', 'DELETE'].includes(req.method) ? await readBody(req) : {};
    const out = await r.handler(req, res, body, params, u);
    if (r.opts.stream) return undefined;
    send(res, 200, out === undefined ? { ok: true } : out);
  } catch (e) {
    const status = e.status && e.status >= 400 && e.status < 600 && e instanceof HttpError ? e.status : 500;
    if (status === 500 && !/HTTP \d{3}|ECONN|ENOTFOUND|timed out|not found|API key|choose a model/i.test(e.message)) console.error(`[api] ${req.method} ${u.pathname}:`, e.message);
    send(res, status === 500 ? 502 : status, { error: e.message });
  }
  return undefined;
}

// ---- listening (port auto-select, local/network, optional HTTPS) ------------------------
function listenOnce(srv, port, host) {
  return new Promise((resolve, reject) => {
    const onErr = (e) => { srv.removeListener('listening', onOk); reject(e); };
    const onOk = () => { srv.removeListener('error', onErr); resolve(); };
    srv.once('error', onErr);
    srv.once('listening', onOk);
    srv.listen(port, host);
  });
}

function preferredPort() {
  const portArg = Number(arg('port'));
  return Number.isFinite(portArg) && portArg > 0 ? portArg : Number(process.env.PORT) || Number(config.get().server.port) || 8787;
}

async function startListening(first) {
  const c = config.get();
  const hostArg = arg('host');
  currentHost = typeof hostArg === 'string' ? hostArg : c.access.mode === 'network' ? (c.access.bindAddress || '0.0.0.0') : '127.0.0.1';
  currentHttps = false;
  let tls = null;
  if (c.access.https?.enabled) {
    try {
      tls = { cert: fs.readFileSync(expandHome(c.access.https.certPath)), key: fs.readFileSync(expandHome(c.access.https.keyPath)) };
      currentHttps = true;
    } catch (e) {
      console.error(`[server] HTTPS is enabled but the certificate could not be loaded (${e.message}). Falling back to HTTP.`);
      agent.log({ type: 'error', status: 'warn', title: 'HTTPS certificate could not be loaded — serving plain HTTP', detail: e.message });
    }
  }
  server = tls ? https.createServer(tls, handle) : http.createServer(handle);
  server.requestTimeout = 0; // long-running model calls and SSE
  server.headersTimeout = 60000;
  const preferred = preferredPort();
  if (!isLoopbackHost(currentHost) && !c.access.token) {
    c.access.token = newToken();
    config.save(true);
  }
  let lastErr;
  for (let p = preferred; p < preferred + 100; p++) {
    try {
      await listenOnce(server, p, currentHost);
      currentPort = p;
      lastErr = null;
      break;
    } catch (e) {
      lastErr = e;
      if (e.code !== 'EADDRINUSE' && e.code !== 'EACCES') break;
    }
  }
  if (lastErr) throw new Error(`Could not listen on ${currentHost}:${preferred}–${preferred + 99}: ${lastErr.message}`);
  writeJson(path.join(DATA_DIR, 'runtime.json'), { pid: process.pid, port: currentPort, host: currentHost, https: currentHttps, urls: urls(), startedAt: Date.now() });
  const list = urls();
  console.log('');
  console.log(`  Log Sentinel ${PKG.version} is running${currentPort !== preferred ? ` (port ${preferred} was busy, using ${currentPort})` : ''}`);
  for (const x of list) console.log(`  ➜ ${x.label.padEnd(22)} ${x.url}`);
  if (auth.tokenRequired()) console.log(`  Access token: ${c.access.token}`);
  console.log(`  Data folder:            ${DATA_DIR}`);
  console.log('  Press Ctrl+C to stop.\n');
  if (first) maybeOpenBrowser(list[0].url);
}

async function restartListening() {
  for (const res of clients) { try { res.end(); } catch { /* ignore */ } }
  clients.clear();
  await new Promise((resolve) => {
    server.close(() => resolve());
    if (server.closeAllConnections) server.closeAllConnections();
  });
  await startListening(false);
}

function maybeOpenBrowser(url) {
  if (arg('no-open') || process.env.LS_NO_OPEN || !config.get().server.openBrowser) return;
  if (process.platform === 'linux' && !process.env.DISPLAY && !process.env.WAYLAND_DISPLAY) return;
  try {
    const cmd = IS_WIN ? 'cmd' : process.platform === 'darwin' ? 'open' : 'xdg-open';
    const args = IS_WIN ? ['/c', 'start', '""', url] : [url];
    spawn(cmd, args, { detached: true, stdio: 'ignore', windowsHide: true }).on('error', () => {}).unref();
  } catch { /* no browser available */ }
}

// ---- lifecycle ---------------------------------------------------------------------------
let shuttingDown = false;
function shutdown(code = 0) {
  if (shuttingDown) return;
  shuttingDown = true;
  console.log('\n  Saving state and stopping…');
  try { agent.shutdown(); } catch (e) { console.error(e.message); }
  try { logs.stop(); logs.flush(); } catch (e) { console.error(e.message); }
  try { metrics.stop(); metrics.save(); } catch (e) { console.error(e.message); }
  try { findings.flush(); actions.flush(); } catch (e) { console.error(e.message); }
  try { fs.unlinkSync(path.join(DATA_DIR, 'runtime.json')); } catch { /* ignore */ }
  process.exit(code);
}
process.on('SIGINT', () => shutdown(0));
process.on('SIGTERM', () => shutdown(0));
process.on('uncaughtException', (e) => { console.error('[fatal]', e); });
process.on('unhandledRejection', (e) => { console.error('[unhandled]', e && e.message ? e.message : e); });

startListening(true).then(() => {
  logs.start();
  if (agent.running) agent.log({ type: 'info', status: 'info', title: 'Agent resumed after restart' });
}).catch((e) => {
  console.error(`\n  ${e.message}\n`);
  process.exit(1);
});
