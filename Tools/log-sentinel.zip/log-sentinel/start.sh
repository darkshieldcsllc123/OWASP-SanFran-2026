#!/usr/bin/env sh
# Log Sentinel launcher (macOS / Linux). Usage: ./start.sh [--port 8787] [--no-open] [--data ./data]
cd "$(dirname "$0")" || exit 1

if ! command -v node >/dev/null 2>&1; then
  echo "Node.js 18.15 or newer is required. Install it from https://nodejs.org and run this again."
  exit 1
fi

NODE_OK=$(node -e "const [a,b]=process.versions.node.split('.').map(Number);process.stdout.write(a>18||(a===18&&b>=15)?'1':'0')")
if [ "$NODE_OK" != "1" ]; then
  echo "Node.js 18.15 or newer is required (found $(node -v)). Update from https://nodejs.org"
  exit 1
fi

exec node server.js "$@"
