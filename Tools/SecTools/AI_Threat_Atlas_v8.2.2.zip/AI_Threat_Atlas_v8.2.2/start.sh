#!/usr/bin/env sh
set -eu
cd "$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)"
if ! command -v node >/dev/null 2>&1; then
  echo 'Node.js 18+ is required. Install it from https://nodejs.org/' >&2
  exit 1
fi
exec node server.js
