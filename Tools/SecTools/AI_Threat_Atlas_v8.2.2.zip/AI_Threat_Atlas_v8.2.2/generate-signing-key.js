'use strict';
// Generates an Ed25519 signing keypair. Never upload or paste the PRIVATE key into Log Sentinel.
const fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto');
const dir=process.env.ATLAS_DATA_DIR?path.resolve(process.env.ATLAS_DATA_DIR):path.join(__dirname,'.atlas-data');fs.mkdirSync(dir,{recursive:true});
const privateName=path.join(dir,'logsentinel-signing.pem');
if(fs.existsSync(privateName)){console.error('Signing key already exists. Refusing to overwrite it.');process.exit(1)}
const kp=crypto.generateKeyPairSync('ed25519');
fs.writeFileSync(privateName,kp.privateKey.export({type:'pkcs8',format:'pem'}),{mode:0o600});
const publicName=path.join(dir,'logsentinel-signing.pub.pem');fs.writeFileSync(publicName,kp.publicKey.export({type:'spki',format:'pem'}),{mode:0o644});
console.log('Keep this PRIVATE key local:',privateName);
console.log('Register this PUBLIC key in Log Sentinel integration settings:',publicName);
console.log(fs.readFileSync(publicName,'utf8'));
console.log('Atlas setting: .atlas-data/logsentinel-signing.pem');
