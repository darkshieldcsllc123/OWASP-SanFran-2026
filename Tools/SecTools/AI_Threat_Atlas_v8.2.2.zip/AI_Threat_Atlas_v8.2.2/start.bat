@echo off
setlocal
cd /d "%~dp0"
where node >nul 2>nul
if errorlevel 1 (
 echo Node.js 18+ is required. Install from https://nodejs.org/
 pause
 exit /b 1
)
echo Launching AI Threat Atlas with local Ollama proxy...
node server.js
if errorlevel 1 pause
