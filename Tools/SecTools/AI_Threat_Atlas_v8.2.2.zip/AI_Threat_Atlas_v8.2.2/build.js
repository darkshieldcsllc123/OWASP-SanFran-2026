'use strict';
// Embed editable taxonomy JSON in one standalone HTML file. No packages required.
const fs=require('node:fs'),path=require('node:path');
const dir=__dirname;
const template=fs.readFileSync(path.join(dir,'index.template.html'),'utf8');
const data=JSON.parse(fs.readFileSync(path.join(dir,'taxonomy.json'),'utf8'));
if(!Array.isArray(data.techniques)||!Array.isArray(data.frameworks)||!Array.isArray(data.categories))throw Error('Invalid taxonomy shape');
const embedded=JSON.stringify(data).replace(/</g,'\\u003c').replace(/>/g,'\\u003e').replace(/&/g,'\\u0026');
if(!template.includes('__DATA__'))throw Error('Template placeholder missing');
fs.writeFileSync(path.join(dir,'index.html'),template.replace('__DATA__',embedded));
console.log(`Built index.html · ${data.techniques.length} attack patterns · ${data.categories.length} categories`);
