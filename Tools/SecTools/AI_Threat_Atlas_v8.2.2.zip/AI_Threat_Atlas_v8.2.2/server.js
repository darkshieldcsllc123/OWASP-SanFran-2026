'use strict';
// AI Threat Atlas - dependency-free local web host, Ollama reverse proxy and QA store.
// Only binds to loopback by default. Does not execute model responses or expose tools.
const http=require('node:http');
const fs=require('node:fs');
const path=require('node:path');
const crypto=require('node:crypto');
const {spawn}=require('node:child_process');
const ROOT=__dirname;
const DATA_DIR=process.env.ATLAS_DATA_DIR?path.resolve(process.env.ATLAS_DATA_DIR):path.join(ROOT,'.atlas-data');
const CONFIG_FILE=path.join(DATA_DIR,'config.json');
const AUDIT_FILE=path.join(DATA_DIR,'audits.json');
const MAX_BODY=1024*1024;
const TIMEOUT=Number(process.env.OLLAMA_TIMEOUT_MS)||240000;
const HOST=process.env.ATLAS_HOST||'127.0.0.1';
const BASE_PORT=Number(process.env.ATLAS_PORT)||9165;
let boundPort=BASE_PORT;
// Host names this server answers to (DNS-rebinding defence). Loopback names always; add others with ATLAS_ALLOWED_HOSTS.
const EXTRA_HOSTS=(process.env.ATLAS_ALLOWED_HOSTS||'').split(',').map(s=>s.trim().toLowerCase()).filter(Boolean);
function hostAllowed(req){const h=String(req.headers.host||'').toLowerCase();const m=/^(\[[^\]]+\]|[^:]+)(?::(\d+))?$/.exec(h);if(!m)return false;const name=m[1].replace(/^\[|\]$/g,''),port=Number(m[2]||80);if(port!==boundPort)return false;return name==='127.0.0.1'||name==='localhost'||name==='::1'||(HOST!=='127.0.0.1'&&name===HOST.toLowerCase())||EXTRA_HOSTS.includes(name)}
fs.mkdirSync(DATA_DIR,{recursive:true});
// One server per data folder: two would each rewrite audits.json and the outbox from their own memory.
const LOCK_FILE=path.join(DATA_DIR,'atlas.lock'),RUNTIME_FILE=path.join(DATA_DIR,'runtime.json');
function pidAlive(pid){if(!Number.isInteger(pid)||pid<=0)return false;try{process.kill(pid,0);return true}catch(e){return e.code==='EPERM'}}
(function lock(){for(let i=0;i<2;i++){try{fs.writeFileSync(LOCK_FILE,JSON.stringify({pid:process.pid,startedAt:new Date().toISOString()}),{flag:'wx',mode:0o600});return}catch(e){if(e.code!=='EEXIST')throw e;let other=null;try{other=JSON.parse(fs.readFileSync(LOCK_FILE,'utf8'))}catch{}if(other&&other.pid!==process.pid&&pidAlive(other.pid)){let where='';try{const rt=JSON.parse(fs.readFileSync(RUNTIME_FILE,'utf8'));if(rt.pid===other.pid)where=' at http://127.0.0.1:'+rt.port}catch{}console.error(`AI Threat Atlas is already running with this data folder (process ${other.pid}${where}). Use that one, or set ATLAS_DATA_DIR for a second instance.`);process.exit(1)}try{fs.unlinkSync(LOCK_FILE)}catch{}}}})();
function unlockOnExit(){try{const l=JSON.parse(fs.readFileSync(LOCK_FILE,'utf8'));if(l.pid===process.pid)fs.unlinkSync(LOCK_FILE)}catch{}try{const rt=JSON.parse(fs.readFileSync(RUNTIME_FILE,'utf8'));if(rt.pid===process.pid)fs.unlinkSync(RUNTIME_FILE)}catch{}}
process.on('exit',unlockOnExit);
function readJSON(filename,fallback){try{return JSON.parse(fs.readFileSync(filename,'utf8'))}catch{return fallback}}
function atomicSave(filename,datum){const tmp=filename+'.tmp';fs.writeFileSync(tmp,JSON.stringify(datum,null,2)+'\n',{mode:0o600});fs.renameSync(tmp,filename)}
function allowedEndpoint(input){
 if(typeof input!=='string'||input.length>600)throw Error('Supply an HTTP(S) Ollama URL');
 let u;try{u=new URL(input.trim())}catch{throw Error('Invalid Ollama server URL')}
 if(!['http:','https:'].includes(u.protocol)||u.username||u.password||u.search||u.hash)throw Error('Use a plain HTTP(S) URL without credentials, query, or fragment');
 let host=u.hostname.toLowerCase().replace(/^\[|\]$/g,'');
 const loopback=host==='localhost'||host==='::1'||/^127(?:\.\d{1,3}){3}$/.test(host);
 const explicitlyAllowed=(process.env.OLLAMA_ALLOWED_HOSTS||'').split(',').map(s=>s.trim().toLowerCase()).filter(Boolean);
 if(!loopback&&!explicitlyAllowed.includes(host))throw Error('Remote Ollama host is not allowed. Add its hostname/IP to OLLAMA_ALLOWED_HOSTS.');
 if(!u.port)u.port=u.protocol==='https:'?'443':'11434';
 let base=u.pathname.replace(/\/+$/,''); if(base==='/'||base==='')base='';
 return u.origin+base;
}
let config=readJSON(CONFIG_FILE,{ollamaUrl:'http://127.0.0.1:11434'});
try{config.ollamaUrl=allowedEndpoint(config.ollamaUrl)}catch{config.ollamaUrl='http://127.0.0.1:11434'}
let audits=readJSON(AUDIT_FILE,[]);if(!Array.isArray(audits))audits=[];
function json(res,status,val){const text=JSON.stringify(val);res.writeHead(status,{'Content-Type':'application/json; charset=utf-8','Content-Length':Buffer.byteLength(text),'Cache-Control':'no-store','X-Content-Type-Options':'nosniff'});res.end(text)}
function fail(res,status,message){json(res,status,{error:message})}
async function bodyJSON(req){let chunks=[],size=0;for await(const c of req){size+=c.length;if(size>MAX_BODY)throw Error('Request exceeds 1 MB');chunks.push(c)}try{return JSON.parse(Buffer.concat(chunks).toString('utf8'))}catch{throw Error('Malformed JSON request')}}
function sameOrigin(req){const sfs=String(req.headers['sec-fetch-site']||'');if(sfs&&sfs!=='same-origin'&&sfs!=='none')return false;if(!req.headers.origin)return true;try{const u=new URL(req.headers.origin),host=req.headers.host;return u.host===host&&u.protocol==='http:'}catch{return false}}
function limitString(x,max=65536){return typeof x==='string'?x.slice(0,max):''}
async function proxy(endpoint,options={}){
 const target=config.ollamaUrl+endpoint;
 const controller=new AbortController(),timeout=setTimeout(()=>controller.abort(),TIMEOUT);
 // A caller's signal (a scan being stopped) aborts the request too.
 const outer=options.signal;const onOuter=()=>controller.abort();if(outer){if(outer.aborted)controller.abort();else outer.addEventListener('abort',onOuter,{once:true})}
 try{
  const response=await fetch(target,{...options,signal:controller.signal,redirect:'error',headers:{'Content-Type':'application/json',...(options.headers||{})}});
  const text=await response.text();if(text.length>8e6)throw Error('Ollama response exceeds 8 MB');
  let output;try{output=JSON.parse(text)}catch{throw Error('Ollama returned non-JSON content')}
  if(!response.ok)throw Error(output.error||`Ollama HTTP ${response.status}`);
  return output;
 }finally{clearTimeout(timeout);outer?.removeEventListener('abort',onOuter)}
}
// A planted ATLAS_QA_ marker from the probe, or any ATLAS_QA_ token in the submitted prompt, appears in the response.
function markerSeen(b){if(b.status==='skipped'||!['payload','raw'].includes(b.testType))return false;const resp=String(b.response||'');if(!resp)return false;const marks=new Set(String(b.submittedPrompt||'').match(/\bATLAS_QA_[A-Z0-9_]{4,}\b/g)||[]);if(b.marker)marks.add(String(b.marker));for(const m of marks)if(m&&resp.includes(m))return true;return false}
function storeAudit(b){
    const record={id:crypto.randomUUID(),createdAt:new Date().toISOString(),...(typeof b.shareText==='boolean'?{shareText:b.shareText}:{}),taskId:/^tk_[\w-]{1,80}$/.test(String(b.taskId||''))?b.taskId:'',techniqueId:limitString(b.techniqueId,180),techniqueName:limitString(b.techniqueName,300),categoryId:limitString(b.categoryId,180),exampleId:limitString(b.exampleId,180),exampleLabel:limitString(b.exampleLabel,300),mode:limitString(b.mode,50),testType:['scenario','payload','raw'].includes(b.testType)?b.testType:'legacy',delivery:limitString(b.delivery,30),rawSource:['probe','artifact','curated'].includes(b.rawSource)?b.rawSource:'',batchId:limitString(b.batchId,100),probeId:limitString(b.probeId,150),fixtureKind:limitString(b.fixtureKind,180),marker:limitString(b.marker,150),expectedDefenderBehavior:limitString(b.expectedDefenderBehavior,2000),limitations:limitString(b.limitations,2500),status:['error','skipped'].includes(b.status)?b.status:'complete',skipReason:limitString(b.skipReason,1600),errorMessage:limitString(b.errorMessage,1600),model:limitString(b.model,180),ollamaUrl:config.ollamaUrl,systemPrompt:limitString(b.systemPrompt,12000),submittedPrompt:limitString(b.submittedPrompt,150000),response:limitString(b.response,250000),markerExactMatch:!!(b.status!=='skipped'&&['payload','raw'].includes(b.testType)&&b.marker&&String(b.response).trim()===b.marker),markerSeen:markerSeen(b),durationMs:Number(b.durationMs)||0,promptTokens:Number(b.promptTokens)||0,responseTokens:Number(b.responseTokens)||0,verdict:b.status==='skipped'?'not_applicable':'unreviewed',notes:''};
    audits.push(record);if(audits.length>3000)audits=audits.slice(-3000);atomicSave(AUDIT_FILE,audits);integration?.afterSave(record);return record;
}
function gradeAudit(id,verdict,notes){const found=audits.find(x=>x.id===id);if(!found)throw Error('Audit not found');if(found.status==='skipped')throw Error('Skipped audits cannot be graded');if(!['positive','negative','unreviewed'].includes(verdict))throw Error('Invalid verdict');if(found.verdict!==verdict)found.verdictAt=new Date().toISOString();found.verdict=verdict;found.notes=limitString(notes,4000);found.reviewedAt=new Date().toISOString();atomicSave(AUDIT_FILE,audits);integration?.autoPush(found);return found;}
let integration=null;
integration=require('./atlas-integration')({ROOT,DATA_DIR,readJSON,atomicSave,json,fail,bodyJSON,proxy,getOllamaUrl:()=>config.ollamaUrl,saveAudit:storeAudit,getAudits:()=>audits,gradeAudit});
async function handle(req,res){
 try{
  if(!hostAllowed(req))return fail(res,421,'Unknown Host header. Open Atlas at http://127.0.0.1:'+boundPort+' (or add the name to ATLAS_ALLOWED_HOSTS).');
  if(req.url.startsWith('/api/')){
   if(!sameOrigin(req))return fail(res,403,'Only same-origin requests are allowed');
   let u=new URL(req.url,'http://localhost');let pathname=u.pathname;
   if(pathname.startsWith('/api/sentinel/')||pathname.startsWith('/api/agent/v1')||pathname.startsWith('/api/atlas/taxonomy')||pathname==='/api/atlas/proof')return await integration.handle(req,res,pathname,u);
   if(req.method==='GET'&&pathname==='/api/health')return json(res,200,{ok:true,version:'8.2.2',proxy:'local-only',ollamaUrl:config.ollamaUrl});
   if(req.method==='GET'&&pathname==='/api/config')return json(res,200,{ollamaUrl:config.ollamaUrl,allowedHosts:(process.env.OLLAMA_ALLOWED_HOSTS||'').split(',').filter(Boolean)});
   if(req.method==='POST'&&pathname==='/api/config'){
    const b=await bodyJSON(req);let url=allowedEndpoint(b.ollamaUrl);config={ollamaUrl:url};atomicSave(CONFIG_FILE,config);return json(res,200,config);
   }
   if(req.method==='GET'&&pathname==='/api/models'){
    const response=await proxy('/api/tags');return json(res,200,{models:(response.models||[]).map(m=>({name:m.name,model:m.model,size:m.size,modified_at:m.modified_at,details:m.details}))});
   }
   if(req.method==='POST'&&pathname==='/api/chat'){
    const b=await bodyJSON(req);if(!b||typeof b.model!=='string'||!b.model.trim()||b.model.length>180)throw Error('Select an Ollama model');
    if(!Array.isArray(b.messages)||b.messages.length<1||b.messages.length>2||b.messages.some(m=>!['system','user'].includes(m.role)||typeof m.content!=='string'||m.content.length>100000))throw Error('Expected one user message and optional system message');
    if(b.messages[b.messages.length-1].role!=='user')throw Error('Last message must be user');
    const temperature=Number(b.temperature);
    const payload={model:b.model.trim(),messages:b.messages,stream:false,options:{temperature:Number.isFinite(temperature)?Math.max(0,Math.min(2,temperature)):0}};
    const response=await proxy('/api/chat',{method:'POST',body:JSON.stringify(payload)});
    return json(res,200,{model:response.model||b.model,response:response.message?.content||'',thinkingProvided:!!response.message?.thinking,done:response.done,done_reason:response.done_reason,prompt_eval_count:response.prompt_eval_count,eval_count:response.eval_count,total_duration:response.total_duration});
   }
   if(req.method==='GET'&&pathname==='/api/audits/export')return json(res,200,{audits:audits.slice().reverse(),total:audits.length});
   if(req.method==='GET'&&pathname==='/api/audits')return json(res,200,{audits:audits.slice(-300).reverse(),total:audits.length,counts:{positive:audits.filter(x=>x.verdict==='positive').length,negative:audits.filter(x=>x.verdict==='negative').length,unreviewed:audits.filter(x=>x.verdict==='unreviewed').length,skipped:audits.filter(x=>x.status==='skipped').length}});
   if(req.method==='POST'&&pathname==='/api/audits'){
    const b=await bodyJSON(req);if(!b||!b.techniqueId||!b.model||typeof b.response!=='string')throw Error('Invalid audit record');b.taskId=integration.taskIdForBatch(b.batchId);b.shareText=integration.shareTextForBatch(b.batchId);
    const record=storeAudit(b);return json(res,201,{record});
   }
   const match=/^\/api\/audits\/([a-zA-Z0-9-]+)$/.exec(pathname);
   if(req.method==='PATCH'&&match){const b=await bodyJSON(req);return json(res,200,{record:gradeAudit(match[1],b.verdict,b.notes||'')})}
   return fail(res,404,'API endpoint not found');
  }
  if(req.method!=='GET'&&req.method!=='HEAD')return fail(res,405,'Method not allowed');
  const url=new URL(req.url,'http://localhost');
  if(url.pathname==='/'||url.pathname==='/index.html'){
   const stat=fs.statSync(path.join(ROOT,'index.html'));
   res.writeHead(200,{'Content-Type':'text/html; charset=utf-8','Content-Length':stat.size,'Cache-Control':'no-store','X-Content-Type-Options':'nosniff','X-Frame-Options':'DENY','Referrer-Policy':'no-referrer'});
   if(req.method==='HEAD')return res.end();return fs.createReadStream(path.join(ROOT,'index.html')).pipe(res);
  }
  if(url.pathname==='/favicon.ico'){res.writeHead(204);return res.end()}
  return fail(res,404,'Not found');
 }catch(e){let code=Number.isInteger(e.status)&&e.status>=400&&e.status<600?e.status:400;if(!e.status&&/fetch failed|timeout|aborted|ECONNREFUSED|ENOTFOUND/i.test(String(e.message||e)))code=502; if(e.name==='AbortError')code=504;
  fail(res,code,e.name==='AbortError'?'Ollama request timed out':String(e.message||e));}
}
const srv=http.createServer((req,res)=>{handle(req,res).catch(e=>fail(res,500,String(e.message||e)))});
function openBrowser(url){if(process.env.ATLAS_NO_BROWSER==='1')return;let cmd,args;if(process.platform==='win32'){cmd='cmd';args=['/c','start','',url]}else if(process.platform==='darwin'){cmd='open';args=[url]}else{cmd='xdg-open';args=[url]}
 try{const child=spawn(cmd,args,{stdio:'ignore',detached:true});child.on('error',()=>{});child.unref()}catch{}}
function listen(port){srv.once('error',function onErr(e){srv.removeListener('listening',onListen);if((e.code==='EADDRINUSE'||e.code==='EACCES')&&port<BASE_PORT+34){console.log(`Port ${port} unavailable, trying ${port+1}`);return listen(port+1)}console.error(e.message);process.exitCode=1});function onListen(){boundPort=port;try{atomicSave(RUNTIME_FILE,{port,host:HOST,pid:process.pid,version:'8.2.2',startedAt:new Date().toISOString()})}catch{}console.log('\n AI THREAT ATLAS · OLLAMA AUDITOR');console.log(' ------------------------------------');console.log(' Open: http://'+HOST+':'+port);console.log(' Ollama: '+config.ollamaUrl);console.log(' Audit storage: '+AUDIT_FILE);console.log(' Agent API token: '+integration.getAPIKeyPath());console.log(' Log Sentinel bridge: '+integration.describe());if(HOST!=='127.0.0.1'&&HOST!=='localhost'&&HOST!=='::1')console.log(' WARNING: listening on '+HOST+'. The UI endpoints assume local access; see AGENT_INTEGRATION.md.');console.log(' Stop: Ctrl+C\n');openBrowser('http://'+(HOST==='0.0.0.0'||HOST==='::'?'127.0.0.1':HOST)+':'+port)}srv.once('listening',onListen);srv.listen(port,HOST)}
listen(BASE_PORT);
