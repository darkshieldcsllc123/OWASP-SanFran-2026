#!/usr/bin/env node
'use strict';
// AI Threat Atlas task runner, for Log Sentinel's "program" runner. Zero dependencies, Node 18+.
//
//   node tools/atlas-task-runner.js task  [--data <Atlas data folder>]   (Log Sentinel runs this)
//   node tools/atlas-task-runner.js check [--data <Atlas data folder>]   (see what it would use)
//
// Log Sentinel starts it with LS_URL, LS_TASK_ID and LS_TASK_TOKEN in the environment. The runner finds
// Atlas's server through <data>/runtime.json, or starts it (headless) when it isn't running, and hands it the
// task and its token, but only after that server proved it holds this folder's agent token (an HMAC over a
// fresh nonce), so a stale runtime.json pointing at someone else's port gets nothing. Atlas's server claims the task, runs the scan, sends the results with Atlas's
// integration key and reports how it ended. The runner prints progress, which Log Sentinel keeps with the
// action on its Actions page (never the token), and exits when the task has ended. A server it started is
// stopped again at the end; one that was already running keeps running.
const fs = require('node:fs');
const path = require('node:path');
const { spawn } = require('node:child_process');
const crypto = require('node:crypto');

const ROOT = path.join(__dirname, '..');
const argv = process.argv.slice(2);
const mode = argv[0] && !argv[0].startsWith('--') ? argv[0] : 'task';
const opt = (name) => { const i = argv.indexOf('--' + name); return i >= 0 ? argv[i + 1] : undefined; };
const DATA = path.resolve(opt('data') || process.env.ATLAS_DATA_DIR || path.join(ROOT, '.atlas-data'));
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const say = (msg) => console.log(`[atlas-runner] ${msg}`);

function readJSON(f) { try { return JSON.parse(fs.readFileSync(f, 'utf8')); } catch { return null; } }
let HOST = '127.0.0.1';
const loopName = (h) => (['localhost', '::1', '[::1]'].includes(String(h)) || /^127(?:\.\d{1,3}){3}$/.test(String(h)) ? String(h).replace(/^::1$/, '[::1]') : '127.0.0.1');
async function call(port, method, route, body, token) {
  const ctrl = new AbortController(); const t = setTimeout(() => ctrl.abort(), 20000);
  try {
    const r = await fetch(`http://${HOST}:${port}${route}`, { method, signal: ctrl.signal, headers: { 'content-type': 'application/json', ...(token ? { authorization: 'Bearer ' + token } : {}) }, body: body === undefined ? undefined : JSON.stringify(body) });
    const text = await r.text(); let json = {}; try { json = JSON.parse(text); } catch { json = { error: text.slice(0, 300) }; }
    return { status: r.status, json };
  } finally { clearTimeout(t); }
}
function pidAlive(pid) { if (!Number.isInteger(pid) || pid <= 0) return false; try { process.kill(pid, 0); return true; } catch (e) { return e.code === 'EPERM'; } }
function agentToken() { return (fs.readFileSync(path.join(DATA, 'agent-token.txt'), 'utf8') || '').trim(); }
// The server on this port must show it knows the agent token before the runner sends it anything secret.
async function proven(port) {
  try {
    const nonce = crypto.randomBytes(24).toString('hex');
    const r = await call(port, 'GET', `/api/atlas/proof?nonce=${nonce}`);
    if (r.status !== 200 || typeof r.json.proof !== 'string') return false;
    const want = Buffer.from(crypto.createHmac('sha256', agentToken()).update('atlas-runner-proof|' + nonce).digest('hex'));
    const got = Buffer.from(r.json.proof);
    return want.length === got.length && crypto.timingSafeEqual(want, got);
  } catch { return false; }
}
async function findAtlas() {
  const rt = readJSON(path.join(DATA, 'runtime.json'));
  if (!rt || !Number.isInteger(rt.port) || !pidAlive(rt.pid)) return null;
  HOST = loopName(rt.host);
  return (await proven(rt.port)) ? rt.port : null;
}
function startAtlas() {
  // Atlas's server gets no LS_* variables: it reaches Log Sentinel with its own settings, and the task token
  // only through the local agent API.
  const env = { ...process.env, ATLAS_NO_BROWSER: '1', ATLAS_DATA_DIR: DATA };
  for (const k of Object.keys(env)) if (k.startsWith('LS_')) delete env[k];
  const child = spawn(process.execPath, [path.join(ROOT, 'server.js')], { cwd: ROOT, env, stdio: ['ignore', 'pipe', 'pipe'] });
  return new Promise((resolve, reject) => {
    let out = '';
    const timer = setTimeout(() => { child.kill(); reject(new Error('Atlas did not start within 20 s: ' + out.slice(-400))); }, 20000);
    HOST = '127.0.0.1';
    const onData = (c) => { out += c; const m = /Open: http:\/\/[^:\s]+:(\d+)/.exec(out); if (m) { clearTimeout(timer); resolve({ child, port: Number(m[1]) }); } };
    child.stdout.on('data', onData); child.stderr.on('data', (c) => { out += c; });
    child.on('exit', (code) => { clearTimeout(timer); reject(new Error(`Atlas exited (${code}) before it started: ${out.slice(-400)}`)); });
  });
}
async function stopChild(child) { if (!child || child.exitCode !== null) return; child.kill('SIGTERM'); await Promise.race([new Promise((r) => child.once('exit', r)), sleep(5000)]); if (child.exitCode === null) child.kill('SIGKILL'); }
// Tell Log Sentinel directly when Atlas could not take the task (the task token can report on its own task).
async function reportFailed(error) {
  const { LS_URL, LS_TASK_ID, LS_TASK_TOKEN } = process.env;
  if (!LS_URL || !LS_TASK_ID || !LS_TASK_TOKEN) return;
  try {
    await fetch(`${LS_URL.replace(/\/+$/, '')}/api/v1/tasks/${encodeURIComponent(LS_TASK_ID)}/status`, { method: 'POST', headers: { authorization: 'Bearer ' + LS_TASK_TOKEN, 'content-type': 'application/json' }, body: JSON.stringify({ status: 'failed', error: String(error).slice(0, 2000) }) });
  } catch { /* Log Sentinel marks the task failed when the program exits without reporting */ }
}

async function check() {
  const cfg = readJSON(path.join(DATA, 'sentinel-config.json')) || {};
  const port = await findAtlas();
  say(`Atlas folder: ${ROOT}`);
  say(`Data folder:  ${DATA}${fs.existsSync(DATA) ? '' : ' (missing: start Atlas once)'}`);
  say(`Atlas server: ${port ? 'running on port ' + port : 'not running (the runner starts it for a task)'}`);
  say(`Log Sentinel: ${cfg.url || 'not set'} · integration ${cfg.enabled ? 'on' : 'off'} · key ${cfg.key ? 'saved' : 'missing'}`);
  say(`Agent token:  ${fs.existsSync(path.join(DATA, 'agent-token.txt')) ? 'present' : 'missing (start Atlas once)'}`);
  if (!cfg.enabled || !cfg.key) { say('Set up the integration in Atlas first (Log Sentinel / Agents tab).'); process.exitCode = 1; }
}

async function task() {
  const { LS_TASK_ID, LS_TASK_TOKEN, LS_URL } = process.env;
  if (!LS_TASK_ID || !LS_TASK_TOKEN) { say('LS_TASK_ID and LS_TASK_TOKEN are not set. Log Sentinel sets them when it starts this runner for a task.'); process.exitCode = 2; return; }
  let child = null, port = await findAtlas();
  try {
    if (port) say(`Using Atlas's server on port ${port}.`);
    else {
      say('Atlas is not running; starting its server.'); ({ child, port } = await startAtlas()); say(`Atlas's server started on port ${port}.`);
      if (!(await proven(port))) throw new Error('The server that started does not hold this folder\'s agent token');
    }
    const agentTok = agentToken();
    const run = await call(port, 'POST', '/api/agent/v1/tasks/run', { taskId: LS_TASK_ID, token: LS_TASK_TOKEN, lsUrl: LS_URL || '' }, agentTok);
    if (run.status !== 202) throw new Error(run.json.error || `Atlas answered HTTP ${run.status}`);
    say(`Atlas took task ${LS_TASK_ID}.`);
    let stopDeadline = 0;
    const stop = async (sig) => {
      if (stopDeadline) return; stopDeadline = Date.now() + 20000;
      say(`${sig}: asking Atlas to stop the scan.`);
      try { await call(port, 'POST', '/api/agent/v1/tasks/stop', { taskId: LS_TASK_ID, reason: 'Stopped from Log Sentinel' }, agentTok); } catch { /* it may have ended */ }
    };
    process.on('SIGTERM', () => { stop('SIGTERM'); }); process.on('SIGINT', () => { stop('SIGINT'); });
    let lastDone = -1, lastSaid = 0, failingSince = 0;
    for (;;) {
      await sleep(2000);
      if (stopDeadline && Date.now() > stopDeadline) { say('Atlas did not confirm the stop within 20 s; exiting.'); break; }
      let v;
      try {
        const r = await call(port, 'GET', '/api/agent/v1/tasks/current', undefined, agentTok);
        if (r.status !== 200) throw new Error(`HTTP ${r.status}`);
        v = r.json; failingSince = 0;
      } catch (e) {
        if (child && child.exitCode !== null) throw new Error('Atlas stopped during the task');
        failingSince = failingSince || Date.now();
        if (Date.now() - failingSince > 30000) throw new Error(`Lost contact with Atlas's server for 30 s (${e.message})`);
        continue;
      }
      const c = v.current;
      if (c && c.id === LS_TASK_ID) {
        if (c.done !== lastDone && Date.now() - lastSaid > 10000) { say(`${c.done}/${c.total} tests · ${c.counts.problem} problems · ${c.counts.partial} partial`); lastDone = c.done; lastSaid = Date.now(); }
        continue;
      }
      const last = v.last && v.last.id === LS_TASK_ID ? v.last : null;
      say(last ? `Task ${last.status}: ${last.message}` : 'The task has ended.');
      break;
    }
  } catch (e) {
    say('Could not run the task: ' + e.message);
    await reportFailed('AI Threat Atlas could not run the task: ' + e.message);
    process.exitCode = 1;
  } finally {
    if (child) { say("Stopping the Atlas server this runner started."); await stopChild(child); }
  }
}

(mode === 'check' ? check() : mode === 'task' ? task() : Promise.resolve(say(`Unknown mode "${mode}". Use task or check.`))).catch((e) => { say(e.message); process.exitCode = 1; });
