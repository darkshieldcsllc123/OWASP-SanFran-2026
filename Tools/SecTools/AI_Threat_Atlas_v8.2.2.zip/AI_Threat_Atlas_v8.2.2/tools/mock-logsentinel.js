#!/usr/bin/env node
'use strict';
// Stand-in for Log Sentinel's integration API v1. Shapes follow Log Sentinel 1.6.0 (whoami, taxonomy, the
// sample and reference schemas). Tasks are a minimal model of Log Sentinel's (one running task per integration,
// next/claim/log/status/started, cancel and remote end through hooks) for timing tests; the real thing is covered
// by test/logsentinel.e2e.test.js.
// For testing AI Threat Atlas without a real Log Sentinel. Zero dependencies, Node 18+.
// It is NOT Log Sentinel: detection, the AI agent and the review UI are not implemented.
//
//   node tools/mock-logsentinel.js [--port 8787] [--key lsk_mock_atlas] [--trust review|trusted]
//        [--scopes a,b,c] [--slug ai-threat-atlas] [--sign <public-key.pem>]
//
// Test hooks (no key needed, loopback only): GET /__mock/state, POST /__mock/emit {type,data},
// POST /__mock/fail {count,status,retryAfter,afterStore,noResults}, POST /__mock/config {trust,scopes,whoamiShape,requireSigned,maxRequestBytes,maxRequestMb,threatDetectors}.
const http = require('node:http');
const crypto = require('node:crypto');
const fs = require('node:fs');
const path = require('node:path');

const ALL_SCOPES = ['events:write', 'taxonomy:write', 'mitigations:write', 'feed:read', 'findings:read', 'findings:write', 'alerts:read', 'detections:read', 'actions:read', 'actions:propose', 'actions:approve', 'taxonomy:read', 'taxonomy:samples', 'metrics:read', 'agent:run'];
const SAMPLE_KINDS = ['injection', 'document', 'tool-description', 'config', 'command', 'url', 'transcript', 'log'];
const SAMPLE_KEYS = new Set(['risk', 'name', 'label', 'kind', 'payload', 'benign', 'logSource', 'log', 'note', 'adapted', 'source', 'ref']);
const EXAMPLE_TYPES = ['Documented incident', 'Red team assessment', 'Disclosed vulnerability', 'Field measurement', 'Research demonstration', 'Analogous incident', 'Illustrative scenario'];
const LEVELS = ['trace', 'debug', 'info', 'notice', 'warn', 'warning', 'error', 'err', 'critical', 'crit', 'fatal', 'alert', 'emergency'];
const SEVERITIES = ['low', 'medium', 'high', 'critical'];

function arg(name, def) { const i = process.argv.indexOf('--' + name); return i > 0 && process.argv[i + 1] ? process.argv[i + 1] : def; }

function createMock(opts = {}) {
  const st = {
    key: opts.key || 'lsk_mock_atlas_0123456789',
    integration: {
      id: 'int_atlas01', name: opts.name || 'AI Threat Atlas', slug: opts.slug || 'ai-threat-atlas',
      trust: opts.trust || 'review',
      scopes: opts.scopes || ['events:write', 'feed:read', 'findings:read', 'alerts:read', 'detections:read', 'actions:read', 'taxonomy:read', 'taxonomy:write'],
      requireSigned: !!opts.publicKey, publicKey: opts.publicKey || null,
    },
    whoamiShape: 'nested',
    readOnly: false,
    stored: [], // events stored for monitoring
    seen: new Map(), // source+id -> time
    content: new Map(), // contentId -> {kind,status,live,pending,versions,history}
    feed: [], seq: 0, waiters: new Set(),
    findings: [], actions: [], notes: [], agentRuns: 0,
    idem: new Map(), nonces: new Map(),
    fail: null, // {count,status,retryAfter}
    requests: [],
    risks: opts.risks || [],
    kinds: [], tasks: [], taskDelays: { started: 0 }, taskCalls: [], maxRunning: 0,
  };
  // Seed findings from the risks we know.
  const now = () => new Date().toISOString();
  st.findings.push({ id: 'f_seed_pi02', title: 'Indirect prompt injection in a fetched web page', severity: 'high', status: 'open', risks: ['PI-02'], source: 'proxy', firstSeen: now(), lastSeen: now(), count: 3, explanation: 'A fetched page told the agent to ignore its instructions. ⟦hidden tags: "obey"⟧' });
  st.findings.push({ id: 'f_seed_ops', title: 'Disk almost full on build-01', severity: 'medium', status: 'open', risks: [], source: 'syslog', firstSeen: now(), lastSeen: now(), count: 1 });

  function emit(type, data, onlyFor) {
    const ev = { specversion: '1.0', id: crypto.randomUUID(), source: 'urn:logsentinel:mock', type, time: now(), datacontenttype: 'application/json', lsseq: ++st.seq, data };
    if (onlyFor) ev._only = onlyFor;
    st.feed.push(ev);
    for (const w of st.waiters) w();
    return ev;
  }
  emit('logsentinel.finding.created', st.findings[0]);

  function err(res, status, code, message, hint, extra = {}, headers = {}) {
    const body = JSON.stringify({ ok: false, error: { code, message, hint, docs: '/api/v1/docs', ...extra } });
    res.writeHead(status, { 'content-type': 'application/json', ...headers }); res.end(body);
  }
  function ok(res, status, obj, headers = {}) { const body = JSON.stringify(obj); res.writeHead(status, { 'content-type': 'application/json', ...headers }); res.end(body); }
  const has = (s) => st.integration.scopes.includes(s);
  const effective = () => st.integration.scopes.filter((s) => s !== 'actions:approve' || st.integration.trust === 'trusted');

  function readBody(req) {
    // Like Log Sentinel: over the integration's request limit, keep reading (so the 413 answer arrives) but drop it.
    const max = st.maxRequestBytes || 10 * 1024 * 1024;
    return new Promise((resolve, reject) => { const chunks = []; let n = 0, failed = false; req.on('data', (c) => { if (failed) return; n += c.length; if (n > max) { failed = true; reject(Object.assign(new Error('too large'), { code: 'body_too_large' })); req.resume(); } else chunks.push(c); }); req.on('end', () => { if (!failed) resolve(Buffer.concat(chunks)); }); req.on('error', (e) => { if (!failed) reject(e); }); });
  }

  function authKey(req) {
    const a = String(req.headers.authorization || '');
    let m = /^Bearer\s+(\S+)$/i.exec(a) || /^Splunk\s+(\S+)$/i.exec(a);
    if (m) return m[1];
    if (req.headers['x-ls-key']) return String(req.headers['x-ls-key']);
    return null;
  }

  function checkSignature(req, raw, pathQuery) {
    const ts = req.headers['x-ls-timestamp'], nonce = req.headers['x-ls-nonce'], sig = req.headers['x-ls-signature'];
    if (!ts || !nonce || !sig) return ['signature_required', 'This integration requires every request to be signed.'];
    if (Math.abs(Date.now() / 1000 - Number(ts)) > 300) return ['stale_signature', 'X-LS-Timestamp is more than 5 minutes off.'];
    if (!/^[A-Za-z0-9_.:+/=-]{8,128}$/.test(nonce)) return ['bad_nonce', 'X-LS-Nonce must be 8-128 letters, digits and _ . : + / = -'];
    if (st.nonces.has(nonce)) return ['replayed', 'This nonce was already used.'];
    const msg = `${ts}\n${nonce}\n${req.method.toUpperCase()}\n${pathQuery}\n${crypto.createHash('sha256').update(raw).digest('hex')}`;
    let good = false;
    try { good = crypto.verify(null, Buffer.from(msg), st.integration.publicKey, Buffer.from(String(sig), 'base64')); } catch { good = false; }
    if (!good) return ['bad_signature', 'The signature does not match.'];
    st.nonces.set(nonce, Date.now());
    return null;
  }

  // ---------- content checks (an approximation of the guide's checks) ----------
  function shapeBad(src) {
    // repeated group containing a quantifier or alternatives, or a backreference
    if (/\\[1-9]|\\k</.test(src)) return 'backreference';
    const re = /\((?:\?:)?([^()]*)\)[+*{]/g; let m;
    while ((m = re.exec(src))) if (/[+*{]|\|/.test(m[1])) return 'repeated group containing a quantifier or alternatives';
    return null;
  }
  function checkRegex(p, flags, where) {
    if (typeof p !== 'string' || !p) throw new Error(`${where}: pattern is required`);
    if (flags && !/^[imsu]*$/.test(flags)) throw new Error(`${where}: flags may only be i, m, s, u`);
    try { new RegExp(p, flags || ''); } catch (e) { throw new Error(`${where}: does not compile: ${e.message}`); }
    const bad = shapeBad(p); if (bad) throw new Error(`${where}: ${bad} (catastrophic backtracking)`);
  }
  const nameOk = (n) => typeof n === 'string' && /^[a-z0-9][a-z0-9-]{0,63}$/.test(n);
  const riskIds = () => new Set(st.risks.map((r) => r.id));
  function hidden(s) { return /[\u200b-\u200f\u202a-\u202e\u2060-\u2064\ufeff]|[\u{e0000}-\u{e007f}]|\x1b/u.test(String(s || '')); }

  function contentFor(type, data) {
    const slug = st.integration.slug;
    if (JSON.stringify(data || {}).length > 64 * 1024) throw new Error('One item may be at most 64 KB');
    if (!data || typeof data !== 'object' || Array.isArray(data)) throw new Error('data must be an object');
    if (type === 'logsentinel.signature') {
      if (!riskIds().has(data.risk)) throw new Error(`/data/risk: unknown risk ${data.risk}`);
      const d = data.detector || {};
      if (!nameOk(d.name)) throw new Error('/data/detector/name: lowercase letters, digits and dashes');
      if (d.kind !== 'regex' && d.kind !== 'builtin') throw new Error('/data/detector/kind must be regex or builtin');
      if (d.kind === 'regex') checkRegex(d.pattern, d.flags, '/data/detector/pattern');
      for (const k of ['context', 'exclude']) if (d[k] !== undefined) checkRegex(d[k], d.flags, `/data/detector/${k}`);
      if (d.level && !['warn', 'error', 'critical'].includes(d.level)) throw new Error('/data/detector/level: warn, error or critical');
      if (d.floor && !SEVERITIES.includes(d.floor)) throw new Error('/data/detector/floor: low..critical');
      if (hidden(d.note)) throw new Error('/data/detector/note contains hidden characters');
      return { contentId: `signature:${data.risk}.${slug}.${d.name}`, kind: 'signature' };
    }
    if (type === 'logsentinel.sample') {
      if (!riskIds().has(data.risk)) throw new Error(`/data/risk: unknown risk ${data.risk}`);
      for (const k of Object.keys(data)) if (!SAMPLE_KEYS.has(k)) throw new Error(`/data/${k} is not allowed`);
      if (typeof data.name !== 'string' || !/^[a-z0-9][a-z0-9-]{0,40}$/.test(data.name)) throw new Error('/data/name: lowercase letters, digits and dashes, up to 41 characters');
      if (typeof data.label !== 'string' || data.label.length < 3 || data.label.length > 160) throw new Error('/data/label: 3 to 160 characters');
      if (!SAMPLE_KINDS.includes(data.kind)) throw new Error(data.kind === undefined ? '/data/kind is required' : `/data/kind must be one of ${SAMPLE_KINDS.join(', ')}`);
      if (typeof data.payload !== 'string' || !data.payload || data.payload.length > 20000) throw new Error('/data/payload: 1 to 20,000 characters');
      for (const k of ['adapted', 'note']) if (data[k] !== undefined && (typeof data[k] !== 'string' || data[k].length > 600)) throw new Error(`/data/${k} must be string, up to 600 characters`);
      if (data.log !== undefined) { const lines = Array.isArray(data.log) ? data.log : String(data.log).split('\n'); if (lines.length > 10 || lines.some((l) => String(l).length > 4000)) throw new Error('/data/log: up to 10 lines of up to 4,000 characters'); }
      if (data.source !== undefined && !st.content.has(`reference:${slug}.${data.source}`)) throw new Error(`/data/source: no reference named ${data.source}; send a logsentinel.reference first`);
      return { contentId: `sample:${data.risk}.x.${slug}.${data.name}`, kind: 'sample' };
    }
    if (type === 'logsentinel.reference') {
      if (!nameOk(data.name)) throw new Error('/data/name: lowercase letters, digits and dashes');
      if (!data.title) throw new Error('/data/title is required');
      if (!data.license) throw new Error('/data/license is required');
      if (data.url !== undefined && !/^https:\/\//.test(data.url)) throw new Error('/data/url must be https');
      return { contentId: `reference:${slug}.${data.name}`, kind: 'reference' };
    }
    if (type === 'logsentinel.risk') {
      if (!/^[A-Z]{2}-\d{2}$/.test(String(data.id || ''))) throw new Error('/data/id like XT-01');
      if (riskIds().has(data.id)) throw new Error(`/data/id: ${data.id} is already used`);
      for (const k of ['name', 'summary']) if (!data[k]) throw new Error(`/data/${k} is required`);
      if (hidden(data.name) || hidden(data.summary)) throw new Error('hidden characters in text the AI agent reads');
      return { contentId: `risk:${data.id}`, kind: 'risk' };
    }
    if (type === 'logsentinel.mitigation') {
      if (!nameOk(data.name)) throw new Error('/data/name: lowercase letters, digits and dashes');
      if (!data.run || typeof data.run.program !== 'string') throw new Error('/data/run/program is required');
      if (!(data.risks || []).length && !(data.detectors || []).length) throw new Error('give risks or detectors');
      let signatureValid = null;
      if (data.signature) {
        const { name, title, risks, detectors, mode, run, params } = data;
        const bytes = canonical({ name, title, risks, detectors, mode, run, params });
        try { signatureValid = !!st.integration.publicKey && crypto.verify(null, Buffer.from(bytes), st.integration.publicKey, Buffer.from(data.signature, 'base64')); } catch { signatureValid = false; }
      }
      return { contentId: `mitigation:${slug}.${data.name}`, kind: 'mitigation', signatureValid };
    }
    if (type === 'logsentinel.withdraw') {
      const c = st.content.get(data.contentId);
      if (!c || c.owner !== st.integration.id) throw new Error(`/data/contentId: no content ${data.contentId} of yours`);
      return { contentId: data.contentId, kind: 'withdraw' };
    }
    throw new Error('unknown content type');
  }

  function canonical(v) {
    if (v === null || typeof v !== 'object') return JSON.stringify(v);
    if (Array.isArray(v)) return `[${v.map((x) => (x === undefined ? 'null' : canonical(x))).join(',')}]`;
    return `{${Object.keys(v).filter((k) => v[k] !== undefined).sort().map((k) => `${JSON.stringify(k)}:${canonical(v[k])}`).join(',')}}`;
  }

  const SCOPE_FOR = { 'logsentinel.event': 'events:write', 'logsentinel.risk': 'taxonomy:write', 'logsentinel.sample': 'taxonomy:write', 'logsentinel.signature': 'taxonomy:write', 'logsentinel.reference': 'taxonomy:write', 'logsentinel.mitigation': 'mitigations:write', 'logsentinel.withdraw': 'taxonomy:write' };
  const ENVELOPE = new Set(['specversion', 'id', 'source', 'type', 'time', 'subject', 'datacontenttype', 'dataschema', 'data']);

  function processEvent(ev, index, dryRun, inRequest) {
    const r = { index, id: ev && ev.id, type: ev && ev.type };
    const reject = (code, message, p) => Object.assign(r, { status: 'rejected', error: { code, message, path: p ?? `/${index}`, hint: code === 'invalid_event' ? 'Wrap your payload: {specversion:"1.0", id, source, type, data}' : undefined } });
    if (!ev || typeof ev !== 'object' || Array.isArray(ev)) return reject('invalid_event', `/${index} must be an object`);
    for (const k of ['specversion', 'id', 'source', 'type']) if (typeof ev[k] !== 'string' || !ev[k]) return reject('invalid_event', `/${index}/${k} is required`, `/${index}/${k}`);
    if (ev.specversion !== '1.0') return reject('invalid_event', `/${index}/specversion must be "1.0"`);
    if (ev.time !== undefined && (typeof ev.time !== 'string' || !/^\d{4}-\d\d-\d\dT\d\d:\d\d:\d\d(\.\d+)?(Z|[+-]\d\d:\d\d)$/.test(ev.time))) return reject('invalid_event', `/${index}/time must be RFC 3339`);
    for (const k of Object.keys(ev)) if (!ENVELOPE.has(k) && !/^[a-z0-9]{1,20}$/.test(k)) return reject('invalid_event', `/${index}/${k}: extension attributes are lowercase letters and digits, up to 20`);
    const t = ev.type;
    const foreign = !t.startsWith('logsentinel.');
    const scope = foreign ? 'events:write' : SCOPE_FOR[t];
    if (!scope) return reject('unknown_type', `Unknown type ${t}`);
    let needed = scope;
    if (t === 'logsentinel.withdraw' && String(ev.data?.contentId || '').startsWith('mitigation:')) needed = 'mitigations:write';
    if (!has(needed)) return reject('missing_scope', `The key does not have the ${needed} scope.`);
    const dk = ev.source + '\u0000' + ev.id;
    if (st.seen.has(dk) || inRequest.has(dk)) { r.status = 'duplicate'; return r; }
    inRequest.add(dk);
    if (t === 'logsentinel.event' || foreign) {
      const d = ev.data;
      if (t === 'logsentinel.event') {
        if (!d || typeof d !== 'object' || !(typeof d.message === 'string' || typeof d.raw === 'string' || (d.record && typeof d.record === 'object'))) return reject('invalid_data', `/${index}/data needs message, raw or record`, `/${index}/data`);
        if (d.level !== undefined && !LEVELS.includes(d.level)) return reject('invalid_data', `/${index}/data/level is not a level`);
      }
      if (JSON.stringify(ev).length > 256 * 1024) return reject('invalid_data', 'One stored line is at most 256 KB');
      if (dryRun) { r.status = 'would_store'; return r; }
      st.seen.set(dk, Date.now());
      let level = 'info';
      if (foreign && d && typeof d === 'object') { level = d.level || ({ critical: 'critical', high: 'error', medium: 'warn', low: 'info' })[d.severity] || 'info'; }
      st.stored.push({ time: ev.time || now(), level, message: (d && (d.message || d.title || d.summary)) || t, type: t, ce_source: ev.source, ce_id: ev.id, subject: ev.subject, data: d });
      r.status = 'stored'; r.lines = 1; return r;
    }
    // content
    let info;
    try { info = contentFor(t, ev.data); } catch (e) { return reject('invalid_content', e.message, `/${index}/data`); }
    const existing = st.content.get(info.contentId);
    if (existing && existing.owner !== st.integration.id) return reject('invalid_content', `${info.contentId} belongs to another integration`);
    r.contentId = info.contentId;
    const trusted = st.integration.trust === 'trusted';
    if (info.kind === 'withdraw') {
      if (dryRun) { r.status = trusted ? 'would_be_withdrawn' : 'would_be_pending'; return r; }
      st.seen.set(dk, Date.now());
      if (trusted) { existing.status = 'withdrawn'; existing.live = null; r.status = 'withdrawn'; } else { existing.pendingWithdraw = true; r.status = 'queued_for_review'; r.reason = 'Withdrawals from a review-level integration wait for a person.'; }
      emit('logsentinel.content.status', { contentId: info.contentId, status: r.status }, st.integration.id);
      return r;
    }
    const json = canonical(ev.data);
    if (existing && (existing.liveJson === json || existing.pendingJson === json)) { r.status = 'unchanged'; r.version = existing.version; return r; }
    const checks = {};
    if (info.kind === 'signature') checks.detectors = [{ id: `${ev.data.risk}.${st.integration.slug}.${ev.data.detector.name}`, benignHits: 0, attackHits: 0, slowestMs: 0.4, benignExamples: [] }];
    if (info.kind === 'mitigation' && ev.data.mode === 'auto' && !info.signatureValid) checks.warnings = ['auto mode needs a valid Ed25519 signature; it will run as approve'];
    const live = trusted;
    if (dryRun) { r.status = live ? 'would_be_live' : 'would_be_pending'; r.checks = checks; return r; }
    st.seen.set(dk, Date.now());
    const c = existing || { contentId: info.contentId, kind: info.kind, owner: st.integration.id, version: 0, history: [] };
    c.version++; c.history.push({ version: c.version, at: now(), status: live ? 'live' : 'pending' });
    if (live) { c.status = 'live'; c.liveJson = json; c.data = ev.data; } else { c.status = c.status === 'live' ? 'live' : 'pending'; c.pendingJson = json; c.pendingData = ev.data; }
    c.signatureValid = info.signatureValid;
    st.content.set(info.contentId, c);
    r.status = live ? 'live' : 'queued_for_review'; r.version = c.version; r.checks = checks;
    if (!live) r.reason = 'This integration is review-level; a person approves its content.';
    emit('logsentinel.content.status', { contentId: info.contentId, status: r.status, version: c.version }, st.integration.id);
    if (!live) emit('logsentinel.review.pending', { contentId: info.contentId, integration: st.integration.name });
    return r;
  }

  function parseEvents(ct, raw) {
    const text = raw.toString('utf8');
    if (!text.trim()) throw Object.assign(new Error('The body is empty.'), { code: 'empty_body' });
    if (/ndjson|jsonl/.test(ct)) return text.split('\n').filter((l) => l.trim()).map((l) => { try { return JSON.parse(l); } catch { return { __bad: true }; } });
    let body; try { body = JSON.parse(text); } catch { throw Object.assign(new Error('The body is not valid JSON.'), { code: 'invalid_json' }); }
    if (Array.isArray(body)) return body;
    if (body && Array.isArray(body.events)) return body.events;
    return [body];
  }

  function feedVisible(ev) {
    if (ev._only && ev._only !== st.integration.id) return false;
    const t = ev.type;
    if (t === 'logsentinel.content.status') return true;
    if (t.startsWith('logsentinel.finding.')) return has('findings:read');
    if (t === 'logsentinel.alert') return has('alerts:read');
    if (t === 'logsentinel.detection') return has('detections:read');
    if (t.startsWith('logsentinel.action.')) return has('actions:read');
    if (t.startsWith('logsentinel.metric.')) return has('metrics:read');
    if (t === 'logsentinel.taxonomy.changed' || t === 'logsentinel.review.pending') return has('taxonomy:read');
    return false;
  }
  function typeMatch(filters, t) { return !filters.length || filters.some((f) => (f.endsWith('*') ? t.startsWith(f.slice(0, -1)) : f === t)); }
  const strip = (ev) => { const { _only, ...rest } = ev; return rest; };

  function idemCheck(req, res, u, raw) {
    const k = req.headers['idempotency-key'];
    if (!k) return { fresh: true };
    const fp = `${req.method} ${u.pathname} ${u.search} ${crypto.createHash('sha256').update(raw).digest('hex')}`;
    const prior = st.idem.get(k);
    if (prior) {
      if (prior.fp !== fp) { err(res, 409, 'idempotency_conflict', 'This Idempotency-Key was used for a different request.', 'Use a new key for a new request.'); return { done: true }; }
      ok(res, prior.status, prior.body, { 'idempotent-replayed': 'true' }); return { done: true };
    }
    return { fresh: true, remember: (status, body) => st.idem.set(k, { fp, status, body }) };
  }

  async function handle(req, res) {
    const u = new URL(req.url, 'http://x');
    const p = u.pathname;
    let raw = Buffer.alloc(0);
    try { raw = await readBody(req); } catch { return err(res, 413, 'body_too_large', 'Request too large', 'Send smaller batches.'); }
    st.requests.push({ method: req.method, path: p + u.search, idem: req.headers['idempotency-key'] || null, signed: !!req.headers['x-ls-signature'], at: Date.now(), auth: req.headers.authorization ? 'bearer' : null });
    if (st.requests.length > 2000) st.requests.shift();

    // test hooks
    if (p.startsWith('/__mock/')) {
      const b = raw.length ? JSON.parse(raw.toString()) : {};
      if (p === '/__mock/state') return ok(res, 200, { stored: st.stored, content: [...st.content.values()], findings: st.findings, actions: st.actions, notes: st.notes, agentRuns: st.agentRuns, feed: st.feed.length, requests: st.requests, integration: { ...st.integration, publicKey: !!st.integration.publicKey } });
      if (p === '/__mock/emit') { const ev = emit(b.type, b.data || {}); if (b.type === 'logsentinel.finding.created' && b.data?.id) st.findings.push(b.data); return ok(res, 200, { lsseq: ev.lsseq }); }
      if (p === '/__mock/fail') { st.fail = { count: b.count ?? 1, status: b.status || 429, retryAfter: b.retryAfter ?? 1, path: b.path || null, afterStore: !!b.afterStore, noResults: !!b.noResults }; return ok(res, 200, { ok: true }); }
      if (p === '/__mock/config') { for (const k of ['trust', 'scopes', 'requireSigned']) if (b[k] !== undefined) st.integration[k] = b[k]; if (b.whoamiShape) st.whoamiShape = b.whoamiShape; if (b.readOnly !== undefined) st.readOnly = b.readOnly; for (const k of ['maxRequestBytes', 'maxRequestMb', 'threatDetectors']) if (b[k] !== undefined) st[k] = b[k]; if (b.publicKey) st.integration.publicKey = b.publicKey; return ok(res, 200, { ok: true }); }
      if (p === '/__mock/reset-seen') { st.seen.clear(); return ok(res, 200, { ok: true }); }
      if (p === '/__mock/task') { const t = { id: 'tk_' + crypto.randomBytes(5).toString('hex'), kind: b.kind || 'scan', params: b.params || {}, runner: 'page', status: 'queued', integration: { id: st.integration.id, name: st.integration.name }, cancelRequested: false, log: [], statuses: [] }; st.tasks.push(t); for (const w of st.waiters) w(); return ok(res, 200, { task: t }); }
      return err(res, 404, 'not_found', 'no such hook');
    }

    // discovery (no key)
    if (req.method === 'GET' && p === '/api/v1') return ok(res, 200, { ok: true, name: 'Log Sentinel (mock)', version: 'mock-1.3', docs: '/api/v1/docs', openapi: '/api/v1/openapi.json', scopes: ALL_SCOPES });
    if (req.method === 'GET' && p === '/services/collector/health') return ok(res, 200, { text: 'HEC is healthy', code: 17 });

    const key = authKey(req);
    if (!key) return err(res, 401, 'missing_key', 'No key was sent.', 'Send Authorization: Bearer lsk_…');
    if (key !== st.key) return err(res, 401, 'invalid_key', 'This is not a key Log Sentinel knows.', 'Create an integration under Integrations → Add an integration and copy its key.');
    if (st.integration.requireSigned) {
      const bad = checkSignature(req, raw, p + u.search);
      if (bad) return err(res, 401, bad[0], bad[1], 'See /api/v1/docs#signed-requests');
    }
    let failAfterStore = false;
    if (st.fail && st.fail.count > 0 && (!st.fail.path || p.startsWith(st.fail.path))) {
      st.fail.count--;
      if (st.fail.noResults) return ok(res, 200, { ok: true });
      if (st.fail.afterStore) failAfterStore = true; else {
      if (st.fail.status === 429) return err(res, 429, 'rate_limited', 'A limit was reached.', 'Wait for Retry-After seconds. Nothing in the request was stored.', {}, { 'retry-after': String(st.fail.retryAfter) });
      return err(res, st.fail.status, 'internal_error', 'Injected failure', 'request id mock');
      }
    }
    const dryRun = u.searchParams.get('dryRun') === 'true' || (!st.integration.requireSigned && req.headers['x-ls-dry-run'] === 'true');
    const need = (s) => { if (has(s)) return false; err(res, 403, 'missing_scope', `The key for "${st.integration.name}" does not have the ${s} scope.`, `Grant ${s} on the integration's page in Log Sentinel.`); return true; };

    // ---- tasks (minimal) ----
    const running = () => st.tasks.filter((x) => x.status === 'running');
    const track = () => { st.maxRunning = Math.max(st.maxRunning, running().length); };
    if (p.startsWith('/api/v1/task')) {
      if (need('tasks:run')) return;
      let b = {}; try { b = raw.length ? JSON.parse(raw.toString()) : {}; } catch { return err(res, 400, 'invalid_json', 'Body is not JSON'); }
      st.taskCalls.push({ at: Date.now(), method: req.method, path: p, status: b.status });
      if (p === '/api/v1/task-kinds' && req.method === 'POST') { st.kinds = b.kinds || []; st.suggested = b.program ?? null; return ok(res, 200, { ok: true, kinds: st.kinds }); }
      if (p === '/api/v1/task-kinds') return ok(res, 200, { kinds: st.kinds });
      if (p === '/api/v1/tasks/next') {
        const pick = () => (running().length ? null : st.tasks.find((x) => x.status === 'queued') || null);
        let t = pick(); const wait = Math.min(30, Number(u.searchParams.get('wait')) || 0);
        if (!t && wait) { await new Promise((resolve) => { const tm = setTimeout(done, wait * 1000); function done() { clearTimeout(tm); st.waiters.delete(done); resolve(); } st.waiters.add(done); req.on('close', done); }); t = pick(); }
        return ok(res, 200, { task: t });
      }
      if (p === '/api/v1/tasks/started') {
        if (st.taskDelays.started) await new Promise((r) => setTimeout(r, st.taskDelays.started));
        if (!st.kinds.some((k) => k.kind === b.kind)) return err(res, 400, 'unknown_kind', 'not declared');
        if (running().length) return err(res, 409, 'not_claimable', 'Another task of this integration is running; one runs at a time.');
        const t = { id: 'tk_' + crypto.randomBytes(5).toString('hex'), kind: b.kind, params: b.params || {}, runner: 'page', status: 'running', startedHere: true, integration: { id: st.integration.id, name: st.integration.name }, cancelRequested: false, log: [], statuses: [] };
        st.tasks.push(t); track(); return ok(res, 201, { ok: true, task: t });
      }
      const tm = /^\/api\/v1\/tasks\/([\w-]+)(?:\/(claim|log|status))?$/.exec(p);
      const t = tm && st.tasks.find((x) => x.id === tm[1]);
      if (!t) return err(res, 404, 'not_found', 'No such task');
      if (!tm[2]) return ok(res, 200, t);
      if (tm[2] === 'claim') { if (t.status !== 'queued' || running().length) return err(res, 409, 'not_claimable', `Task ${t.id} is ${t.status}.`); t.status = 'running'; t.claimedAt = Date.now(); track(); return ok(res, 200, { ok: true, task: t }); }
      if (t.status !== 'running') return err(res, 409, 'not_running', `Task ${t.id} is ${t.status}, not running.`);
      if (tm[2] === 'log') { t.log.push(...(b.lines || [])); return ok(res, 200, { ok: true, cancelRequested: t.cancelRequested }); }
      t.statuses.push({ at: Date.now(), status: b.status, message: b.message, progress: b.progress });
      if (b.status && b.status !== 'running') { t.status = b.status; t.message = b.message; t.result = b.result; t.endedAt = Date.now(); for (const w of st.waiters) w(); }
      return ok(res, 200, { ok: true, cancelRequested: t.cancelRequested, task: t });
    }

    if (req.method === 'GET' && p === '/api/v1/whoami') {
      const who = { id: st.integration.id, name: st.integration.name, slug: st.integration.slug, trust: st.integration.trust, enabled: true, scopes: st.integration.scopes, effectiveScopes: effective(), signedRequests: st.integration.requireSigned, hasPublicKey: !!st.integration.publicKey, limits: { maxRequestMb: st.maxRequestMb || 10 }, ...(typeof st.threatDetectors === 'boolean' ? { events: { threatDetectors: st.threatDetectors } } : {}) };
      return ok(res, 200, st.whoamiShape === 'nested' ? { ok: true, integration: who } : { ok: true, ...who });
    }
    if (req.method === 'GET' && p === '/api/v1/status') return ok(res, 200, { ok: true, agent: { state: 'stopped', model: null }, findings: { open: st.findings.filter((f) => f.status === 'open').length }, pendingApprovals: st.actions.filter((a) => a.status === 'pending').length, reviewQueue: [...st.content.values()].filter((c) => c.status === 'pending').length });

    if (req.method === 'POST' && p === '/api/v1/events') {
      const ct = String(req.headers['content-type'] || '');
      let events;
      try { events = parseEvents(ct, raw); } catch (e) { return err(res, 400, e.code || 'invalid_body', e.message, 'Send one event, an array, or {events:[…]}.'); }
      if (events.length > 5000) return err(res, 413, 'too_many_items', 'Up to 5,000 events per request.', 'Send smaller batches.');
      const inRequest = new Set();
      const results = events.map((ev, i) => (ev && ev.__bad ? { index: i, status: 'rejected', error: { code: 'invalid_json', message: `line ${i + 1} is not JSON` } } : processEvent(ev, i, dryRun, inRequest)));
      const accepted = results.filter((r) => !['rejected', 'duplicate'].includes(r.status)).length;
      const rejected = results.filter((r) => r.status === 'rejected').length;
      const duplicates = results.filter((r) => r.status === 'duplicate').length;
      const body = { ok: accepted > 0 || (duplicates > 0 && rejected === 0), accepted, rejected, duplicates, dryRun, results };
      if (failAfterStore) return err(res, 503, 'internal_error', 'Injected failure after the events were stored', 'request id mock');
      if (!accepted && !duplicates) return ok(res, 400, { ...body, ok: false, error: { code: 'nothing_accepted', message: 'Every item was rejected.', hint: 'See results[].error.' } });
      return ok(res, 200, body);
    }

    if (req.method === 'GET' && p === '/api/v1/feed') {
      if (need('feed:read')) return;
      const types = (u.searchParams.get('types') || '').split(',').map((s) => s.trim()).filter(Boolean);
      const limit = Math.max(1, Math.min(1000, Number(u.searchParams.get('limit')) || 100));
      const wait = Math.max(0, Math.min(30, Number(u.searchParams.get('wait')) || 0));
      const afterRaw = u.searchParams.get('after');
      const pick = () => {
        const vis = st.feed.filter((e) => feedVisible(e) && typeMatch(types, e.type));
        if (afterRaw === null) return { list: vis.slice(-limit), more: false };
        const after = Number(afterRaw);
        const newer = vis.filter((e) => e.lsseq > after);
        return { list: newer.slice(0, limit), more: newer.length > limit };
      };
      let r = pick();
      if (!r.list.length && wait > 0 && afterRaw !== null) {
        await new Promise((resolve) => { const t = setTimeout(done, wait * 1000); function done() { clearTimeout(t); st.waiters.delete(done); resolve(); } st.waiters.add(done); req.on('close', done); });
        r = pick();
      }
      const next = r.list.length ? r.list[r.list.length - 1].lsseq : (afterRaw === null ? st.seq : Number(afterRaw));
      return ok(res, 200, { ok: true, events: r.list.map(strip), next, latest: st.seq, more: r.more });
    }

    if (req.method === 'GET' && p === '/api/v1/taxonomy') {
      if (need('taxonomy:read')) return;
      if (u.searchParams.get('samples') === 'true' && need('taxonomy:samples')) return;
      const extra = [...st.content.values()].filter((c) => c.kind === 'risk' && c.status === 'live').map((c) => c.data);
      const cats = []; for (const r of st.risks) if (!cats.some((c) => c.id === r.cat)) cats.push({ id: r.cat, name: r.catName || r.cat });
      return ok(res, 200, { revision: 'mock', title: 'Mock taxonomy', categories: cats, risks: [...st.risks.map(({ catName, ...r }) => r), ...extra], vocabulary: { layers: ['Model', 'Harness'], phases: ['Reconnaissance', 'Execution'], logSources: { app: 'Application logs' }, exampleTypes: EXAMPLE_TYPES, owaspAgentic: { ASI01: 'ASI01 Agent goal hijack' }, categories: cats } });
    }
    if (req.method === 'GET' && p === '/api/v1/mitigations') { if (need('taxonomy:read')) return; return ok(res, 200, { ok: true, mitigations: [...st.content.values()].filter((c) => c.kind === 'mitigation' && c.status === 'live').map((c) => ({ contentId: c.contentId, effectiveMode: 'approve' })) }); }
    if (req.method === 'GET' && p === '/api/v1/content') { return ok(res, 200, { ok: true, content: [...st.content.values()].filter((c) => c.owner === st.integration.id).map(({ liveJson, pendingJson, ...c }) => c) }); }
    let m = /^\/api\/v1\/content\/(.+)$/.exec(p);
    if (req.method === 'GET' && m) { const c = st.content.get(decodeURIComponent(m[1])); if (!c || c.owner !== st.integration.id) return err(res, 404, 'not_found', 'No such content'); const { liveJson, pendingJson, ...rest } = c; return ok(res, 200, { ok: true, ...rest }); }

    if (req.method === 'GET' && p === '/api/v1/findings') {
      if (need('findings:read')) return;
      const statuses = (u.searchParams.get('status') || 'open,acknowledged').split(',');
      let list = st.findings.filter((f) => statuses.includes('all') || statuses.includes(f.status));
      const risk = u.searchParams.get('risk'); if (risk) list = list.filter((f) => risk === 'any' ? f.risks.length : f.risks.some((r) => r === risk || r.startsWith(risk + '-')));
      return ok(res, 200, { ok: true, findings: list.slice(0, Number(u.searchParams.get('limit')) || 100) });
    }
    m = /^\/api\/v1\/findings\/([\w.-]+)(?:\/(status|notes))?$/.exec(p);
    if (m) {
      const f = st.findings.find((x) => x.id === m[1]);
      if (!f) return err(res, 404, 'not_found', 'No such finding');
      if (req.method === 'GET' && !m[2]) { if (need('findings:read')) return; return ok(res, 200, { ok: true, finding: f }); }
      if (req.method === 'POST' && m[2]) {
        if (need('findings:write')) return;
        const idem = idemCheck(req, res, u, raw); if (idem.done) return;
        let b; try { b = JSON.parse(raw.toString() || '{}'); } catch { return err(res, 400, 'invalid_json', 'Body is not JSON'); }
        let out;
        if (m[2] === 'status') {
          if (!['acknowledged', 'muted', 'resolved', 'open'].includes(b.status)) return err(res, 400, 'invalid_body', 'status must be acknowledged, muted, resolved or open', '', { path: '/status' });
          if (['muted', 'resolved'].includes(b.status) && f.risks.length && st.integration.trust !== 'trusted') return err(res, 403, 'needs_trusted', 'Muting or resolving a security finding needs a trusted integration.', 'Ask the operator to make this integration trusted.');
          if (!dryRun) f.status = b.status;
          out = { ok: true, dryRun, finding: { id: f.id, status: dryRun ? f.status : b.status } };
        } else {
          if (typeof b.note !== 'string' || !b.note) return err(res, 400, 'invalid_body', 'note is required');
          if (!dryRun) st.notes.push({ findingId: f.id, note: b.note, at: now() });
          out = { ok: true, dryRun, findingId: f.id };
        }
        if (!dryRun) idem.remember?.(200, out);
        return ok(res, 200, out);
      }
    }
    if (req.method === 'GET' && p === '/api/v1/actions') { if (need('actions:read')) return; const s = u.searchParams.get('status'); return ok(res, 200, { ok: true, actions: st.actions.filter((a) => !s || a.status === s) }); }
    if (req.method === 'POST' && p === '/api/v1/actions') {
      if (need('actions:propose')) return;
      if (st.readOnly) return err(res, 409, 'read_only', 'Autonomy is read-only; nothing can be proposed.', 'Switch autonomy to Propose.');
      const idem = idemCheck(req, res, u, raw); if (idem.done) return;
      let b; try { b = JSON.parse(raw.toString() || '{}'); } catch { return err(res, 400, 'invalid_json', 'Body is not JSON'); }
      if (!['run_program', 'run_command', 'write_file'].includes(b.type)) return err(res, 400, 'invalid_body', 'type must be run_program, run_command or write_file', '', { path: '/type' });
      const a = { id: 'a_' + crypto.randomBytes(4).toString('hex'), status: 'pending', type: b.type, program: b.program, args: b.args, reason: b.reason, proposedBy: 'integration:' + st.integration.id, createdAt: now() };
      if (dryRun) return ok(res, 200, { ok: true, dryRun: true, decision: 'would wait for approval' });
      st.actions.push(a); emit('logsentinel.action.pending', a);
      const out = { ok: true, action: a }; idem.remember?.(201, out); return ok(res, 201, out);
    }
    m = /^\/api\/v1\/actions\/([\w.-]+)(?:\/(approve|reject))?$/.exec(p);
    if (m) {
      const a = st.actions.find((x) => x.id === m[1]);
      if (!a) return err(res, 404, 'not_found', 'No such action');
      if (req.method === 'GET' && !m[2]) { if (need('actions:read')) return; return ok(res, 200, { ok: true, action: a }); }
      if (req.method === 'POST' && m[2]) {
        if (need('actions:approve')) return;
        if (st.integration.trust !== 'trusted') return err(res, 403, 'needs_trusted', 'Only a trusted integration may approve.', 'Ask the operator to make it trusted.');
        if (a.proposedBy === 'integration:' + st.integration.id) return err(res, 403, 'self_approval', 'This integration proposed the action and cannot decide it.', 'Give the approving role to another integration.');
        if (a.status !== 'pending') return err(res, 409, 'not_pending', 'Already decided.');
        if (!dryRun) a.status = m[2] === 'approve' ? 'approved' : 'rejected';
        return ok(res, 200, { ok: true, dryRun, action: a });
      }
    }
    if (req.method === 'POST' && p === '/api/v1/agent/run') { if (need('agent:run')) return; const idem = idemCheck(req, res, u, raw); if (idem.done) return; if (!dryRun) st.agentRuns++; const out = { ok: true, dryRun, started: !dryRun }; idem.remember?.(202, out); return ok(res, 202, out); }
    if (req.method === 'GET' && p === '/api/v1/metrics') { if (need('metrics:read')) return; return ok(res, 200, { ok: true, metrics: [{ name: 'log.lines', labels: ['source', 'level'] }] }); }
    if (req.method === 'POST' && p === '/api/v1/metrics/query') { if (need('metrics:read')) return; return ok(res, 200, { ok: true, series: [{ labels: { source: 'AI Threat Atlas (integration)' }, points: [[Date.now(), st.stored.length]] }] }); }
    return err(res, 404, 'not_found', `No endpoint ${req.method} ${p}`, 'GET /api/v1 lists every endpoint.');
  }

  const server = http.createServer((req, res) => { handle(req, res).catch((e) => { try { err(res, 500, 'internal_error', String(e && e.stack || e), 'mock bug'); } catch {} }); });
  return { server, state: st, emit };
}

function risksFromAtlas(file) {
  try {
    const d = JSON.parse(fs.readFileSync(file, 'utf8'));
    const cats = new Map(d.categories.map((c) => [c.id, c]));
    return d.techniques.filter((t) => t.frameworkId === 'research-2026-69').map((t) => ({ id: t.id, cat: t.id.slice(0, 2), catName: cats.get(t.categoryId)?.name || t.id.slice(0, 2), name: t.name, sev: t.severity === 'High' ? '4' : '3', lik: '3', hint: (t.detectionSignals || [])[0] || t.mechanism, asi: (t.mapping?.relatedCategories || []).find((x) => /^ASI\d\d$/.test(x)) || null, mit: t.mitigations || [], detectors: [] }));
  } catch { return []; }
}

module.exports = { createMock, risksFromAtlas };

if (require.main === module) {
  const pubFile = arg('sign', null);
  const mock = createMock({
    key: arg('key', process.env.LS_MOCK_KEY || 'lsk_mock_atlas_0123456789'),
    trust: arg('trust', 'review'), slug: arg('slug', 'ai-threat-atlas'),
    scopes: arg('scopes', null)?.split(',').map((s) => s.trim()).filter(Boolean),
    publicKey: pubFile ? fs.readFileSync(pubFile, 'utf8') : null,
    risks: risksFromAtlas(path.join(__dirname, '..', 'taxonomy.json')),
  });
  const port = Number(arg('port', 8787));
  mock.server.listen(port, '127.0.0.1', () => {
    console.log(`Mock Log Sentinel on http://127.0.0.1:${mock.server.address().port}`);
    console.log(`Key: ${mock.state.key}  trust: ${mock.state.integration.trust}  scopes: ${mock.state.integration.scopes.join(',')}`);
  });
}
