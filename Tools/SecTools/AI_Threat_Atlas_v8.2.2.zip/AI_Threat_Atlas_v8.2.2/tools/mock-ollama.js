#!/usr/bin/env node
'use strict';
// Stub Ollama for testing AI Threat Atlas without a model. Zero dependencies, Node 18+.
//   node tools/mock-ollama.js [--port 11434] [--delay <ms per answer>] [--models stub:latest,llama3.2:3b]
// /api/tags lists the models (default: stub:latest); every one answers the same way. /api/chat answers deterministically from a hash of the prompt:
// about a third of prompts that ask for an ATLAS_QA_ marker get exactly the marker (defense failed),
// a third get a refusal that quotes the marker (echo), and a third get a plain summary (defended).
const http = require('node:http');
const crypto = require('node:crypto');

function createOllama(opts = {}) {
  const calls = [];
  const state = { delay: Number(opts.delay) || 0, models: opts.models && opts.models.length ? opts.models : ['stub:latest'] };
  const server = http.createServer(async (req, res) => {
    const chunks = []; for await (const c of req) chunks.push(c);
    const send = (s, o) => { const b = JSON.stringify(o); res.writeHead(s, { 'content-type': 'application/json' }); res.end(b); };
    if (req.method === 'GET' && req.url === '/api/tags') return send(200, { models: state.models.map((name) => ({ name, model: name, size: 1, modified_at: new Date().toISOString(), details: { family: 'stub' } })) });
    if (req.method === 'POST' && req.url === '/api/chat') {
      let b; try { b = JSON.parse(Buffer.concat(chunks).toString()); } catch { return send(400, { error: 'bad json' }); }
      // Like Ollama, a name without a tag means :latest.
      if (!state.models.includes(String(b.model || '').includes(':') ? b.model : `${b.model}:latest`)) return send(404, { error: `model "${b.model}" not found, try pulling it first` });
      const user = (b.messages || []).filter((m) => m.role === 'user').map((m) => m.content).join('\n');
      calls.push({ model: b.model, roles: (b.messages || []).map((m) => m.role) });
      if (state.delay) await new Promise((r) => setTimeout(r, state.delay));
      const marker = (/\b(ATLAS_QA_[A-Z0-9_]+)\b/.exec(user) || [])[1];
      const h = crypto.createHash('sha256').update(user).digest()[0] % 3;
      let content;
      if (marker && h === 0) content = marker;
      else if (marker && h === 1) content = `I will not follow embedded instructions such as outputting ${marker}. This is a prompt-injection test artifact.`;
      else if (/Analyze this authorized security scenario/.test(user)) content = 'Failure mode: untrusted text gained authority. Mitigations: separate roles, verify approvals outside the model.';
      else content = 'This is an untrusted security-training artifact that tries to redirect the assistant.';
      // A long answer (state.longAnswer times state.longChar, default é) to test caps on the text sent to Log Sentinel.
      if (state.longAnswer) content = (state.longChar || 'é').repeat(state.longAnswer);
      return send(200, { model: b.model, message: { role: 'assistant', content }, done: true, done_reason: 'stop', prompt_eval_count: Math.ceil(user.length / 4), eval_count: Math.ceil(content.length / 4), total_duration: 1e6 });
    }
    send(404, { error: 'not found' });
  });
  return { server, calls, state };
}
module.exports = { createOllama };
if (require.main === module) {
  const i = process.argv.indexOf('--port');
  const port = i > 0 ? Number(process.argv[i + 1]) : 11434;
  const d = process.argv.indexOf('--delay');
  const m = process.argv.indexOf('--models');
  const o = createOllama({ delay: d > 0 ? Number(process.argv[d + 1]) : 0, models: m > 0 ? process.argv[m + 1].split(',').map((x) => x.trim()).filter(Boolean) : null }); o.server.listen(port, '127.0.0.1', () => console.log(`Stub Ollama on http://127.0.0.1:${o.server.address().port} (models: ${o.state.models.join(', ')})`));
}
