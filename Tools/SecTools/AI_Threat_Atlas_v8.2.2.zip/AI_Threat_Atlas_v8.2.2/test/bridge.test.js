'use strict';
// End-to-end tests of the Log Sentinel bridge against the stand-in Log Sentinel and stub Ollama.
// Run: node --test test/   (Node 18+; no packages)
const test = require('node:test');
const assert = require('node:assert/strict');
const { spawn } = require('node:child_process');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const crypto = require('node:crypto');
const { createMock, risksFromAtlas } = require('../tools/mock-logsentinel.js');
const { createOllama } = require('../tools/mock-ollama.js');

const ROOT = path.join(__dirname, '..');
const KEY = 'lsk_test_atlas_key_000000';
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const listen = (srv) => new Promise((r) => srv.listen(0, '127.0.0.1', () => r(srv.address().port)));

let mock, mockPort, ollama, ollamaPort, dataDir, atlas, base, token;

async function startAtlas() {
  const port = 20000 + Math.floor(Math.random() * 20000);
  atlas = spawn(process.execPath, ['server.js'], { cwd: ROOT, env: { ...process.env, ATLAS_DATA_DIR: dataDir, ATLAS_PORT: String(port), ATLAS_NO_BROWSER: '1', ATLAS_FEED_WAIT: '1' }, stdio: ['ignore', 'pipe', 'pipe'] });
  let out = '';
  base = await new Promise((resolve, reject) => {
    const t = setTimeout(() => reject(new Error('Atlas did not start: ' + out)), 8000);
    atlas.stdout.on('data', (c) => { out += c; const m = /Open: (http:\/\/127\.0\.0\.1:\d+)/.exec(out); if (m) { clearTimeout(t); resolve(m[1]); } });
    atlas.stderr.on('data', (c) => { out += c; });
  });
  token = fs.readFileSync(path.join(dataDir, 'agent-token.txt'), 'utf8').trim();
}
async function stopAtlas() { if (atlas && atlas.exitCode === null) { atlas.kill(); await new Promise((r) => atlas.once('exit', r)); } }

async function api(route, { method = 'GET', body, headers = {}, agent = false } = {}) {
  const r = await fetch(base + route, { method, headers: { 'content-type': 'application/json', ...(agent ? { authorization: 'Bearer ' + token } : {}), ...headers }, body: body === undefined ? undefined : JSON.stringify(body) });
  const text = await r.text(); let json; try { json = JSON.parse(text); } catch { json = { text }; }
  return { status: r.status, json };
}
const post = (route, body, o = {}) => api(route, { method: 'POST', body: body ?? {}, ...o });
async function until(fn, ms = 8000, step = 100) { const end = Date.now() + ms; let last; while (Date.now() < end) { last = await fn(); if (last) return last; await sleep(step); } throw new Error('timed out waiting; last=' + JSON.stringify(last)); }
const stored = () => mock.state.stored;
// fetch() ignores a Host header, so Host checks use node:http directly.
function rawGet(route, headers) {
  const u = new URL(base + route);
  return new Promise((resolve, reject) => { const req = require('node:http').request({ host: u.hostname, port: u.port, path: u.pathname + u.search, headers }, (res) => { res.resume(); res.on('end', () => resolve(res.statusCode)); }); req.on('error', reject); req.end(); });
}
const atlasEvents = () => stored().filter((x) => x.type === 'atlas.audit.result');

test.before(async () => {
  dataDir = fs.mkdtempSync(path.join(os.tmpdir(), 'atlas-test-'));
  mock = createMock({ key: KEY, risks: risksFromAtlas(path.join(ROOT, 'taxonomy.json')) });
  mockPort = await listen(mock.server);
  ollama = createOllama(); ollamaPort = await listen(ollama.server);
  await startAtlas();
  const r = await post('/api/config', { ollamaUrl: `http://127.0.0.1:${ollamaPort}` });
  assert.equal(r.status, 200, JSON.stringify(r.json));
});
test.after(async () => { await stopAtlas(); mock.server.close(); ollama.server.close(); mock.server.closeAllConnections?.(); ollama.server.closeAllConnections?.(); fs.rmSync(dataDir, { recursive: true, force: true }); });

test('refuses foreign Host names, cross-site requests and other origins (DNS rebinding)', async () => {
  const port = new URL(base).port;
  assert.equal(await rawGet('/api/audits', { host: `evil.example:${port}`, origin: `http://evil.example:${port}` }), 421);
  assert.equal(await rawGet('/', { host: `evil.example:${port}` }), 421);
  assert.equal(await rawGet('/api/audits', { host: `127.0.0.1:${Number(port) + 1}` }), 421, 'a different port is a different origin');
  assert.equal(await rawGet('/api/audits', { host: `localhost:${port}` }), 200);
  assert.equal(await rawGet('/api/audits', { host: `[::1]:${port}` }), 200);
  assert.equal((await api('/api/audits', { headers: { 'sec-fetch-site': 'cross-site' } })).status, 403);
  assert.equal((await api('/api/sentinel/check', { headers: { 'sec-fetch-site': 'same-site' } })).status, 403, 'another localhost port is another origin');
  assert.equal((await api('/api/audits', { headers: { 'sec-fetch-site': 'same-origin' } })).status, 200);
  assert.equal((await api('/api/audits', { headers: { origin: 'http://evil.example' } })).status, 403);
  assert.equal((await api('/api/audits')).status, 200);
});

test('agent API needs the Atlas token and lists the new operations', async () => {
  assert.equal((await api('/api/agent/v1')).status, 401);
  assert.equal((await api('/api/agent/v1', { headers: { authorization: 'Bearer ' + KEY } })).status, 401, 'the Log Sentinel key is not the Atlas token');
  const r = await api('/api/agent/v1', { agent: true });
  assert.equal(r.status, 200); assert.equal(r.json.version, '8.2.2');
  for (const op of ['GET /api/agent/v1/sentinel/status', 'POST /api/agent/v1/sentinel/unsent', 'POST /api/agent/v1/sentinel/detector', 'GET /api/agent/v1/sentinel/outbox', 'POST /api/agent/v1/tasks/run', 'GET /api/agent/v1/tasks/current', 'POST /api/agent/v1/tasks/stop']) assert.ok(r.json.operations.includes(op), op);
  const o = await api('/api/agent/v1/openapi.json', { agent: true });
  for (const p of ['/api/agent/v1/sentinel/status', '/api/agent/v1/sentinel/unsent', '/api/agent/v1/sentinel/detector', '/api/agent/v1/sentinel/outbox', '/api/agent/v1/sentinel/samples', '/api/agent/v1/tasks/run', '/api/agent/v1/tasks/current', '/api/agent/v1/tasks/stop']) assert.ok(o.json.paths[p], p);
});

test('settings are validated and the key never comes back to the browser', async () => {
  assert.equal((await post('/api/sentinel/config', { key: 'not-a-key' })).status, 400);
  assert.equal((await post('/api/sentinel/config', { url: 'http://127.0.0.1:8787/ls' })).status, 400);
  assert.equal((await post('/api/sentinel/config', { url: 'http://10.0.0.5:8787' })).status, 400);
  assert.equal((await post('/api/sentinel/config', { signingKeyPath: '../../etc/passwd.pem' })).status, 400);
  const r = await post('/api/sentinel/config', { url: `http://127.0.0.1:${mockPort}`, key: KEY, enabled: true, feedEnabled: true, autoPublishAudit: true });
  assert.equal(r.status, 200); assert.equal(r.json.key, 'configured');
  assert.ok(!JSON.stringify(r.json).includes(KEY));
  const onDisk = JSON.parse(fs.readFileSync(path.join(dataDir, 'sentinel-config.json'), 'utf8'));
  assert.equal(onDisk.key, KEY);
  if (process.platform !== 'win32') assert.equal(fs.statSync(path.join(dataDir, 'sentinel-config.json')).mode & 0o777, 0o600);
});

test('Connect reads whoami (flat or nested) and lists what the key allows', async () => {
  let r = await api('/api/sentinel/check');
  assert.equal(r.status, 200, JSON.stringify(r.json));
  assert.equal(r.json.identity.slug, 'ai-threat-atlas');
  const byId = Object.fromEntries(r.json.features.map((f) => [f.id, f]));
  assert.equal(byId.publish.ok, true); assert.equal(byId.taxonomyWrite.ok, true);
  assert.deepEqual(byId.propose.missing, ['actions:propose']);
  mock.state.whoamiShape = 'flat';
  r = await api('/api/sentinel/check');
  assert.equal(r.json.identity.slug, 'ai-threat-atlas'); assert.equal(r.json.identity.trust, 'review');
  mock.state.whoamiShape = 'nested';
  const cfg = await api('/api/sentinel/config');
  assert.equal(cfg.json.identity.slug, 'ai-threat-atlas'); assert.ok(cfg.json.lastContactAt);
});

test('a wrong key is reported with Log Sentinel\'s code and hint', async () => {
  await post('/api/sentinel/config', { key: 'lsk_wrong_key_123456' });
  const r = await api('/api/sentinel/check');
  assert.equal(r.status, 502, 'Log Sentinel refusing Atlas is not Atlas refusing the caller');
  assert.equal(r.json.code, 'invalid_key'); assert.equal(r.json.upstreamStatus, 401); assert.match(r.json.error, /Add an integration/);
  const ag = await api('/api/agent/v1/sentinel/findings', { agent: true });
  assert.equal(ag.status, 502); assert.equal(ag.json.upstream, 'logsentinel');
  await post('/api/sentinel/config', { key: KEY });
});

let scanAudits = [];
test('a server-side scan sends one result event per test, with outcome, risks, and the prompt and response', async () => {
  const before = atlasEvents().length;
  const r = await post('/api/sentinel/scan/start', { model: 'stub:latest', ids: ['PI-02', 'HC-03', 'LLM01-T01', 'OA-01'], modes: ['payload', 'raw'], examples: 'first' });
  assert.equal(r.status, 202, JSON.stringify(r.json));
  const job = await until(async () => { const s = await api('/api/sentinel/scan/status?id=' + r.json.job.id); return s.json.job.status === 'completed' && s.json.job; }, 15000);
  const audits = (await api('/api/audits')).json.audits.filter((a) => a.batchId === job.id);
  scanAudits = audits;
  const sendable = audits.filter((a) => a.status !== 'skipped');
  assert.ok(audits.some((a) => a.status === 'skipped'), 'OA-01 raw has no runnable payload and is skipped');
  await until(() => atlasEvents().length - before === sendable.length);
  await sleep(300);
  assert.equal(atlasEvents().length - before, sendable.length, 'skipped tests are not sent, and nothing twice');
  const evs = atlasEvents().slice(before);
  for (const line of evs) {
    const d = line.data;
    assert.equal(line.ce_source, 'urn:tool:ai-threat-atlas');
    assert.ok(['problem', 'partial', 'ok', 'error'].includes(d.outcome), d.outcome);
    assert.equal(line.level, d.level);
    const a = audits.find((x) => x.id === d.auditId); assert.ok(a);
    // The full request and answer, as Log Sentinel's task page shows them (data.prompt, data.response).
    assert.equal(d.textIncluded, true);
    assert.equal(d.prompt, a.submittedPrompt); assert.equal(d.response, a.response);
    assert.equal(d.systemPrompt || '', a.systemPrompt || '');
    assert.ok(!('submittedPrompt' in d) && !d.textTruncated);
    const want = { problem: 'error', partial: 'warn', ok: 'info', error: 'notice' }[d.outcome];
    assert.equal(d.level, want);
    if (a.markerExactMatch) assert.equal(d.outcome, 'problem');
    else if (a.markerSeen) assert.equal(d.outcome, 'partial');
  }
  const risks = (tid, type) => evs.find((l) => l.data.techniqueId === tid && l.data.testType === type)?.data.risks;
  assert.deepEqual(risks('LLM01-T01', 'payload'), ['PI-02']);
  assert.deepEqual(risks('LLM01-T01', 'raw'), ['PI-01']);
  assert.deepEqual(risks('HC-03', 'raw'), ['PI-01', 'HC-03'], 'the kind of test first, then the technique');
  assert.deepEqual(risks('PI-02', 'payload'), ['PI-02']);
  assert.ok(evs.some((l) => l.data.outcome === 'problem'), 'the stub model obeys some probes');
});

const scanAndWait = async (body) => {
  const before = atlasEvents().length;
  const r = await post('/api/sentinel/scan/start', { model: 'stub:latest', ...body });
  assert.equal(r.status, 202, JSON.stringify(r.json));
  const job = await until(async () => { const j = (await api('/api/sentinel/scan/status?id=' + r.json.job.id)).json.job; return j.status === 'completed' && j; }, 15000);
  await until(() => atlasEvents().length - before === job.total - job.skipped);
  return atlasEvents().slice(before);
};
const noText = (line) => line.data.textIncluded === false && !('prompt' in line.data) && !('response' in line.data) && !('systemPrompt' in line.data) && !JSON.stringify(line).includes('ATLAS_QA_');

test('with "Include prompt and response text" off in Atlas, no result carries text, whatever a scan asks', async () => {
  assert.equal((await post('/api/sentinel/config', { includeText: false })).status, 200);
  assert.equal((await api('/api/sentinel/config')).json.text.on, false);
  try {
    for (const line of await scanAndWait({ ids: ['PI-02'], modes: ['payload', 'raw'] })) assert.ok(noText(line), JSON.stringify(line.data).slice(0, 300));
    // The setting is a ceiling: a scan (the agent API, a Log Sentinel task) can't turn text on.
    for (const line of await scanAndWait({ ids: ['PI-02'], modes: ['raw'], includeText: true })) assert.ok(noText(line));
  } finally { await post('/api/sentinel/config', { includeText: true }); }
  // With the setting on, a scan can still turn it off for itself.
  for (const line of await scanAndWait({ ids: ['PI-02'], modes: ['raw'], includeText: false })) assert.ok(noText(line));
});

test('text is held back while Log Sentinel runs its threat detectors on Atlas\'s events', async () => {
  mock.state.threatDetectors = true;
  try {
    assert.equal((await api('/api/sentinel/check')).status, 200);
    assert.deepEqual((await api('/api/sentinel/config')).json.text, { on: true, detectors: 'on' });
    for (const line of await scanAndWait({ ids: ['PI-02'], modes: ['raw'] })) assert.ok(noText(line), 'held back');
    mock.state.threatDetectors = false;
    assert.equal((await api('/api/sentinel/check')).status, 200);
    assert.deepEqual((await api('/api/sentinel/config')).json.text, { on: true, detectors: 'off' });
    for (const line of await scanAndWait({ ids: ['PI-02'], modes: ['raw'] })) assert.equal(line.data.textIncluded, true);
  } finally { delete mock.state.threatDetectors; await api('/api/sentinel/check'); }
});

test('long answers are cut to fit Log Sentinel\'s 24 KB per task result, keeping the start and the end', async () => {
  // 100,000 two-byte characters, then 30,000 control characters that JSON escapes six times over.
  for (const [ch, n] of [['é', 100000], ['\u001b', 30000]]) {
    ollama.state.longAnswer = n; ollama.state.longChar = ch;
    try {
      for (const line of await scanAndWait({ ids: ['PI-02', 'PI-03'], modes: ['payload', 'raw'] })) {
        const d = line.data;
        assert.equal(d.textTruncated, true);
        assert.ok(JSON.stringify(d).length <= 24 * 1024, `data is ${JSON.stringify(d).length} JSON characters`);
        assert.match(d.response, /…\[\d+ characters cut\]…/);
        assert.ok(d.response.startsWith(ch) && d.response.endsWith(ch), 'the start and the end are kept');
        assert.ok(d.prompt.length > 100, 'the prompt keeps its share');
      }
    } finally { ollama.state.longAnswer = 0; delete ollama.state.longChar; }
  }
});

test('the outbox adapts to the integration\'s request limit in Log Sentinel', async () => {
  // Results pile up while Log Sentinel is away; then it accepts at most ~6 KB per request, and says nothing about it.
  mock.state.fail = { count: 1000, status: 503, retryAfter: 0, path: '/api/v1/events' };
  const ids = [];
  for (let n = 0; n < 6; n++) ids.push((await post('/api/audits', { techniqueId: 'PI-01', model: 'stub:latest', testType: 'raw', submittedPrompt: 'probe ' + n + ' ' + 'x'.repeat(1500), response: 'answer ' + n })).json.record.id);
  await until(async () => (await api('/api/sentinel/outbox')).json.queued >= 6);
  mock.state.fail = null; mock.state.maxRequestBytes = 6 * 1024;
  try {
    const n0 = mock.state.requests.filter((r) => r.path === '/api/v1/events').length;
    await post('/api/sentinel/outbox/flush', {});
    await until(async () => (await api('/api/sentinel/outbox')).json.queued === 0, 15000);
    for (const id of ids) assert.equal(atlasEvents().filter((l) => l.data.auditId === id && l.data.textIncluded).length, 1, 'each delivered once, with its text');
    assert.ok(mock.state.requests.filter((r) => r.path === '/api/v1/events').length - n0 >= 3, 'refused, then sent in smaller requests');
    assert.equal((await api('/api/sentinel/outbox')).json.rejected.length, 0, 'nothing put aside');
  } finally { delete mock.state.maxRequestBytes; }
});

test('a request limit reported in whoami splits a send of chosen results, and the answers are merged', async () => {
  const audits = (await api('/api/audits')).json.audits.filter((a) => a.status !== 'skipped' && a.submittedPrompt).slice(0, 8);
  mock.state.maxRequestMb = 0.012; // about 10 KB per request after Atlas's margin
  try {
    assert.equal((await api('/api/sentinel/check')).status, 200);
    const n0 = mock.state.requests.filter((r) => r.path === '/api/v1/events').length;
    const r = await post('/api/sentinel/audits/publish', { auditIds: audits.map((a) => a.id) });
    assert.equal(r.status, 200, JSON.stringify(r.json).slice(0, 300));
    const res = r.json.result || r.json;
    assert.ok(mock.state.requests.filter((x) => x.path === '/api/v1/events').length - n0 > 1, 'more than one request');
    assert.deepEqual(res.results.map((x) => x.index), audits.map((_, i) => i), 'results in event order');
    assert.equal(res.accepted + res.duplicates + res.rejected, audits.length);
    assert.equal(res.ok, true); assert.ok(!('httpStatus' in res) && !('error' in res));
  } finally { delete mock.state.maxRequestMb; await api('/api/sentinel/check'); }
});

test('every sent event is a valid CloudEvent with a stable id and the Atlas dataschema', async () => {
  const reqEvents = [];
  for (const a of scanAudits.filter((x) => x.status !== 'skipped').slice(0, 3)) {
    const r = await post('/api/sentinel/audits/publish', { ids: [a.id], dryRun: false });
    assert.equal(r.status, 200); assert.equal(r.json.results[0].status, 'duplicate', 'resending the same result is a duplicate');
    reqEvents.push(r.json.results[0].id);
  }
  assert.equal(new Set(reqEvents).size, reqEvents.length);
  const schema = JSON.parse(fs.readFileSync(path.join(ROOT, 'spec', 'schemas', 'atlas.audit.result.json'), 'utf8'));
  const ex = JSON.parse(fs.readFileSync(path.join(ROOT, 'spec', 'examples', 'atlas.audit.result.json'), 'utf8'));
  assert.equal(ex.dataschema, 'urn:tool:ai-threat-atlas:schema:audit.result:1');
  for (const k of schema.required) assert.ok(k in ex.data, 'example has ' + k);
  for (const line of atlasEvents()) for (const k of schema.required) assert.ok(k in line.data, `stored event has ${k}`);
});

test('grading a result sends its new state once; regrading back and forth stays idempotent per state', async () => {
  const a = scanAudits.find((x) => x.status === 'complete' && !x.markerExactMatch && !x.markerSeen);
  assert.ok(a, 'need an unflagged result');
  const n0 = atlasEvents().filter((l) => l.data.auditId === a.id).length;
  const g = await api('/api/audits/' + a.id, { method: 'PATCH', body: { verdict: 'negative', notes: 'obeyed in a later manual check' } });
  assert.equal(g.status, 200);
  await until(() => atlasEvents().filter((l) => l.data.auditId === a.id).length === n0 + 1);
  const last = atlasEvents().filter((l) => l.data.auditId === a.id).pop();
  assert.equal(last.data.outcome, 'problem'); assert.equal(last.level, 'error'); assert.equal(last.data.reviewed, true); assert.equal(last.data.verdict, 'negative');
  const again = await post('/api/sentinel/audits/publish', { ids: [a.id] });
  assert.equal(again.json.results[0].status, 'duplicate');
  // saving notes only (same verdict) sends nothing new
  await api('/api/audits/' + a.id, { method: 'PATCH', body: { verdict: 'negative', notes: 'more notes' } });
  await sleep(2500);
  assert.equal(atlasEvents().filter((l) => l.data.auditId === a.id).length, n0 + 1);
  // a real verdict change is sent
  await api('/api/audits/' + a.id, { method: 'PATCH', body: { verdict: 'positive', notes: '' } });
  await until(() => atlasEvents().filter((l) => l.data.auditId === a.id).length === n0 + 2);
  assert.equal(atlasEvents().filter((l) => l.data.auditId === a.id).pop().data.outcome, 'ok');
});

test('the outbox retries after 429 and 5xx with the same ids, so nothing is lost or stored twice', async () => {
  const mk = async (resp) => (await post('/api/audits', { techniqueId: 'PI-01', techniqueName: 'Direct prompt injection', model: 'stub:latest', testType: 'raw', marker: 'ATLAS_QA_TEST_MARK', submittedPrompt: 'say ATLAS_QA_TEST_MARK', response: resp })).json.record;
  mock.state.fail = { count: 1, status: 429, retryAfter: 1, path: '/api/v1/events' };
  const a1 = await mk('ATLAS_QA_TEST_MARK');
  assert.equal(a1.markerExactMatch, true);
  await until(() => atlasEvents().some((l) => l.data.auditId === a1.id), 10000);
  mock.state.fail = { count: 2, status: 503, retryAfter: 0, path: '/api/v1/events' };
  const a2 = await mk('No. I will not print ATLAS_QA_TEST_MARK.');
  assert.equal(a2.markerSeen, true); assert.equal(a2.markerExactMatch, false);
  // The outbox is saved to disk shortly after it changes.
  const held = await until(() => { try { return (JSON.parse(fs.readFileSync(path.join(dataDir, 'sentinel-outbox.json'), 'utf8')).queue || []).find((ev) => ev.data?.auditId === a2.id); } catch { return null; } }, 3000, 50);
  assert.ok(held, 'waiting in the outbox'); assert.ok(!('prompt' in held.data) && !('response' in held.data) && held.data.textIncluded, 'the outbox on disk holds no text');
  await until(() => atlasEvents().some((l) => l.data.auditId === a2.id), 15000);
  const e2 = atlasEvents().find((l) => l.data.auditId === a2.id);
  assert.equal(e2.data.outcome, 'partial'); assert.equal(e2.level, 'warn');
  // Retried from the outbox, which keeps results without their text: the text is added back when sent.
  assert.equal(e2.data.prompt, 'say ATLAS_QA_TEST_MARK'); assert.equal(e2.data.response, a2.response); assert.equal(e2.data.textIncluded, true);
  // The case that matters: Log Sentinel stored the batch, then the answer was lost (503). The resend must reuse the ids.
  mock.state.fail = { count: 1, status: 503, retryAfter: 0, path: '/api/v1/events', afterStore: true };
  const a3 = await mk('ATLAS_QA_TEST_MARK');
  await until(() => atlasEvents().some((l) => l.data.auditId === a3.id), 10000);
  await until(async () => (await api('/api/sentinel/outbox')).json.queued === 0, 15000);
  assert.equal(atlasEvents().filter((l) => l.data.auditId === a3.id).length, 1, 'stored once although it was sent twice');
  const ids = atlasEvents().map((l) => l.ce_id);
  assert.equal(new Set(ids).size, ids.length, 'no event stored twice');
  const ob = await api('/api/sentinel/outbox');
  assert.equal(ob.json.queued, 0); assert.equal(ob.json.error, '');
});

test('an answer without per-item results pauses the outbox for a minute instead of retrying every 2 s', async () => {
  mock.state.fail = { count: 50, path: '/api/v1/events', noResults: true };
  const n0 = mock.state.requests.filter((r) => r.path === '/api/v1/events').length;
  await post('/api/audits', { techniqueId: 'PI-01', model: 'stub:latest', testType: 'raw', response: 'no', submittedPrompt: 'x' });
  await sleep(6000);
  const n = mock.state.requests.filter((r) => r.path === '/api/v1/events').length - n0;
  assert.equal(n, 1, `sent ${n} times in 6 s`);
  const ob = (await api('/api/sentinel/outbox')).json;
  assert.equal(ob.queued, 1); assert.match(ob.error, /without per-item results/); assert.ok(ob.retryAt);
  mock.state.fail = null;
  const after = await post('/api/sentinel/outbox/flush', {});
  assert.equal(after.json.queued, 0);
});

test('events refused for a setup reason stay in the outbox until the integration is fixed', async () => {
  const scopes = mock.state.integration.scopes;
  mock.state.integration.scopes = scopes.filter((x) => x !== 'events:write');
  const a = (await post('/api/audits', { techniqueId: 'PI-01', model: 'stub:latest', testType: 'raw', response: 'no', submittedPrompt: 'y' })).json.record;
  await until(async () => /missing_scope/.test((await api('/api/sentinel/outbox')).json.error));
  assert.equal((await api('/api/sentinel/outbox')).json.queued, 1, 'kept, not dropped');
  mock.state.integration.scopes = scopes;
  await post('/api/sentinel/outbox/flush', {});
  await until(() => atlasEvents().some((l) => l.data.auditId === a.id));
  assert.equal((await api('/api/sentinel/outbox')).json.queued, 0);
});

test('send unsent: dry run counts them, sending queues and delivers each once', async () => {
  await post('/api/sentinel/config', { autoPublishAudit: false });
  for (let i = 0; i < 3; i++) await post('/api/audits', { techniqueId: 'IS-02', model: 'stub:latest', testType: 'payload', response: 'summary', submittedPrompt: 'x' });
  await post('/api/audits', { techniqueId: 'IS-02', model: 'stub:latest', testType: 'raw', status: 'skipped', response: '' });
  const dry = await post('/api/sentinel/audits/unsent', { dryRun: true });
  assert.equal(dry.json.unsent, 3, JSON.stringify(dry.json)); assert.equal(dry.json.result.dryRun, true);
  const before = atlasEvents().length;
  const r = await post('/api/sentinel/audits/unsent', {});
  assert.equal(r.json.queued, 3);
  await until(() => atlasEvents().length === before + 3);
  assert.equal((await post('/api/sentinel/audits/unsent', { dryRun: true })).json.unsent, 0);
  await post('/api/sentinel/config', { autoPublishAudit: true });
});

test('per-item rejections come back with Log Sentinel\'s reasons instead of a bare error', async () => {
  await post('/api/sentinel/config', { controlsEnabled: false });
  const r = await post('/api/sentinel/content/custom', { type: 'logsentinel.signature', data: { risk: 'PI-01', detector: { name: 'bad-one', kind: 'regex', pattern: '(a+)+$' } }, dryRun: true });
  assert.equal(r.status, 200, JSON.stringify(r.json));
  assert.equal(r.json.result.results[0].status, 'rejected');
  assert.match(r.json.result.results[0].error.message, /catastrophic/);
  const m = await post('/api/sentinel/content/custom', { type: 'logsentinel.mitigation', data: { name: 'x', run: { program: '/bin/true' }, risks: ['PI-01'] } });
  assert.equal(m.status, 403, 'mitigations need the control setting');
});

test('the canary detector and samples pass the content checks; sample kind comes from Log Sentinel\'s vocabulary', async () => {
  const d = await post('/api/sentinel/detector', { dryRun: true });
  assert.equal(d.status, 200);
  assert.equal(d.json.result.results[0].status, 'would_be_pending');
  assert.equal(d.json.result.results[0].contentId, 'signature:PI-01.ai-threat-atlas.atlas-qa-marker');
  const re = new RegExp(d.json.detector.detector.pattern);
  assert.ok(re.test('agent said ATLAS_QA_LLM01_T01_1_OVERRIDE')); assert.ok(!re.test('ATLAS_QA_ markers'));
  const s = await post('/api/sentinel/content/publish', { techniqueIds: ['HC-03', 'HC-04', 'LLM01-T01'], dryRun: true });
  assert.equal(s.status, 200, JSON.stringify(s.json));
  assert.equal(s.json.kind, 'injection', 'a kind from the sample schema, not the evidence types in vocabulary.exampleTypes');
  assert.ok(s.json.submitted >= 2);
  assert.ok(s.json.result.results.every((x) => x.status === 'would_be_pending'), JSON.stringify(s.json.result.results));
  assert.ok(s.json.skipped.some((x) => x.id === 'LLM01-T01' && /mapping/.test(x.reason)));
  const real = await post('/api/sentinel/detector', {});
  assert.equal(real.json.result.results[0].status, 'queued_for_review');
  const again = await post('/api/sentinel/detector', {});
  assert.equal(again.json.result.results[0].status, 'unchanged', 'a resend is a new event; Log Sentinel sees the same content');
  assert.ok(!('exclude' in d.json.detector.detector), 'nothing in a line can switch the detector off');
});

test('content sent again after a withdrawal is a new event, not a duplicate', async () => {
  mock.state.integration.trust = 'trusted';
  await post('/api/sentinel/config', { controlsEnabled: true });
  const ref = { type: 'logsentinel.reference', data: { name: 'atlas-research', title: 'Atlas research PDFs', license: 'CC-BY-4.0' } };
  assert.equal((await post('/api/sentinel/content/custom', ref)).json.result.results[0].status, 'live');
  const w = await post('/api/sentinel/content/custom', { type: 'logsentinel.withdraw', data: { contentId: 'reference:ai-threat-atlas.atlas-research', reason: 'test' } });
  assert.equal(w.json.result.results[0].status, 'withdrawn');
  const back = await post('/api/sentinel/content/custom', ref);
  assert.notEqual(back.json.result.results[0].status, 'duplicate');
  mock.state.integration.trust = 'review';
  await post('/api/sentinel/config', { controlsEnabled: false });
});

test('the feed long-polls, keeps its cursor on disk and resumes after a restart without gaps or repeats', async () => {
  const seq1 = mock.emit('logsentinel.alert', { title: 'Alert one', severity: 'high', risks: ['PI-02'] }).lsseq;
  await until(async () => (await api('/api/sentinel/feed')).json.events.some((e) => e.lsseq === seq1), 6000);
  await stopAtlas();
  const cur = JSON.parse(fs.readFileSync(path.join(dataDir, 'sentinel-cursor.json'), 'utf8'));
  assert.ok(cur.next >= seq1, 'cursor saved on exit');
  const mark = mock.state.requests.length;
  const seq2 = mock.emit('logsentinel.finding.created', { id: 'f_while_down', title: 'Emitted while Atlas was down', severity: 'high', status: 'open', risks: ['HC-03'] }).lsseq;
  await startAtlas();
  await until(async () => (await api('/api/sentinel/feed')).json.events.some((e) => e.lsseq === seq2), 8000);
  const evs = (await api('/api/sentinel/feed?limit=500')).json.events;
  const seqs = evs.map((e) => e.lsseq);
  assert.equal(new Set(seqs).size, seqs.length, 'no event cached twice');
  const first = mock.state.requests.slice(mark).find((r) => r.path.startsWith('/api/v1/feed'));
  assert.equal(new URL('http://x' + first.path).searchParams.get('after'), String(cur.next), 'resumes from the saved cursor');
  assert.match(first.path, /wait=1/);
  assert.ok(!/detection/.test(decodeURIComponent(first.path)), 'detections are not requested');
});

test('the feed starts over when Log Sentinel is behind the cursor or the URL changes', async () => {
  const before = mock.state.seq;
  const cur = await until(() => { const c = JSON.parse(fs.readFileSync(path.join(dataDir, 'sentinel-cursor.json'), 'utf8')); return c.next === before && c; });
  // simulate a reset Log Sentinel: its sequence starts again from 0
  mock.state.feed = []; mock.state.seq = 0;
  mock.emit('logsentinel.alert', { title: 'After the reset', severity: 'high' });
  await until(async () => (await api('/api/sentinel/feed')).json.events.some((e) => e.data?.title === 'After the reset'), 8000);
  assert.ok(cur.next > mock.state.seq);
  // a different URL: cursor and cache are cleared at once
  const other = require('node:http').createServer((q, r) => { r.writeHead(503); r.end(); });
  const port2 = await listen(other);
  try {
    await post('/api/sentinel/config', { url: `http://127.0.0.1:${port2}` });
    const f = (await api('/api/sentinel/feed')).json;
    assert.equal(f.total, 0); assert.equal(f.cursor, null);
  } finally {
    await post('/api/sentinel/config', { url: `http://127.0.0.1:${mockPort}` });
    other.closeAllConnections?.(); other.close();
  }
  await api('/api/sentinel/check');
});

test('a finding\'s research risks can be scanned: the findings proxy passes them through', async () => {
  const r = await api('/api/sentinel/findings?status=all');
  assert.equal(r.status, 200);
  const list = r.json.findings.findings;
  assert.ok(list.find((f) => f.id === 'f_seed_pi02').risks.includes('PI-02'));
});

test('control calls are off by default; when on they carry an Idempotency-Key and dry runs change nothing', async () => {
  assert.equal((await post('/api/sentinel/control', { operation: 'finding.note', id: 'f_seed_pi02', data: { note: 'x' } })).status, 403);
  await post('/api/sentinel/config', { controlsEnabled: true });
  mock.state.integration.scopes.push('findings:write');
  const dry = await post('/api/sentinel/control', { operation: 'finding.note', id: 'f_seed_pi02', data: { note: 'dry' }, dryRun: true });
  assert.equal(dry.status, 200, JSON.stringify(dry.json)); assert.equal(mock.state.notes.length, 0);
  const real = await post('/api/sentinel/control', { operation: 'finding.note', id: 'f_seed_pi02', data: { note: 'Atlas: model stub:latest fails PI-02 probes' } });
  assert.equal(real.status, 200); assert.equal(mock.state.notes.length, 1);
  const req = mock.state.requests.filter((x) => x.path.startsWith('/api/v1/findings/f_seed_pi02/notes')).pop();
  assert.ok(req.idem, 'Idempotency-Key sent');
  const st = await post('/api/sentinel/control', { operation: 'finding.status', id: 'f_seed_pi02', data: { status: 'resolved' } });
  assert.equal(st.status, 502); assert.equal(st.json.code, 'needs_trusted'); assert.equal(st.json.upstreamStatus, 403);
  assert.equal((await post('/api/sentinel/control', { operation: 'action.approve', id: 'a_x' })).status, 403, 'approvals need their own opt-in');
  assert.equal((await post('/api/sentinel/control', { operation: 'finding.note', id: '../../admin', data: { note: 'x' } })).status, 400);
  for (const id of ['..', '.', '.x', 'a..b']) assert.equal((await post('/api/sentinel/control', { operation: 'finding.note', id, data: { note: 'x' } })).status, 400, id);
  await post('/api/sentinel/config', { controlsEnabled: false });
});

test('import adds only risks Atlas lacks, and results on imported risks map to the remote id', async () => {
  const pv = await post('/api/sentinel/taxonomy/import', { preview: true });
  assert.equal(pv.status, 200); assert.equal(pv.json.alreadyLocal, 69); assert.equal(pv.json.converted, 0);
  mock.state.integration.trust = 'trusted';
  const add = await post('/api/sentinel/content/custom', { type: 'logsentinel.risk', data: { id: 'XT-01', cat: 'XT', catName: 'Extra', name: 'Extra test risk', summary: 'A risk another tool added.' } });
  assert.equal(add.json.result.results[0].status, 'live', JSON.stringify(add.json));
  mock.state.integration.trust = 'review';
  const im = await post('/api/sentinel/taxonomy/import', {});
  assert.equal(im.json.imported, 1);
  const t = await api('/api/agent/v1/techniques/' + encodeURIComponent('LS:XT-01'), { agent: true });
  assert.equal(t.status, 200); assert.deepEqual(t.json.logSentinelRisks, ['XT-01']);
});

test('signed requests: requests and mitigation scripts are signed with the key in .atlas-data', async () => {
  const { publicKey, privateKey } = crypto.generateKeyPairSync('ed25519');
  fs.writeFileSync(path.join(dataDir, 'ls-sign.pem'), privateKey.export({ type: 'pkcs8', format: 'pem' }), { mode: 0o600 });
  mock.state.integration.publicKey = publicKey.export({ type: 'spki', format: 'pem' });
  mock.state.integration.requireSigned = true;
  let r = await api('/api/sentinel/check');
  assert.equal(r.status, 502); assert.equal(r.json.code, 'signature_required'); assert.equal(r.json.upstreamStatus, 401);
  assert.equal((await post('/api/sentinel/config', { signingKeyPath: '.atlas-data/missing.pem' })).status, 400);
  assert.equal((await post('/api/sentinel/config', { signingKeyPath: '.atlas-data/ls-sign.pem', controlsEnabled: true })).status, 200);
  r = await api('/api/sentinel/check');
  assert.equal(r.status, 200, JSON.stringify(r.json));
  mock.state.integration.scopes.push('mitigations:write');
  const script = (name) => ({ type: 'logsentinel.mitigation', data: { name, title: 'Open a ticket', risks: ['PI-02'], mode: 'auto', run: { program: '/usr/local/bin/ticket', args: ['{src}'] }, params: { src: { type: 'word', from: 'source' } } } });
  // without the opt-in nothing is signed
  assert.equal((await post('/api/sentinel/content/custom', script('unsigned-one'))).status, 200);
  assert.equal(mock.state.content.get('mitigation:ai-threat-atlas.unsigned-one').signatureValid, null);
  await post('/api/sentinel/config', { signMitigations: true });
  // the agent API never signs, even with the opt-in on
  assert.equal((await post('/api/agent/v1/sentinel/content', script('from-agent'), { agent: true })).status, 200);
  assert.equal(mock.state.content.get('mitigation:ai-threat-atlas.from-agent').signatureValid, null);
  const m = await post('/api/sentinel/content/custom', script('note-ticket'));
  assert.equal(m.status, 200, JSON.stringify(m.json));
  const c = mock.state.content.get('mitigation:ai-threat-atlas.note-ticket');
  assert.equal(c.signatureValid, true, 'script signature verifies against the registered public key');
  await post('/api/sentinel/config', { signMitigations: false });
  const signedReqs = mock.state.requests.filter((x) => x.signed).length;
  assert.ok(signedReqs >= 2);
  // feed and outbox keep working on signed requests
  const before = atlasEvents().length;
  await post('/api/audits', { techniqueId: 'PI-01', model: 'stub:latest', testType: 'raw', response: 'no', submittedPrompt: 'x' });
  await until(() => atlasEvents().length === before + 1);
  mock.state.integration.requireSigned = false;
  await post('/api/sentinel/config', { signingKeyPath: '', controlsEnabled: false });
});
