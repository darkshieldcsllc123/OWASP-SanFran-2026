'use strict';
// Log Sentinel tasks in Atlas: timing and safety cases that need a controllable Log Sentinel (the stand-in's
// minimal Tasks API). The real Log Sentinel is covered by test/logsentinel.e2e.test.js.
// Run: node --test test/tasks.test.js
const test = require('node:test');
const assert = require('node:assert/strict');
const { spawn } = require('node:child_process');
const http = require('node:http');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const { createMock, risksFromAtlas } = require('../tools/mock-logsentinel.js');
const { createOllama } = require('../tools/mock-ollama.js');

const ROOT = path.join(__dirname, '..');
const KEY = 'lsk_test_tasks_key_000000';
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const listen = (srv) => new Promise((r) => srv.listen(0, '127.0.0.1', () => r(srv.address().port)));
let mock, mockPort, ollama, dataDir, atlas, base, token;

function startAtlasIn(dir, extraEnv = {}) {
  const port = 20000 + Math.floor(Math.random() * 20000);
  const child = spawn(process.execPath, ['server.js'], { cwd: ROOT, env: { ...process.env, ATLAS_DATA_DIR: dir, ATLAS_PORT: String(port), ATLAS_NO_BROWSER: '1', ATLAS_FEED_WAIT: '1', ATLAS_TASK_WAIT: '1', ...extraEnv }, stdio: ['ignore', 'pipe', 'pipe'] });
  let out = '';
  const ready = new Promise((resolve, reject) => {
    const t = setTimeout(() => reject(new Error('no start: ' + out)), 8000);
    child.stdout.on('data', (c) => { out += c; const m = /Open: (http:\/\/127\.0\.0\.1:\d+)/.exec(out); if (m) { clearTimeout(t); resolve(m[1]); } });
    child.stderr.on('data', (c) => { out += c; });
    child.on('exit', (code) => { clearTimeout(t); reject(Object.assign(new Error(`exited ${code}: ${out}`), { code, out })); });
  });
  return { child, ready, out: () => out };
}
async function api(route, { method = 'GET', body, agent = false } = {}) {
  const r = await fetch(base + route, { method, headers: { 'content-type': 'application/json', ...(agent ? { authorization: 'Bearer ' + token } : {}) }, body: body === undefined ? undefined : JSON.stringify(body) });
  const text = await r.text(); let json; try { json = JSON.parse(text); } catch { json = { text }; }
  return { status: r.status, json };
}
const post = (route, body, o = {}) => api(route, { method: 'POST', body: body ?? {}, ...o });
async function until(fn, ms = 10000, step = 100) { const end = Date.now() + ms; let last; while (Date.now() < end) { last = await fn(); if (last) return last; await sleep(step); } throw new Error('timed out; last=' + JSON.stringify(last)); }
const idle = () => until(async () => { const v = (await api('/api/sentinel/tasks')).json; return !v.current && !v.batch && v; }, 20000);

test.before(async () => {
  dataDir = fs.mkdtempSync(path.join(os.tmpdir(), 'atlas-tasks-'));
  mock = createMock({ key: KEY, risks: risksFromAtlas(path.join(ROOT, 'taxonomy.json')), scopes: ['events:write', 'feed:read', 'findings:read', 'taxonomy:read', 'tasks:run'] });
  mockPort = await listen(mock.server);
  ollama = createOllama(); await listen(ollama.server);
  const a = startAtlasIn(dataDir); atlas = a.child; base = await a.ready;
  token = fs.readFileSync(path.join(dataDir, 'agent-token.txt'), 'utf8').trim();
  await post('/api/config', { ollamaUrl: `http://127.0.0.1:${ollama.server.address().port}` });
  await post('/api/sentinel/config', { url: `http://127.0.0.1:${mockPort}`, key: KEY, enabled: true });
  await api('/api/sentinel/check');
  await until(() => mock.state.kinds.length);
});
test.after(async () => {
  if (atlas.exitCode === null) { atlas.kill(); await new Promise((r) => atlas.once('exit', r)); }
  for (const s of [mock.server, ollama.server]) { s.closeAllConnections?.(); s.close(); }
  fs.rmSync(dataDir, { recursive: true, force: true });
});

test('a second Atlas on the same data folder refuses to start', async () => {
  const b = startAtlasIn(dataDir);
  await assert.rejects(b.ready, (e) => e.code === 1 && /already running with this data folder/.test(e.out));
  assert.equal((await api('/api/health')).status, 200, 'the first one is unaffected');
});

test('a page task handed out while a started scan is being reported is left queued, then run after it', async () => {
  mock.state.taskDelays.started = 1500; ollama.state.delay = 20;
  const r = post('/api/sentinel/scan/start', { model: 'stub:latest', ids: ['PI-01', 'PI-02'], modes: ['raw'] });
  await sleep(300);
  const queued = (await fetch(`http://127.0.0.1:${mockPort}/__mock/task`, { method: 'POST', body: JSON.stringify({ params: { model: 'stub:latest', ids: ['HC-03'], modes: ['raw'] } }) }).then((x) => x.json())).task;
  const started = (await r).json.job;
  mock.state.taskDelays.started = 0;
  assert.match(started.taskId, /^tk_/, 'the scan started here is still shown as a task');
  await until(() => mock.state.tasks.find((x) => x.id === queued.id).status === 'done', 20000);
  const st = mock.state.tasks.find((x) => x.id === started.taskId), pg = mock.state.tasks.find((x) => x.id === queued.id);
  assert.equal(st.status, 'done', 'the started task got its final status');
  assert.ok(pg.claimedAt >= st.endedAt, 'the page task was claimed only after the other ended');
  assert.equal(mock.state.maxRunning, 1, 'never two tasks at once');
  ollama.state.delay = 0; await idle();
});

test('when Log Sentinel ends a task (restart, time limit), Atlas stops the scan and becomes free', async () => {
  ollama.state.delay = 80;
  const t = (await fetch(`http://127.0.0.1:${mockPort}/__mock/task`, { method: 'POST', body: JSON.stringify({ params: { model: 'stub:latest' } }) }).then((x) => x.json())).task;
  await until(() => mock.state.tasks.find((x) => x.id === t.id).status === 'running');
  await sleep(1000);
  const mt = mock.state.tasks.find((x) => x.id === t.id); mt.status = 'failed'; const endedAt = Date.now();
  const v = await until(async () => { const x = (await api('/api/sentinel/tasks')).json; return !x.current && x.last && x.last.id === t.id && x; }, 15000);
  assert.equal(v.last.status, 'ended in Log Sentinel');
  assert.ok(Date.now() - endedAt < 12000, 'noticed within a few seconds');
  assert.equal(mt.statuses.filter((s) => s.at > endedAt).length, 0, 'no more reports for a task Log Sentinel ended');
  const job = (await api('/api/agent/v1/audits?limit=1000', { agent: true })).json.audits.filter((a) => a.taskId === t.id);
  assert.ok(job.length < 338, 'the scan stopped early');
  ollama.state.delay = 0; await idle();
});

test('Stop aborts the model request in flight', async () => {
  ollama.state.delay = 4000;
  const r = await post('/api/sentinel/scan/start', { model: 'stub:latest', ids: ['PI-01'], modes: ['raw'] });
  await sleep(500);
  const t0 = Date.now();
  await post('/api/sentinel/scan/stop', { id: r.json.job.id });
  await until(async () => (await api('/api/sentinel/scan/status?id=' + r.json.job.id)).json.job.status === 'stopped', 3000);
  assert.ok(Date.now() - t0 < 2500, 'did not wait for the 4 s answer');
  const audits = (await api('/api/agent/v1/audits?limit=1000', { agent: true })).json.audits.filter((a) => a.batchId === r.json.job.id);
  assert.equal(audits.length, 0, 'a test stopped mid-request is not saved');
  ollama.state.delay = 0; await idle();
});

test('the page\'s batch holds the scan slot even when it is not shown as a task', async () => {
  await post('/api/sentinel/config', { tasksReport: false });
  const batchId = crypto.randomUUID();
  const s = await post('/api/sentinel/batch/start', { batchId, model: 'stub:latest', total: 2 });
  assert.equal(s.json.taskId, null); assert.ok(!s.json.busy);
  const busy = await post('/api/sentinel/scan/start', { model: 'stub:latest', ids: ['PI-01'], modes: ['raw'] });
  assert.equal(busy.status, 409, 'no server scan beside a running batch');
  const other = await post('/api/sentinel/batch/start', { batchId: crypto.randomUUID(), model: 'stub:latest', total: 2 });
  assert.equal(other.json.busy, true, 'no second batch');
  await post('/api/sentinel/batch/end', { batchId, stopped: false });
  assert.equal((await post('/api/sentinel/scan/start', { model: 'stub:latest', ids: ['PI-01'], modes: ['raw'] })).status, 202);
  await post('/api/sentinel/config', { tasksReport: true });
  await idle();
});

test('a re-graded test is not sent as a new task result', async () => {
  const r = await post('/api/sentinel/scan/start', { model: 'stub:latest', ids: ['PI-03'], modes: ['payload'] });
  await idle();
  const a = (await api('/api/agent/v1/audits?limit=1000', { agent: true })).json.audits.find((x) => x.batchId === r.json.job.id);
  assert.equal(a.taskId, r.json.job.taskId);
  await api('/api/audits/' + a.id, { method: 'PATCH', body: { verdict: a.verdict === 'negative' ? 'positive' : 'negative' } });
  await post('/api/sentinel/config', { autoPublishAudit: true });
  await api('/api/audits/' + a.id, { method: 'PATCH', body: { verdict: 'negative', notes: 'checked' } });
  await until(() => mock.state.stored.filter((l) => l.data?.auditId === a.id).length >= 2);
  const lines = mock.state.stored.filter((l) => l.data?.auditId === a.id);
  assert.equal(lines.filter((l) => l.data.taskId).length, 1, 'only the first state names the task');
  assert.ok(lines.every((l) => l.data.scanTaskId === r.json.job.taskId), 'later states still say which scan they came from');
  await post('/api/sentinel/config', { autoPublishAudit: false });
});

test('the program handover checks which Log Sentinel issued the token', async () => {
  const r = await post('/api/agent/v1/tasks/run', { taskId: 'tk_abc', token: 'lst_0123456789abcdef', lsUrl: 'http://127.0.0.9:1' }, { agent: true });
  assert.equal(r.status, 409); assert.match(r.json.error, /comes from http:\/\/127\.0\.0\.9:1, but Atlas is set up for/);
  assert.equal((await post('/api/agent/v1/tasks/run', { taskId: 'tk_abc', token: 'lst_0123456789abcdef', lsUrl: `http://localhost:${mockPort}` })).status, 401, 'needs the agent token');
});

test('the runner gives no secret to a server that cannot prove it holds the agent token', async () => {
  // A stale runtime.json pointing at someone else's server (here: a fake one, with a live pid).
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'atlas-runner-'));
  fs.writeFileSync(path.join(dir, 'agent-token.txt'), 'agent-secret-xyz\n');
  const got = [];
  const fake = http.createServer((q, s) => { let b = ''; q.on('data', (c) => { b += c; }); q.on('end', () => { got.push({ url: q.url, auth: q.headers.authorization || '', body: b }); s.writeHead(200, { 'content-type': 'application/json' }); s.end(JSON.stringify({ ok: true, proof: 'nope' })); }); });
  const fakePort = await listen(fake);
  fs.writeFileSync(path.join(dir, 'runtime.json'), JSON.stringify({ port: fakePort, host: '127.0.0.1', pid: process.pid }));
  const child = spawn(process.execPath, [path.join(ROOT, 'tools', 'atlas-task-runner.js'), 'task', '--data', dir], { env: { ...process.env, LS_URL: `http://127.0.0.1:${mockPort}`, LS_TASK_ID: 'tk_fake', LS_TASK_TOKEN: 'lst_SECRETSECRETSECRET' }, stdio: ['ignore', 'pipe', 'pipe'] });
  let out = ''; child.stdout.on('data', (c) => { out += c; }); child.stderr.on('data', (c) => { out += c; });
  const code = await new Promise((r) => child.on('exit', r));
  fake.close(); fs.rmSync(dir, { recursive: true, force: true });
  assert.ok(got.length >= 1 && got.every((x) => x.url.startsWith('/api/atlas/proof')), JSON.stringify(got));
  assert.ok(!JSON.stringify(got).includes('agent-secret-xyz') && !JSON.stringify(got).includes('lst_SECRET'), 'no token reached the fake server');
  assert.ok(!out.includes('lst_SECRET'), 'the runner never prints the task token');
  assert.equal(code, 1, out); assert.match(out, /Atlas is not running; starting its server/);
});
