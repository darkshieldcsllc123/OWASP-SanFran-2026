'use strict';
// End-to-end tests against a real Log Sentinel (1.6.0 or newer), started from its folder:
//   LS_DIR=/path/to/log-sentinel node --test test/logsentinel.e2e.test.js
// Skipped when LS_DIR is not set. Uses temporary data folders and free ports; a stub model stands in for Ollama.
const test = require('node:test');
const assert = require('node:assert/strict');
const { spawn } = require('node:child_process');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const { createOllama } = require('../tools/mock-ollama.js');

const LS_DIR = process.env.LS_DIR;
const ROOT = path.join(__dirname, '..');
const skip = !LS_DIR || !fs.existsSync(path.join(LS_DIR, 'server.js'));
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
let tmp, ls, lsUrl, lsEnv, atlas, atlasUrl, ollama, ollamaPort, key, iid;
// The key's scopes, without tasks:run (granted in the first test).
const SCOPES = ['events:write', 'feed:read', 'findings:read', 'alerts:read', 'taxonomy:read', 'taxonomy:write'];

function start(cmd, args, env, cwd, re) {
  const child = spawn(process.execPath, [cmd, ...args], { cwd, env: { ...process.env, ...env }, stdio: ['ignore', 'pipe', 'pipe'] });
  let out = '';
  return new Promise((resolve, reject) => {
    const t = setTimeout(() => reject(new Error('did not start: ' + out.slice(-500))), 15000);
    const on = (c) => { out += c; const m = re.exec(out); if (m) { clearTimeout(t); resolve({ child, url: m[1], out: () => out }); } };
    child.stdout.on('data', on); child.stderr.on('data', (c) => { out += c; });
    child.on('exit', (code) => { clearTimeout(t); reject(new Error(`exited ${code}: ${out.slice(-500)}`)); });
  });
}
const stop = async (c) => { if (c && c.exitCode === null) { c.kill('SIGTERM'); await Promise.race([new Promise((r) => c.once('exit', r)), sleep(5000)]); } };
async function http(base, method, route, body, headers = {}) {
  const r = await fetch(base + route, { method, headers: { 'content-type': 'application/json', ...headers }, body: body === undefined ? undefined : JSON.stringify(body) });
  const text = await r.text(); let json; try { json = JSON.parse(text); } catch { json = { text }; }
  return { status: r.status, json };
}
const admin = (m, r, b) => http(lsUrl, m, r, b, { 'x-ls-client': '1' });
const at = (m, r, b) => http(atlasUrl, m, r, b);
const atAgent = (m, r, b) => http(atlasUrl, m, r, b, { authorization: 'Bearer ' + fs.readFileSync(path.join(tmp, 'atlas', 'agent-token.txt'), 'utf8').trim() });
async function until(fn, ms = 20000, step = 250) { const end = Date.now() + ms; let last; while (Date.now() < end) { last = await fn(); if (last) return last; await sleep(step); } throw new Error('timed out; last=' + JSON.stringify(last)); }
const lsTask = async (id) => (await admin('GET', `/api/tasks/${id}`)).json;
const results = async (id) => { const r = await admin('GET', `/api/tasks/${id}/results?limit=500`); return r.json.results || r.json.items || []; };
// The integration's "Run the threat detectors on its events" switch in Log Sentinel.
async function setDetectors(on) {
  const list = (await admin('GET', '/api/integrations')).json; const cur = (list.integrations || list).find((x) => x.id === iid);
  return admin('PUT', `/api/integrations/${iid}`, { events: { ...cur.events, threatDetectors: on } });
}
const ended = (id, ms = 30000) => until(async () => { const d = await lsTask(id); return ['done', 'failed', 'cancelled', 'blocked', 'declined'].includes(d.task.status) && d; }, ms);
const queue = async (params, runner) => { const r = await admin('POST', '/api/tasks', { integrationId: iid, kind: 'scan', params, ...(runner ? { runner } : {}) }); assert.ok(r.json.task, JSON.stringify(r.json)); return r.json.task.id; };
async function startAtlas(env = {}) {
  const port = 20000 + Math.floor(Math.random() * 20000);
  const a = await start('server.js', [], { ATLAS_DATA_DIR: path.join(tmp, 'atlas'), ATLAS_PORT: String(port), ATLAS_NO_BROWSER: '1', ATLAS_FEED_WAIT: '2', ATLAS_TASK_WAIT: '2', ATLAS_RECHECK: '2', ...env }, ROOT, /Open: (http:\/\/127\.0\.0\.1:\d+)/);
  atlas = a.child; atlasUrl = a.url;
}

test.describe('with a real Log Sentinel', { skip: skip && 'set LS_DIR to a Log Sentinel folder to run these' }, () => {
  test.before(async () => {
    tmp = fs.mkdtempSync(path.join(os.tmpdir(), 'atlas-e2e-'));
    const lsPort = 30000 + Math.floor(Math.random() * 20000);
    lsEnv = { LS_DATA_DIR: path.join(tmp, 'ls'), PORT: String(lsPort), LS_NO_OPEN: '1' };
    const l = await start('server.js', [], lsEnv, LS_DIR, /(http:\/\/127\.0\.0\.1:\d+)/);
    ls = l.child; lsUrl = l.url;
    ollama = createOllama({ models: ['stub:latest', 'llama3.2:3b'] }); await new Promise((r) => ollama.server.listen(0, '127.0.0.1', r)); ollamaPort = ollama.server.address().port;
    await startAtlas();
    await at('POST', '/api/config', { ollamaUrl: `http://127.0.0.1:${ollamaPort}` });
  });
  test.after(async () => { await stop(atlas); await stop(ls); ollama.server.closeAllConnections?.(); ollama.server.close(); fs.rmSync(tmp, { recursive: true, force: true }); });

  test('connects; once tasks:run is granted in Log Sentinel, declares the scan task by itself and suggests its runner', async () => {
    const scopes = SCOPES;
    const c = await admin('POST', '/api/integrations', { name: 'AI Threat Atlas', trust: 'review', scopes });
    key = c.json.key; iid = c.json.integration.id;
    assert.equal((await at('POST', '/api/sentinel/config', { url: lsUrl, key, enabled: true, feedEnabled: true })).status, 200);
    const chk = await at('GET', '/api/sentinel/check');
    assert.equal(chk.status, 200, JSON.stringify(chk.json));
    assert.equal(chk.json.identity.slug, 'ai-threat-atlas');
    assert.ok(!chk.json.features.find((f) => f.id === 'tasks').ok, 'no tasks without tasks:run');
    const integ = async () => (await admin('GET', '/api/tasks')).json.integrations.find((x) => x.id === iid);
    await sleep(1000);
    assert.equal((await integ()).kinds.length, 0);
    // The operator grants tasks:run later, in Log Sentinel. Nothing is done in Atlas: it asks again every
    // minute (every 2 s here, ATLAS_RECHECK), declares its task and starts listening.
    assert.equal((await admin('PUT', `/api/integrations/${iid}`, { scopes: [...scopes, 'tasks:run'] })).status, 200);
    const i = await until(async () => { const t = await integ(); return t && t.listening && t.kinds.length && t; }, 15000);
    assert.deepEqual(i.kinds.map((k) => k.kind), ['scan']);
    assert.ok((await at('GET', '/api/sentinel/check')).json.features.find((f) => f.id === 'tasks').ok);
    // The Start panel offers the models Ollama has.
    const model = i.kinds[0].params.find((p) => p.name === 'model');
    assert.equal(model.type, 'enum');
    assert.deepEqual(model.values, ['stub:latest', 'llama3.2:3b']);
    assert.equal(i.kinds[0].runners.page, "Atlas's server, while it is running (no window needed)");
    assert.equal(i.suggested.program, process.execPath);
    assert.ok(i.suggested.args.some((a) => a.endsWith(path.join('tools', 'atlas-task-runner.js'))));
    assert.ok(i.suggested.args.includes(path.join(tmp, 'atlas')), 'passes the data folder when it is not the default');
    assert.equal(i.kinds[0].params.find((p) => p.name === 'includeText').default, true);
    says = chk.json.identity.threatDetectors !== undefined; // Log Sentinel 1.6.3 and later
  });

  let says;
  const text = async () => (await at('GET', '/api/sentinel/config')).json.text;
  test('text is held back while Log Sentinel\'s threat detectors run on Atlas\'s events, and flows within a minute of turning them off', async () => {
    // Log Sentinel 1.6.3+ says the detectors are on (its default): Atlas holds the text back and the task says why.
    assert.deepEqual(await text(), { on: true, detectors: says ? 'on' : 'unknown' });
    // (Another model than the next tests', so the finding they check is theirs.)
    const id = await queue({ model: 'llama3.2:3b', ids: ['PI-01'], modes: ['raw'] });
    const d = await ended(id);
    assert.equal(d.task.status, 'done', JSON.stringify(d.task));
    const list = await results(id);
    if (says) {
      assert.ok(list.length >= 1 && list.every((x) => !x.data.prompt && !x.data.response), 'held back');
      assert.match(d.log.lines.map((l) => l.msg).join('\n'), /Prompt and response text is held back/);
    } else assert.ok(list.some((x) => x.data.prompt), 'an older Log Sentinel doesn\'t say: the setting decides');
    // The operator unticks the switch in Log Sentinel. Nothing is pressed in Atlas: it asks again every minute
    // (2 s here) while text is held back.
    assert.equal((await setDetectors(false)).status, 200);
    if (says) await until(async () => (await text()).detectors === 'off', 15000);
  });

  let findingId;
  test('a scan queued on the Tasks page is picked up, its results kept, and its problems become one finding', async () => {
    const id = await queue({ model: 'stub:latest', ids: ['PI', 'LLM01-T01'] });
    const d = await ended(id);
    assert.equal(d.task.status, 'done', JSON.stringify(d.task));
    assert.equal(d.task.progress.done, d.task.progress.total, 'the progress bar ends full');
    const r = d.task.result;
    assert.equal(r.total, 28); assert.equal(r.completed, 28);
    assert.equal(d.task.results.total, r.completed - r.skipped + 1, 'one result per test that ran, plus the summary; skipped tests are not sent');
    assert.equal(d.task.results.summary, 1);
    assert.equal(d.task.results.problem, r.problem); assert.equal(d.task.results.partial, r.partial);
    const msgs = d.log.lines.map((l) => l.msg).join('\n');
    assert.match(msgs, /Picked up by AI Threat Atlas 8\.2/); assert.match(msgs, /PI-01 payload: /);
    const f = await until(async () => (await admin('GET', '/api/findings?status=all')).json.find((x) => x.taskId === id));
    assert.equal(f.title, 'AI Threat Atlas found problems with stub:latest');
    assert.equal(f.category, 'security');
    assert.deepEqual(f.taxonomy.slice(0, 2).sort(), ['PI-01', 'PI-02'], 'the prompt-injection risks the probes test come first');
    findingId = f.id;
    // Each test's request and the model's answer are on the task page (data.prompt and data.response).
    const tests = (await results(id)).filter((x) => x.outcome !== 'summary');
    assert.equal(tests.length, r.completed - r.skipped);
    assert.ok(tests.every((x) => x.data && x.data.textIncluded === true && x.data.prompt && x.data.response), JSON.stringify(tests[0]).slice(0, 600));
    assert.ok(tests.some((x) => /ATLAS_QA_/.test(x.data.prompt)), 'the probe, with its canary');
    assert.ok(tests.some((x) => x.data.systemPrompt), 'payload tests carry their system prompt');
  });

  test('a task with "Include prompt and response text" off sends results without any text', async () => {
    const none = (list) => list.length >= 1 && list.every((x) => !x.data.prompt && !x.data.response && !x.data.systemPrompt && !/ATLAS_QA_/.test(JSON.stringify(x)));
    const id = await queue({ model: 'stub:latest', ids: ['PI-01'], modes: ['payload', 'raw'], includeText: false });
    const d = await ended(id);
    assert.equal(d.task.status, 'done', JSON.stringify(d.task));
    assert.ok(none(await results(id)));
    // Off in Atlas: the switch leaves the Tasks page's form (Atlas declares again), and no task sends text.
    const param = async () => (await admin('GET', '/api/tasks')).json.integrations.find((x) => x.id === iid).kinds[0].params.find((p) => p.name === 'includeText');
    assert.equal((await at('POST', '/api/sentinel/config', { includeText: false })).status, 200);
    try {
      await until(async () => !(await param()), 15000);
      const id2 = await queue({ model: 'stub:latest', ids: ['PI-01'], modes: ['raw'] });
      assert.equal((await ended(id2)).task.status, 'done');
      assert.ok(none(await results(id2)));
    } finally { await at('POST', '/api/sentinel/config', { includeText: true }); }
    await until(async () => (await param())?.default === true, 15000);
  });

  test('re-grading a test does not add a task result', async () => {
    const r = await at('POST', '/api/sentinel/scan/start', { model: 'stub:latest', ids: ['PI-01', 'PI-02', 'PI-03'], modes: ['payload'] });
    const d = await ended(r.json.job.taskId);
    const before = d.task.results.total;
    const a = (await atAgent('GET', '/api/agent/v1/audits?limit=1000')).json.audits.find((x) => x.taskId === r.json.job.taskId);
    await at('PATCH', '/api/audits/' + a.id, { verdict: 'negative' });
    await at('PATCH', '/api/audits/' + a.id, { verdict: 'positive' });
    await sleep(3000);
    assert.equal((await lsTask(r.json.job.taskId)).task.results.total, before);
  });

  test('a task with ids Atlas does not know fails with a clear error', async () => {
    const d = await ended(await queue({ model: 'stub:latest', ids: ['NOPE-99'] }));
    assert.equal(d.task.status, 'failed'); assert.match(d.task.error, /Unknown technique or risk ids: NOPE-99/);
  });

  test('a model pulled into Ollama is offered on the Tasks page within a minute, and runs', async () => {
    ollama.state.models.push('qwen2.5:7b');
    const k = await until(async () => { const t = (await admin('GET', '/api/tasks')).json.integrations.find((x) => x.id === iid); const m = t && t.kinds[0] && t.kinds[0].params.find((p) => p.name === 'model'); return m && m.values.includes('qwen2.5:7b') && t; }, 15000);
    assert.ok(k.listening);
    const d = await ended(await queue({ model: 'qwen2.5:7b', ids: ['PI-01'], modes: ['raw'] }));
    assert.equal(d.task.status, 'done', JSON.stringify(d.task));
    assert.ok(ollama.calls.some((c) => c.model === 'qwen2.5:7b'));
    // A model Ollama does not have is refused when the task is added, not after it starts.
    const bad = await admin('POST', '/api/tasks', { integrationId: iid, kind: 'scan', params: { model: 'nope:1b' } });
    assert.equal(bad.status, 400, JSON.stringify(bad.json));
    assert.match(bad.json.error, /model: must be one of stub:latest, llama3\.2:3b, qwen2\.5:7b/);
  });

  test('a scan started in Atlas shows as a task and updates the same finding', async () => {
    const r = await at('POST', '/api/sentinel/scan/start', { model: 'stub:latest', ids: ['HC-03', 'HC-04', 'PI-05'], modes: ['payload', 'raw'] });
    assert.equal(r.status, 202); assert.match(r.json.job.taskId, /^tk_/); assert.ok(r.json.job.taskUrl.startsWith(lsUrl));
    const d = await ended(r.json.job.taskId);
    assert.equal(d.task.status, 'done'); assert.match(d.task.decisionReason, /Started in AI Threat Atlas itself/);
    const f = await until(async () => { const x = (await admin('GET', '/api/findings?status=all')).json.find((y) => y.id === findingId); return x && x.taskId === r.json.job.taskId && x; });
    assert.equal(f.title, 'AI Threat Atlas found problems with stub:latest');
  });

  test('a scan started in Atlas with a short model name, or a model Ollama does not list, still shows as a task', async () => {
    const modelParam = async () => (await admin('GET', '/api/tasks')).json.integrations.find((x) => x.id === iid).kinds[0].params.find((p) => p.name === 'model');
    const r = await at('POST', '/api/sentinel/scan/start', { model: 'stub', ids: ['PI-01'], modes: ['raw'] });
    assert.equal(r.status, 202); assert.match(r.json.job.taskId, /^tk_/, JSON.stringify(r.json));
    const d = await ended(r.json.job.taskId);
    assert.equal(d.task.status, 'done', JSON.stringify(d.task));
    assert.equal(d.task.params.model, 'stub:latest', 'named the way Ollama lists it');
    // Not in Ollama's list: Atlas declares the model as text for this report, then the list again.
    const g = await at('POST', '/api/sentinel/scan/start', { model: 'ghost:1b', ids: ['PI-01'], modes: ['raw'] });
    assert.equal(g.status, 202); assert.match(g.json.job.taskId || '', /^tk_/, JSON.stringify(g.json));
    assert.equal((await ended(g.json.job.taskId)).task.params.model, 'ghost:1b');
    await until(async () => (await modelParam()).type === 'enum', 15000);
    assert.ok(!(await modelParam()).values.includes('ghost:1b'));
  });

  test('Stop on the Tasks page stops the scan; results so far are kept', async () => {
    ollama.state.delay = 60;
    const id = await queue({ model: 'stub:latest' });
    await until(async () => (await lsTask(id)).task.status === 'running');
    await sleep(1500);
    await admin('POST', `/api/tasks/${id}/cancel`, {});
    const d = await ended(id);
    ollama.state.delay = 0;
    assert.equal(d.task.status, 'cancelled'); assert.match(d.task.message, /^Stopped from Log Sentinel after \d+ of \d+ tests/);
    assert.ok(d.task.result.completed < d.task.result.total);
  });

  test('Stop in Atlas ends the task as cancelled', async () => {
    ollama.state.delay = 60;
    const r = await at('POST', '/api/sentinel/scan/start', { model: 'stub:latest', scope: 'all', modes: ['payload'] });
    await sleep(1200);
    assert.equal((await at('POST', '/api/sentinel/tasks/stop', {})).status, 202);
    const d = await ended(r.json.job.taskId);
    ollama.state.delay = 0;
    assert.equal(d.task.status, 'cancelled'); assert.match(d.task.message, /^Stopped in Atlas after/);
  });

  test('the page\'s batch queue is shown live; only the server ties a result to a task', async () => {
    const batchId = crypto.randomUUID();
    const s = await at('POST', '/api/sentinel/batch/start', { batchId, model: 'stub:latest', total: 3, ids: ['PI-01', 'PI-02'], modes: ['raw'] });
    assert.match(s.json.taskId, /^tk_/, JSON.stringify(s.json));
    for (const [t, resp] of [['PI-01', 'no'], ['PI-02', 'ATLAS_QA_X_MARK'], ['PI-03', 'fine']]) {
      const a = await at('POST', '/api/audits', { batchId, techniqueId: t, model: 'stub:latest', testType: 'raw', marker: 'ATLAS_QA_X_MARK', submittedPrompt: 'say ATLAS_QA_X_MARK', response: resp, taskId: 'tk_forged' });
      assert.equal(a.json.record.taskId, s.json.taskId);
    }
    const forged = await at('POST', '/api/audits', { techniqueId: 'PI-01', model: 'stub:latest', testType: 'raw', response: 'x', taskId: s.json.taskId });
    assert.equal(forged.json.record.taskId, '', 'a page cannot attach a result to a task by naming it');
    assert.equal((await at('GET', `/api/sentinel/batch/status?id=${batchId}`)).json.stop, false);
    await at('POST', '/api/sentinel/batch/end', { batchId, stopped: false });
    const d = await ended(s.json.taskId);
    assert.equal(d.task.status, 'done'); assert.equal(d.task.results.total, 4); assert.equal(d.task.results.problem, 1);
  });

  test('samples, the canary detector and references pass (or fail) Log Sentinel\'s real checks', async () => {
    const s = await at('POST', '/api/sentinel/content/publish', { techniqueIds: ['HC-03', 'HC-04', 'PI-08'], dryRun: true });
    assert.equal(s.status, 200, JSON.stringify(s.json));
    assert.equal(s.json.kind, 'injection');
    assert.ok(s.json.result.results.every((x) => x.status === 'would_be_pending'), JSON.stringify(s.json.result.results));
    const d = await at('POST', '/api/sentinel/detector', { dryRun: true });
    assert.equal(d.json.result.results[0].status, 'would_be_pending', JSON.stringify(d.json));
    assert.equal(d.json.result.results[0].checks.detectors[0].benignHits, 0, 'no false alarms on Log Sentinel\'s benign corpus');
    const ref = await at('POST', '/api/sentinel/content/custom', { type: 'logsentinel.reference', data: { name: 'atlas-research', title: 'Atlas research' }, dryRun: true });
    assert.match(ref.json.result.results[0].error.message, /license is required/);
    const im = await at('POST', '/api/sentinel/taxonomy/import', { preview: true, includeExisting: true });
    assert.equal(im.json.found, 69);
    const oa = im.json.additions.techniques.find((t) => t.id === 'LS:OA-01');
    assert.equal(oa.severity, 'Critical'); assert.ok(oa.mechanism.length > 20); assert.ok(oa.mitigations.length);
  });

  test('task status changes arrive in Atlas\'s feed', async () => {
    await until(async () => (await at('GET', '/api/sentinel/feed?limit=500')).json.events.some((e) => e.type === 'logsentinel.task.status'));
  });

  test('the program runner hands the task to the running Atlas', async () => {
    assert.equal((await admin('POST', `/api/integrations/${iid}/tasks/use-suggested`, {})).status, 200);
    await admin('PUT', '/api/config/agent', { autonomy: 'propose' });
    const id = await queue({ model: 'stub:latest', ids: ['HC'], modes: ['raw'] });
    assert.equal((await lsTask(id)).task.runner, 'program');
    const d = await ended(id);
    assert.equal(d.task.status, 'done', JSON.stringify(d.task));
    assert.match(d.log.lines.map((l) => l.msg).join('\n'), /handed over by the task runner/);
    const act = await until(async () => { const a = (await admin('GET', '/api/actions')).json.find((x) => x.id === d.task.actionId); return a && a.status === 'done' && a; });
    const out = JSON.stringify(act.result || act);
    assert.match(out, /Using Atlas's server on port/);
    assert.ok(!/lst_/.test(out), 'the task token is never printed');
  });

  test('a Log Sentinel restart mid-task ends the task in Atlas too, and Atlas listens again', async () => {
    ollama.state.delay = 60;
    const id = await queue({ model: 'stub:latest' }, 'page');
    await until(async () => (await lsTask(id)).task.status === 'running');
    await sleep(1000);
    await stop(ls);
    const l = await start('server.js', [], lsEnv, LS_DIR, /(http:\/\/127\.0\.0\.1:\d+)/); ls = l.child;
    assert.equal(l.url, lsUrl);
    const v = await until(async () => { const x = (await at('GET', '/api/sentinel/tasks')).json; return !x.current && x.last && x.last.id === id && x; }, 30000);
    ollama.state.delay = 0;
    assert.ok(['ended in Log Sentinel', 'cancelled', 'failed'].includes(v.last.status), v.last.status);
    assert.notEqual((await lsTask(id)).task.status, 'running');
    await until(async () => (await at('GET', '/api/sentinel/tasks')).json.listening, 30000);
    const d = await ended(await queue({ model: 'stub:latest', ids: ['PI-01'], modes: ['raw'] }, 'page'));
    assert.equal(d.task.status, 'done');
  });

  test('the runner reports the task failed when the Atlas it used goes away', async () => {
    ollama.state.delay = 100;
    const id = await queue({ model: 'stub:latest' }, 'program');
    await until(async () => (await lsTask(id)).task.status === 'running', 20000);
    await sleep(1000);
    atlas.kill('SIGKILL');
    const d = await ended(id, 60000);
    ollama.state.delay = 0;
    assert.equal(d.task.status, 'failed'); assert.match(d.task.error || '', /Lost contact with Atlas|could not run/i);
  });

  test('the program runner starts Atlas when it is not running, and stops it again', async () => {
    await stop(atlas);
    await sleep(500);
    const id = await queue({ model: 'stub:latest', ids: ['IS'], modes: ['payload'] });
    const d = await ended(id, 60000);
    assert.equal(d.task.status, 'done', JSON.stringify(d.task));
    const act = await until(async () => { const a = (await admin('GET', '/api/actions')).json.find((x) => x.id === d.task.actionId); return a && a.status === 'done' && a; }, 20000);
    const out = JSON.stringify(act.result || act);
    assert.match(out, /Atlas is not running; starting its server/); assert.match(out, /Stopping the Atlas server this runner started/);
    const port = Number(/Atlas's server started on port (\d+)/.exec(out)[1]);
    await assert.rejects(fetch(`http://127.0.0.1:${port}/api/health`), 'the server it started is gone');
    assert.ok(!fs.existsSync(path.join(tmp, 'atlas', 'runtime.json')) && !fs.existsSync(path.join(tmp, 'atlas', 'atlas.lock')), 'it cleaned up its runtime file and lock');
  });

  test('Connect picks up tasks:run granted since Atlas last asked, without waiting for its next check', async () => {
    await stop(atlas);
    assert.equal((await admin('PUT', `/api/integrations/${iid}`, { scopes: SCOPES })).status, 200);
    await startAtlas({ ATLAS_RECHECK: '600' });
    await sleep(3000);
    assert.equal((await at('GET', '/api/sentinel/tasks')).json.listening, false, 'no tasks:run: not listening');
    assert.equal((await admin('PUT', `/api/integrations/${iid}`, { scopes: [...SCOPES, 'tasks:run'] })).status, 200);
    assert.equal((await at('GET', '/api/sentinel/check')).status, 200);
    await until(async () => (await at('GET', '/api/sentinel/tasks')).json.listening, 8000);
    const d = await ended(await queue({ model: 'stub:latest', ids: ['PI-01'], modes: ['raw'] }, 'page'));
    assert.equal(d.task.status, 'done', JSON.stringify(d.task));
  });
});
