# AI Threat Atlas 8.2.2 · Log Sentinel Bridge + Agent API

**Offline-first, no dependencies:** a native HTML/JavaScript page with a Node.js 18+ host and Ollama proxy. Kept from v8:
- the OWASP and research taxonomy;
- single and batch auditing, raw prompts, QA grading and the scanner progress view;
- the five research PDFs.

**Start:** double-click `start.bat` (Windows) or run `./start.sh` (Linux/macOS). Your browser opens on `http://127.0.0.1:9165` or the next free local port. Configure Ollama on the **Ollama Auditor** tab. Log Sentinel and agents are on the **Log Sentinel / Agents** tab.

## What's new in 8.2.2: the full request and response in Log Sentinel

- **Each result now carries the test's system prompt, prompt and the model's response**, plus token counts and request errors.
  - Log Sentinel's task page shows them under Prompt and Response for every test. 8.2.1 sent only the verdict and its details.
  - Long text is cut to fit Log Sentinel's 24 KB per task result, keeping the start and the end. It is marked `textTruncated`, and the full text stays in Atlas.
- **On by default.**
  - Off on Atlas's Log Sentinel tab means off for everything.
  - With it on, each task can turn it off (**Include prompt and response text** on the Tasks page).
- **Turn Log Sentinel's threat detectors off for Atlas's events** (Integrations → AI Threat Atlas → Settings → Events it sends). The probes are prompt-injection text on purpose, and Log Sentinel would otherwise report them as attacks on its computer.
  - Until you do, Atlas holds the text back, says so on the task and shows a red warning.
  - Log Sentinel 1.6.3 tells Atlas the setting, and Atlas notices the change within a minute.
- **The outbox** on disk keeps results without their text; the text is added back when they are sent. Requests fit the integration's request limit in Log Sentinel, and a `413` makes the outbox send fewer at a time.
- **Tests:**
  - 3 new end-to-end tests: held back while the detectors are on; text on the task page; text off per task and in Atlas. They pass against Log Sentinel 1.6.2 and 1.6.3.
  - 5 new stand-in tests: the setting as a ceiling, held back, long and escape-heavy answers, the request limit, and merged answers.
- **Reviewed:** an independent review of this change found 4 issues and a risky default; all are fixed:
  - Long text would have been dropped by Log Sentinel's 24 KB per-result limit.
  - Turning the setting off didn't stop text for tasks queued in Log Sentinel.
  - A low request limit could jam the outbox.
  - Answers split across requests were merged wrongly.
  - Text went out while the detectors were on.
- **With it, Log Sentinel 1.6.3:** whoami reports whether the threat detectors run on the integration's events.

## What's new in 8.2.1: add and run Atlas scans from Log Sentinel's Tasks page

- **Granting `tasks:run` later just works.** 8.2 declared its scan only when you saved the integration, so a key that got `tasks:run` afterwards never showed Atlas on the Tasks page. Now Atlas asks Log Sentinel every minute while the key lacks it, then declares its scan and starts listening. **Save integration** and **Connect / whoami** check at once.
- **Pick the model from a list.** The Tasks page offers the models Ollama has. Atlas re-reads them every minute, so a model you pull shows up without restarting anything. A model Ollama doesn't have is refused when you add the task.
- **To run a scan:** Tasks → Start a task → pick the model, the techniques or risks (`PI`, `HC-03` …) and the tests → **Start**. It runs on Atlas's server while Atlas is running. For scans with Atlas closed, choose *Atlas's task runner*, click **Use this program** once and switch autonomy to Propose. **Run again** repeats a scan.
- **Tests:** 17 end-to-end tests against a real Log Sentinel, three of them new: granting `tasks:run` later (by itself, and with Connect), a newly pulled model, and scans started in Atlas whose model name Ollama lists differently. Plus the 8 task and 21 stand-in tests.
- **Reviewed:** an independent review of 8.2.1 found 4 issues, all fixed: Connect didn't wake Atlas after a grant; a scan started in Atlas as `llama3.2` (listed as `llama3.2:latest`) wasn't shown in Log Sentinel; the task loop's pauses kept their abort listeners; and a model-list change could be marked declared when it wasn't.
- **With it, Log Sentinel 1.6.2:** the Start panel picks the runner that can start at once (the tool listening), and task lists name the runner the way the tool does ("Atlas's server, while it is running"), not "The tool's open page".

## What's new in 8.2: Log Sentinel Tasks

- **Scans from Log Sentinel's Tasks page.**
  - Atlas declares a "Run an AI Threat Atlas scan" task: model, techniques or risks (PI-02, PI, LLM01 …), tests, examples.
  - While Atlas's server runs, it picks queued scans up, with no window open.
  - With Atlas not running, Log Sentinel can start `tools/atlas-task-runner.js` (click **Use this program**). It starts Atlas's server for the scan and stops it after.
- **Scans started in Atlas show live in Log Sentinel.** That covers server-side scans, the agent API and the Ollama Auditor's batch queue. Each runs as a task you can watch and stop from either side.
- **Findings from results.** Results carry the task id. Log Sentinel 1.6+ keeps them on the task page and turns the problems into one finding per model, "AI Threat Atlas found problems with *model*". Its risks lead with the prompt-injection risks the probes test.
- **Fixed against the real Log Sentinel:**
  - Samples use the real sample schema: `kind: injection`, `adapted` as text, names up to 41 characters, labels up to 160. 8.1 guessed, and every sample was rejected.
  - Risk import reads Log Sentinel's `hint`, 1–5 severities, mitigation lists and category names.
  - References need a license.
  - Skipped tests are never sent; Log Sentinel would count them as passed.
- **Tests:** 14 end-to-end tests against a real Log Sentinel (`LS_DIR=… node --test test/logsentinel.e2e.test.js`), 8 task timing and safety tests, and the 21 against the stand-in.
- **Reviewed:** an independent review of the task code found 10 issues; all are fixed with tests. Among them:
  - the runner now proves it is talking to the real Atlas before sending tokens;
  - one scan at a time is enforced without races;
  - Atlas notices when Log Sentinel ends a task;
  - re-grades don't recount results;
  - Stop cancels the model request in flight;
  - a lock prevents two servers on one data folder.
- **With it, Log Sentinel 1.6.1:** a task finding now names the risks most of its problems name. 1.6.0 showed the first eight in taxonomy order (OA-01 … OA-08) even when nearly every problem was PI-02.

## What's new in 8.1

- **Fixed against Log Sentinel's integration guide:**
  - Results have stable event ids, so a resend is answered `duplicate` instead of being stored twice.
  - Automatic sends go through a durable outbox and are retried after 429, 5xx and network errors with the same ids.
  - Per-item rejections are shown with Log Sentinel's reason and hint. Before, they came back as a bare `nothing_accepted`.
  - The feed long-polls and resumes from its saved cursor.
  - whoami is read in either shape.
  - Samples take their `kind` from Log Sentinel's vocabulary.
  - Import skips the 69 risks Atlas already has.
  - Errors keep their real HTTP status instead of 500.
- **Results Log Sentinel can act on.** Each `atlas.audit.result` carries:
  - `outcome` (problem, partial, ok, error) and a matching `level`;
  - `risks`: the research risk tested, plus PI-01 for raw tests or PI-02 for guided ones, so OWASP techniques are covered too.

  A canary echoed anywhere in an answer is now flagged ("CANARY ECHOED · REVIEW"), not only an exact match. The type has a JSON Schema in `spec/`.
- **New on the tab:**
  - what the key allows, scope by scope;
  - Send all unsent results;
  - outbox status and recent rejections;
  - a canary detector for `ATLAS_QA_` markers in other logs;
  - Test a model against a finding's risks;
  - a ready-made note for Log Sentinel's source page.
- **Security:**
  - Atlas answers only to loopback Host names on its own port, which blocks DNS rebinding. Before, any web page could read the audit store and drive the bridge this way.
  - Cross-site browser requests are refused.
  - Mitigation scripts are signed only with an explicit opt-in, only from the page, and after a confirmation that shows what will run. The agent API never signs.
  - When Log Sentinel refuses Atlas's key, the answer is a 502 carrying Log Sentinel's code, so it can't be mistaken for a bad Atlas token.
- **Testing:** `node --test test/bridge.test.js` runs 21 end-to-end tests against a stand-in Log Sentinel and a stub Ollama, both in `tools/`. An independent review found 12 issues; all are fixed and covered by these tests.

## Set up Log Sentinel

1. In Log Sentinel, go to Integrations → Add an integration.
   - Name it `AI Threat Atlas` and keep trust at *Review its content*.
   - Tick `events:write`, `tasks:run`, `feed:read`, `findings:read`, `alerts:read` and `taxonomy:read`. Add `taxonomy:write` only for samples or the detector.
   - Copy the `lsk_…` key.
2. In Atlas → Log Sentinel / Agents:
   - Paste the URL and the key.
   - Tick Enable and Listen to the feed. The two task switches and "Include prompt and response text" are on by default.
   - In Log Sentinel, untick "Run the threat detectors on its events" for this integration (Settings → Events it sends), so Atlas's probes aren't reported as attacks. Until then Atlas sends no prompt or response text.
   - Click **Save integration**. It connects, lists what the key allows, and shows up as listening on Log Sentinel's Tasks page.
   - Optional, for scans with Atlas closed: on the Tasks page, click **Use this program**, and switch autonomy to Propose if it is read-only.
3. Once results arrive, paste the suggested note into the "AI Threat Atlas (integration)" source page in Log Sentinel.

Full details are in **AGENT_INTEGRATION.md**. The machine-readable contract is `agent-openapi.json`, served at authenticated `GET /api/agent/v1/openapi.json`.

## Agents

On first start, Node creates `.atlas-data/agent-token.txt`. Give your coding or AI agent these three things:
- `AGENT_INTEGRATION.md`;
- the local base URL;
- this Atlas token. It is not the Log Sentinel key.

Agents can:
- read and merge the taxonomy;
- run and grade Ollama scans;
- send results and content to Log Sentinel;
- read its findings and feed;
- make the control calls you allow.

## Moving from v7/v8

To keep old QA history and Ollama settings, copy `.atlas-data/config.json` and `.atlas-data/audits.json` into this version before first launch. A v8 `.atlas-data` folder can be copied whole. Results saved before 8.1 are left out of **Send all unsent results** unless you tick "Include results saved before …". 8.0 may already have sent them, with ids Log Sentinel can't match. Never include `.atlas-data` in a shared ZIP.

