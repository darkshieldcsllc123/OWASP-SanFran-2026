@echo off
rem Surface: start the proxy and open the app (Windows 10 and later)
rem
rem Uses Node.js 18+ from your PATH if you have it. If not, downloads a private
rem copy of Node.js into the .node folder next to this file (no admin rights,
rem nothing installed system-wide), verifies its SHA-256 checksum, and uses it.
rem If the port is busy, server.js picks the next free one.
rem
rem Options, set before running, for example:  set PORT=9000
rem   PORT=9000                 port to try first, default 8787
rem   NO_OPEN=1                 don't open a browser
rem   ALLOW_PRIVATE=1           allow scanning private and internal addresses
rem   SURFACE_NO_INSTALL=1      never download Node.js
rem   SURFACE_NODE_MAJOR=26     Node.js line to download, default 24 (an LTS line)
rem   SURFACE_NODE_MIRROR=url   download from a mirror instead of nodejs.org/dist
rem   HTTPS_PROXY=url           proxy for the download, if your network needs one

setlocal EnableExtensions DisableDelayedExpansion
cd /d "%~dp0"
title Surface
set "HERE=%~dp0"
if "%HERE:~-1%"=="\" set "HERE=%HERE:~0,-1%"
if not defined SURFACE_NODE_MAJOR set "SURFACE_NODE_MAJOR=24"
if not defined SURFACE_NODE_MIRROR set "SURFACE_NODE_MIRROR=https://nodejs.org/dist"
set "LOCAL_DIR=%HERE%\.node"
set "LOCAL_NODE=%HERE%\.node\node.exe"
set "WORK=%HERE%\.node-download"
set "NODE_EXE="

rem 1. Node.js on the PATH
where node >nul 2>nul
if errorlevel 1 goto check_local
call :node_major node
if %MAJOR% GEQ 18 (
  set "NODE_EXE=node"
  goto run
)
echo The Node.js on your PATH is older than 18 or didn't start. Using a private copy instead.

rem 2. A private copy downloaded earlier
:check_local
if not exist "%LOCAL_NODE%" goto install
call :node_major "%LOCAL_NODE%"
if %MAJOR% GEQ 18 (
  set "NODE_EXE=%LOCAL_NODE%"
  goto run
)

rem 3. Download one
:install
if "%SURFACE_NO_INSTALL%"=="1" (
  echo Node.js 18+ wasn't found and automatic setup is off, because SURFACE_NO_INSTALL=1.
  echo Install Node.js from https://nodejs.org and run this again.
  goto failed
)
call :install_node
if errorlevel 1 goto failed
set "NODE_EXE=%LOCAL_NODE%"

:run
if not "%NO_OPEN%"=="1" set "SURFACE_OPEN=1"
"%NODE_EXE%" server.js
if errorlevel 1 pause
endlocal
exit /b 0

:failed
if exist "%WORK%" rmdir /s /q "%WORK%"
echo.
pause
endlocal
exit /b 1


rem ---------------------------------------------------------------------------
rem Sets MAJOR to the major version of the node binary given, or 0.
rem Node reports it through its exit code, so nothing needs parsing.
:node_major
"%~1" -e "process.exit(parseInt(process.versions.node,10)||0)" >nul 2>nul
set "MAJOR=%errorlevel%"
if %MAJOR% LSS 0 set "MAJOR=0"
if %MAJOR% GTR 199 set "MAJOR=0"
exit /b 0


rem ---------------------------------------------------------------------------
rem Downloads the latest Node.js %SURFACE_NODE_MAJOR%.x zip, checks it against
rem SHASUMS256.txt, and keeps only node.exe and its licence in .node
:install_node
set "ARCH="
if /i "%PROCESSOR_ARCHITECTURE%"=="AMD64" set "ARCH=x64"
if /i "%PROCESSOR_ARCHITECTURE%"=="ARM64" set "ARCH=arm64"
if /i "%PROCESSOR_ARCHITEW6432%"=="AMD64" set "ARCH=x64"
if /i "%PROCESSOR_ARCHITEW6432%"=="ARM64" set "ARCH=arm64"
if not defined ARCH (
  echo Current Node.js releases don't support this %PROCESSOR_ARCHITECTURE% processor, including 32-bit Windows.
  echo Install an older Node.js 18+ release from https://nodejs.org and run this again.
  exit /b 1
)
set "CURL=%SystemRoot%\System32\curl.exe"
set "TAR=%SystemRoot%\System32\tar.exe"
if not exist "%CURL%" goto old_windows
if not exist "%TAR%" goto old_windows
set "BASE=%SURFACE_NODE_MIRROR%/latest-v%SURFACE_NODE_MAJOR%.x"

echo.
echo Node.js 18 or newer isn't installed. Downloading the latest Node.js %SURFACE_NODE_MAJOR% for
echo win-%ARCH%, about 30 MB, into "%LOCAL_DIR%".
echo This copy is only used by Surface; nothing is installed system-wide.
echo.

if exist "%WORK%" rmdir /s /q "%WORK%"
mkdir "%WORK%" 2>nul
if not exist "%WORK%" (
  echo Couldn't create "%WORK%".
  exit /b 1
)
"%CURL%" -fsSL --retry 2 -o "%WORK%\SHASUMS256.txt" "%BASE%/SHASUMS256.txt"
if errorlevel 1 (
  echo Couldn't download the Node.js %SURFACE_NODE_MAJOR% release list from %BASE%
  echo Check your internet connection and proxy settings, check that SURFACE_NODE_MAJOR
  echo names a released version, or install Node.js 18+ from https://nodejs.org
  exit /b 1
)
set "HASH="
set "FILE="
for /f "tokens=1,2" %%a in ('findstr /c:"-win-%ARCH%.zip" "%WORK%\SHASUMS256.txt"') do (
  set "HASH=%%a"
  set "FILE=%%b"
)
if not defined FILE (
  echo %BASE% has no Node.js %SURFACE_NODE_MAJOR% build for win-%ARCH%.
  echo Install Node.js 18+ from https://nodejs.org, or set SURFACE_NODE_MAJOR to another version.
  exit /b 1
)

echo Downloading %FILE%
"%CURL%" -fL --retry 2 --progress-bar -o "%WORK%\%FILE%" "%BASE%/%FILE%"
if errorlevel 1 (
  echo The download of %FILE% failed.
  exit /b 1
)

set "GOT="
for /f "skip=1 delims=" %%h in ('certutil -hashfile "%WORK%\%FILE%" SHA256') do if not defined GOT set "GOT=%%h"
if not defined GOT goto bad_hash
set "GOT=%GOT: =%"
if /i not "%GOT%"=="%HASH%" goto bad_hash
echo Checksum verified. Unpacking...

"%TAR%" -xf "%WORK%\%FILE%" -C "%WORK%"
if errorlevel 1 (
  echo Couldn't unpack %FILE%.
  exit /b 1
)
set "DIR=%WORK%\%FILE:~0,-4%"
if not exist "%DIR%\node.exe" (
  echo The archive didn't contain node.exe.
  exit /b 1
)
rem Keep only the runtime and its licence; Surface doesn't need npm.
if exist "%LOCAL_DIR%" rmdir /s /q "%LOCAL_DIR%"
mkdir "%LOCAL_DIR%"
move /y "%DIR%\node.exe" "%LOCAL_NODE%" >nul
if exist "%DIR%\LICENSE" move /y "%DIR%\LICENSE" "%LOCAL_DIR%\LICENSE" >nul
rmdir /s /q "%WORK%"

call :node_major "%LOCAL_NODE%"
if %MAJOR% LSS 18 (
  echo The downloaded Node.js doesn't run on this system.
  exit /b 1
)
echo Installed Node.js %MAJOR% to "%LOCAL_DIR%". Delete that folder to remove it.
echo.
exit /b 0

:bad_hash
echo The download's SHA-256 checksum doesn't match the published value, so it was discarded.
exit /b 1

:old_windows
echo Automatic setup needs Windows 10 or later, which include curl and tar.
echo Install Node.js 18+ from https://nodejs.org and run this again.
exit /b 1
