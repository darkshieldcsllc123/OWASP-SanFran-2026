#!/usr/bin/env sh
# Surface: start the proxy and open the app (macOS, Linux)
#
# Uses Node.js 18+ from your PATH if you have it. If not, downloads a private
# copy of Node.js into ./.node (no admin rights, nothing installed system-wide),
# verifies its SHA-256 checksum, and uses that. If the port is busy, server.js
# picks the next free one.
#
# Options (environment variables):
#   PORT=9000                 port to try first (default 8787)
#   NO_OPEN=1                 don't open a browser
#   ALLOW_PRIVATE=1           allow scanning private and internal addresses
#   SURFACE_NO_INSTALL=1      never download Node.js
#   SURFACE_NODE_MAJOR=26     Node.js line to download (default 24, an LTS line)
#   SURFACE_NODE_MIRROR=url   download from a mirror instead of nodejs.org/dist

cd "$(dirname "$0")" || exit 1
HERE=$(pwd)
NODE_MAJOR="${SURFACE_NODE_MAJOR:-24}"
MIRROR="${SURFACE_NODE_MIRROR:-https://nodejs.org/dist}"
LOCAL_DIR="$HERE/.node"
LOCAL_NODE="$LOCAL_DIR/bin/node"
WORK="$HERE/.node-download"

say() { printf '%s\n' "$*"; }
fail() { printf '\n%s\n' "$*" >&2; rm -rf "$WORK"; exit 1; }

# Prints the major version of the node binary given, or 0.
node_major() {
  v=$("$1" -p 'parseInt(process.versions.node, 10) || 0' 2>/dev/null) || v=0
  case "$v" in ''|*[!0-9]*) v=0 ;; esac
  printf '%s' "$v"
}

find_node() {
  if command -v node >/dev/null 2>&1; then
    m=$(node_major node)
    if [ "$m" -ge 18 ]; then NODE=node; return 0; fi
    say "Found Node.js $m on your PATH, but Surface needs 18 or newer. Using a private copy instead."
  fi
  if [ -x "$LOCAL_NODE" ] && [ "$(node_major "$LOCAL_NODE")" -ge 18 ]; then
    NODE="$LOCAL_NODE"
    return 0
  fi
  return 1
}

download() { # url file [quiet]
  if command -v curl >/dev/null 2>&1; then
    if [ -n "${3:-}" ]; then curl -fsSL --retry 2 -o "$2" "$1"; else curl -fL --retry 2 --progress-bar -o "$2" "$1"; fi
  elif command -v wget >/dev/null 2>&1; then
    if [ -n "${3:-}" ]; then wget -q -O "$2" "$1"; else wget -O "$2" "$1"; fi
  else
    fail "Downloading Node.js needs curl or wget. Install one of them, or install Node.js 18+ from https://nodejs.org, then run this again."
  fi
}

sha256_of() {
  if command -v sha256sum >/dev/null 2>&1; then sha256sum "$1" | awk '{print $1}'
  elif command -v shasum >/dev/null 2>&1; then shasum -a 256 "$1" | awk '{print $1}'
  elif command -v openssl >/dev/null 2>&1; then openssl dgst -sha256 "$1" | awk '{print $NF}'
  fi
}

install_node() {
  os=$(uname -s)
  arch=$(uname -m)
  case "$os" in
    Linux) plat=linux ;;
    Darwin) plat=darwin ;;
    MINGW*|MSYS*|CYGWIN*) fail "This looks like Windows. Run start.bat instead." ;;
    *) fail "Automatic setup doesn't support $os. Install Node.js 18+ from https://nodejs.org and run this again." ;;
  esac
  # A shell running under Rosetta reports x86_64 on Apple Silicon; get the native build.
  if [ "$plat" = darwin ] && [ "$(sysctl -n sysctl.proc_translated 2>/dev/null)" = 1 ]; then arch=arm64; fi
  case "$arch" in
    x86_64|amd64) cpu=x64 ;;
    aarch64|arm64) cpu=arm64 ;;
    armv7l) cpu=armv7l ;;
    ppc64le) cpu=ppc64le ;;
    s390x) cpu=s390x ;;
    *) fail "Automatic setup doesn't support the $arch processor. Install Node.js 18+ from https://nodejs.org and run this again." ;;
  esac

  # Official Linux builds need glibc. On musl systems such as Alpine, use the package manager.
  if [ "$plat" = linux ] && { [ -f /etc/alpine-release ] || ldd --version 2>&1 | grep -qi musl; }; then
    if command -v apk >/dev/null 2>&1 && [ "$(id -u)" = 0 ]; then
      say "Installing Node.js with apk..."
      apk add --no-cache nodejs >/dev/null || fail "apk couldn't install Node.js."
      NODE=node
      return 0
    fi
    fail "This system uses musl libc, which official Node.js builds don't support. Run: sudo apk add nodejs, then run this again."
  fi

  [ -n "$(command -v tar)" ] || fail "Unpacking Node.js needs tar. Install it, or install Node.js 18+ from https://nodejs.org."
  base="$MIRROR/latest-v$NODE_MAJOR.x"
  say ""
  say "Node.js 18 or newer isn't installed. Downloading the latest Node.js $NODE_MAJOR for"
  say "$plat-$cpu (about 30-50 MB) into $LOCAL_DIR."
  say "This copy is only used by Surface; nothing is installed system-wide."
  say ""

  rm -rf "$WORK"
  mkdir -p "$WORK" || fail "Couldn't create $WORK."
  download "$base/SHASUMS256.txt" "$WORK/SHASUMS256.txt" quiet \
    || fail "Couldn't download the Node.js $NODE_MAJOR release list from $base. Check your internet connection and proxy settings (https_proxy), check that SURFACE_NODE_MAJOR names a released version, or install Node.js 18+ from https://nodejs.org."
  line=$(grep " node-v[0-9.]*-$plat-$cpu\.tar\.gz\$" "$WORK/SHASUMS256.txt" | head -n 1)
  [ -n "$line" ] || fail "$base has no Node.js $NODE_MAJOR build for $plat-$cpu. Install Node.js 18+ from https://nodejs.org, or set SURFACE_NODE_MAJOR to another version."
  hash=${line%% *}
  file=${line##* }

  say "Downloading $file"
  download "$base/$file" "$WORK/$file" || fail "The download of $file failed."

  got=$(sha256_of "$WORK/$file")
  [ -n "$got" ] || fail "Can't verify the download: no sha256sum, shasum or openssl found."
  [ "$got" = "$hash" ] || fail "The download's SHA-256 checksum doesn't match the published value, so it was discarded."
  say "Checksum verified. Unpacking..."

  tar -xzf "$WORK/$file" -C "$WORK" || fail "Couldn't unpack $file."
  dir="$WORK/${file%.tar.gz}"
  [ -x "$dir/bin/node" ] || fail "The archive didn't contain bin/node."
  # Keep only the runtime and its licence; Surface doesn't need npm.
  rm -rf "$LOCAL_DIR"
  mkdir -p "$LOCAL_DIR/bin" || fail "Couldn't create $LOCAL_DIR."
  mv "$dir/bin/node" "$LOCAL_NODE" && mv "$dir/LICENSE" "$LOCAL_DIR/LICENSE" 2>/dev/null
  rm -rf "$WORK"
  [ "$(node_major "$LOCAL_NODE")" -ge 18 ] || fail "The downloaded Node.js doesn't run on this system."
  say "Installed Node.js $("$LOCAL_NODE" -v) to $LOCAL_DIR. Delete that folder to remove it."
  NODE="$LOCAL_NODE"
}

if ! find_node; then
  if [ "${SURFACE_NO_INSTALL:-0}" = 1 ]; then
    fail "Node.js 18+ wasn't found and automatic setup is off (SURFACE_NO_INSTALL=1). Install it from https://nodejs.org."
  fi
  install_node
fi

if [ "${NO_OPEN:-0}" != 1 ]; then
  SURFACE_OPEN=1
  export SURFACE_OPEN
fi

exec "$NODE" server.js
