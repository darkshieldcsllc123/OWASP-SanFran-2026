# Surface

Passive OSINT for any public website, in one HTML file and one Node script with no dependencies.

Enter a domain or URL and Surface collects what the site exposes publicly (DNS, certificates, headers, markup, crawl files, registration, IP ownership, Certificate Transparency subdomains, Wayback history), scores how well it's configured, and lists the fixes worth doing first. A built-in checker tests the scoring rules and the proxy, and the prompt used to build the tool is included so it can be reproduced.

## Start

| System | Command |
|---|---|
| macOS, Linux | `./start.sh` |
| Windows 10 or later | double-click `start.bat` |
| Anywhere with Node.js 18+ | `node server.js`, then open the address it prints |

The start scripts handle the rest:

- **Node.js.** They use Node.js 18 or newer from your PATH. If there isn't one, they download the latest Node.js 24 (an LTS line) from nodejs.org, verify it against the SHA-256 checksums nodejs.org publishes, and keep a private copy in a `.node` folder next to the scripts. No admin rights are needed and nothing is installed system-wide. Later runs reuse that copy. Delete `.node` to remove it, or to fetch a newer release.
- **Ports.** Surface tries port 8787, then the next 19, then any free port the system offers, and prints the address it ends up on. If Surface is already running with the same settings, starting it again opens the running copy instead of a second one.
- **Browser.** It opens once the server is listening.

What the download needs: on macOS and Linux, curl or wget, tar, and one of sha256sum, shasum or openssl (all standard). On Windows, the curl, tar and certutil tools built into Windows 10 and later. Official Node.js builds don't run on musl-based Linux such as Alpine; there the script uses `apk add nodejs` when run as root, or tells you to. 32-bit Windows isn't supported by current Node.js releases.

| Setting | Default | Effect |
|---|---|---|
| `PORT` | `8787` | Port to try first |
| `HOST` | `127.0.0.1` | Interface to bind. Leave it on loopback unless you know why not |
| `ALLOW_PRIVATE=1` | off | Allow scanning private, loopback and link-local addresses |
| `NO_OPEN=1` | off | Don't open a browser |
| `SURFACE_NO_INSTALL=1` | off | Never download Node.js |
| `SURFACE_NODE_MAJOR` | `24` | Node.js line to download, e.g. `26` |
| `SURFACE_NODE_MIRROR` | `https://nodejs.org/dist` | Download from a mirror with the same layout |
| `HTTPS_PROXY` | none | Proxy for the download, if your network requires one |
| `SURFACE_QUIET=1` | off | Don't log each request to the terminal |
| `SURFACE_UA` | Chrome-like UA tagged `SurfaceOSINT` | User-Agent for outbound requests |

On Windows, set these before running, e.g. `set PORT=9000` then `start.bat`.

## What a scan does

All modules run in parallel through the local proxy. Everything is a normal request a browser or resolver would make; nothing is brute-forced or port-scanned.

| Module | Source |
|---|---|
| Page fetch | GET of the URL with redirects followed |
| HTTP to HTTPS | GET of `http://host/` |
| DNS and email | System resolver: A, AAAA, CNAME, MX, NS, TXT, SOA, CAA, `_dmarc`, `_mta-sts`, PTR, 15 common DKIM selectors; DNSSEC via Cloudflare DNS-over-HTTPS |
| TLS | Handshake on 443 (or the URL's port), certificate chain, ALPN, TLS 1.0/1.1 probe |
| Crawl files | `robots.txt`, sitemap, `/.well-known/security.txt` |
| Registration | rdap.org |
| IP ownership | rdap.org for the first resolved IP |
| Subdomains | crt.sh Certificate Transparency search |
| Wayback | archive.org availability and CDX APIs |

The last four can be turned off per scan. They send the domain you're looking up to those services.

## Scores

Each check passes, warns, fails, or is informational. Points come from passes and partial passes; informational and not-applicable checks don't count.

| Category | Weight |
|---|---:|
| HTTPS & TLS | 20 |
| Security headers | 25 |
| DNS & email | 15 |
| SEO & content | 15 |
| Performance | 10 |
| Exposure & hygiene | 15 |

A category's score is the share of its available points earned. The overall score is the weighted mean of categories that have data, so a failed module doesn't drag the score to zero; it lowers **coverage** instead, shown with a confidence label next to the score. Grades: A+ 97+, A 90+, B 80+, C 70+, D 60+, F below.

"Fix these first" ranks failing and warning checks by how many overall points fixing each could recover.

## Checker

The Checker tab has three layers:

- **Unit tests** (run on every page load; the header shows the result) cover every parser and scoring rule, including a well-run and a neglected sample site, integrity tamper detection and the exports.
- **Live tests** send real requests through the proxy to example.com, github.com, rdap.org, crt.sh and archive.org, and confirm the private-address guard works.
- **Report integrity** validation runs on every report: points within bounds, category scores recomputed from checks, overall and grade consistent, unique IDs, coverage counts consistent. The result shows on the report and in exports.

## Proxy API

All endpoints are `GET` and return JSON with `ok: true`, or `ok: false` and an `error`.

| Endpoint | Purpose |
|---|---|
| `/api/health` | Version and settings |
| `/api/fetch?url=&follow=1&max=&timeout=&accept=` | HTTP(S) GET with redirect chain, headers, timing and decoded body |
| `/api/dns?host=&apex=&dkim=1` | DNS, email-authentication records, PTR, DNSSEC |
| `/api/tls?host=&port=443&legacy=1` | Handshake, certificate, chain, ALPN, legacy protocol probe |
| `/api/ct?domain=` | Subdomains from crt.sh |

The page and the API share an origin, which is how CORS is satisfied; the proxy sends no CORS headers, so other websites can't read its responses. It also refuses requests with an unexpected `Host` header (DNS rebinding) or `Sec-Fetch-Site: cross-site`, and blocks private and reserved addresses on every connection, including redirects, unless `ALLOW_PRIVATE=1`.

## Things that affect results

- **Your network.** Timings are measured from your machine. A TLS-inspecting corporate proxy or antivirus replaces certificates, so certificate results will describe it, not the site. A filtering DNS resolver can hide records; if no NS or SOA comes back, Surface marks DNS as incomplete and doesn't score it.
- **Client-rendered sites.** Surface reads the HTML the server sends. Apps that build their page in the browser show fewer tags, links and technologies.
- **crt.sh** is often slow or overloaded. A timeout there only removes the subdomain list.
- **Registrable domain** detection uses a built-in list of common multi-part suffixes rather than the full Public Suffix List.

Only scan sites you own or have permission to assess.

## Files

| File | Purpose |
|---|---|
| `index.html` | The app |
| `server.js` | Proxy and static server |
| `start.sh`, `start.bat` | Start scripts that find or fetch Node.js |
| `.node/` | Created only if Node.js had to be downloaded; safe to delete |
| `PROMPT.md` | The original prompt and a build spec for reproducing Surface (also in the app's Reproduce tab) |
