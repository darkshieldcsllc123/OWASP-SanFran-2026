# Surface: reproduction prompt

## Original prompt

```
i need a no-dep html/js spa where i can run basic OSINT scans on a website. Make sure it has quality scores and checker built in, as well as this prompt so it can be reproduced It will need a node proxy to satisfy CORS, and a start.bat/start.sh for easy startup
```

## Build spec

```
Build "Surface", a passive website OSINT scanner, as index.html, server.js, start.sh and start.bat, plus README.md and PROMPT.md.

Constraints
- Zero dependencies: no npm packages, no CDNs, no web fonts. Plain HTML/CSS/JS in a single index.html; Node 18+ built-ins only (http, https, dns, tls, zlib, net, fs, child_process).
- server.js serves index.html and a JSON API on 127.0.0.1, port 8787 by default (PORT and HOST env vars). The page calls the API same-origin, which is how CORS is satisfied, so the proxy sends no CORS headers at all.
- Guards: Host-header check against DNS rebinding, reject Sec-Fetch-Site: cross-site, block private and reserved IPs on every outbound socket through a custom dns lookup, checking IP literals directly because Node skips the lookup for them (ALLOW_PRIVATE=1 overrides), a strict CSP on the page, and HTML-escape all scanned content when rendering.
- start.sh and start.bat find Node.js 18+ on the PATH, then a private copy in ./.node. If neither exists they download the latest release of an LTS line (default 24, SURFACE_NODE_MAJOR to change, SURFACE_NODE_MIRROR for a mirror) from nodejs.org/dist/latest-vNN.x, pick the archive for the OS and CPU from SHASUMS256.txt, verify its SHA-256, and keep only the node binary and licence in ./.node: no admin rights, nothing installed system-wide. start.sh uses curl or wget, sha256sum/shasum/openssl and tar, handles Apple Silicon under Rosetta, and uses apk on musl systems. start.bat uses the curl.exe, tar.exe and certutil built into Windows 10+, and reads the node version from its exit code. SURFACE_NO_INSTALL=1 turns downloading off. Both then run server.js with SURFACE_OPEN=1 so it opens the browser once listening (NO_OPEN=1 skips that).
- Port selection lives in server.js, which binds by actually listening: PORT (default 8787), then the next 19 ports, then any port the OS assigns. If a busy port is already running Surface with the same settings (checked in parallel with a short timeout via /api/health), it opens that one instead of starting a second copy.

Proxy API (GET only, JSON, {ok:false,error} on failure)
- /api/health: version, node version, allowPrivate.
- /api/fetch?url=&follow=1&max=&timeout=&accept=: manual redirect chain, status, headers, raw headers, timing (dns, connect, tls, ttfb, total), transfer vs decoded bytes, content-encoding, decoded text body (gzip, deflate, br), whether the socket's certificate was trusted.
- /api/dns?host=&apex=&dkim=1: A, AAAA, CNAME for the host; MX, NS, TXT, SOA, CAA for the apex (CAA at the host first); _dmarc and _mta-sts TXT; PTR of the first IP; DKIM probe of about 15 common selectors; DNSSEC via Cloudflare DNS-over-HTTPS (DNSKEY present plus AD flag).
- /api/tls?host=&port=443&legacy=1: protocol, cipher, ALPN (h2), authorization error, leaf certificate (subject, issuer, SAN, validity, key bits or curve, SHA-256 fingerprint), chain, and a TLS 1.0/1.1 probe that reports "untestable" when the local OpenSSL cannot offer those versions.
- /api/ct?domain=: subdomains from crt.sh JSON, extracted with a regex so a truncated body still works, de-duplicated and sorted.

Scan modules (run in the browser, in parallel where independent)
Page fetch, HTTP-to-HTTPS redirect, DNS and email, TLS, files (robots.txt, the sitemap named in robots or /sitemap.xml, /.well-known/security.txt with /security.txt fallback), registration (rdap.org/domain), IP ownership (rdap.org/ip of the first A record), subdomains (CT logs), Wayback Machine (archive.org "available" API plus CDX first capture). The slower modules are toggles. Each module records status, duration and error.

Page analysis (DOMParser, inert document)
Title, description, canonical, lang, viewport, robots meta, generator, Open Graph and Twitter tags, H1s, image alt coverage, JSON-LD types, internal and external links, social profiles, emails, tel links, tracking IDs (GA, GA4, GTM, Google Ads, AdSense, Meta Pixel, Hotjar, Clarity, Yandex) as pivots, third-party script hosts, render-blocking head scripts, mixed content, insecure forms, HTML comments. Technology fingerprinting from markup, headers, cookies and the generator meta, with versions where exposed.

Quality scores
- Each check has a status (pass, warn, fail, info, na), earned and max points, a detail line and a fix. info and na checks carry 0 max and are excluded from scoring.
- Categories and weights: HTTPS & TLS 20, Security headers 25, DNS & email 15, SEO & content 15, Performance 10, Exposure & hygiene 15. Category score = earned / max. Overall = weighted mean over categories that have data, with weights renormalised. Grades: A+ >= 97, A >= 90, B >= 80, C >= 70, D >= 60, F below.
- Scan coverage = modules that succeeded / modules attempted, with a High/Medium/Low confidence label, so a low score caused by failed modules is visible.
- If the resolver returns no NS and no SOA for the apex, its answers are treated as incomplete: the DNS module is marked failed and DNS & email checks are not scored, rather than penalising the site for a filtering resolver.
- Top fixes ranked by the overall points each fix could recover (lost points x category weight).

Built-in checker
- Unit tests for every parser and scoring rule: target normalisation, registrable domain, HSTS, SPF, DMARC, CSP, cookies, SAN wildcard matching, robots.txt, security.txt, tech fingerprints and versions, HTML analysis, grade thresholds, category weighting, coverage, incomplete-DNS handling, report integrity, tamper detection, a good sample site scoring well above a bad one, fix ranking and Markdown export. They run on page load and the header shows the result.
- Live tests through the proxy: health, DNS, HTTPS fetch, redirect following, TLS, private-address blocking, RDAP, crt.sh, Wayback.
- Every report is validated (points within bounds, info/na carry no points, category scores recomputed from checks, overall matches categories, grade matches score, unique check ids, coverage counts add up) and the result is shown on the report and in exports.

UI
- Tabs: Scan, Checker, Reproduce, with #hash routing. Large target field, module toggles, recent scans stored in localStorage, live module progress, a concentric-ring chart (one ring per category, coloured by score) with the grade in the centre, a category table, ranked fixes, checks grouped by category, intelligence panels (hosting, registration, technology, certificate, subdomains with filter and copy, pivots, third parties, crawl files, history, page facts, redirect chain), raw headers, DNS records and JSON, export to JSON and Markdown, and a sample report built from fixture data that works offline.
- The Reproduce tab shows the original prompt verbatim and this build spec, with copy and download buttons.
- Dark and light themes (system default plus a toggle), responsive down to phones, visible keyboard focus, reduced motion respected.
```

## Files

| File | Purpose |
|---|---|
| `index.html` | The single-page app: scanner, scoring, checker, reproduction prompt |
| `server.js` | Zero-dependency Node proxy and static server |
| `start.sh` | Start on macOS and Linux |
| `start.bat` | Start on Windows |
| `README.md` | Usage, settings, API, scoring |
| `PROMPT.md` | This file |
