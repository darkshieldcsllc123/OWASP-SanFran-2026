#!/usr/bin/env node
'use strict';
/*
 * Surface: passive website OSINT scanner
 * Zero-dependency Node.js proxy and static server (Node 18+).
 *
 * Serves index.html and a small JSON API that the browser cannot do itself
 * because of CORS or missing browser APIs (raw DNS, TLS handshakes):
 *
 *   GET /api/health                          proxy status
 *   GET /api/fetch?url=&follow=1&max=&timeout=&accept=
 *                                            HTTP(S) GET with redirect chain, headers, timing
 *   GET /api/dns?host=&apex=&dkim=1          DNS records, SPF/DMARC/DKIM/MTA-STS, PTR, DNSSEC (via DoH)
 *   GET /api/tls?host=&port=443&legacy=1     TLS handshake, certificate chain, ALPN, legacy protocol probe
 *   GET /api/ct?domain=                      subdomains from Certificate Transparency logs (crt.sh)
 *
 * Safety defaults:
 *   - binds to 127.0.0.1 only (HOST env to change)
 *   - rejects requests whose Host header is not this server (DNS-rebinding guard)
 *   - rejects cross-site API calls (Sec-Fetch-Site) and sends no CORS headers
 *   - refuses to connect to private/reserved IPs unless ALLOW_PRIVATE=1
 */

const http = require('http');
const https = require('https');
const dns = require('dns');
const net = require('net');
const tls = require('tls');
const zlib = require('zlib');
const fs = require('fs');
const path = require('path');
const { spawn } = require('child_process');

const VERSION = '1.0.0';
const NODE_MAJOR = parseInt(process.versions.node, 10);
if (NODE_MAJOR < 18) {
  console.error(`Surface needs Node.js 18 or newer. Found ${process.version}. Get it from https://nodejs.org`);
  process.exit(1);
}

const REQUESTED_PORT = (() => { const n = parseInt(process.env.PORT || '8787', 10); return n >= 0 && n <= 65535 ? n : 8787; })();
const PORT_TRIES = 20;          // REQUESTED_PORT, +1, +2 ... then any free port
let PORT = REQUESTED_PORT;      // the port actually bound, set once listening
const HOST = process.env.HOST || '127.0.0.1';
const ALLOW_PRIVATE = process.env.ALLOW_PRIVATE === '1';
const LOOPBACK = HOST === '127.0.0.1' || HOST === 'localhost' || HOST === '::1';
const UA = process.env.SURFACE_UA ||
  `Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0 Safari/537.36 SurfaceOSINT/${VERSION}`;
const ROOT = __dirname;
const STARTED = Date.now();

const resolver = new dns.promises.Resolver({ timeout: 4000, tries: 2 });

/* ------------------------------------------------------------------ guards */

function isPrivateIP(ip) {
  if (net.isIPv4(ip)) {
    const p = ip.split('.').map(Number);
    return p[0] === 0 || p[0] === 10 || p[0] === 127 ||
      (p[0] === 100 && p[1] >= 64 && p[1] <= 127) ||
      (p[0] === 169 && p[1] === 254) ||
      (p[0] === 172 && p[1] >= 16 && p[1] <= 31) ||
      (p[0] === 192 && p[1] === 0 && p[2] === 0) ||
      (p[0] === 192 && p[1] === 168) ||
      (p[0] === 198 && (p[1] === 18 || p[1] === 19)) ||
      p[0] >= 224;
  }
  if (net.isIPv6(ip)) {
    const v = ip.toLowerCase();
    if (v === '::' || v === '::1') return true;
    if (/^fe[89ab]/.test(v) || /^f[cd]/.test(v) || v.startsWith('ff')) return true;
    const mapped = v.match(/^::ffff:(\d+\.\d+\.\d+\.\d+)$/);
    if (mapped) return isPrivateIP(mapped[1]);
    return false;
  }
  return true;
}

// dns.lookup wrapper used for every outbound socket, so redirects can't reach internal hosts either.
function safeLookup(hostname, options, cb) {
  if (typeof options === 'function') { cb = options; options = {}; }
  dns.lookup(hostname, options, (err, address, family) => {
    if (err) return cb(err);
    const list = Array.isArray(address) ? address : [{ address, family }];
    if (!ALLOW_PRIVATE) {
      for (const a of list) {
        if (isPrivateIP(a.address)) {
          const e = new Error(`Blocked private or reserved address ${a.address}. Start the proxy with ALLOW_PRIVATE=1 to scan internal hosts.`);
          e.code = 'EPRIVATE';
          return cb(e);
        }
      }
    }
    cb(null, address, family);
  });
}

// Node skips the lookup function for IP literals, so those are checked directly.
function assertAllowedHost(hostname) {
  const h = String(hostname || '').replace(/^\[|\]$/g, '');
  if (!ALLOW_PRIVATE && net.isIP(h) && isPrivateIP(h)) {
    const e = new Error(`Blocked private or reserved address ${h}. Start the proxy with ALLOW_PRIVATE=1 to scan internal hosts.`);
    e.code = 'EPRIVATE';
    throw e;
  }
}

function allowedHost(hostHeader) {
  if (!LOOPBACK) return true;
  const h = String(hostHeader || '').toLowerCase();
  const names = ['127.0.0.1', 'localhost', '[::1]'];
  return names.some(n => h === `${n}:${PORT}` || (PORT === 80 && h === n));
}

/* ------------------------------------------------------------- http client */

const now = () => performance.now();

function isTextual(ct) {
  if (!ct) return true;
  return /text\/|json|xml|javascript|html|x-www-form-urlencoded/i.test(ct);
}

function decodeBody(buf, contentType) {
  const m = /charset\s*=\s*["']?([\w-]+)/i.exec(contentType || '');
  const charset = (m ? m[1] : 'utf-8').toLowerCase();
  try { return new TextDecoder(charset).decode(buf); } catch { return new TextDecoder('utf-8').decode(buf); }
}

function httpGet(urlStr, { maxBytes = 2 * 1024 * 1024, timeout = 15000, headers = {} } = {}) {
  return new Promise((resolve, reject) => {
    let u;
    try { u = new URL(urlStr); } catch { return reject(new Error(`Invalid URL: ${urlStr}`)); }
    if (u.protocol !== 'http:' && u.protocol !== 'https:') return reject(new Error('Only http and https URLs are allowed'));
    try { assertAllowedHost(u.hostname); } catch (e) { return reject(e); }
    const mod = u.protocol === 'https:' ? https : http;
    const t = { start: now() };
    let done = false;

    const req = mod.request(u, {
      method: 'GET',
      agent: false,
      lookup: safeLookup,
      rejectUnauthorized: false, // certificate problems are reported by /api/tls, not fatal here
      headers: {
        'User-Agent': UA,
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
        'Accept-Encoding': 'gzip, deflate, br',
        'Accept-Language': 'en-US,en;q=0.8',
        ...headers,
      },
    }, res => {
      t.ttfb = now();
      const sock = res.socket || {};
      const meta = {
        remoteAddress: sock.remoteAddress || null,
        remotePort: sock.remotePort || null,
        tlsAuthorized: typeof sock.authorized === 'boolean' ? sock.authorized : null,
        tlsError: sock.authorizationError ? String(sock.authorizationError) : null,
      };
      const enc = String(res.headers['content-encoding'] || '').toLowerCase().trim();
      let rawBytes = 0;
      res.on('data', c => { rawBytes += c.length; });

      let stream = res;
      if (enc === 'gzip' || enc === 'x-gzip') stream = res.pipe(zlib.createGunzip());
      else if (enc === 'deflate') stream = res.pipe(zlib.createInflate());
      else if (enc === 'br') stream = res.pipe(zlib.createBrotliDecompress());

      const chunks = [];
      let size = 0;
      let truncated = false;
      const finish = (extra = {}) => {
        if (done) return;
        done = true;
        clearTimeout(deadline);
        t.end = now();
        resolve({ res, buf: Buffer.concat(chunks), rawBytes, truncated, encoding: enc || null, timing: t, ...meta, ...extra });
      };
      stream.on('data', c => {
        if (truncated) return;
        if (size + c.length > maxBytes) {
          chunks.push(c.subarray(0, maxBytes - size));
          size = maxBytes;
          truncated = true;
          finish();
          req.destroy();
          return;
        }
        chunks.push(c);
        size += c.length;
      });
      stream.on('end', () => finish());
      stream.on('error', e => finish({ decodeError: e.message }));
      res.on('aborted', () => finish({ aborted: true }));
    });

    req.on('socket', s => {
      s.once('lookup', () => { t.dns = now(); });
      s.once('connect', () => { t.connect = now(); });
      s.once('secureConnect', () => { t.tls = now(); });
    });
    req.on('error', e => {
      if (done) return;
      done = true;
      clearTimeout(deadline);
      reject(e);
    });
    const deadline = setTimeout(() => req.destroy(new Error(`Timed out after ${timeout} ms`)), timeout);
    req.end();
  });
}

async function fetchChain(urlStr, opts = {}) {
  const follow = opts.follow !== false;
  const maxRedirects = 10;
  const redirects = [];
  let current = urlStr;
  for (;;) {
    const r = await httpGet(current, opts);
    const status = r.res.statusCode;
    const loc = r.res.headers.location;
    if (follow && status >= 300 && status < 400 && loc) {
      let next;
      try { next = new URL(loc, current).toString(); } catch { return { r, finalUrl: current, redirects }; }
      redirects.push({ url: current, status, location: next, ms: Math.round(r.timing.end - r.timing.start) });
      if (redirects.length > maxRedirects) throw new Error(`More than ${maxRedirects} redirects`);
      current = next;
      continue;
    }
    return { r, finalUrl: current, redirects };
  }
}

function timingSummary(t) {
  const rel = x => (typeof x === 'number' ? Math.round(x - t.start) : null);
  return { dns: rel(t.dns), connect: rel(t.connect), tls: rel(t.tls), ttfb: rel(t.ttfb), total: rel(t.end) };
}

/* -------------------------------------------------------------------- DNS */

async function rr(fn, name) {
  try { return { value: await fn(name) }; } catch (e) {
    if (['ENODATA', 'ENOTFOUND', 'NOTFOUND'].includes(e.code)) return { value: [] };
    return { value: [], error: e.code || e.message };
  }
}

async function doh(name, type) {
  const r = await httpGet(`https://cloudflare-dns.com/dns-query?name=${encodeURIComponent(name)}&type=${type}`, {
    headers: { Accept: 'application/dns-json' }, timeout: 8000, maxBytes: 256 * 1024,
  });
  return JSON.parse(r.buf.toString('utf8'));
}

const DKIM_SELECTORS = ['default', 'google', 'selector1', 'selector2', 'k1', 'k2', 's1', 's2', 'mail', 'dkim', 'smtp', 'mandrill', 'everlytickey1', 'zoho', 'protonmail'];

async function dnsReport(host, apex, wantDkim) {
  const errors = {};
  const take = (label, res) => { if (res.error) errors[label] = res.error; return res.value; };
  const r = resolver;
  const [A, AAAA, CNAME, MX, NS, TXT, SOA, CAAhost, CAAapex, DMARC, MTASTS] = await Promise.all([
    rr(n => r.resolve4(n), host), rr(n => r.resolve6(n), host), rr(n => r.resolveCname(n), host),
    rr(n => r.resolveMx(n), apex), rr(n => r.resolveNs(n), apex), rr(n => r.resolveTxt(n), apex),
    rr(n => r.resolveSoa(n), apex),
    rr(n => r.resolveCaa(n), host), host !== apex ? rr(n => r.resolveCaa(n), apex) : Promise.resolve({ value: [] }),
    rr(n => r.resolveTxt(n), `_dmarc.${apex}`), rr(n => r.resolveTxt(n), `_mta-sts.${apex}`),
  ]);
  const joinTxt = v => (v || []).map(parts => (Array.isArray(parts) ? parts.join('') : String(parts)));
  const records = {
    A: take('A', A), AAAA: take('AAAA', AAAA), CNAME: take('CNAME', CNAME),
    MX: take('MX', MX).sort((a, b) => a.priority - b.priority), NS: take('NS', NS).sort(),
    TXT: joinTxt(take('TXT', TXT)), SOA: SOA.value && !Array.isArray(SOA.value) ? SOA.value : null,
    CAA: [],
  };
  if (SOA.error) errors.SOA = SOA.error;
  const caaHost = take('CAA', CAAhost);
  const caaApex = CAAapex.value || [];
  records.CAA = (caaHost.length ? caaHost : caaApex).map(c => {
    const tag = ['issue', 'issuewild', 'iodef', 'contactemail', 'contactphone'].find(k => k in c) || Object.keys(c).find(k => k !== 'critical');
    return { critical: c.critical || 0, tag, value: c[tag] };
  });
  const caaAt = caaHost.length ? host : (caaApex.length ? apex : null);

  let ptr = null;
  const ip = records.A[0] || records.AAAA[0];
  if (ip) {
    try { ptr = { ip, names: await r.reverse(ip) }; } catch (e) { ptr = { ip, names: [], error: e.code || e.message }; }
  }

  let dkim = null;
  if (wantDkim) {
    const found = await Promise.all(DKIM_SELECTORS.map(async sel => {
      const res = await rr(n => r.resolveTxt(n), `${sel}._domainkey.${apex}`);
      const txt = joinTxt(res.value).find(t => /v=DKIM1|k=rsa|p=/i.test(t));
      return txt ? { selector: sel, record: txt } : null;
    }));
    dkim = { tried: DKIM_SELECTORS, found: found.filter(Boolean) };
  }

  let dnssec = null;
  try {
    const [key, soa] = await Promise.all([doh(apex, 'DNSKEY'), doh(apex, 'SOA')]);
    const hasKey = (key.Answer || []).some(a => a.type === 48);
    dnssec = { signed: hasKey, validated: !!soa.AD, resolver: 'cloudflare-dns.com' };
  } catch (e) {
    dnssec = { error: e.message };
  }

  return {
    host, apex, records, caaAt,
    dmarc: joinTxt(take('DMARC', DMARC)),
    mtaSts: joinTxt(take('MTA-STS', MTASTS)),
    ptr, dkim, dnssec, errors,
  };
}

/* -------------------------------------------------------------------- TLS */

function nameOf(x) {
  if (!x) return '';
  const v = x.CN || x.O || Object.values(x)[0];
  return Array.isArray(v) ? v.join(', ') : String(v || '');
}

function tlsProbe(host, port, extra = {}) {
  return new Promise((resolve, reject) => {
    const t0 = now();
    let sock;
    try {
      assertAllowedHost(host);
      sock = tls.connect({
        host, port,
        servername: net.isIP(host) ? undefined : host,
        rejectUnauthorized: false,
        ALPNProtocols: ['h2', 'http/1.1'],
        lookup: safeLookup,
        ...extra,
      });
    } catch (e) { return reject(e); }
    const timer = setTimeout(() => sock.destroy(new Error('TLS handshake timed out after 10000 ms')), 10000);
    sock.once('secureConnect', () => {
      clearTimeout(timer);
      const ms = Math.round(now() - t0);
      const peer = sock.getPeerCertificate(true) || {};
      const chain = [];
      const seen = new Set();
      let c = peer;
      while (c && c.fingerprint256 && !seen.has(c.fingerprint256) && chain.length < 8) {
        seen.add(c.fingerprint256);
        chain.push({ subject: nameOf(c.subject), issuer: nameOf(c.issuer), validTo: c.valid_to, selfSigned: c.issuerCertificate === c });
        c = c.issuerCertificate;
      }
      const info = {
        ms,
        authorized: sock.authorized,
        authorizationError: sock.authorizationError ? String(sock.authorizationError) : null,
        protocol: sock.getProtocol(),
        cipher: sock.getCipher(),
        alpn: sock.alpnProtocol || null,
        remoteAddress: sock.remoteAddress,
        cert: peer.subject ? {
          subject: nameOf(peer.subject),
          subjectOrg: peer.subject && peer.subject.O ? String(peer.subject.O) : null,
          issuer: nameOf(peer.issuer),
          issuerOrg: peer.issuer && peer.issuer.O ? String(peer.issuer.O) : null,
          san: peer.subjectaltname || '',
          validFrom: peer.valid_from,
          validTo: peer.valid_to,
          serialNumber: peer.serialNumber,
          fingerprint256: peer.fingerprint256,
          bits: peer.bits || null,
          curve: peer.asn1Curve || peer.nistCurve || null,
        } : null,
        chain,
      };
      sock.end();
      resolve(info);
    });
    sock.once('error', e => { clearTimeout(timer); reject(e); });
  });
}

async function tlsReport(host, port, wantLegacy) {
  const main = await tlsProbe(host, port);
  if (wantLegacy) {
    try {
      const old = await tlsProbe(host, port, { minVersion: 'TLSv1', maxVersion: 'TLSv1.1', ciphers: 'DEFAULT:@SECLEVEL=0', ALPNProtocols: undefined });
      main.legacy = { tested: true, accepted: true, protocol: old.protocol };
    } catch (e) {
      const msg = `${e.code || ''} ${e.message || ''}`;
      // If our own OpenSSL can't speak TLS 1.0/1.1, the probe proves nothing.
      const untestable = /NO_PROTOCOLS_AVAILABLE|no protocols available|NO_CIPHERS_AVAILABLE/i.test(msg);
      main.legacy = { tested: !untestable, accepted: false, error: e.code || e.message };
    }
  } else {
    main.legacy = { tested: false };
  }
  return main;
}

/* -------------------------------------------------------- CT log subdomains */

async function ctReport(domain) {
  const url = `https://crt.sh/?q=${encodeURIComponent('%.' + domain)}&output=json`;
  const { r } = await fetchChain(url, { timeout: 45000, maxBytes: 24 * 1024 * 1024, headers: { Accept: 'application/json' } });
  if (r.res.statusCode !== 200) throw new Error(`crt.sh returned HTTP ${r.res.statusCode} (it is often overloaded; try again later)`);
  const text = r.buf.toString('utf8');
  // Regex extraction tolerates a truncated body, unlike JSON.parse.
  const names = new Set();
  let certs = 0;
  const re = /"(?:name_value|common_name)":"((?:[^"\\]|\\.)*)"/g;
  let m;
  while ((m = re.exec(text))) {
    if (m[0].startsWith('"name_value"')) certs++;
    for (let n of m[1].split('\\n')) {
      n = n.trim().toLowerCase().replace(/^\*\./, '');
      if (!n || !/^[a-z0-9.-]+$/.test(n)) continue;
      if (n === domain || n.endsWith('.' + domain)) names.add(n);
    }
  }
  const subdomains = [...names].sort((a, b) => a.split('.').reverse().join('.').localeCompare(b.split('.').reverse().join('.')));
  return { source: 'crt.sh', domain, certificates: certs, count: subdomains.length, subdomains: subdomains.slice(0, 2000), truncated: r.truncated || subdomains.length > 2000 };
}

/* -------------------------------------------------------------------- API */

const clampInt = (v, def, min, max) => {
  const n = parseInt(v, 10);
  return Number.isFinite(n) ? Math.min(max, Math.max(min, n)) : def;
};
const validHost = h => typeof h === 'string' && h.length > 0 && h.length < 254 && /^[a-z0-9.\-:\[\]]+$/i.test(h);

async function handleApi(u, res) {
  const q = u.searchParams;
  const route = u.pathname.slice('/api/'.length);

  if (route === 'health') {
    return sendJson(res, 200, { ok: true, name: 'surface-proxy', version: VERSION, node: process.version, allowPrivate: ALLOW_PRIVATE, uptimeSec: Math.round((Date.now() - STARTED) / 1000) });
  }

  if (route === 'fetch') {
    const url = q.get('url');
    if (!url) return sendJson(res, 400, { ok: false, error: 'Missing url parameter' });
    const opts = {
      follow: q.get('follow') !== '0',
      maxBytes: clampInt(q.get('max'), 2 * 1024 * 1024, 1024, 16 * 1024 * 1024),
      timeout: clampInt(q.get('timeout'), 15000, 1000, 60000),
      headers: q.get('accept') ? { Accept: q.get('accept') } : {},
    };
    const t0 = now();
    const { r, finalUrl, redirects } = await fetchChain(url, opts);
    const ct = r.res.headers['content-type'] || '';
    const textual = isTextual(ct);
    const rawHeaders = [];
    for (let i = 0; i < r.res.rawHeaders.length; i += 2) rawHeaders.push([r.res.rawHeaders[i], r.res.rawHeaders[i + 1]]);
    return sendJson(res, 200, {
      ok: true,
      url, finalUrl, redirects,
      status: r.res.statusCode,
      statusText: r.res.statusMessage,
      httpVersion: r.res.httpVersion,
      headers: r.res.headers,
      rawHeaders,
      contentType: ct,
      encoding: r.encoding,
      transferBytes: r.rawBytes,
      bodyBytes: r.buf.length,
      truncated: r.truncated,
      decodeError: r.decodeError || null,
      timing: timingSummary(r.timing),
      totalMs: Math.round(now() - t0),
      remoteAddress: r.remoteAddress,
      tlsAuthorized: r.tlsAuthorized,
      tlsError: r.tlsError,
      body: textual ? decodeBody(r.buf, ct) : null,
    });
  }

  if (route === 'dns') {
    const host = (q.get('host') || '').toLowerCase();
    const apex = (q.get('apex') || host).toLowerCase();
    if (!validHost(host) || !validHost(apex)) return sendJson(res, 400, { ok: false, error: 'Invalid host' });
    return sendJson(res, 200, { ok: true, ...(await dnsReport(host, apex, q.get('dkim') === '1')) });
  }

  if (route === 'tls') {
    const host = (q.get('host') || '').toLowerCase();
    if (!validHost(host)) return sendJson(res, 400, { ok: false, error: 'Invalid host' });
    const port = clampInt(q.get('port'), 443, 1, 65535);
    return sendJson(res, 200, { ok: true, host, port, ...(await tlsReport(host, port, q.get('legacy') === '1')) });
  }

  if (route === 'ct') {
    const domain = (q.get('domain') || '').toLowerCase();
    if (!validHost(domain) || !domain.includes('.')) return sendJson(res, 400, { ok: false, error: 'Invalid domain' });
    return sendJson(res, 200, { ok: true, ...(await ctReport(domain)) });
  }

  return sendJson(res, 404, { ok: false, error: `Unknown endpoint /api/${route}` });
}

/* ----------------------------------------------------------------- server */

const BASE_HEADERS = {
  'X-Content-Type-Options': 'nosniff',
  'Referrer-Policy': 'no-referrer',
  'Cross-Origin-Opener-Policy': 'same-origin',
  'Cross-Origin-Resource-Policy': 'same-origin',
};
const PAGE_CSP = "default-src 'self'; script-src 'self' 'unsafe-inline'; style-src 'self' 'unsafe-inline'; img-src 'self' data:; connect-src 'self'; object-src 'none'; base-uri 'none'; form-action 'none'; frame-ancestors 'none'";

function sendJson(res, status, obj) {
  const body = JSON.stringify(obj);
  res.writeHead(status, { ...BASE_HEADERS, 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store', 'Content-Length': Buffer.byteLength(body) });
  res.end(body);
}

const STATIC = {
  '/': ['index.html', 'text/html; charset=utf-8'],
  '/index.html': ['index.html', 'text/html; charset=utf-8'],
  '/PROMPT.md': ['PROMPT.md', 'text/markdown; charset=utf-8'],
  '/README.md': ['README.md', 'text/markdown; charset=utf-8'],
};

function serveStatic(pathname, res) {
  const entry = STATIC[pathname];
  if (!entry) return false;
  fs.readFile(path.join(ROOT, entry[0]), (err, data) => {
    if (err) return sendJson(res, 404, { ok: false, error: `${entry[0]} not found next to server.js` });
    res.writeHead(200, { ...BASE_HEADERS, 'Content-Type': entry[1], 'Content-Security-Policy': PAGE_CSP, 'Cache-Control': 'no-cache' });
    res.end(data);
  });
  return true;
}

function errorMessage(e) {
  const map = {
    ENOTFOUND: 'Host name could not be resolved',
    ECONNREFUSED: 'Connection refused',
    ECONNRESET: 'Connection reset by the remote host',
    ETIMEDOUT: 'Connection timed out',
    EHOSTUNREACH: 'Host unreachable',
    CERT_HAS_EXPIRED: 'Certificate has expired',
  };
  return map[e.code] ? `${map[e.code]} (${e.code})` : (e.message || String(e));
}

async function handleRequest(req, res) {
  try {
    if (!allowedHost(req.headers.host)) {
      return sendJson(res, 421, { ok: false, error: 'Unexpected Host header. Open the app at http://127.0.0.1:' + PORT });
    }
    const u = new URL(req.url, `http://127.0.0.1:${PORT}`);
    if (req.method !== 'GET' && req.method !== 'HEAD') return sendJson(res, 405, { ok: false, error: 'Only GET is supported' });
    if (u.pathname.startsWith('/api/')) {
      if (req.headers['sec-fetch-site'] === 'cross-site') return sendJson(res, 403, { ok: false, error: 'Cross-site requests are not allowed' });
      const t0 = now();
      try {
        await handleApi(u, res);
      } catch (e) {
        sendJson(res, 200, { ok: false, error: errorMessage(e), code: e.code || null });
      }
      if (process.env.SURFACE_QUIET !== '1') console.log(`${new Date().toISOString().slice(11, 19)}  ${u.pathname.padEnd(12)} ${Math.round(now() - t0)} ms  ${(u.searchParams.get('url') || u.searchParams.get('host') || u.searchParams.get('domain') || '').slice(0, 90)}`);
      return;
    }
    if (!serveStatic(u.pathname, res)) sendJson(res, 404, { ok: false, error: 'Not found' });
  } catch (e) {
    if (!res.headersSent) sendJson(res, 500, { ok: false, error: errorMessage(e) });
  }
}

/* ---------------------------------------------------------- startup */

const urlFor = port => `http://${HOST.includes(':') ? `[${HOST}]` : HOST}:${port}/`;

// Bind by actually listening, so there is no gap between "port looks free" and using it.
function tryListen(port) {
  return new Promise((resolve, reject) => {
    const srv = http.createServer(handleRequest);
    srv.once('error', reject);
    srv.listen(port, HOST, () => { srv.removeListener('error', reject); resolve(srv); });
  });
}

// Is a Surface proxy already answering on this port? Returns its health info or null.
function probeSurface(port, timeout = 800) {
  const host = LOOPBACK || HOST === '0.0.0.0' || HOST === '::' ? '127.0.0.1' : HOST;
  return new Promise(resolve => {
    const done = v => { clearTimeout(timer); resolve(v); };
    const req = http.get({ host, port, path: '/api/health', headers: { Host: `${host}:${port}` } }, res => {
      let body = '';
      res.setEncoding('utf8');
      res.on('data', c => { body += c; if (body.length > 8192) req.destroy(); });
      res.on('end', () => {
        try { const j = JSON.parse(body); done(j && j.name === 'surface-proxy' ? j : null); } catch { done(null); }
      });
    });
    // A hard deadline: something may accept the connection and never answer.
    const timer = setTimeout(() => { req.destroy(); resolve(null); }, timeout);
    req.on('error', () => done(null));
  });
}

async function start() {
  const busy = [];
  const candidates = [];
  for (let i = 0; i < PORT_TRIES && REQUESTED_PORT + i <= 65535; i++) candidates.push(REQUESTED_PORT + i);
  candidates.push(0); // last resort: let the OS pick any free port

  // 1. Bind the first free port. Binding is instant, so this loop is fast.
  let srv = null;
  for (const port of candidates) {
    try {
      srv = await tryListen(port);
      break;
    } catch (e) {
      if (e.code !== 'EADDRINUSE' && e.code !== 'EACCES') {
        console.error(`Couldn't start on ${HOST}:${port}: ${e.message}`);
        process.exit(1);
      }
      busy.push(port);
    }
  }

  // 2. Started twice? If a busy port is already running Surface with the same
  //    settings, use that copy instead. All busy ports are checked at once.
  if (busy.length) {
    const found = await Promise.all(busy.filter(p => p > 0).map(async p => ({ port: p, info: await probeSurface(p) })));
    const running = found.find(f => f.info && f.info.allowPrivate === ALLOW_PRIVATE);
    if (running) {
      if (srv) srv.close();
      const url = urlFor(running.port);
      console.log(`\n  Surface ${running.info.version} is already running at ${url}\n  Opening it instead of starting a second copy.\n`);
      if (process.env.SURFACE_OPEN === '1') openBrowser(url);
      return;
    }
  }

  if (!srv) {
    console.error(`No free port found near ${REQUESTED_PORT}. Set PORT to a free port and try again.`);
    process.exit(1);
  }
  PORT = srv.address().port;
  listening(busy.filter(p => p > 0));
}

function listening(busy) {
  const url = urlFor(PORT);
  const note = busy.length
    ? `\n  ${busy.length === 1 ? `Port ${busy[0]} was` : `Ports ${busy[0]}-${busy[busy.length - 1]} were`} busy, so Surface is using ${PORT}.`
    : '';
  console.log(`\n  Surface ${VERSION} - passive website OSINT${note}\n  Open ${url}\n  Private targets: ${ALLOW_PRIVATE ? 'allowed' : 'blocked (ALLOW_PRIVATE=1 to allow)'}\n  Press Ctrl+C to stop.\n`);
  if (process.env.SURFACE_OPEN === '1') openBrowser(url);
}

start();

function openBrowser(url) {
  const cmd = process.platform === 'win32' ? ['cmd', ['/c', 'start', '""', url]]
    : process.platform === 'darwin' ? ['open', [url]]
    : ['xdg-open', [url]];
  try {
    const p = spawn(cmd[0], cmd[1], { stdio: 'ignore', detached: true, windowsVerbatimArguments: true });
    p.on('error', () => {});
    p.unref();
  } catch { /* opening a browser is a convenience only */ }
}
