#!/usr/bin/env node
'use strict';
/**
 * Mock LLM server for testing the harness without a GPU or API key.
 * Speaks three wire formats with streaming and scripted tool calls:
 *   Ollama      http://127.0.0.1:11435/api/chat        (point the Ollama base URL here)
 *   OpenAI      http://127.0.0.1:11435/v1/chat/completions
 *   Anthropic   http://127.0.0.1:11435/v1/messages
 *
 * Script per user turn: list_dir -> write_file -> run_command -> final answer.
 * Say "no tools" in your message to get a plain markdown answer instead.
 *
 * Usage: node test/mock-llm.js [--port 11435] [--delay 12]
 */
const http = require('http');
const crypto = require('crypto');

const argv = process.argv.slice(2);
const opt = (k, d) => { const i = argv.indexOf('--' + k); return i > -1 ? argv[i + 1] : d; };
const PORT = Number(opt('port', 11435));
const DELAY = Number(opt('delay', 12));
const sleep = ms => new Promise(r => setTimeout(r, ms));
const id = p => p + crypto.randomBytes(6).toString('hex');

const MODELS = [
  { name: 'mock-coder:7b', family: 'mock', parameter_size: '7B', quantization_level: 'Q4_K_M', size: 4_700_000_000, caps: ['completion', 'tools', 'thinking'] },
  { name: 'mock-embed:latest', family: 'mock-bert', parameter_size: '137M', quantization_level: 'F16', size: 274_000_000, caps: ['embedding'] },
];

// ── conversation analysis ──────────────────────────────────────────
function textOf(content) {
  if (typeof content === 'string') return content;
  if (Array.isArray(content)) return content.map(b => b.text || (typeof b.content === 'string' ? b.content : '')).join('\n');
  return '';
}
function isToolResult(m) {
  if (m.role === 'tool') return true;
  if (m.role === 'user' && Array.isArray(m.content) && m.content.some(b => b.type === 'tool_result')) return true;
  if (m.role === 'user' && /<tool_result/.test(textOf(m.content))) return true;
  return false;
}
function analyze(messages, system) {
  let results = 0, lastUser = '';
  for (let i = messages.length - 1; i >= 0; i--) {
    const m = messages[i];
    if (isToolResult(m)) { results++; continue; }
    if (m.role === 'user') { lastUser = textOf(m.content); break; }
  }
  const sys = (system || '') + messages.filter(m => m.role === 'system').map(m => textOf(m.content)).join('\n');
  return { results, lastUser, textProtocol: /<tool_call>/.test(sys) };
}

function plan(messages, system, hasTools) {
  const a = analyze(messages, system);
  const canTool = hasTools || a.textProtocol;
  const thinking = `The user asked: "${a.lastUser.slice(0, 80)}". ${a.results} tool result(s) so far, so I will ${a.results >= 3 || !canTool ? 'answer' : 'call the next tool'}.`;
  if (!canTool || /no tools/i.test(a.lastUser) || a.results >= 3) {
    return {
      thinking,
      text: [
        `Done. Here is a summary of what the **mock model** did${a.results ? ` across ${a.results} tool calls` : ''}.`,
        '', '| Step | Tool | Purpose |', '|---|---|---|',
        '| 1 | `list_dir` | Look at the workspace |', '| 2 | `write_file` | Create `hello.js` |', '| 3 | `run_command` | Run it with Node |',
        '', 'The file it wrote:', '', '```js', '// hello.js', 'const who = process.argv[2] ?? "world";', 'console.log(`hello, ${who}`);', '```',
        '', '> This answer came from `test/mock-llm.js`. Point the harness at a real model when you are ready.',
      ].join('\n'),
      calls: [],
    };
  }
  const steps = [
    { name: 'list_dir', args: { path: '.', depth: 2 }, say: 'I will start by looking at what is in the workspace.' },
    { name: 'write_file', args: { path: 'hello.js', content: 'const who = process.argv[2] ?? "world";\nconsole.log(`hello, ${who}`);\n' }, say: 'Now I will create a small script.' },
    { name: 'run_command', args: { command: 'node hello.js harness' }, say: 'Let me run it to make sure it works.' },
  ];
  const s = steps[a.results];
  return { thinking, text: s.say, calls: [{ id: id('call_'), name: s.name, args: s.args }], textProtocol: !hasTools && a.textProtocol };
}

function words(s) { return s.match(/\S+\s*|\s+/g) || []; }
function readBody(req) { return new Promise(r => { let d = ''; req.on('data', c => d += c); req.on('end', () => { try { r(JSON.parse(d || '{}')); } catch { r({}); } }); }); }
function json(res, status, obj) { res.writeHead(status, { 'content-type': 'application/json' }); res.end(JSON.stringify(obj)); }
function fakeEmbedding(text, dim = 64) {
  const v = new Array(dim).fill(0);
  for (const w of String(text).toLowerCase().match(/[a-z0-9]+/g) || []) {
    const h = crypto.createHash('md5').update(w).digest();
    for (let i = 0; i < 4; i++) v[h[i] % dim] += (h[i + 4] & 1 ? 1 : -1);
  }
  const n = Math.hypot(...v) || 1;
  return v.map(x => x / n);
}

// ── Ollama ─────────────────────────────────────────────────────────
async function ollamaChat(req, res, body) {
  const p = plan(body.messages || [], '', Array.isArray(body.tools) && body.tools.length > 0);
  const model = body.model || MODELS[0].name;
  const send = o => res.write(JSON.stringify({ model, created_at: new Date().toISOString(), ...o }) + '\n');
  if (body.stream === false) {
    return json(res, 200, { model, message: { role: 'assistant', content: p.text, thinking: body.think ? p.thinking : undefined, tool_calls: p.calls.map(c => ({ function: { name: c.name, arguments: c.args } })) }, done: true });
  }
  res.writeHead(200, { 'content-type': 'application/x-ndjson' });
  const think = body.think !== false;
  if (think) for (const w of words(p.thinking)) { send({ message: { role: 'assistant', content: '', thinking: w }, done: false }); await sleep(DELAY); }
  let text = p.text;
  if (p.textProtocol) text += '\n<tool_call>\n' + JSON.stringify({ name: p.calls[0].name, arguments: p.calls[0].args }) + '\n</tool_call>';
  for (const w of words(text)) { send({ message: { role: 'assistant', content: w }, done: false }); await sleep(DELAY); }
  if (p.calls.length && !p.textProtocol) send({ message: { role: 'assistant', content: '', tool_calls: p.calls.map(c => ({ function: { name: c.name, arguments: c.args } })) }, done: false });
  send({ message: { role: 'assistant', content: '' }, done: true, done_reason: 'stop', total_duration: 900e6, prompt_eval_count: 812, eval_count: 96, eval_duration: 640e6 });
  res.end();
}

// ── OpenAI ─────────────────────────────────────────────────────────
async function openaiChat(req, res, body) {
  if (!/^Bearer \S+/.test(req.headers.authorization || '')) return json(res, 401, { error: { message: 'Missing API key (mock wants any Bearer token)' } });
  const p = plan(body.messages || [], '', Array.isArray(body.tools) && body.tools.length > 0);
  const cid = id('chatcmpl-');
  res.writeHead(200, { 'content-type': 'text/event-stream' });
  const send = delta => res.write(`data: ${JSON.stringify({ id: cid, object: 'chat.completion.chunk', model: body.model, choices: [{ index: 0, delta, finish_reason: null }] })}\n\n`);
  for (const w of words(p.thinking)) { send({ reasoning_content: w }); await sleep(DELAY); }
  let text = p.text;
  if (p.textProtocol) text += '\n<tool_call>\n' + JSON.stringify({ name: p.calls[0].name, arguments: p.calls[0].args }) + '\n</tool_call>';
  for (const w of words(text)) { send({ content: w }); await sleep(DELAY); }
  if (p.calls.length && !p.textProtocol) {
    const c = p.calls[0]; const argStr = JSON.stringify(c.args);
    send({ tool_calls: [{ index: 0, id: c.id, type: 'function', function: { name: c.name, arguments: '' } }] });
    for (let i = 0; i < argStr.length; i += 8) { send({ tool_calls: [{ index: 0, function: { arguments: argStr.slice(i, i + 8) } }] }); await sleep(DELAY); }
  }
  res.write(`data: ${JSON.stringify({ id: cid, choices: [{ index: 0, delta: {}, finish_reason: p.calls.length ? 'tool_calls' : 'stop' }], usage: { prompt_tokens: 812, completion_tokens: 96 } })}\n\n`);
  res.write('data: [DONE]\n\n'); res.end();
}

// ── Anthropic ──────────────────────────────────────────────────────
async function anthropicMessages(req, res, body) {
  if (!req.headers['x-api-key']) return json(res, 401, { type: 'error', error: { type: 'authentication_error', message: 'x-api-key header is required' } });
  if (!body.max_tokens) return json(res, 400, { type: 'error', error: { type: 'invalid_request_error', message: 'max_tokens: Field required' } });
  const sys = Array.isArray(body.system) ? body.system.map(b => b.text).join('\n') : body.system;
  const p = plan(body.messages || [], sys, Array.isArray(body.tools) && body.tools.length > 0);
  res.writeHead(200, { 'content-type': 'text/event-stream' });
  const ev = (type, data) => res.write(`event: ${type}\ndata: ${JSON.stringify({ type, ...data })}\n\n`);
  ev('message_start', { message: { id: id('msg_'), type: 'message', role: 'assistant', model: body.model, content: [], usage: { input_tokens: 812, output_tokens: 1 } } });
  ev('content_block_start', { index: 0, content_block: { type: 'text', text: '' } });
  let text = p.text;
  if (p.textProtocol) text += '\n<tool_call>\n' + JSON.stringify({ name: p.calls[0].name, arguments: p.calls[0].args }) + '\n</tool_call>';
  for (const w of words(text)) { ev('content_block_delta', { index: 0, delta: { type: 'text_delta', text: w } }); await sleep(DELAY); }
  ev('content_block_stop', { index: 0 });
  if (p.calls.length && !p.textProtocol) {
    const c = p.calls[0]; const argStr = JSON.stringify(c.args);
    ev('content_block_start', { index: 1, content_block: { type: 'tool_use', id: id('toolu_'), name: c.name, input: {} } });
    for (let i = 0; i < argStr.length; i += 10) { ev('content_block_delta', { index: 1, delta: { type: 'input_json_delta', partial_json: argStr.slice(i, i + 10) } }); await sleep(DELAY); }
    ev('content_block_stop', { index: 1 });
  }
  ev('message_delta', { delta: { stop_reason: p.calls.length ? 'tool_use' : 'end_turn' }, usage: { output_tokens: 96 } });
  ev('message_stop', {});
  res.end();
}

// ── router ─────────────────────────────────────────────────────────
http.createServer(async (req, res) => {
  const url = new URL(req.url, 'http://x');
  const key = `${req.method} ${url.pathname}`;
  const body = req.method === 'GET' ? {} : await readBody(req);
  try {
    switch (key) {
      case 'GET /api/version': return json(res, 200, { version: '0.0.0-mock' });
      case 'GET /api/tags': return json(res, 200, { models: MODELS.map(m => ({ name: m.name, model: m.name, size: m.size, modified_at: new Date().toISOString(), details: { family: m.family, parameter_size: m.parameter_size, quantization_level: m.quantization_level, format: 'gguf' } })) });
      case 'GET /api/ps': return json(res, 200, { models: [{ name: MODELS[0].name, size: MODELS[0].size, size_vram: MODELS[0].size, expires_at: new Date(Date.now() + 300000).toISOString(), details: { parameter_size: '7B' } }] });
      case 'POST /api/show': {
        const m = MODELS.find(x => x.name === body.model) || MODELS[0];
        return json(res, 200, { modelfile: `FROM ${m.name}\nPARAMETER temperature 0.7\nPARAMETER num_ctx 8192`, parameters: 'temperature 0.7\nnum_ctx 8192\nstop "<|im_end|>"', template: '{{ .System }}\n{{ .Prompt }}', details: { family: m.family, parameter_size: m.parameter_size, quantization_level: m.quantization_level, format: 'gguf' }, model_info: { 'general.architecture': 'mock', 'mock.context_length': 32768 }, capabilities: m.caps });
      }
      case 'POST /api/chat': return ollamaChat(req, res, body);
      case 'POST /api/generate': return json(res, 200, { model: body.model, done: true, done_reason: 'unload' });
      case 'POST /api/embed': { const input = Array.isArray(body.input) ? body.input : [body.input]; return json(res, 200, { model: body.model, embeddings: input.map(t => fakeEmbedding(t)) }); }
      case 'POST /api/pull': {
        res.writeHead(200, { 'content-type': 'application/x-ndjson' });
        res.write(JSON.stringify({ status: 'pulling manifest' }) + '\n');
        for (let i = 0; i <= 10; i++) { res.write(JSON.stringify({ status: 'pulling layer', digest: 'sha256:abc', total: 1000, completed: i * 100 }) + '\n'); await sleep(120); }
        res.write(JSON.stringify({ status: 'success' }) + '\n'); return res.end();
      }
      case 'DELETE /api/delete': return json(res, 200, {});
      case 'GET /v1/models': return json(res, 200, { object: 'list', data: [{ id: 'mock-gpt', object: 'model' }, { id: 'mock-claude', display_name: 'Mock Claude', type: 'model' }] });
      case 'POST /v1/chat/completions': return openaiChat(req, res, body);
      case 'POST /v1/embeddings': { const input = Array.isArray(body.input) ? body.input : [body.input]; return json(res, 200, { data: input.map((t, index) => ({ index, embedding: fakeEmbedding(t) })) }); }
      case 'POST /v1/messages': return anthropicMessages(req, res, body);
      default: return json(res, 404, { error: `mock: no route ${key}` });
    }
  } catch (e) { console.error(e); if (!res.headersSent) json(res, 500, { error: e.message }); }
}).listen(PORT, '127.0.0.1', () => {
  console.log(`\n  Mock LLM listening on http://127.0.0.1:${PORT}`);
  console.log(`  Ollama base URL:  http://127.0.0.1:${PORT}`);
  console.log(`  OpenAI base URL:  http://127.0.0.1:${PORT}/v1   (any API key)`);
  console.log(`  Anthropic base:   http://127.0.0.1:${PORT}/v1   (any API key)\n`);
});
