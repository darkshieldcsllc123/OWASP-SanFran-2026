#!/usr/bin/env node
'use strict';
// Demo mode: starts the mock model server and the harness pointed at it, so you can try
// everything without Ollama or an API key.  Usage: node test/demo.js [workspace-folder]
const { spawn } = require('child_process');
const path = require('path');
const root = path.join(__dirname, '..');
const mock = spawn(process.execPath, [path.join(__dirname, 'mock-llm.js')], { stdio: 'inherit' });
const srv = spawn(process.execPath, [path.join(root, 'server.js'), ...process.argv.slice(2), '--ollama', 'http://127.0.0.1:11435', '--open'], { stdio: 'inherit' });
const stop = () => { mock.kill(); srv.kill(); process.exit(0); };
process.on('SIGINT', stop);
process.on('SIGTERM', stop);
srv.on('exit', stop);
