#!/usr/bin/env bash
# Agent Harness launcher for macOS and Linux.
# Usage: ./start.sh [workspace-folder] [--port 8787] [--no-exec] [--host 0.0.0.0] [--ollama http://host:11434]
set -euo pipefail
cd "$(dirname "$0")"

if ! command -v node >/dev/null 2>&1; then
  echo "Node.js 18 or newer is required. Install it from https://nodejs.org and run this again."
  exit 1
fi
major="$(node -p 'process.versions.node.split(".")[0]')"
if [ "$major" -lt 18 ]; then
  echo "Found Node.js $major. Version 18 or newer is required."
  exit 1
fi
if [ ! -f .env ] && [ -f .env.example ]; then
  echo "Tip: copy .env.example to .env to keep API keys out of the browser."
fi
exec node server.js --open "$@"
