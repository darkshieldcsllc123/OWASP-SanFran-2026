# Contracts

Paste this file with every step. It defines the interfaces that let separately built pieces fit together. If you change something here, change it everywhere.

## Folder layout

```
server.js                 Node server, no dependencies
start.sh, start.bat       launchers
.env.example              optional API keys
public/index.html         app shell (contains <meta name="harness-token" content="__HARNESS_TOKEN__">)
public/css/app.css        all styles
public/js/*.js            ES modules, loaded by <script type="module" src="js/main.js">
test/mock-llm.js          fake model server on port 11435
test/demo.js              runs mock + server together
```

## Server API

Every `/api/*` and `/proxy` request must send header `x-harness-token: <token>`. The server generates the token at startup and replaces `__HARNESS_TOKEN__` in index.html with it. Wrong token gives 401 `{ "error": "...", "code": "TOKEN" }`. Requests whose Host header is not localhost/127.0.0.1/[::1] get 403, unless the server listens on 0.0.0.0.

All errors are JSON: `{ "error": "human readable message" }` with a fitting status (400, 403, 404, 409, 413, 422, 500, 502).

| Route | Body | Returns |
|---|---|---|
| `GET /api/info` | | `{ version, root, rootName, platform, os, arch, node, exec, shell, ollama, envKeys: { OPENAI_API_KEY: bool, ... } }` |
| `POST /api/fs/list` | `{ path='.', depth=1, max=800 }` | `{ root, entries: [{ path, name, type:'file'\|'dir', size, mtime, depth, ignored }], truncated }` |
| `POST /api/fs/read` | `{ path, start?, end? }` (1-based, inclusive) | `{ path, content, startLine, endLine, totalLines, size, mtime }` or `{ path, binary:true, size }` |
| `POST /api/fs/write` | `{ path, content, append? }` | `{ path, bytes, lines, created, appended }` |
| `POST /api/fs/edit` | `{ path, old_str, new_str, replace_all? }` | `{ path, replacements, line }`; 422 if old_str missing or not unique |
| `POST /api/fs/delete` | `{ path }` | `{ path, deleted:true, type }` |
| `POST /api/fs/move` | `{ from, to }` | `{ from, to }` |
| `POST /api/fs/search` | `{ pattern, path='.', glob?, regex?, case_sensitive?, max_results=100 }` | `{ matches: [{ path, line, text }], filesScanned, truncated }` |
| `POST /api/exec` | `{ command, cwd='.', timeout=60 }` | `{ command, cwd, code, signal, stdout, stderr, timedOut, durationMs }` |
| `ANY /proxy` | any body | the upstream response, streamed. Target comes from header `x-target-url`. |

Paths are relative to the workspace root. A leading `/` is treated as workspace-relative. Anything resolving outside the root (including via symlinks) is 403. Listing and search skip `node_modules .git __pycache__ .venv venv .next dist build target coverage .cache` (listed with `ignored:true`, not expanded).

The proxy strips `origin, referer, cookie, host, accept-encoding` and hop-by-hop headers, forwards everything else, and if no auth header is present adds a key from the environment for known hosts (api.openai.com → `authorization: Bearer $OPENAI_API_KEY`, api.anthropic.com → `x-api-key: $ANTHROPIC_API_KEY`, and so on for OpenRouter, Groq, Gemini, DeepSeek, Mistral, xAI, Together).

## Browser module map

| Module | Owns | Key exports |
|---|---|---|
| `util.js` | DOM and generic helpers | `$ $$ h icon iconSVG ibtn uid esc debounce throttleRAF safeJSON deepClone fmtBytes fmtDuration fmtNum relTime truncate estimateTokens downloadFile pickFiles readFileText readFileDataURL copyText fuzzyScore bus toast modal confirmDialog promptDialog closeTopModal hasModal menu toggle` |
| `defaults.js` | static content, no imports | `DEFAULT_SYSTEM_PROMPT PROMPT_PRESETS TEMPLATE_VARS STARTER_SKILLS SKILL_TEMPLATES TOOL_TEMPLATES STARTER_PROMPTS ACCENTS` |
| `store.js` | persistence | `settings saveSettings(what) replaceSettings DEFAULTS idb state loadConvos newConvo switchConvo activeConvo saveConvo deleteConvo renameConvo sortConvos` |
| `api.js` | talking to server.js | `api(path, body, {method, signal}) proxyFetch(url, opts) proxyJSON(url, opts) fsApi getInfo serverOK requestLog logRequest finishLog` |
| `providers.js` | model wire formats | `PRESETS presetById PARAMS PARAM_GROUPS SAMPLING_PROFILES getConf activeProvider resetGen headersFor listModels buildRequest streamChat ThinkSplitter textToolPrompt parseTextToolCalls resultText ollama embed ndjson` |
| `markdown.js` | rendering | `renderMarkdown(src) → html` `highlight(code, lang) → html` `langFromPath(path)` |
| `tools.js` | tool registry | `BUILTINS CATEGORIES getActiveTools schemaOf approvalFor validateArgs executeTool customToTool newCustomTool schemaFromParams builtinState makeCtx` |
| `skills.js` | skills | `skillsFor(text, forced) getSkill parseSkillFile skillToMarkdown newSkill triggerMatch triggerList MODE_LABELS slug` |
| `rag.js` | knowledge base | `kb loadKB addDocument removeDocument clearKB rechunkAll search formatResults chunkText tokenize embedPending needsEmbedding stats importURL importWorkspace htmlToText hasVectors` |
| `agent.js` | the loop | `agent` (with `send run stop regenerate editAndResend resolveApproval running convoId phase`), `buildSystem renderTemplate estimateContext previewRequest pushNotice historyOf` |
| `chat.js` | conversation view | `mountChat renderAll renderChips focusComposer setComposer addFiles attachText exportChat` |
| `ui.js` | panel widgets | `section field select input textarea segmented badge empty btn paramRow listEditor` |
| `panel-*.js` | one settings panel each | default export `{ id, label, icon, mount(el), show?(), focus?(what) }` |
| `main.js` | app shell and boot | nothing; runs `boot()` |

Conventions: `h(tag, attrs, ...children)` builds elements (`onClick` style handlers, `class`, `dataset`, `html` for trusted HTML only). `append`, `prepend` and `replaceChildren` are patched in util.js to skip `null`/`false`, so `cond ? h(...) : null` is safe everywhere. Never insert model or user text with `innerHTML` unless it went through `esc()` or `renderMarkdown()`.

## Data shapes

```js
// settings (localStorage "harness.settings.v1"); call saveSettings(what) after any change
{
  theme: 'system'|'dark'|'light', accent: 'amber'|'teal'|'coral'|'iris'|'lime', fontSize: 14,
  sidebarOpen, panelOpen, panelTab, panelWidth,
  provider: 'ollama',                                   // a PRESETS id
  providers: { [presetId]: { baseUrl, apiKey, model, autoBase?,
               gen: { [paramKey]: { on: bool, v: value } },          // see PARAMS
               extra: { think, keep_alive: {on, v}, format } | { reasoning_effort } } },
  systemPrompt, promptPresets: [{ id, name, text }], activePreset,
  agent: { toolMode: 'native'|'text'|'off', approval: 'all'|'risky'|'none', maxSteps: 20, outputLimit: 12000, showThinking: true, contextLimit: 128000 },
  tools: { builtin: { [name]: { enabled, approval: 'inherit'|'ask'|'auto' } }, custom: [CustomTool] },
  skills: [Skill],
  rag: { chunkSize: 1200, overlap: 150, topK: 4, mode: 'bm25'|'hybrid'|'vector', autoInject: true, asTool: true,
         embed: { enabled: false, source: 'ollama'|presetId, model: 'nomic-embed-text' } },
  recentModels: [{ provider, model }],
}

// conversation (IndexedDB store "convos", keyPath id)
{ id, title, created, updated, pinned, plan: { steps: [{ title, status: 'pending'|'in_progress'|'done' }] } | null, messages: [Message] }

// message — one internal format for every provider
{ id, role: 'user'|'assistant'|'notice', time,
  content,                                   // text shown to the user (tool_call markup removed)
  attachments?: [{ kind: 'text', name, size, text } | { kind: 'image', name, size, mime, dataUrl }],
  forceSkills?: [name], rag?: [RagResult], ragNote?,                 // user only
  thinking?, toolCalls?: [ToolCall], partialCalls?: [{ name, argsText }], streaming?, stopped?, error?,
  meta?: { provider, model, step, skills, usage: { input, output, tps }, ms, ttft, stopReason },   // assistant only
  level?: 'info'|'warn'|'err' }                                       // notice only (never sent to the model)

// tool call (lives inside its assistant message; the result is stored on it)
{ id, name, args: {}, status: 'queued'|'pending'|'running'|'done'|'error'|'denied'|'cancelled', result?: string, startedAt?, endedAt? }

// tool definition (from getActiveTools())
{ name, description, parameters: JSONSchema, category: 'read'|'write'|'exec'|'net'|'meta'|'custom', source: 'builtin'|'custom', run: async (args, { signal, convo }) => string, available?: () => bool }

// custom tool (settings.tools.custom)
{ id, name, description, type: 'js'|'http', params: [{ name, type, description, required }], schemaMode: 'builder'|'raw', schemaRaw,
  code, url, method, headers, enabled, approval: 'inherit'|'ask'|'auto', sample }

// skill
{ id, name, description, triggers: 'comma, separated', mode: 'always'|'auto'|'manual', enabled, content }

// knowledge document (IndexedDB store "docs")
{ id, name, source: 'paste'|'file'|'url'|'workspace', text, size, added, embedModel, chunks: [{ id, i, text, line, emb? }] }
// search result
{ id, docId, docName, line, text, score, parts: { bm25?, vector? } }
```

## How internal messages become provider requests

An assistant message with toolCalls expands to the provider's pair of turns. Every tool call always gets a result (`resultText(call)` supplies one for denied or cancelled calls), so histories are always valid.

| | Ollama `/api/chat` | OpenAI `/chat/completions` | Anthropic `/messages` |
|---|---|---|---|
| system | first message, role system | first message, role system | top-level `system` |
| assistant tool calls | `tool_calls: [{ function: { name, arguments: {obj} } }]` | `tool_calls: [{ id, type:'function', function: { name, arguments: 'json string' } }]` | content blocks `{ type:'tool_use', id, name, input }` |
| tool results | `{ role:'tool', content, tool_name }` | `{ role:'tool', tool_call_id, content }` | user turn with `{ type:'tool_result', tool_use_id, content }` first |
| images | `images: [base64]` | content parts `image_url` | `{ type:'image', source:{ type:'base64' } }` |
| stream | NDJSON lines | SSE `data:` chunks, `[DONE]` | SSE events `message_start … message_stop` |
| params | `options: {…}` + `think`, `keep_alive`, `format` | top level; `max_completion_tokens` on OpenAI, `max_tokens` elsewhere | `max_tokens` required; never temperature and top_p together |

Text protocol mode (toolMode 'text') sends no `tools` field. Tools are described in the system prompt, the model writes `<tool_call>{"name": "...", "arguments": {...}}</tool_call>`, and results go back as a user message of `<tool_result name="...">…</tool_result>` blocks.

## Bus events

`bus.emit(name, data)` / `bus.on(name, fn)`:

| Event | Data | Emitted when |
|---|---|---|
| `settings` | what changed: 'agent', 'provider', 'tools', 'skills', 'rag', 'system', 'theme', 'layout', 'model', 'all' | any saveSettings |
| `convos` | | list or titles changed |
| `convo:switch` | convo | active chat changed |
| `convo:render` | convo | whole chat must re-render |
| `convo:msg` | `{ convo, msg, added }` | one message changed or was added |
| `agent:start` / `agent:end` | convo | loop started / finished |
| `agent:phase` | `{ phase: 'idle'|'knowledge'|'model'|'approval'|'tool', step?, tool?, category? }` | the signal chain updates |
| `agent:approval` | `{ convo, msg, call }` | a call waits for the user |
| `plan` | convo | update_plan changed the plan |
| `workspace:changed` | `{ tool, args }` | a write or exec tool succeeded |
| `kb` | | knowledge base changed |
| `log` | entry | request log entry added or updated |
| `models:loaded` | presetId | model list fetched |
| `model:changed`, `provider:changed` | | header and panels resync |
| `panel:open` | `{ tab, focus? }` | open a panel tab |
| `conn`, `conn:check` | | connection status |
| `server:token`, `server:down` | | show the reconnect banner |
| `chain`, `help` | | re-render the chain / show shortcuts |
