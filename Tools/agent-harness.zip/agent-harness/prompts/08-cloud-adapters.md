# Step 08: OpenAI-compatible and Anthropic adapters

**Goal:** One `streamChat` for every provider, plus think-tag splitting and the text tool protocol helpers.
**Depends on:** 07.
**Paste these files:** `CONTRACTS.md`, `public/js/providers.js`.

## Prompt

````text
Extend public/js/providers.js. Keep every existing export working.

1. toOpenAI(messages, system, native, preset): system message first; user text, or content parts [{type:'text'}, {type:'image_url', image_url:{url:dataUrl}}] when there are images; assistant {role:'assistant', content: text or null when only tool calls, tool_calls:[{id, type:'function', function:{name, arguments: JSON string}}]} followed by {role:'tool', tool_call_id, content} per call. If preset.shortIds, map every id through a deterministic 9-character [a-z0-9] hash. Text mode works like the Ollama one.

2. toAnthropic(messages, native): no system message in the list. Push turns with a helper that merges consecutive same-role turns into one content array. User: image blocks {type:'image', source:{type:'base64', media_type, data}} then {type:'text'}. Assistant: a text block if non-empty, plus {type:'tool_use', id, name, input} per call; then a user turn whose first blocks are {type:'tool_result', tool_use_id, content, is_error when status is error}. If the first turn is not a user turn, insert a user turn "(conversation start)".

3. Parameter mapping genFor(preset, conf): openai type sends temperature, top_p, presence_penalty, frequency_penalty, seed (integer), max tokens under preset.maxKey or max_tokens (only when > 0), stop (up to 4), reasoning_effort when not 'default'. Anthropic always sends max_tokens (8192 when off), temperature capped at 1, top_p only when temperature is off, top_k, stop_sequences.

4. buildRequest for openai type: POST {base}/chat/completions; stream_options {include_usage:true} only when preset.usage; tools as functions. For anthropic: POST {base}/messages with top-level system and tools [{name, description, input_schema}]. headersFor: Bearer key for openai type ("Bearer local" for local presets with no key, x-title and http-referer for OpenRouter); x-api-key and anthropic-version: 2023-06-01 for Anthropic.

5. sse(res): parse server-sent events from rawLines (event: and data: fields, blank line dispatches, ignore comments starting with ':').

6. In streamChat add:
- OpenAI: stop at data [DONE]; throw on j.error; usage from j.usage; reasoning from delta.reasoning_content or delta.reasoning; content; tool_calls accumulated by index (when index is missing, a new id starts a new slot), set id when present, set the name when empty and append only when the chunk's name is a continuation, append argument fragments. Expose partialCalls [{name, argsText}] during streaming so the UI can show "writing arguments". Parse arguments at the end.
- Anthropic: message_start input tokens; content_block_start records blocks by index; content_block_delta handles text_delta, thinking_delta and input_json_delta; message_delta gives stop_reason and output tokens; event type error throws. Tool calls come from tool_use blocks.
- For every provider, pass content through a ThinkSplitter class that moves <think>…</think> text into thinking, even when a tag is split across chunks (keep a partial-tag suffix in a buffer). Flush it at the end.
- If tps is missing, compute it from output tokens and the time since the first token.

7. Text tool protocol helpers: textToolPrompt(tools) explaining the <tool_call>{"name": ..., "arguments": {...}}</tool_call> format, the rules (one JSON object, double quotes, several blocks allowed, stop after calls, results come back in <tool_result name="..."> tags, answer normally when done) and each tool's name, description and JSON Schema. parseTextToolCalls(text, knownNames): extract every <tool_call> block (also an unclosed one at the very end), tolerate code fences and trailing commas, accept arguments under "arguments", "parameters", "args" or "input" (parse strings), and as a fallback accept fenced ```json blocks only when they have an "arguments" key and name a known tool. Return {clean (text without the blocks), calls}.

8. embed(texts): settings.rag.embed.source 'ollama' → POST /api/embed {model, input, truncate:true} → embeddings; an openai-type preset id → POST {base}/embeddings → data sorted by index → embedding.
````

## Check it works

Using the mock, in the console:

- `settings.provider = 'custom'; getConf('custom').baseUrl = 'http://127.0.0.1:11435/v1'; getConf('custom').model = 'mock-gpt'`: the streamed reply ends with one tool call whose `args` is the parsed object.
- The same with `anthropic` and `mock-claude`: no 400 about max_tokens.
- `new ThinkSplitter()` fed `'<thi'`, `'nk>hmm</th'`, `'ink>answer'` gives thinking "hmm" and content "answer".
- `parseTextToolCalls('ok\n<tool_call>{"name":"list_dir","arguments":{"path":"."}}</tool_call>')` returns one call and clean text "ok".
