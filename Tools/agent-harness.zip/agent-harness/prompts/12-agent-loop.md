# Step 12: Agent loop, approvals and the text tool protocol

**Goal:** The heart of the harness. After this step you have a working coding agent.
**Depends on:** 10, 11.
**Paste these files:** `CONTRACTS.md`, `public/js/providers.js` (exports only), `public/js/tools.js` (exports only), `public/js/chat.js`.

## Prompt

````text
Write public/js/agent.js and update chat.js to use it.

agent.js
- renderTemplate(text): replace {{date}} {{time}} {{workspace}} {{os}} {{shell}} {{model}} {{tools}}; leave unknown variables alone.
- buildSystem(convo) returns {text, parts:[{id, label, text}], skills, tools}. Parts in order: the rendered system prompt; "# Active skills" with every injected skill (from skillsFor(lastUser.content, lastUser.forceSkills)); "# Skills you can load" index when there are loadable skills and load_skill is active; textToolPrompt(tools) when toolMode is 'text'; "# Retrieved context" with formatResults(lastUser.rag) when the last user message has retrieval results. (Stub skillsFor and rag until steps 15 and 16.)
- historyOf(convo): user and assistant messages only.
- estimateContext(convo): token estimate per part, tool definitions in native mode, and conversation; limit is num_ctx for Ollama (4096 when off) or settings.agent.contextLimit.
- previewRequest(convo) builds the request without sending it.
- pushNotice(convo, text, level).

class Agent (export const agent):
- State: running, controller (AbortController), convoId, approvals (Map callId → {resolve, reject}), sessionAllow (Set of tool names), phase.
- setPhase(phase, detail) emits 'agent:phase'. stop() aborts. resolveApproval(callId, {action:'approve'|'always'|'deny', args?, reason?}). waitApproval(callId, signal) rejects on abort.
- send(convo, {text, attachments, forceSkills}): push the user message, set the chat title from the first line if it is still "New chat", save, emit, run.
- regenerate(convo): remove everything after the last user message (clear its rag), run. editAndResend(convo, id, text): replace the text, truncate after it, run.
- run(convo): guard against double runs; emit agent:start; if auto-inject is on and the knowledge base has chunks and the last user message has no rag yet, phase 'knowledge' and search (store results and any note on the message). Then loop step 1..maxSteps; after the last allowed step push a warning notice telling the user to press Continue or raise the limit. Errors become error notices (except AbortError). In finally: clear streaming flags, mark any queued/pending/running call as cancelled with a result, clear approvals, phase idle, save immediately, emit agent:end and convo:render.
- step(convo, n, signal): buildSystem; push a streaming assistant message {meta:{provider, model, step, skills}}; phase 'model'; streamChat with a throttled (requestAnimationFrame) onDelta copying content, thinking and partialCalls. On AbortError keep the partial text and mark stopped. If toolMode is native and the error matches /does not support tools|tool use is not supported|tools? (are|is) not supported|function calling is not/, remove the empty message, switch settings.agent.toolMode to 'text', save, push an info notice naming the model, and return true to retry the step. Otherwise store the error on the message.
  After streaming: copy content, thinking and meta (usage, ms, ttft, stopReason). If there are no native calls (or mode is text) and the content contains <tool_call> or a code fence, run parseTextToolCalls with the active tool names. Set toolCalls with status 'queued'. If none, return false. Otherwise run each call in order with runCall, saving after each, and return true unless aborted.
- runCall: unknown tool → error result listing available tools; validateArgs error → error result asking it to fix the arguments; if approvalFor(tool) and not in sessionAllow → status 'pending', phase 'approval', emit agent:approval, wait. Edited args replace the originals. Deny → status 'denied' with a result that includes the user's reason and says not to repeat the same call. 'always' adds to sessionAllow. Then status 'running', phase 'tool' (with tool name and category), executeTool, status 'done' or 'error' ("Error: …"); emit 'workspace:changed' after successful write and exec tools.

chat.js changes
- send() calls agent.send(convo, {...}). Stop calls agent.stop(). Regenerate, Continue (agent.run) and Save and resend use the agent.
- Tool call cards inside the assistant message: header button (category icon, monospace name, one-line argument summary such as the path, command, query or URL, a status pill, duration, chevron). Pending cards are always open with an accent border; others toggle. Body: edit_file shows a diff (old lines prefixed "- ", new "+ ", highlighted as diff); write_file shows the content highlighted by file extension; run_command shows "$ command" in a terminal style; others show pretty JSON. Pending cards get an approval bar: "Allow write_file?", Run (Y), Always allow (A), Edit arguments (a modal with a JSON textarea that validates), Deny (asks for an optional reason). Results show in a pre with a Copy link; errors in red.
- While streaming, partialCalls show as dashed cards "writing arguments (N chars)".
- Keyboard: when the agent is waiting and focus is not in a text field, Y approves, A always allows, N denies.
- If the tab is hidden while an approval waits, set document.title to "Approval needed: <tool>".
- renderChips(): composer chips for tool mode (menu: Native tool calling, Text protocol (any model), No tools, Manage tools), approval policy (menu of the three), Knowledge on/off when documents exist, and for Ollama a Thinking chip (model default, on, off, low, medium, high).
- Plan box (#plan) above the composer when convo.plan has steps: "Plan", "2 of 5 done", a progress bar, collapsible list with done/in-progress/pending marks, and a clear button.
- Slash commands with a popup (arrow keys, Tab or Enter to pick, Escape to close): /new, /clear (confirm), /skill <name> (completes skill names; adds a chip; the skill is forced for the next message), /model <name> (completes cached models), /rag <query>, /system, /export (Markdown download), /help.
````

## Check it works

With the mock and the default "ask before changes" policy:

- "Create a hello script and run it": list_dir runs on its own, write_file waits with a highlighted preview, Y runs it, then run_command waits; Always allow runs it, and the final answer shows a table. `workspace/hello.js` exists.
- Deny a call with a reason: the card says Denied and the next model turn sees the reason (check the Inspector later, or `requestLog[0].body`).
- Press Esc while a call waits: it becomes Cancelled and the composer is idle again.
- Switch the tool chip to Text protocol and repeat: the same three tools run.
