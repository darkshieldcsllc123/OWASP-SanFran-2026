# Step 04: Mock model server

**Goal:** A fake model that speaks all three wire formats with streaming and scripted tool calls, so every later step can be tested without a GPU or API key.
**Depends on:** 00.
**Paste these files:** `CONTRACTS.md`.

## Prompt

````text
Write test/mock-llm.js: a zero-dependency Node HTTP server on 127.0.0.1:11435 (flags --port, --delay ms between streamed tokens, default 12).

Scripted behaviour per user turn: count tool results since the last real user message (a message with role "tool"; a user message containing tool_result blocks; or a user message containing "<tool_result"). A real user message is a user message that is none of those.
- 0 results: say "I will start by looking at what is in the workspace." and call list_dir {"path":".","depth":2}
- 1 result: say "Now I will create a small script." and call write_file {"path":"hello.js","content":"const who = process.argv[2] ?? \"world\";\nconsole.log(`hello, ${who}`);\n"}
- 2 results: say "Let me run it to make sure it works." and call run_command {"command":"node hello.js harness"}
- 3 or more, or the user said "no tools", or the request has no tools and no text protocol: answer with markdown containing a short sentence, a 3-row table of the steps, a fenced js code block, and a blockquote.
Before the text, emit "thinking" describing the decision (Ollama message.thinking, OpenAI delta.reasoning_content). If the request has no tools field but the system prompt contains "<tool_call>", append the call to the text as <tool_call>{"name":...,"arguments":{...}}</tool_call> instead (text protocol).

Endpoints:
- Ollama: GET /api/version, GET /api/tags (two models: mock-coder:7b with details family/parameter_size/quantization_level and a size, and mock-embed:latest), GET /api/ps, POST /api/show (modelfile, parameters, template, details, model_info with "mock.context_length": 32768, capabilities ["completion","tools","thinking"] or ["embedding"]), POST /api/chat (NDJSON stream: thinking chunks, content chunks word by word, then one chunk with message.tool_calls [{function:{name, arguments: object}}], then a done chunk with done_reason, prompt_eval_count, eval_count, eval_duration in ns), POST /api/generate (returns done), POST /api/embed (deterministic 64-dim vectors from hashing words, normalised), POST /api/pull (NDJSON progress with total/completed, then "success"), DELETE /api/delete.
- OpenAI: GET /v1/models, POST /v1/chat/completions (401 unless "authorization: Bearer ..."; SSE chunks with delta.reasoning_content, delta.content, then tool_calls streamed as one chunk with id/name and several chunks of argument fragments, a final chunk with finish_reason and usage, then data: [DONE]), POST /v1/embeddings.
- Anthropic: POST /v1/messages (401 without x-api-key, 400 without max_tokens; SSE events message_start, content_block_start/delta(text_delta)/stop for text, then a tool_use block with input_json_delta fragments, message_delta with stop_reason tool_use or end_turn, message_stop).
Print the three base URLs on start.

Also write test/demo.js that spawns mock-llm.js and server.js (passing through argv, plus --ollama http://127.0.0.1:11435 --open) and kills both on Ctrl+C.
````

## Check it works

- `curl -N localhost:11435/api/chat -d '{"messages":[{"role":"user","content":"hi"}],"tools":[{}]}'` streams lines and ends with a tool call to `list_dir`.
- `curl -N localhost:11435/v1/chat/completions -H "authorization: Bearer x" -d '{"messages":[{"role":"user","content":"hi"}],"tools":[{}]}'` streams SSE ending in `[DONE]`.
- Through the harness proxy, the same Ollama call works with `x-target-url: http://127.0.0.1:11435/api/chat`.
