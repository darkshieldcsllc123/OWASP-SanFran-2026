# Step 03: start.sh, start.bat and .env

**Goal:** Double-click (or one command) to start the harness on any OS.
**Depends on:** 01, 02.
**Paste these files:** `CONTRACTS.md`, the top 60 lines of `server.js` (config section).

## Prompt

````text
Write three small files for Agent Harness.

1. start.sh (bash, macOS/Linux). set -euo pipefail; cd to the script's folder; check that node exists and that its major version is at least 18, with clear messages that link https://nodejs.org; if .env is missing but .env.example exists, print a one-line tip; then exec node server.js --open "$@" so the user can pass a workspace folder and flags.

2. start.bat (Windows, must use CRLF line endings). @echo off, setlocal, title, cd /d "%~dp0"; check node with `where node`; parse the major version with for /f "tokens=1 delims=." over `node -p "process.versions.node"` (remember %%v inside batch files); the same .env tip; then node server.js --open %*; pause only if it exits with an error so the window does not vanish with the error message.

3. .env.example listing every supported key commented out (OPENAI_API_KEY, ANTHROPIC_API_KEY, OPENROUTER_API_KEY, GEMINI_API_KEY, GROQ_API_KEY, DEEPSEEK_API_KEY, MISTRAL_API_KEY, XAI_API_KEY, TOGETHER_API_KEY) and the optional PORT, HOST, HARNESS_WORKSPACE, HARNESS_NO_EXEC, OLLAMA_HOST, with a two-line explanation that keys here stay on the server.

Also add a package.json with no dependencies, "engines": {"node": ">=18"} and scripts start ("node server.js --open"), mock ("node test/mock-llm.js") and demo ("node test/demo.js").
````

## Check it works

- `./start.sh ~/tmp/ws` starts the server on that folder and opens the browser.
- On Windows, double-clicking `start.bat` does the same. With Node missing, the window stays open with the message.
- `file start.bat` reports CRLF line terminators.
