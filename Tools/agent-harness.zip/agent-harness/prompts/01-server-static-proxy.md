# Step 01: Node server, static files and the CORS proxy

**Goal:** `server.js` serves `public/` and relays any HTTP request to a model API, streaming the response back unchanged.
**Depends on:** 00.
**Paste these files:** `CONTRACTS.md`.

## Prompt

````text
Write server.js for Agent Harness (Node 18+, CommonJS, standard library only: http, https, fs, path, crypto, os, child_process).

Configuration:
- CLI parsing without libraries: first positional argument is the workspace folder; flags --port (default 8787 or env PORT), --host (default 127.0.0.1), --ollama (default env OLLAMA_HOST or http://127.0.0.1:11434; normalise "0.0.0.0" to 127.0.0.1 and add :11434 and http:// when missing), --open, --quiet, --no-exec. Accept --key value and --key=value.
- Load a .env file next to server.js with a tiny parser (KEY=value, optional quotes, # comments, optional "export "). Never overwrite variables that are already set.
- Generate TOKEN = crypto.randomBytes(18).toString('hex') at startup.

Static files:
- Serve ./public with correct MIME types and cache-control: no-cache. Prevent path traversal.
- For index.html, read it (cache by mtime) and replace the literal __HARNESS_TOKEN__ with TOKEN before sending.

Security middleware for every request:
- If the Host header (without port) is not localhost, 127.0.0.1, [::1] or the configured host, answer 403, unless HOST is 0.0.0.0 or ::.
- /proxy and /api/* require header x-harness-token equal to TOKEN (crypto.timingSafeEqual). Otherwise 401 JSON {"error":"Session token missing or expired. Reload the page.","code":"TOKEN"}.

The proxy (route /proxy, any method):
- Target URL comes from header x-target-url; only http and https allowed.
- Copy request headers except host, connection, keep-alive, proxy-connection, transfer-encoding, upgrade, origin, referer, cookie, accept-encoding, te, trailer, x-target-url, x-harness-token and any sec-* header. Set host to the target host and accept-encoding to identity.
- Env key injection table: api.openai.com OPENAI_API_KEY (authorization Bearer), api.anthropic.com ANTHROPIC_API_KEY (x-api-key), openrouter.ai OPENROUTER_API_KEY, api.groq.com GROQ_API_KEY, generativelanguage.googleapis.com GEMINI_API_KEY, api.deepseek.com DEEPSEEK_API_KEY, api.mistral.ai MISTRAL_API_KEY, api.x.ai XAI_API_KEY, api.together.xyz TOGETHER_API_KEY (all Bearer except Anthropic). Add the key only if that header is not already present.
- Pipe the request body upstream and pipe the upstream response back with the same status. Drop hop-by-hop, set-cookie, content-security-policy and access-control-* response headers. Add cache-control: no-cache and x-accel-buffering: no so streams are not buffered.
- If the browser disconnects, destroy the upstream request. Set no timeouts on the upstream socket.
- On connection errors reply 502 JSON with a helpful message, e.g. "Could not reach http://127.0.0.1:11434 (ECONNREFUSED). Is Ollama running? Start it with "ollama serve"." (mention Ollama when the port is 11434).
- Log one line per proxied request unless --quiet: method, host+path, status, duration.

Server behaviour:
- server.requestTimeout = 0 and headersTimeout = 0, so long generations are not cut off.
- If the port is busy and --port was not given, try the next port, up to 10 times.
- On start print a short banner: App URL, workspace path, shell enabled or disabled, Ollama URL plus whether GET /api/version answers within 1.5 s, and which env keys were found. With --open, open the browser (cmd /c start, open, or xdg-open).
- Leave a clearly marked place for the /api routes from the next step: an API object mapping "METHOD /path" to async handler(body, res) whose return value is sent as JSON, with errors carrying .status.
````

## Check it works

- `node server.js` prints the banner. Opening the URL serves `public/index.html` (a placeholder is fine).
- View source: the token meta tag holds a hex string, not `__HARNESS_TOKEN__`.
- Without the token: `curl -i localhost:8787/proxy` gives 401.
- With the token (copy it from the page source):
  `curl -N -H "x-harness-token: TOKEN" -H "x-target-url: http://127.0.0.1:11434/api/tags" localhost:8787/proxy` returns your Ollama models.
- Stop Ollama and repeat: you get a 502 with the "Is Ollama running?" hint.
- `curl -H "Host: evil.com" localhost:8787/` gives 403.

## Common problems

- Streams arrive all at once: the assistant buffered the body. It must `upRes.pipe(res)`.
- Gzip garbage in the browser: accept-encoding was not forced to identity.
