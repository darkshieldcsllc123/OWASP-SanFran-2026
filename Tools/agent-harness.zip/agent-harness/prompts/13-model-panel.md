# Step 13: Panel host and the Model panel

**Goal:** The right-hand settings panel, starting with connection, the Ollama model manager, the system prompt and every generation parameter.
**Depends on:** 12.
**Paste these files:** `CONTRACTS.md`, `public/js/providers.js` (exports and PARAMS), `public/js/main.js`.

## Prompt

````text
1. public/js/ui.js: section(title, body, {id, open, actions, count, sub}) collapsible with a rotating chevron, remembering open state per id in sessionStorage; field(label, control, help); select(options, value, onChange); input(value, onChange, attrs, wait) debounced; textarea; segmented(options, value, onChange, {size}); badge(text, kind); empty(icon, title, text, action); btn(label, onClick, {kind, iconName, title, size, disabled}); paramRow({label, help, min, max, step, value, on, log, int, noSlider, options, disabledNote, onValue, onToggle}) with an enable checkbox, an info icon that shows help as a tooltip (data-tip), a number input and a slider kept in sync (log scale when log is set; the slider track fills to the value via --fill); listEditor(values, onChange).

2. Panel host in main.js: tabs Model, Tools, Skills, Knowledge, Files, Inspector (icons cpu, tool, book, database, folder, activity). Each panel module default-exports {id, label, icon, mount(el), show?(), focus?(what)}. Mount lazily on first open, call show() on later opens. Remember settings.panelTab. A drag handle on the left edge resizes between 320 and 760 px (pointer events, saves settings.panelWidth, double-click resets). Listen to bus 'panel:open' {tab, focus}. Stub panels for the tabs that come later.

3. public/js/panel-model.js:
- Connection section: provider select grouped Local/Cloud; base URL (Ollama hint: the proxy means no CORS setup); API key as a password field with a show button, and when the server reports the preset's env key, the placeholder says "Using OPENAI_API_KEY from .env"; model input with a datalist and a Fetch button; recent models as chips; a Test connection button that times the call and reports how many models exist and whether the chosen one is among them. Export fetchModels(id, {quiet}), setProvider(id), setModel(name) (maintains settings.recentModels, emits model:changed).
- Local models section (Ollama only): list from tags with a green lamp for models loaded in memory (from /api/ps), parameter size, quantisation and disk size; clicking a row selects it; an info button opens a details modal (capability badges, a hint when "tools" is missing, a facts table, trained context length with a "Use full context" button that sets num_ctx, and collapsible default parameters, template and modelfile); a menu to load, unload, copy the name or delete (confirm). A filter box when there are more than six models. A pull input with progress bar, status text and Cancel. When Ollama is down, show the "ollama serve" command.
- System prompt section: a preset select (built-ins plus saved ones, and "Custom (unsaved)" when the text differs), Save as (name prompt), a menu with Preview (renderTemplate output in a modal), Reset to default and Delete preset; a monospace textarea that saves after 250 ms; an "Insert variable" menu from TEMPLATE_VARS that inserts at the cursor; a counter with characters and estimated tokens.
- Generation parameters section: quick profile buttons (Precise, Balanced, Creative) that turn on and set the params that apply; groups by PARAM_GROUPS with "N of M apply to <provider>"; each param is a paramRow, disabled with "Not used by Anthropic" when it does not apply; stop sequences use listEditor; a reset button in the section header. Explain that unchecked params use the model's own default.
- Provider options: for Ollama, thinking as a segmented control (Default, On, Off, Low, Med, High) with help, keep-alive with a toggle, and output format Free text / JSON only. For OpenAI-type, reasoning effort and the context limit used by the meter. For Anthropic, a note about max_tokens and temperature/top_p plus the context limit.
- Re-render only on model:changed, provider:changed and models:loaded (not while an input inside the panel has focus).
````

## Check it works

- Turn on Top K and set it to 20, then send a message: `requestLog[0].body.options.top_k` is 20.
- Switch to Anthropic: Min P and Repeat penalty show "Not used by Anthropic".
- Pull `mock-embed:latest` against the mock: the progress bar fills.
- Choose the Code reviewer preset, edit one word: the select changes to "Custom (unsaved)".
