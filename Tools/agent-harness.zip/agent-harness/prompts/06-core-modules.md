# Step 06: Core browser modules (util, defaults, store, api)

**Goal:** The foundation every other module imports.
**Depends on:** 02, 05.
**Paste these files:** `CONTRACTS.md`, `public/index.html`.

## Prompt

````text
Write four ES modules for public/js/, matching the exports listed in CONTRACTS.md.

util.js
- At the top, patch Element.prototype and DocumentFragment.prototype append, prepend and replaceChildren to filter out null, undefined and false (comment why: conditional children never render "null").
- h(tag, attrs, ...children): attrs handle class, style objects, html (innerHTML), on* functions as listeners, dataset, value, checked/disabled/selected/open as properties, true as an empty attribute; children may be nested arrays, strings or nodes; skip null/false.
- uid(prefix), esc(), sleep, clamp, estimateTokens (length / 3.8), debounce, throttleRAF, safeJSON(str, fallback), deepClone (structuredClone), fmtBytes, fmtDuration, fmtNum (1.2k), relTime ("just now", "5 min ago", "3 h ago", or a short date), truncate.
- downloadFile, pickFiles (hidden input), readFileText, readFileDataURL, copyText (clipboard with a textarea fallback, then a toast), fuzzyScore(query, text) (substring first, then subsequence with streak bonus; -1 for no match).
- bus with on/off/emit (listener errors are caught and logged).
- An icon set: iconSVG(name, size) returning a 24x24 stroke SVG (stroke-width 1.8, round caps) and icon(name) wrapping it in span.ico. Include: plus x check trash edit copy play stop send sliders sun moon monitor search file folder chevronRight chevronDown refresh download upload tool book cpu terminal link eye layers database message alert info zap menu sidebar panel command clip rotate bulb globe list activity dots shield box scroll branch pin keyboard wand.
- ibtn(name, title, onClick, cls), toast(message, {type ok|err|warn|info, timeout, action}), modal({title, body, actions:[{label, primary, danger, ghost, icon, onClick (return false to keep open)}], wide, full, className, onClose}) returning {close, box} with a stack so Escape closes the top one (export closeTopModal, hasModal), confirmDialog, promptDialog, menu(anchor, items, {align}) popover with separators 'sep', and toggle(checked, onChange, label).

defaults.js (no imports): DEFAULT_SYSTEM_PROMPT for a careful coding agent (inspect before editing, small edit_file changes, verify by running, keep a plan with update_plan for multi-step work, read errors instead of repeating calls, ask when unclear or destructive, finish with a short summary; uses {{workspace}}, {{os}}, {{date}}), PROMPT_PRESETS (Coding agent, Code reviewer, Patient tutor, Minimal; builtin:true), TEMPLATE_VARS, STARTER_SKILLS (test-first-fixes auto, git-hygiene manual, project-scaffold auto, small-model-mode always but disabled), SKILL_TEMPLATES, TOOL_TEMPLATES (current_time, calculator, git_status, file_stats, weather via Open-Meteo HTTP GET, run_tests), STARTER_PROMPTS (four), ACCENTS {amber, teal, coral, iris, lime} each {dark, light, name}.

store.js: DEFAULTS exactly as the settings shape in CONTRACTS.md; settings = deep merge of DEFAULTS with localStorage (arrays replace, objects merge); saveSettings(what) debounced to localStorage, emitting bus 'settings' with what; replaceSettings. IndexedDB "agent-harness" v1 with object stores convos and docs (keyPath id) and a tiny promise wrapper idb {all, get, put, del, clear}. Conversation state {convos, activeId, info}; loadConvos (mark leftover streaming messages as interrupted), sortConvos (pinned first, then updated desc), newConvo, switchConvo (remember id in localStorage "harness.active"), activeConvo, saveConvo(c, {immediate, touch}) debounced 500 ms per chat (store a JSON copy), deleteConvo, renameConvo.

api.js: read the token from the meta tag (serverOK is false when it still says __HARNESS_TOKEN__); api(path, body, {method, signal}) adds the token and JSON headers, throws Error with the server's message and .status, emits 'server:token' on code TOKEN and 'server:down' on network failure; proxyFetch(url, {method, headers, body, signal}) sends to /proxy with x-target-url and returns the raw Response; proxyJSON throws on !ok; fsApi wrappers for every route; getInfo; requestLog (newest first, max 60) with logRequest (redact authorization/x-api-key to their first 10 characters) and finishLog, both emitting 'log'.

Also write a temporary public/js/main.js that imports these, calls getInfo(), loadConvos() and shows toast(`Workspace: ${info.root}`).
````

## Check it works

- Reload the page: a toast shows your workspace path.
- In the console: `(await import('/js/api.js')).fsApi.list('.', 2)` returns entries.
- `localStorage['harness.settings.v1']` appears after `(await import('/js/store.js')).saveSettings()`.
