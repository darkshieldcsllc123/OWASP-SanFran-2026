# Build the Agent Harness, step by step

This folder is a prompt pack. Each numbered file is one step: a prompt you hand to an AI coding assistant (Claude, ChatGPT, a local model in Ollama, or this harness itself once it runs) plus the checks that tell you the step worked. Follow the steps in order and you end up with the same app that ships in this repository.

## How to use a step

1. Open the step file and read **Goal** and **Depends on**.
2. Start a fresh chat with your assistant. Paste, in this order:
   - `CONTRACTS.md` (every time; it keeps the pieces compatible),
   - the files listed under **Paste these files** (your versions from earlier steps),
   - the text inside the **Prompt** block.
3. Save the files it produces, then run every item under **Check it works**.
4. If a check fails, paste the error and the failing file back with: "This check failed: … Fix it without changing the contracts."
5. Commit to git before starting the next step, so you can roll back.

## Ground rules that every prompt repeats

- **No dependencies.** Node 18+ standard library on the server; plain ES modules in the browser. No bundler, no framework, no CDN.
- **Contracts are fixed.** Function names, data shapes and event names in `CONTRACTS.md` do not change unless you decide to change them everywhere.
- **Small files, clear owners.** Each module owns one job (see the module map in `CONTRACTS.md`).
- **Write UI copy for users.** Sentence case, plain verbs, errors that say what happened and how to fix it.

## The steps

| Step | Builds | You can test it with |
|---|---|---|
| 00 | Project brief and folder layout | reading it |
| 01 | Node server: static files and the CORS proxy | curl through the proxy to Ollama |
| 02 | Workspace API: files, search, shell, session token | curl |
| 03 | start.sh, start.bat and .env loading | double-click |
| 04 | Mock model server (Ollama, OpenAI, Anthropic formats) | curl, then every later step |
| 05 | HTML shell, design tokens and the layout grid | a static page |
| 06 | Core browser modules: util, store, api | the browser console |
| 07 | Ollama adapter and NDJSON streaming | a bare streaming chat |
| 08 | OpenAI and Anthropic adapters, think-tag splitting | the mock's /v1 endpoints |
| 09 | Markdown renderer and syntax highlighter | a test page |
| 10 | Chat view and composer | chatting with the mock |
| 11 | Tool registry and built-in tools | console calls |
| 12 | Agent loop, approvals and the text tool protocol | the mock's scripted task |
| 13 | Panel host and the Model panel | changing parameters, then the Inspector |
| 14 | Tools panel and the custom tool builder | the calculator template |
| 15 | Skills | the trigger tester |
| 16 | Knowledge base (RAG) | the search tester |
| 17 | Files panel and Inspector | editing a file, previewing a request |
| 18 | App shell polish: sidebar, signal chain, palette, shortcuts, themes, mobile | using it |
| 19 | Testing and hardening | a Playwright smoke test |

From step 12 on you have a working agent. Point it at its own source folder (`./start.sh .`) and use it to build the remaining steps. That is the best test there is.

## Tips

- Run `node test/mock-llm.js` (step 04) in a second terminal and set the Ollama base URL to `http://127.0.0.1:11435`. You get deterministic tool calls without a GPU.
- When an assistant's answer is long, ask for one file per reply.
- Small local models struggle with steps 10, 12 and 18 because they are long. Split them: "Write only the renderMsg and renderCall functions first."
