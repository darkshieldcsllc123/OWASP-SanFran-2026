# Step 19: Testing and hardening

**Goal:** Prove the whole thing works and close the gaps that only show up in real use.
**Depends on:** all previous steps.
**Paste these files:** `CONTRACTS.md`, `README.md`, the file you are hardening.

## Prompt A: an end-to-end smoke test

````text
Write a Playwright smoke test (Python or Node, your choice; it is a dev-only tool and not part of the app) that:
1. Starts test/mock-llm.js and server.js on a temporary workspace with --ollama pointing at the mock.
2. Opens the app and records every pageerror and console error.
3. Asserts the model was auto-selected and the connection shows Connected, and that the page never contains a stray "null" text line.
4. Runs the scripted task with the default approval policy: waits for the pending card, approves with the button, uses Always allow for the second call, waits for the final table, and checks hello.js exists on disk.
5. Repeats the task with the custom OpenAI-compatible preset (base http://127.0.0.1:11435/v1) and with Anthropic (same base, any key), then sends a second Anthropic message to make sure the replayed tool history is accepted.
6. Runs it in Text protocol mode.
7. Denies a call with a reason, presses Escape on the next one, and checks the statuses are Denied and Cancelled and the composer is idle.
8. Adds a pasted doc and indexes the workspace in Knowledge, enables embeddings with mock-embed:latest, embeds, and checks a search ranks the right doc first.
9. Creates the calculator tool from its template and checks the test output is 12.
10. Opens each panel and takes screenshots in dark, light and a 390px mobile viewport.
Print a summary and exit non-zero if any step or console error fails (ignore network errors from deliberately unreachable providers).
````

## Prompt B: a hardening review

````text
Review this file for problems that appear in real use, and fix them without changing the contracts:
- Anything that can leave the UI stuck in a running or pending state after an error or abort.
- Histories that a provider would reject (a tool call without a result, empty assistant turns, consecutive same-role Anthropic turns, tool_result not first).
- Unescaped model or file text reaching innerHTML.
- Listeners added on every render (leaks), or renders that steal focus from an input the user is typing in.
- Large inputs: a 5 MB file, a 2,000-message chat, a tool that returns 1 MB, a model that streams for ten minutes.
- Windows paths and CRLF files in the workspace API.
List each finding as: what can happen, how to trigger it, and the fix you made.
````

## Final checklist

- Real Ollama with a tool-capable model completes a multi-file task end to end.
- A model without native tools is switched to the text protocol automatically and still completes it.
- A cloud provider works with the key in `.env` and an empty key box.
- `--no-exec` hides the shell tool and blocks `/api/exec`.
- Restarting the server shows the reload banner instead of silent failures.
