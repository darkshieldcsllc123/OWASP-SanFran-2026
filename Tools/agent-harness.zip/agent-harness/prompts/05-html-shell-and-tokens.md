# Step 05: HTML shell, design tokens and layout

**Goal:** The static page skeleton and a stylesheet with a deliberate visual identity, before any JavaScript.
**Depends on:** 01.
**Paste these files:** `CONTRACTS.md`.

## Prompt

````text
Write public/index.html and the first version of public/css/app.css for Agent Harness. No JavaScript behaviour yet besides a tiny inline script that applies the saved theme before first paint (read localStorage "harness.settings.v1", theme "system" | "dark" | "light", resolve "system" with matchMedia, set document.documentElement.dataset.theme).

Visual direction, "instrument panel": cool slate surfaces with one signal-amber accent used only for live state and primary actions.
- Dark tokens: --bg #172026, --bg-2 #1b262d, --surface #1f2b33, --raised #26353f, --sunken #131b20, --line #31434e, --line-soft #263640, --text #dbe5e9, --text-2 #a7b9c1, --muted #7b919b, --accent #f0a73a, --ok #5cc6a0, --err #ef7070, --info #72b6ec, --code-bg #121a1f. Derive --accent-soft and --accent-line with color-mix. Also define syntax colours --hl-k --hl-s --hl-n --hl-c --hl-f --hl-t --hl-b --hl-a.
- Light theme under [data-theme="light"]: cool paper (#e8eef0 background, white surfaces), darker accent for contrast, matching syntax colours. Avoid warm cream.
- Type, no web fonts: --font-ui system-ui stack; --font-display "Bahnschrift", "DIN Alternate", "D-DIN", "Barlow", system-ui for headings, labels and gauges; --font-mono ui-monospace, "Cascadia Code", "SF Mono", Menlo, Consolas, only for code, paths and JSON. Base size var(--fs) 14px.
- Radii: 3, 5, 8, 12 px used by hierarchy (chips small, cards medium, composer and welcome large). No all-caps labels, no gradient washes, no identical cards with identical shadows.

Layout (#app is a CSS grid): row 1 is a 50px top bar spanning all columns; row 2 has three columns: sidebar (264px), main (1fr), settings panel (var(--panel-w), 400px). Classes .sidebar-open and .panel-open on #app switch the side columns between 0 and their width with a short transition.

Markup ids (later steps depend on them):
- header#topbar: #btn-sidebar, .brand (svg mark: a filled accent circle between two short wire stubs, plus "Agent Harness"), .model-switch with select#top-provider, input#top-model list="top-models", datalist#top-models, button#conn (span.lamp + span.conn-text), spacer, button#ctx-meter (.ctx-bar > .ctx-fill, .ctx-text), #btn-palette, #btn-theme, #btn-panel.
- aside#sidebar: #btn-new, input#side-search, #convo-list, footer button#btn-backup.
- main#main: nav#chain, #messages-wrap > #messages[role=log] + button#jump, #plan, #composer > .composer-box > (#attachments, textarea#input, .composer-bar > #btn-attach, #composer-chips, spacer, #btn-send), #slash-pop.
- aside#panel: #panel-resize, #panel-tabs[role=tablist], #panel-body. Then #scrim, and #banner outside #app.
- <meta name="harness-token" content="__HARNESS_TOKEN__">, <script type="module" src="js/main.js">.

Styles to include now: reset, buttons (.btn, .btn-sm, .btn-xs, .btn-primary, .btn-ghost, .btn-danger, .btn-danger-ghost, .ibtn, .ibtn-sm, .ibtn-xs, .linkbtn), inputs (.input, .input-sm, .input-num, textarea.input, select.input with an inline SVG chevron, .slider with a --fill custom property, .switch toggle, .seg segmented control), .badge, .lamp, .spin, top bar, sidebar, composer box with a focus ring in --accent-soft, panel tabs with an accent underline, toasts, modals, popup menus, focus-visible outlines, and prefers-reduced-motion. Under 1100px the panel becomes a fixed drawer from the right with #scrim behind it; under 760px the sidebar becomes a drawer from the left and the header hides secondary items.
````

## Check it works

- Opening the page shows the empty frame in dark mode; adding `data-theme="light"` to `<html>` in devtools switches cleanly.
- Toggle `sidebar-open` and `panel-open` on `#app` in devtools: the columns animate.
- Shrink the window to phone width: nothing scrolls sideways.
