# Step 07: Ollama adapter and streaming

**Goal:** Talk to Ollama with every generation option, and stream tokens into the page.
**Depends on:** 04, 06.
**Paste these files:** `CONTRACTS.md`, `public/js/store.js`, `public/js/api.js`.

## Prompt

````text
Write the first half of public/js/providers.js.

1. PRESETS: ollama (type ollama, http://127.0.0.1:11434, local), openai (https://api.openai.com/v1, env OPENAI_API_KEY, usage:true, maxKey 'max_completion_tokens'), anthropic (type anthropic, https://api.anthropic.com/v1), openrouter, gemini (https://generativelanguage.googleapis.com/v1beta/openai), groq (https://api.groq.com/openai/v1), deepseek, mistral (shortIds:true, because Mistral wants 9-character tool call ids), xai, together, lmstudio (http://127.0.0.1:1234/v1, local), custom (OpenAI-compatible, local). presetById.

2. PARAMS, each {key, label, group, min, max, step, def, for:[types], help, int?, log?, noSlider?, options?, type?}. Groups "Sampling", "Repetition", "Length and memory", "Advanced". Include temperature, top_p, top_k (ollama, anthropic), min_p, typical_p, repeat_penalty, repeat_last_n, presence_penalty and frequency_penalty (ollama, openai), num_ctx (log slider 512-262144), num_predict (all), stop (type list), seed (ollama, openai), mirostat (options 0,1,2), mirostat_tau, mirostat_eta, num_gpu, num_thread, num_batch. Write help text a non-expert understands. Also SAMPLING_PROFILES Precise, Balanced, Creative.

3. getConf(id): create settings.providers[id] on first use with baseUrl from the preset, apiKey '', model '', gen = every param {on:false, v:def} (for ollama turn on temperature 0.6 and num_ctx 16384; for anthropic turn on num_predict 8192), extra = ollama {think:'default', keep_alive:{on:false, v:'10m'}, format:''} or openai {reasoning_effort:'default'}. Fill in params missing from older saved settings. activeProvider(), resetGen().

4. headersFor(preset, conf), listModels(id) (Ollama GET /api/tags → [{id, label, detail "7B Q4_K_M", size}]; others GET {base}/models → data[].id, strip a "models/" prefix).

5. Message conversion for Ollama (internal format in CONTRACTS.md): system first; user content plus text attachments wrapped in <attached_file name="..."> tags, images as base64 in images[]; assistant messages with no content and no calls are skipped; assistant tool calls become tool_calls with object arguments, followed by one {role:'tool', content: resultText(call), tool_name} per call. resultText supplies a sentence for denied or cancelled calls. In text mode (native false), the assistant content gets each call appended as <tool_call>{json}</tool_call> and the results go in one following user message of <tool_result name="..."> blocks.

6. buildRequest({presetId, messages, system, tools, toolMode, stream}) for type ollama: POST {base}/api/chat with model, messages, stream, options (only params that are on and apply to ollama; stop only if non-empty), tools as [{type:'function', function:{name, description, parameters}}] when toolMode is native, think (true for 'on', false for 'off', the string for low/medium/high, omitted for 'default'), keep_alive when on (numbers stay numbers), format 'json' when set. Throw "No model selected for Ollama. Pick one in the header or the Model panel." if the model is empty. Return {url, headers, body, preset, conf}.

7. Streaming: rawLines(res) async generator (TextDecoder, split on \n, strip \r), ndjson(res). streamChat({request, signal, onDelta}): logRequest; proxyFetch POST; on !ok read the body, extract the error message from JSON shapes {error:"..."}, {error:{message}}, {message}, {detail}, finishLog as error and throw "Ollama returned 400: <message>" with .status. For each NDJSON line: throw on j.error, accumulate message.thinking and message.content, collect message.tool_calls (generate ids with uid('call_'), parse string arguments, and keep unparseable ones as {_raw: string}), and on done record usage {input: prompt_eval_count, output: eval_count, tps: eval_count / (eval_duration / 1e9)} and stopReason. Track time to first token. Call onDelta(out) after each line. On AbortError attach the partial output to the error as .partial. Return {content, thinking, toolCalls, partialCalls: [], usage, stopReason, ttft, ms}.

8. ollama management helpers: version, tags, ps, show(model), load(model) and unload(model) (POST /api/generate with keep_alive '10m' or 0), remove(model) (DELETE /api/delete), pull(model, onProgress, signal) reading the NDJSON progress.

Replace the temporary main.js with a bare test page: a textarea and a button that sends [{role:'user', content}] to streamChat and writes out.content into a <pre> as it streams, using conf.model = first model from listModels('ollama').
````

## Check it works

- With the mock (Ollama base URL set to `http://127.0.0.1:11435` via `getConf('ollama').baseUrl = ...` in the console) the text streams word by word.
- With real Ollama, a reply streams and `out.usage.tps` is a sensible number.
- Turning a parameter on in the console (`getConf().gen.temperature = {on:true, v:0}`) shows up in the request in `requestLog[0].body.options`.
