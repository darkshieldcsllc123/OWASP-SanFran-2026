# Step 18: App shell polish

**Goal:** Turn the pieces into one product: sidebar, header, the signal chain, palette, shortcuts, themes, backup, responsive layout.
**Depends on:** 13 to 17.
**Paste these files:** `CONTRACTS.md`, `public/js/main.js`, `public/index.html`, the bus events table.

## Prompt

````text
Rewrite public/js/main.js as the full app shell. Keep the panel host from step 13.

- Theme: settings.theme system/dark/light (follow prefers-color-scheme live), accent from ACCENTS per theme into --accent, font size into --fs. The theme button cycles system → dark → light and shows a monitor, moon or sun icon. An Appearance modal with a theme segmented control, accent swatches and a text size slider.
- Layout: #btn-sidebar and #btn-panel toggle the columns (aria-pressed), saved in settings. Below 1100px open the panel as a drawer; below 760px the sidebar too, closing the other; #scrim closes them. Force both closed on first load on narrow screens.
- Header: #top-provider (grouped Local/Cloud) and #top-model with a datalist, synced with the Model panel through model:changed, provider:changed and models:loaded; fetch models on first focus. Connection lamp: Ollama → /api/version; local OpenAI-type servers → list models; cloud → "Key set" if a key or env key exists. Re-check every 30 s when visible and idle. Clicking opens the Model panel. Context meter (#ctx-meter) from estimateContext, accent above 85%, opens the Inspector.
- Signal chain (#chain): six nodes in order (System prompt with its token count, Skills "3 enabled", Knowledge "4 docs" or "empty", the provider name with the model, Tools "11 on", Workspace folder name) joined by short wires. Each node is a button that opens its panel (system and model also focus their field). Visual states: unset (hollow lamp, muted), set (solid dim lamp), viewing (its panel is open), fed (system/skills/knowledge while the model generates: accent lamp and border), live (the current phase: accent border, soft accent fill, pulsing lamp), waiting (tools while an approval is pending: faster pulse, value "waiting: write_file"). Wires are lit between set nodes and show moving accent dashes along the active path. A status label at the end: Retrieving, Generating, Step 3, Needs approval, Running tool. Drive it from 'agent:phase'. Use container queries on #main so the chain drops lamps and labels before it overflows.
- Sidebar: New chat (reuses an empty current chat), search across titles and message text, groups Pinned, Today, Yesterday, Previous 7 days, Older; each item shows the title, relative time (hidden on hover in favour of a menu button), a pulsing lamp while the agent runs in that chat; double-click to rename inline; menu: Rename, Pin/Unpin, Export as Markdown, Duplicate, Delete (confirm when it has messages; blocked while running). On phones, picking a chat closes the drawer.
- Command palette (Ctrl/Cmd+K): fuzzy search over commands (new chat, stop, toggles, each panel with Alt+N hints, edit system prompt, fetch models, theme, appearance, tool modes, approval policies, export chat, back up, restore, shortcuts, every provider, every cached model, recent chats); arrow keys, Enter, Escape, mouse hover selects.
- Shortcuts: Ctrl/Cmd+K palette, Ctrl/Cmd+B sidebar, Ctrl/Cmd+. panel, Ctrl/Cmd+/ shortcuts modal, Ctrl/Cmd+Shift+O new chat, Alt+1..6 panels, Escape closes the top modal, else stops the agent, else closes a drawer; "/" outside text fields focuses the composer.
- Tooltips for [data-tip] elements (hover and focus), positioned above or below and kept on screen.
- Banner (#banner) for 'server:token' (Reload) and 'server:down' (Retry), and when the page was opened without the server (token placeholder still present).
- Backup: download {app:'agent-harness', version:1, settings with API keys removed, convos, docs without embeddings}; restore validates app, confirms, keeps current API keys, writes to IndexedDB and reloads. "Reset all settings" with confirm. Put these and Appearance and Shortcuts in the sidebar footer menu.
- Boot order: theme; getInfo (banner on failure); let the Ollama base URL follow state.info.ollama until the user edits it (conf.autoBase); load chats and the knowledge base; pick the remembered chat; layout and listeners; mount chat and panels; render sidebar, header, chain and meter; check the connection; fetch models quietly and, if no model is chosen, pick the first non-embedding model with a toast; focus the composer.
````

## Check it works

- During the mock task the chain lights Knowledge (if docs exist), then Model with system and skills fed, then Tools with "waiting: write_file", then Tools and Workspace while it runs.
- Ctrl+K, type "insp", Enter: the Inspector opens.
- At 390px wide: no horizontal scrolling, drawers open and close, the composer stays usable.
- Back up, clear site data, restore: chats, settings and knowledge return; API keys are not in the file.
