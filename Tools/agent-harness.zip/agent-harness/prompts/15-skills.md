# Step 15: Skills

**Goal:** Reusable instruction packs with three activation modes and SKILL.md compatibility.
**Depends on:** 12, 13.
**Paste these files:** `CONTRACTS.md`, `public/js/agent.js` (buildSystem), `public/js/ui.js` (exports only).

## Prompt

````text
1. public/js/skills.js
- MODE_LABELS {always: 'Always on', auto: 'Auto by keyword', manual: 'Model loads on request'}.
- triggerList(skill) from the comma-separated triggers; triggerMatch(skill, text): case-insensitive; triggers of 4 characters or fewer must match as whole words (so "git" does not match "digit"), longer ones match as substrings.
- skillsFor(text, forced=[]) → {injected, loadable}: injected = enabled skills that are always on, auto skills whose trigger matches, plus forced skills by name; loadable = enabled, not injected and not always-on.
- getSkill(name) (enabled only, case-insensitive), slug(), newSkill(partial).
- parseSkillFile(text, filename): JSON files (one skill, an array, or {skills}); Markdown with optional YAML-style frontmatter (name, description, mode, triggers or keywords); without a name use the filename ("SKILL.md" becomes "imported-skill"); without a description use the first non-heading line; mode defaults to auto when triggers exist, otherwise manual. Returns an array of skills. skillToMarkdown(skill) writes the frontmatter format back.

2. Wire it into agent.js buildSystem (replace the stub) and the load_skill tool in tools.js.

3. public/js/panel-skills.js
- An explanation of the three modes in one short paragraph.
- Skill rows: switch, bold name, mode badge, description, trigger words as small monospace tags for auto skills, token estimate, edit button and a menu (Duplicate, Export as SKILL.md, Delete).
- Buttons: New skill, From template (SKILL_TEMPLATES), Import (multiple .md/.txt/.json files; rename on name clashes), Export all.
- A collapsed "Try a message" section: as the user types, show which skills would be added to the prompt and which would be loadable.
- Editor modal: name (slugged on save; unique), mode segmented control, description, trigger words (only shown for auto), instructions textarea with a Write/Preview switch (renderMarkdown) and a live token estimate.
- Emit 'chain' after changes so the signal chain count updates.
````

## Check it works

- Type "the login test is failing" in Try a message: test-first-fixes is added.
- Type "add a digit": git-hygiene is not triggered by "digit".
- Send a message with `/skill git-hygiene`: the user message shows a "Skill: git-hygiene" chip and the Inspector preview contains the skill text.
- Import a SKILL.md from another project: it appears with the right name and description.
