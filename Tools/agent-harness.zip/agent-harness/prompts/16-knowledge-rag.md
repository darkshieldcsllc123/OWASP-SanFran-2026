# Step 16: Knowledge base (RAG)

**Goal:** Add documents, retrieve the right excerpts for each message, and let the model search on its own.
**Depends on:** 12, 13.
**Paste these files:** `CONTRACTS.md`, `public/js/store.js` (idb), `public/js/providers.js` (embed), `public/js/agent.js` (run and buildSystem).

## Prompt

````text
1. public/js/rag.js
- kb {docs, ready, embedding}; loadKB() from IndexedDB store docs; an in-memory index rebuilt after any change.
- tokenize(text): Unicode letters/digits/underscore words, lowercased, minus a short English stopword list and 1-character tokens; also emit camelCase and snake_case parts so "refreshSession" matches "session".
- chunkText(text, {chunkSize, overlap}): walk lines; hard-split lines longer than the size; close a chunk when adding a line would exceed the size, or at a boundary (blank line, heading, or a line starting with export/def/class/function/fn/func/public/private/interface/type) once the chunk is over 60% full; carry trailing lines up to the overlap into the next chunk; record the 1-based start line of each chunk.
- BM25 (k1 1.2, b 0.75) over doc name plus chunk text.
- Vector search: embed the query, cosine similarity against chunks that have an embedding of the same length.
- search(query, {k, mode}) → {results, mode, note}: 'bm25'; or, when embeddings are enabled and present, 'vector' or 'hybrid' (reciprocal rank fusion, constant 60, over the top 60 of each list, keeping both raw scores in parts). Fall back to BM25 with an explanatory note when there are no vectors or embedding fails.
- formatResults(results): "[1] name (line 12)\n<text>" separated by "---".
- addDocument({name, text, source}) replaces an existing doc with the same name and source; removeDocument, clearKB, rechunkAll (clears embeddings), needsEmbedding(doc) (model changed or a chunk lacks a vector), embedPending(onProgress, signal) in batches of 16 (prefix each chunk with the doc name), stats() {docs, chunks, embedded, chars, pending}.
- htmlToText(html) with DOMParser: drop script/style/nav/footer/form/svg, keep headings as "#" lines and list items as "- ", collapse whitespace, prefix the title.
- importURL(url) via the proxy (reject non-text content types); importWorkspace({path, depth, onProgress}) for text and source extensions under 400 KB, skipping lock files.

2. Replace the stubs in agent.js (auto-inject on run) and tools.js (rag_search). Add a knowledge chip on user messages: "3 excerpts from Knowledge", expandable to show each excerpt's source, line, score and text.

3. public/js/panel-knowledge.js
- Overview: four gauges (documents, chunks, embedded %, text size) and two switches: "Add excerpts to each message" and "Let the model search (rag_search)". A progress bar while importing or embedding.
- Add knowledge: segmented Paste / Files / URL / Workspace. Paste: title and text. Files: a drop zone (refuse PDFs, Office files and images with a clear message). URL: fetch and add. Workspace: a folder input and Index folder. After adding, embed automatically when embeddings are on.
- Documents: list with a source icon, name, chunk count, size, age, an embedded lamp when embeddings are on, delete; filter box past five docs; Remove all with confirm. Clicking a doc shows its chunks.
- Test a search: live results with keyword and vector scores.
- Retrieval settings: mode segmented (Keyword, Hybrid, Vector), excerpts per message, chunk size and overlap (show "Re-chunk all documents" after changes), and an Embeddings group: switch, provider (Ollama or any OpenAI-type preset), model, a hint ("ollama pull nomic-embed-text"), pending count and Embed now / Stop.
````

## Check it works

- Index the workspace, then search "how are tokens refreshed" against a notes file that mentions refreshSession: that file ranks first.
- Turn on embeddings with `mock-embed:latest` on the mock: Embed now reaches 100%, and the search shows both kw and vec scores.
- Send "how are auth tokens refreshed?": the user message shows the excerpts chip, and the Inspector context budget has a Knowledge row.
