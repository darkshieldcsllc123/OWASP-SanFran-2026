# Step 14: Tools panel and the custom tool builder

**Goal:** Control the agent loop and let users create, test, import and export their own tools.
**Depends on:** 11, 13.
**Paste these files:** `CONTRACTS.md`, `public/js/tools.js`, `public/js/ui.js`, `public/js/defaults.js` (TOOL_TEMPLATES only).

## Prompt

````text
Write public/js/panel-tools.js.

Agent behaviour section: tool calling segmented control (Native, Text protocol, Off) with a help line that changes with the choice; approval select (Ask before every tool, Ask before writes, shell and network, Never ask) with a note that per-tool settings below override it; max steps (1-200) and tool output limit (characters) side by side; a switch for showing the model's thinking (re-render the active chat when it changes).

Built-in tools section, grouped by category with "asks first under the default policy" on risky groups: each row has an enable switch, the monospace name, an availability note when relevant (shell disabled on the server, knowledge off, skill index empty), a two-line description, an approval override select (Use policy, Always ask, Never ask) and an eye button that shows the JSON schema. The header shows enabled/total.

Custom tools section: rows with a switch, name, a type badge (JavaScript or HTTP GET/POST), an approval badge when overridden, the description (or a nudge that models need one), an edit button and a menu (Test, Duplicate, Export as JSON, Delete with confirm). Buttons: New tool, From template (menu of TOOL_TEMPLATES), Import (JSON file of one tool, an array, or {tools:[...]}), Export all.

Tool editor (a full-size modal, two columns):
- Left: name (validated: starts with a letter or underscore; letters, digits, _ and -; not a built-in name; unique), approval select, description textarea ("The model reads this."), implementation segmented control JavaScript / HTTP request.
  - JavaScript: a monospace code textarea where Tab inserts two spaces, and a collapsible "What the code can use" reference listing the ctx helpers with examples.
  - HTTP: method select, URL input with {{param}} hint, headers JSON textarea.
- Right: parameters with a Builder / JSON Schema switch. Builder rows: name, type (string, number, integer, boolean, array, object), description, required checkbox, remove; "Add parameter". Switching to JSON Schema converts the rows to a schema and back (parse properties and required).
- A "Try it" box: sample arguments JSON and a Run test button that runs executeTool on the draft (no approval, since the user clicked it), showing a validation warning, the output or the error, and the duration.
- Save validates name, schema (must be an object schema), URL for HTTP tools and headers JSON, then stores the tool and re-renders.
````

## Check it works

- From template → calculator → Run test with `{ "expression": "sqrt(16) + 2^3" }` shows 12. Save it.
- Ask the agent (with the mock replaced by a real model) "what is 17 * 23 using the calculator tool".
- Export all, delete the tool, import the file: it comes back.
