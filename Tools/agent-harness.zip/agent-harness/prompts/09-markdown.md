# Step 09: Markdown renderer and highlighter

**Goal:** Render model output safely and readably, including while it is still streaming.
**Depends on:** 06.
**Paste these files:** `CONTRACTS.md`, `public/js/util.js` (only `esc` is needed).

## Prompt

````text
Write public/js/markdown.js with renderMarkdown(src), highlight(code, lang) and langFromPath(path). It must be safe: escape all HTML from the source; the only HTML produced is your own tags.

renderMarkdown:
- First pass, line by line: pull out fenced code blocks (``` or ~~~, 3 or more, optional language, indented fences de-indented). A fence that never closes runs to the end of the text and is marked streaming (this matters while tokens arrive). Replace each with a placeholder line.
- Block parser: ATX headings, horizontal rules, blockquotes (recursive), GitHub tables (header row followed by a separator row; alignment from colons; split on unescaped pipes; wrap the table in div.table-wrap for horizontal scrolling), lists (ordered with start number and unordered, nested by indentation, lazy continuation lines, blank lines inside items when the next line is indented, task items "[ ]" and "[x]" rendered with span.task-box), and paragraphs where single newlines become <br>.
- Inline: protect code spans first, then escape, then images (rendered as a link "[image: alt]", never <img>), links with a URL whitelist (http, https, mailto, #, relative), bare URL autolinks, bold, italic, bold-italic, strikethrough. Links get target=_blank rel="noopener noreferrer".
- Code blocks render as div.codeblock[data-lang] > div.cb-head (span.cb-lang, Save and Copy buttons with data-act="save-code" and data-act="copy-code") + pre > code with highlighted HTML. Add class streaming when unclosed.

highlight(code, lang):
- A regex tokenizer per language: one combined global regex with groups for comment, string, number and word. Words become keyword (hl-k), literal true/false/null/None/undefined (hl-b), function name when followed by "(" (hl-f), capitalised type (hl-t) for languages with types, otherwise plain. JSON keys (a string followed by ':') and YAML/CSS keys get hl-a.
- Languages: js, ts, py, sh, go, rust, java (also C#, Kotlin, Swift, Dart), c (and C++), rb, sql (case-insensitive), css, json, yaml (also toml, ini), plus a separate tokenizer for html/xml (comments, tags, attribute names, strings) and a line-based diff (+ lines hl-add, - lines hl-del, @@ lines hl-meta). Include sensible aliases (javascript, jsx, bash, zsh, python, yml, …). Unknown languages are just escaped.
- Guard against zero-length matches.

langFromPath maps file extensions (and Dockerfile, Makefile) to these language ids.

Also add the matching CSS to app.css: .md typography (headings in the display font, comfortable line-height, max-width 74ch for user messages, tables, blockquotes, inline code), .codeblock styles, and the hl-* colours from the tokens.
````

## Check it works

Make a scratch page that renders this and compare by eye:

- A table with an inline-code cell, a nested list with a task item, a blockquote, a link and `<script>alert(1)</script>` (it must appear as text).
- A JS code block shows coloured keywords, strings and comments. An unclosed fence renders as a code block.
- `[x](javascript:alert(1))` becomes a link to `#`.
