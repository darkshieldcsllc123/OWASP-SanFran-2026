# Step 11: Tool registry and built-in tools

**Goal:** The tools the agent can call, their schemas, the approval policy and argument validation.
**Depends on:** 06, 08.
**Paste these files:** `CONTRACTS.md`, `public/js/api.js`, `public/js/store.js` (DEFAULTS only).

## Prompt

````text
Write public/js/tools.js (exports in CONTRACTS.md). Tool descriptions are read by the model, so write them as clear instructions.

CATEGORIES: read (icon file), write (edit, risky), exec (terminal, risky), net (globe, risky), meta (list), custom (tool, risky).

BUILTINS, each {name, category, description, parameters (JSON Schema with type object, properties, required), run(args, ctx), available?()}:
- list_dir {path, depth 1-5, default 2}: indented tree with file sizes; folders marked "(not expanded)" when ignored; "The workspace is empty." when empty.
- read_file {path, start_line, end_line}: header "path (N lines)" or "(lines a-b of N)", then each line as "<number>\t<text>". The description tells the model never to include the number prefixes when editing. Binary files return a sentence.
- write_file {path, content}: "Created path: N lines, 1.2 KB." or "Overwrote …".
- edit_file {path, old_str, new_str, replace_all}: "Edited path: replaced 1 occurrence, first at line 42."
- search_files {pattern, path, glob, regex, case_sensitive}: "N matches in M files scanned:" then path:line: text.
- run_command {command, cwd, timeout_sec}: "exit code 0 in 1.2s", then stdout: and stderr: sections, or "(no output)". available() only when state.info.exec is not false.
- delete_path {path}, move_path {from, to}.
- fetch_url {url, max_chars 8000}: via proxyFetch; HTML converted to text with htmlToText (import from rag.js, which you can stub for now as a DOMParser that removes script/style/nav/footer and returns textContent), JSON pretty-printed.
- rag_search {query, top_k}: available() when settings.rag.asTool and the knowledge base has documents (stub until step 16).
- update_plan {steps: [{title, status pending|in_progress|done}]}: accept plain strings and "completed" too; save to ctx.convo.plan, emit 'plan'.
- load_skill {name}: available() when skillsFor('').loadable is non-empty (stub until step 15).

Custom tools: customToTool(c) builds a tool from the custom tool shape. Schema comes from schemaFromParams(params) or, in raw mode, from schemaRaw. JS tools run with new AsyncFunction('args', 'ctx', code); ctx = makeCtx(signal, logs) with fs.read/write/list/edit/search, exec(command, opts), fetch, fetchText, fetchJSON (all through the proxy), rag.search(q, k), log(...) (appended to the result under [log]) and signal; syntax errors become "Syntax error in tool code: …". HTTP tools replace {{param}} in the URL with encoded arguments, put the rest in the query string (GET, DELETE) or a JSON body, merge headers from JSON, and return "HTTP 200" plus the pretty body. newCustomTool(partial) gives defaults.

Registry and policy:
- builtinState(name) lazily creates settings.tools.builtin[name] = {enabled:true, approval:'inherit'}.
- getActiveTools(): enabled and available built-ins, then enabled custom tools whose names do not clash.
- schemaOf(tool) → {name, description, parameters}.
- approvalFor(tool): per-tool 'ask' or 'auto' wins; otherwise settings.agent.approval 'all' → true, 'none' → false, 'risky' → category is risky.
- validateArgs(schema, args) mutates args to coerce friendly mistakes ("2" to 2, "true" to true, objects to pretty JSON strings, JSON-string arrays to arrays), and returns an error string ("Invalid arguments: missing required "path"; "depth" must be a number.") or null. Arguments that failed to parse arrive as {_raw}; report them.
- executeTool(tool, args, ctx): run with a 16-minute timeout and abort support; stringify non-string results; if longer than settings.agent.outputLimit, keep the first 75% and last 25% with a marker telling the model to ask for a narrower range.
````

## Check it works

In the console:

- `t = (await import('/js/tools.js')).getActiveTools(); t.map(x => x.name)` lists the built-ins.
- `await (await import('/js/tools.js')).executeTool(t.find(x => x.name === 'list_dir'), {})` returns a tree.
- `validateArgs(t[0].parameters, {depth: '3'})` returns null and changes depth to 3.
