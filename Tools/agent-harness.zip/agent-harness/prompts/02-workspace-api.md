# Step 02: Workspace API (files, search, shell)

**Goal:** The `/api/*` routes the agent's tools will use, locked to one workspace folder.
**Depends on:** 01.
**Paste these files:** `CONTRACTS.md`, `server.js`.

## Prompt

````text
Add the workspace API to server.js, exactly as listed in the "Server API" table of CONTRACTS.md.

Workspace root: ROOT = resolved workspace folder (create it if missing). REAL_ROOT = fs.realpathSync(ROOT).

safePath(p):
- Must be a string; empty means ".".
- If p is absolute and inside ROOT, use it. Otherwise strip a leading slash or drive letter and resolve it relative to ROOT. Models often send "/src/app.js" meaning workspace-relative.
- Throw 403 if the result is outside ROOT. Then walk up to the nearest existing ancestor, realpath it, and throw 403 if that is outside REAL_ROOT (this blocks symlink escapes).

Routes (return JSON; throw errors with a .status and a message a model can act on):
- GET /api/info: version, root, rootName, platform, os, arch, node, exec (bool), shell, ollama URL, envKeys (which known keys exist, as booleans; never the values).
- POST /api/fs/list {path, depth 1-8, max 800}: breadth-first listing, folders first then alphabetical, each entry with path relative to ROOT using forward slashes, name, type, size, mtime, depth (1 = direct child), ignored. Folders in the ignore set are listed with ignored:true but not expanded.
- POST /api/fs/read {path, start, end}: refuse folders ("is a directory. Use list_dir instead."), files over 8 MB, and report binary files (a NUL byte in the first 8000 bytes) as {binary:true}. Split on \r?\n and return the requested 1-based inclusive range with totalLines.
- POST /api/fs/write {path, content, append}: create parent folders; content that is not a string is JSON-stringified with 2-space indent; refuse writing to ROOT or onto a folder.
- POST /api/fs/edit {path, old_str, new_str, replace_all}: old_str required and non-empty. If it is not found and the file uses CRLF, retry with old_str and new_str converted to CRLF. 0 matches gives 422 "old_str was not found in X. Read the file again and copy the exact text, including whitespace." More than one match without replace_all gives 422 "old_str appears N times in X. Include more surrounding lines to make it unique, or set replace_all to true." Return the line number of the first replacement. Use a replacer function so "$" in new_str is not special.
- POST /api/fs/delete {path}: refuse ROOT; rm recursive.
- POST /api/fs/move {from, to}: 409 if the target exists; create parent folders.
- POST /api/fs/search {pattern, path, glob, regex, case_sensitive, max_results}: walk files (skip ignored folders, files over 1 MB and binary files), test each line, cap at max_results (≤500), truncate long lines to 300 characters. Implement globToRegex yourself: * matches within a segment, ** matches across segments (and swallows a following slash), ? one character, {a,b} alternatives. If the glob has no slash, match it against the file name, otherwise against the relative path.
- POST /api/exec {command, cwd, timeout}: 403 if started with --no-exec. spawn(command, {shell:true, cwd: safePath(cwd), env with NO_COLOR=1, windowsHide, detached on non-Windows}). Cap stdout and stderr at 256 KB each. Kill the whole process tree on timeout (1-900 s, default 60) and when the HTTP client disconnects: process.kill(-pid) on POSIX, taskkill /pid N /T /F on Windows. Return code, signal, stdout, stderr, timedOut, durationMs.
````

## Check it works

Use the token from the page source in `H="x-harness-token: TOKEN"`:

- `curl -H "$H" -X POST localhost:8787/api/fs/write -d '{"path":"src/a.js","content":"const x = 1;\n"}'` creates `workspace/src/a.js`.
- An edit with a missing `old_str` returns 422 and the helpful message.
- `{"path":"../../etc/passwd"}` to read returns 403.
- `{"command":"sleep 5","timeout":1}` to exec returns after about 1 s with `timedOut: true`.
- Search with `{"pattern":"CONST","glob":"**/*.js"}` finds the line, case-insensitively.
