# Step 10: Chat view and composer

**Goal:** A real conversation UI: streaming messages, thinking blocks, the composer with attachments, and a minimal boot.
**Depends on:** 08, 09.
**Paste these files:** `CONTRACTS.md`, `public/index.html`, `public/js/store.js`, `public/js/providers.js` (exports only), `public/js/markdown.js` (exports only).

## Prompt

````text
Write public/js/chat.js (exports in CONTRACTS.md) and a minimal public/js/main.js that boots it. For now, sending a message calls a small local function that builds the request with buildRequest and streams it with streamChat into a new assistant message; step 12 replaces this with the agent.

chat.js:
- mountChat(): wire #messages, #messages-wrap, #input, #btn-send, #btn-attach, #jump. Listen to bus 'convo:switch' and 'convo:render' (full renderAll) and 'convo:msg' {convo, msg, added} (re-render only that message by data-id; when added, also re-render the previous message so its action buttons update).
- Sticky scrolling: only auto-scroll when the user is within 90px of the bottom; otherwise show #jump ("Jump to latest").
- renderAll(): an empty chat shows a welcome view: a heading "What should the agent build?", one sentence about what it does, a checklist (workspace path from state.info, connection status from state.conn, selected model, number of tools) where failing rows have a fix hint and a button, and four starter prompt cards from STARTER_PROMPTS that fill the composer.
- User message: label "You", content rendered with renderMarkdown on a raised surface, attachment chips (image thumbnails for images), hover actions copy, edit (inline textarea with "Save and resend", Ctrl+Enter, Escape), delete.
- Assistant message: label with the model name and provider (omit the label when the previous message is also an assistant message, so multi-step runs read as one block); a <details class="thinking"> that is open while only thinking has streamed and closed afterwards (remember the user's own toggles per message id; record them on summary click, not on the toggle event); content via renderMarkdown with any <tool_call> markup stripped while streaming; three-dot typing indicator before the first token; an error box with a cause-specific hint (Ollama unreachable, auth 401/403, model not found 404, context too long, 429 rate limit) and a Retry button; a footer with usage "812 in, 96 out", tok/s, time to first token, duration, and actions copy, regenerate and Continue (last message only), delete.
- Notice messages (role notice) render as a small centred line with an icon by level.
- Event delegation on #messages via data-act: copy-code, save-code (prompt for a path; guess it from a first-line comment like "// src/app.js"; write with fsApi.write), copy-msg, edit-msg, regen, continue, retry, delete-msg.
- Composer: auto-growing textarea (max 40% of the window), Enter sends, Shift+Enter adds a line, Escape stops when running. Attachments from the button, drag and drop onto #main (show a dashed overlay), and paste: images up to 8 MB as data URLs, text files up to 1 MB (skip files containing NUL). Chips with remove buttons. The send button becomes Stop while running.
- Composer chips row (#composer-chips) is rendered by renderChips(); for now just a placeholder, step 12 fills it.

main.js (temporary): apply the theme, getInfo() into state.info, loadConvos(), create or reuse a chat, mountChat(), and set the Ollama base URL from state.info.ollama.

Add CSS for everything above to app.css in the same visual language.
````

## Check it works

- With the mock, a reply streams with a thinking block that collapses when the text starts.
- Paste a screenshot into the composer: a thumbnail chip appears.
- Reload mid-stream: the message shows "Interrupted (page was reloaded)" instead of spinning forever.
- Scroll up during a long reply: the view stops following and "Jump to latest" appears.
