# Step 17: Files panel and Inspector

**Goal:** See and edit the workspace, and see exactly what is sent to the model.
**Depends on:** 12, 13.
**Paste these files:** `CONTRACTS.md`, `public/js/api.js`, `public/js/agent.js` (exports only), `public/js/markdown.js` (exports only).

## Prompt

````text
1. public/js/panel-files.js
- Subscribe to 'workspace:changed' at module load (not in mount), so changes made before the panel is first opened are not lost; keep the last 30 {path or cmd, tool, time}.
- Header: workspace path (monospace, ellipsis, full path in the title), New file (prompt for a path, create it empty, open it), Refresh.
- Tree: lazy-loaded folders (cache entries per path, remember expanded folders, reload expanded folders on refresh), folder chevrons, file sizes, ignored folders dimmed, files changed by the agent marked with an accent bar and accent name. Hover actions on files: attach to the next message (attachText from chat.js), add to knowledge, delete (confirm); on folders: delete.
- File viewer (full modal): line-numbered highlighted view; Edit switches to a textarea (Tab inserts two spaces, Ctrl/Cmd+S saves); footer buttons Attach to message, Add to knowledge, Download, Edit/Save.
- "Changed by the agent" section listing recent changes with icons and relative times; clicking opens the file.
- "Run a command" section (hidden with a note when exec is disabled): a $ prompt input with history on arrow keys, output appended in a terminal-style pre (stderr in red, exit code and duration), Clear. Say clearly that this output is not sent to the model.

2. public/js/panel-inspector.js
- Context budget: total estimated tokens of the limit with a percentage (warning colour above 85%), a stacked bar coloured per part, and a legend list with token counts (system prompt, skills, skill index, text tool protocol, knowledge, tool definitions, conversation).
- "Preview the next request" button: a modal with the URL, headers (keys hidden) and body as highlighted JSON, an approximate token count, and Copy JSON.
- Request log: newest first, each row with a status lamp (live, ok, error), model, provider, HTTP code, time and duration; clicking opens a two-column modal with the request and the response (or "(still streaming)"). A clear button.
- Redraw on 'log', 'convo:switch', 'agent:end' and 'settings', throttled with requestAnimationFrame.
````

## Check it works

- After the mock task, open Files: hello.js is marked as changed, and opening it shows highlighted code.
- Edit and save a file with Ctrl+S, then ask the agent to read it: it sees your change.
- Preview the next request after the mock task: the body contains the tool calls and tool results in the provider's format.
