# Step 00: Project brief

**Goal:** Give your assistant the big picture before any code exists, and agree on the folder layout.
**Depends on:** nothing.
**Paste these files:** `CONTRACTS.md`.

## Prompt

````text
We are going to build "Agent Harness", step by step, over several chats. Do not write code yet.

What it is: a local agentic coding workbench. A single-page app in plain HTML, CSS and ES-module JavaScript, served by a small Node.js server. The user picks a model (Ollama locally, or OpenAI, Anthropic, OpenRouter, Gemini, Groq, DeepSeek, Mistral, xAI, Together, LM Studio or any OpenAI-compatible server). The agent works inside a workspace folder: it reads and edits files, searches code, and runs shell commands, asking the user for approval before risky actions. Users can add custom tools (JavaScript or HTTP), skills (reusable instructions), and a knowledge base (RAG with BM25 and optional embeddings). Every Ollama generation parameter and the system prompt are editable.

Hard constraints:
- Zero dependencies. Server: Node 18+ standard library only. Browser: no framework, no bundler, no CDN.
- The Node server does three jobs: serve /public, proxy model API calls (to remove CORS problems and optionally add API keys from .env), and expose a sandboxed workspace API (files + shell).
- Security: bind 127.0.0.1, require a per-session token on every API call, reject non-localhost Host headers, confine file access to the workspace.
- Interfaces are fixed by the CONTRACTS.md I pasted. Treat it as the source of truth.

Please reply with:
1. A one-paragraph summary of the architecture in your own words, so I can check we agree.
2. The full file tree you expect at the end, with one line per file saying what it owns.
3. Any contract in CONTRACTS.md you think is ambiguous, with the question you would ask about it.
````

## Check it works

- The summary mentions the three server jobs, the token, and that tool results live on the tool call inside the assistant message.
- The file tree matches the module map in `CONTRACTS.md`.
- Answer its questions in the same chat, then move on.
