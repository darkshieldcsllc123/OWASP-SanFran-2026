// panel-model.js — provider + model, Ollama model manager, system prompt, sampling parameters.
import { settings, saveSettings, state } from './store.js';
import { PRESETS, presetById, getConf, listModels, ollama, PARAMS, PARAM_GROUPS, SAMPLING_PROFILES, resetGen } from './providers.js';
import { PROMPT_PRESETS, TEMPLATE_VARS, DEFAULT_SYSTEM_PROMPT } from './defaults.js';
import { renderTemplate, estimateContext } from './agent.js';
import { activeConvo } from './store.js';
import { h, icon, ibtn, toast, modal, promptDialog, confirmDialog, fmtBytes, fmtNum, estimateTokens, bus, menu, uid, relTime, copyText } from './util.js';
import { section, field, select, input, textarea, segmented, badge, btn, paramRow, listEditor, empty } from './ui.js';
import { renderMarkdown } from './markdown.js';

let root;
const mstate = { ps: [], pulling: null, filter: '' };

export default {
  id: 'model', label: 'Model', icon: 'cpu',
  mount(el) {
    root = el; render();
    bus.on('model:changed', render);
    bus.on('provider:changed', render);
    bus.on('models:loaded', () => { if (!root.contains(document.activeElement)) render(); });
  },
  focus(what) {
    const target = what === 'system' ? root.querySelector('#sys-prompt') : what === 'model' ? root.querySelector('#model-input') : null;
    if (target) { target.closest('.sect')?.classList.add('open'); target.focus(); target.scrollIntoView({ block: 'center', behavior: 'smooth' }); }
  },
};

export async function fetchModels(id = settings.provider, { quiet = false } = {}) {
  try {
    const list = await listModels(id);
    state.models ||= {}; state.models[id] = list;
    bus.emit('models:loaded', id);
    if (!quiet) toast(`Found ${list.length} model${list.length === 1 ? '' : 's'}`, { type: 'ok' });
    return list;
  } catch (e) { if (!quiet) toast(e.message, { type: 'err', timeout: 6000 }); throw e; }
}

export function setProvider(id) {
  settings.provider = id; getConf(id); saveSettings('provider');
  bus.emit('provider:changed', id);
  if (!state.models?.[id]) fetchModels(id, { quiet: true }).catch(() => {});
}

export function setModel(name) {
  const conf = getConf();
  conf.model = name.trim();
  settings.recentModels = [{ provider: settings.provider, model: conf.model }, ...settings.recentModels.filter(r => !(r.provider === settings.provider && r.model === conf.model))].slice(0, 8);
  saveSettings('provider'); bus.emit('model:changed');
}

function render() {
  const preset = presetById(settings.provider);
  const conf = getConf();
  root.replaceChildren(
    connectionSection(preset, conf),
    preset.type === 'ollama' ? ollamaSection() : null,
    systemSection(),
    paramsSection(preset, conf),
    extrasSection(preset, conf),
  );
  if (preset.type === 'ollama') refreshOllama();
}

// ── connection ───────────────────────────────────────────────────
function connectionSection(preset, conf) {
  const groups = [['Local', PRESETS.filter(p => p.local)], ['Cloud', PRESETS.filter(p => !p.local)]];
  const providerSel = h('select', { class: 'input', id: 'provider-select', onChange: e => setProvider(e.target.value) },
    groups.map(([g, list]) => h('optgroup', { label: g }, list.map(p => h('option', { value: p.id, selected: p.id === preset.id }, p.name)))));
  const envSet = preset.env && state.info?.envKeys?.[preset.env];
  const keyInput = h('input', { class: 'input mono', type: 'password', value: conf.apiKey, placeholder: envSet ? `Using ${preset.env} from .env` : preset.key ? 'Paste your API key' : 'Not needed for local servers', autocomplete: 'off', spellcheck: 'false', onInput: e => { conf.apiKey = e.target.value.trim(); saveSettings('provider'); } });
  const models = state.models?.[preset.id] || [];
  const list = h('datalist', { id: 'model-list' }, models.map(m => h('option', { value: m.id }, m.detail || m.label)));
  const modelInput = h('input', { class: 'input mono', id: 'model-input', list: 'model-list', value: conf.model, placeholder: preset.type === 'ollama' ? 'e.g. qwen2.5-coder:7b' : 'Model id', spellcheck: 'false', onChange: e => setModel(e.target.value) });
  const result = h('div', { class: 'test-result', hidden: true });
  const test = async () => {
    result.hidden = false; result.className = 'test-result wait'; result.textContent = 'Testing…';
    const t0 = performance.now();
    try {
      const list = await fetchModels(preset.id, { quiet: true });
      result.className = 'test-result ok';
      result.textContent = `Connected in ${Math.round(performance.now() - t0)} ms. ${list.length} models available.${conf.model && list.length && !list.some(m => m.id === conf.model) ? ` "${conf.model}" is not in the list.` : ''}`;
      bus.emit('conn:check');
    } catch (e) { result.className = 'test-result bad'; result.textContent = e.message; }
  };
  return section('Connection', h('div', { class: 'stack' },
    field('Provider', providerSel),
    field('Base URL', input(conf.baseUrl, v => { conf.baseUrl = v.trim(); conf.autoBase = false; saveSettings('provider'); bus.emit('conn:check'); }, { class: 'input mono', spellcheck: 'false' }),
      preset.type === 'ollama' ? 'Usually http://127.0.0.1:11434. The proxy forwards requests, so Ollama needs no CORS setup.' : preset.id === 'custom' ? 'Any OpenAI-compatible server: vLLM, llama.cpp server, LiteLLM, Jan, text-generation-webui.' : null),
    preset.key || preset.id === 'custom' ? field('API key', h('div', { class: 'row' }, keyInput, ibtn('eye', 'Show or hide key', () => { keyInput.type = keyInput.type === 'password' ? 'text' : 'password'; })),
      envSet ? `The server found ${preset.env} in its environment and adds it to requests when this box is empty.` : 'Stored in this browser only. You can also put it in a .env file next to server.js.') : null,
    field('Model', h('div', { class: 'row' }, modelInput, list, btn('Fetch', () => fetchModels(preset.id), { iconName: 'refresh', title: 'Fetch the model list' })),
      models.length ? `${models.length} models available. Type to filter.` : 'Press Fetch to load available models.'),
    settings.recentModels.length ? h('div', { class: 'recent' }, h('span', { class: 'muted' }, 'Recent'), settings.recentModels.slice(0, 5).map(r => h('button', { class: 'chip', type: 'button', onClick: () => { if (r.provider !== settings.provider) setProvider(r.provider); setModel(r.model); render(); } }, `${r.model}`, r.provider !== settings.provider ? h('small', {}, presetById(r.provider).name) : null))) : null,
    h('div', { class: 'row' }, btn('Test connection', test, { iconName: 'zap' })),
    result), { id: 'conn' });
}

// ── Ollama model manager ─────────────────────────────────────────
function ollamaSection() {
  const body = h('div', { class: 'stack', id: 'ollama-mgr' }, h('p', { class: 'muted' }, 'Loading local models…'));
  return section('Local models', body, { id: 'ollama', actions: [ibtn('refresh', 'Refresh', () => refreshOllama(), 'ibtn-sm')] });
}

async function refreshOllama() {
  const body = root.querySelector('#ollama-mgr'); if (!body) return;
  let tags, ps;
  try { [tags, ps] = await Promise.all([ollama.tags(), ollama.ps().catch(() => ({ models: [] }))]); }
  catch (e) { body.replaceChildren(empty('alert', 'Ollama is not reachable', `${e.message}`, h('div', { class: 'stack-sm' }, h('code', { class: 'cmdline' }, 'ollama serve'), h('small', { class: 'muted' }, 'Install from ollama.com, then start it and press refresh.')))); return; }
  mstate.ps = ps.models || [];
  state.models ||= {}; state.models.ollama = (tags.models || []).map(m => ({ id: m.name, label: m.name, detail: [m.details?.parameter_size, m.details?.quantization_level].filter(Boolean).join(' '), size: m.size }));
  const conf = getConf('ollama');
  const filter = h('input', { class: 'input', placeholder: 'Filter models', value: mstate.filter, onInput: e => { mstate.filter = e.target.value; drawList(); } });
  const listEl = h('div', { class: 'model-list' });
  const drawList = () => {
    const q = mstate.filter.toLowerCase();
    const models = (tags.models || []).filter(m => m.name.toLowerCase().includes(q));
    listEl.replaceChildren(...(models.length ? models.map(m => {
      const running = mstate.ps.find(p => p.name === m.name);
      const active = conf.model === m.name;
      return h('div', { class: `mrow ${active ? 'active' : ''}` },
        h('button', { class: 'mrow-main', type: 'button', title: 'Use this model', onClick: () => { if (settings.provider !== 'ollama') setProvider('ollama'); setModel(m.name); drawList(); } },
          h('span', { class: `lamp ${running ? 'on' : ''}`, title: running ? 'Loaded in memory' : 'Not loaded' }),
          h('span', { class: 'mrow-name' }, m.name),
          h('span', { class: 'mrow-meta' }, [m.details?.parameter_size, m.details?.quantization_level, fmtBytes(m.size)].filter(Boolean).join('  '))),
        ibtn('info', 'Model details', () => showModelDetails(m.name), 'ibtn-sm'),
        ibtn('dots', 'More', e => menu(e.currentTarget, [
          { label: 'Use this model', icon: 'check', onClick: () => { setModel(m.name); drawList(); } },
          running ? { label: 'Unload from memory', icon: 'x', onClick: async () => { await ollama.unload(m.name).catch(err => toast(err.message, { type: 'err' })); toast(`Unloaded ${m.name}`); refreshOllama(); } }
            : { label: 'Load into memory now', icon: 'zap', onClick: async () => { toast(`Loading ${m.name}…`); await ollama.load(m.name).catch(err => toast(err.message, { type: 'err' })); refreshOllama(); } },
          { label: 'Copy name', icon: 'copy', onClick: () => copyText(m.name) },
          'sep',
          { label: 'Delete from disk', icon: 'trash', danger: true, onClick: async () => { if (await confirmDialog(`Delete ${m.name} from disk? You can pull it again later.`, { okLabel: 'Delete model', danger: true })) { try { await ollama.remove(m.name); toast(`Deleted ${m.name}`, { type: 'ok' }); refreshOllama(); } catch (err) { toast(err.message, { type: 'err' }); } } } },
        ], { align: 'right' }), 'ibtn-sm'));
    }) : [h('p', { class: 'muted' }, q ? 'No models match.' : 'No models yet. Pull one below.')]));
  };
  drawList();
  const pullInput = h('input', { class: 'input mono', placeholder: 'Model to pull, e.g. llama3.1:8b', spellcheck: 'false' });
  const prog = h('div', { class: 'pull-progress', hidden: !mstate.pulling }, h('div', { class: 'bar' }, h('span')), h('small', {}));
  const pull = async () => {
    const name = pullInput.value.trim(); if (!name) return pullInput.focus();
    const ctrl = new AbortController(); mstate.pulling = { name, ctrl };
    prog.hidden = false; const bar = prog.querySelector('.bar span'), label = prog.querySelector('small');
    try {
      await ollama.pull(name, p => {
        const pct = p.total ? Math.round((p.completed || 0) / p.total * 100) : null;
        bar.style.width = pct != null ? pct + '%' : '100%'; bar.classList.toggle('indet', pct == null);
        label.textContent = `${p.status}${pct != null ? ` ${pct}% of ${fmtBytes(p.total)}` : ''}`;
      }, ctrl.signal);
      toast(`Pulled ${name}`, { type: 'ok' }); pullInput.value = '';
      refreshOllama();
    } catch (e) { if (e.name !== 'AbortError') toast(e.message, { type: 'err', timeout: 6000 }); label.textContent = e.name === 'AbortError' ? 'Cancelled' : e.message; }
    finally { mstate.pulling = null; }
  };
  pullInput.addEventListener('keydown', e => { if (e.key === 'Enter') pull(); });
  body.replaceChildren(
    (tags.models || []).length > 6 ? filter : null,
    listEl,
    mstate.ps.length ? h('p', { class: 'muted small' }, `In memory: ${mstate.ps.map(p => `${p.name} (${fmtBytes(p.size_vram || p.size)})`).join(', ')}`) : null,
    h('div', { class: 'row' }, pullInput, btn('Pull', pull, { iconName: 'download' }), btn('Cancel', () => mstate.pulling?.ctrl.abort(), { kind: 'ghost' })),
    prog,
  );
}

async function showModelDetails(name) {
  const body = h('div', { class: 'stack' }, h('p', { class: 'muted' }, 'Loading…'));
  modal({ title: name, body, wide: true, actions: [{ label: 'Close', ghost: true }] });
  try {
    const d = await ollama.show(name);
    const info = d.model_info || {};
    const ctxKey = Object.keys(info).find(k => k.endsWith('.context_length'));
    const ctxLen = ctxKey ? info[ctxKey] : null;
    const caps = d.capabilities || [];
    const rows = [['Family', d.details?.family], ['Parameters', d.details?.parameter_size], ['Quantization', d.details?.quantization_level], ['Format', d.details?.format], ['Architecture', info['general.architecture']], ['Trained context', ctxLen ? fmtNum(ctxLen) + ' tokens' : null]].filter(r => r[1]);
    const pre = (t) => h('pre', { class: 'code small' }, t || '(none)');
    body.replaceChildren(
      caps.length ? h('div', { class: 'chips' }, caps.map(c => badge(c, c === 'tools' ? 'ok' : c === 'thinking' ? 'info' : ''))) : null,
      !caps.includes('tools') && caps.length ? h('p', { class: 'hint' }, 'This model does not advertise native tool support. Use the text protocol tool mode with it.') : null,
      h('table', { class: 'kv' }, rows.map(([k, v]) => h('tr', {}, h('th', {}, k), h('td', {}, String(v))))),
      ctxLen ? h('div', { class: 'row' }, btn(`Use full context (${fmtNum(ctxLen)})`, () => { const c = getConf('ollama'); c.gen.num_ctx = { on: true, v: ctxLen }; saveSettings('provider'); render(); toast(`Context window set to ${fmtNum(ctxLen)}. Large values need a lot of memory.`); })) : null,
      section('Default parameters', pre(d.parameters), { open: true }),
      section('Prompt template', pre(d.template), { open: false }),
      section('Modelfile', pre(d.modelfile), { open: false }));
  } catch (e) { body.replaceChildren(h('p', { class: 'form-error' }, e.message)); }
}

// ── system prompt ────────────────────────────────────────────────
function allPresets() { return [...PROMPT_PRESETS, ...settings.promptPresets]; }

function systemSection() {
  const presets = allPresets();
  const current = presets.find(p => p.id === settings.activePreset);
  const dirty = !current || current.text !== settings.systemPrompt;
  const counter = h('span', { class: 'muted small' });
  const updateCount = () => { counter.textContent = `${fmtNum(settings.systemPrompt.length)} chars, about ${fmtNum(estimateTokens(settings.systemPrompt))} tokens${dirty ? ', edited' : ''}`; };
  const ta = h('textarea', { class: 'input mono sys-prompt', id: 'sys-prompt', rows: 12, spellcheck: 'false' }, settings.systemPrompt);
  let t;
  ta.addEventListener('input', () => { clearTimeout(t); t = setTimeout(() => { settings.systemPrompt = ta.value; saveSettings('system'); updateCount(); }, 250); });
  updateCount();
  const insertVar = e => menu(e.currentTarget, TEMPLATE_VARS.map(v => ({ label: v.key, hint: v.desc, onClick: () => { const s = ta.selectionStart; ta.setRangeText(v.key, s, ta.selectionEnd, 'end'); ta.dispatchEvent(new Event('input')); ta.focus(); } })));
  const sel = select([...presets.map(p => ({ value: p.id, label: p.name + (p.builtin ? '' : ' (yours)') })), ...(dirty ? [{ value: '__custom', label: 'Custom (unsaved)' }] : [])], dirty ? '__custom' : settings.activePreset, v => {
    const p = allPresets().find(x => x.id === v); if (!p) return;
    settings.activePreset = p.id; settings.systemPrompt = p.text; saveSettings('system'); rerenderSection();
  });
  const rerenderSection = () => { const old = root.querySelector('#sect-system'); old?.replaceWith(systemSection()); };
  const savePreset = async () => {
    const name = await promptDialog('Name this system prompt so you can switch back to it.', { title: 'Save prompt preset', value: current && !current.builtin ? current.name : '' });
    if (!name) return;
    const existing = settings.promptPresets.find(p => p.name === name.trim());
    if (existing) existing.text = settings.systemPrompt;
    else settings.promptPresets.push({ id: uid('pp_'), name: name.trim(), text: settings.systemPrompt });
    settings.activePreset = (existing || settings.promptPresets[settings.promptPresets.length - 1]).id;
    saveSettings('system'); toast(`Saved preset "${name.trim()}"`, { type: 'ok' }); rerenderSection();
  };
  const preview = () => {
    const c = activeConvo();
    const ctx = c ? estimateContext(c) : null;
    modal({
      title: 'System prompt as the model sees it', wide: true,
      body: h('div', { class: 'stack' }, h('p', { class: 'muted' }, 'Variables are filled in. Skills, the skill index, retrieved knowledge and the text tool protocol are added after this when they apply; see the Inspector for the full request.'),
        h('pre', { class: 'code' }, renderTemplate(settings.systemPrompt)),
        ctx ? h('p', { class: 'muted small' }, `Current chat context: about ${fmtNum(ctx.total)} of ${fmtNum(ctx.limit)} tokens.`) : null),
      actions: [{ label: 'Close', ghost: true }],
    });
  };
  const el = section('System prompt', h('div', { class: 'stack' },
    h('div', { class: 'row' }, sel,
      btn('Save as', savePreset, { iconName: 'download', title: 'Save as a named preset' }),
      ibtn('dots', 'More', e => menu(e.currentTarget, [
        { label: 'Preview with variables filled in', icon: 'eye', onClick: preview },
        { label: 'Reset to the default coding agent prompt', icon: 'rotate', onClick: () => { settings.systemPrompt = DEFAULT_SYSTEM_PROMPT; settings.activePreset = 'coding-agent'; saveSettings('system'); rerenderSection(); } },
        current && !current.builtin ? { label: `Delete preset "${current.name}"`, icon: 'trash', danger: true, onClick: () => { settings.promptPresets = settings.promptPresets.filter(p => p.id !== current.id); settings.activePreset = 'coding-agent'; saveSettings('system'); rerenderSection(); } } : null,
      ].filter(Boolean), { align: 'right' }))),
    ta,
    h('div', { class: 'row' }, h('button', { class: 'linkbtn', type: 'button', onClick: insertVar }, icon('plus', 12), 'Insert variable'), h('span', { class: 'spacer' }), counter)),
    { id: 'system', sub: 'Sent at the start of every request. Use {{variables}} for live values.' });
  el.id = 'sect-system';
  return el;
}

// ── parameters ───────────────────────────────────────────────────
function paramsSection(preset, conf) {
  const rows = h('div', { class: 'stack' });
  const profiles = h('div', { class: 'row wrap' }, h('span', { class: 'muted small' }, 'Quick profile'),
    Object.keys(SAMPLING_PROFILES).map(name => btn(name, () => {
      for (const [k, v] of Object.entries(SAMPLING_PROFILES[name])) {
        const p = PARAMS.find(x => x.key === k);
        if (p && p.for.includes(preset.type)) conf.gen[k] = { on: true, v };
      }
      saveSettings('provider'); redraw(); toast(`${name} profile applied`);
    }, { kind: 'ghost' })));
  const redraw = () => {
    rows.replaceChildren(...PARAM_GROUPS.map(g => {
      const list = PARAMS.filter(p => p.group === g);
      const applicable = list.filter(p => p.for.includes(preset.type)).length;
      return h('div', { class: 'pgroup' }, h('div', { class: 'pgroup-title' }, g, h('small', {}, `${applicable} of ${list.length} apply to ${preset.name}`)),
        list.map(p => {
          const st = conf.gen[p.key];
          const na = p.for.includes(preset.type) ? null : `Not used by ${preset.name}`;
          if (p.type === 'list') {
            return h('div', { class: `param ${st.on ? 'on' : ''} ${na ? 'na' : ''}` },
              h('div', { class: 'param-top' }, h('label', { class: 'param-label' }, h('input', { type: 'checkbox', checked: st.on, disabled: !!na, onChange: e => { st.on = e.target.checked; saveSettings('provider'); redraw(); } }), h('span', {}, p.label)), h('span', { class: 'tip', tabindex: 0, 'data-tip': p.help }, icon('info', 13)), h('span', { class: 'spacer' }), na ? h('span', { class: 'param-na' }, na) : null),
              st.on && !na ? listEditor(st.v, v => { st.v = v; saveSettings('provider'); }, 'One stop sequence per line') : null);
          }
          return paramRow({ ...p, value: st.v, on: st.on, disabledNote: na, onValue: v => { st.v = v; saveSettings('provider'); }, onToggle: o => { st.on = o; saveSettings('provider'); } });
        }));
    }));
  };
  redraw();
  return section('Generation parameters', h('div', { class: 'stack' }, h('p', { class: 'sect-sub' }, 'Checked parameters are sent with each request. Unchecked ones use the model\'s own default.'), profiles, rows),
    { id: 'params', actions: [ibtn('rotate', 'Reset parameters to defaults', () => { resetGen(); saveSettings('provider'); render(); toast('Parameters reset'); }, 'ibtn-sm')] });
}

function extrasSection(preset, conf) {
  if (preset.type === 'ollama') {
    const x = conf.extra;
    return section('Ollama options', h('div', { class: 'stack' },
      field('Thinking', segmented([{ value: 'default', label: 'Default' }, { value: 'on', label: 'On' }, { value: 'off', label: 'Off' }, { value: 'low', label: 'Low' }, { value: 'medium', label: 'Med' }, { value: 'high', label: 'High' }], x.think, v => { x.think = v; saveSettings('provider'); }, { size: 'seg-sm' }),
        'For reasoning models (qwen3, deepseek-r1, gpt-oss). Low, medium and high only work with models that support levels. Models without thinking reject "On".'),
      h('div', { class: 'param ' + (x.keep_alive.on ? 'on' : '') },
        h('div', { class: 'param-top' }, h('label', { class: 'param-label' }, h('input', { type: 'checkbox', checked: x.keep_alive.on, onChange: e => { x.keep_alive.on = e.target.checked; saveSettings('provider'); } }), h('span', {}, 'Keep model loaded for')),
          h('span', { class: 'tip', tabindex: 0, 'data-tip': 'How long Ollama keeps the model in memory after a request: "10m", "1h", "-1" for forever, "0" to unload right away.' }, icon('info', 13)), h('span', { class: 'spacer' }),
          input(x.keep_alive.v, v => { x.keep_alive.v = v.trim(); saveSettings('provider'); }, { class: 'input input-num mono', placeholder: '10m' }))),
      field('Output format', segmented([{ value: '', label: 'Free text' }, { value: 'json', label: 'JSON only' }], x.format, v => { x.format = v; saveSettings('provider'); }, { size: 'seg-sm' }), 'JSON mode forces valid JSON output. Leave it off for agent work.'),
    ), { id: 'ollama-extra', open: false });
  }
  if (preset.type === 'openai') {
    return section('Provider options', h('div', { class: 'stack' },
      field('Reasoning effort', segmented([{ value: 'default', label: 'Default' }, { value: 'minimal', label: 'Minimal' }, { value: 'low', label: 'Low' }, { value: 'medium', label: 'Medium' }, { value: 'high', label: 'High' }], conf.extra.reasoning_effort, v => { conf.extra.reasoning_effort = v; saveSettings('provider'); }, { size: 'seg-sm' }), 'Only for reasoning models. Other models reject this field, so leave it on Default for them.'),
      field('Context limit for the meter', input(settings.agent.contextLimit, v => { settings.agent.contextLimit = Math.max(1000, +v || 128000); saveSettings('agent'); }, { type: 'number', class: 'input input-num' }), 'Used only for the context meter in the header.'),
    ), { id: 'provider-extra', open: false });
  }
  return section('Provider options', h('div', { class: 'stack' },
    h('p', { class: 'sect-sub' }, 'Anthropic needs Max output tokens; it defaults to 8192 when unchecked. Temperature and Top P are not sent together.'),
    field('Context limit for the meter', input(settings.agent.contextLimit, v => { settings.agent.contextLimit = Math.max(1000, +v || 200000); saveSettings('agent'); }, { type: 'number', class: 'input input-num' })),
  ), { id: 'provider-extra', open: false });
}
