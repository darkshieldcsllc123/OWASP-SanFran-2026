// chat.js — conversation view, tool-call cards and approvals, composer with attachments and slash commands.
import { settings, saveSettings, activeConvo, saveConvo, state, newConvo } from './store.js';
import { agent } from './agent.js';
import { renderMarkdown, highlight, langFromPath } from './markdown.js';
import { h, $, icon, ibtn, esc, copyText, toast, modal, promptDialog, confirmDialog, fmtDuration, fmtNum, fmtBytes, truncate, readFileText, readFileDataURL, pickFiles, bus, menu, safeJSON, downloadFile } from './util.js';
import { fsApi } from './api.js';
import { CATEGORIES, BUILTINS, getActiveTools } from './tools.js';
import { STARTER_PROMPTS } from './defaults.js';
import { activeProvider, getConf, presetById } from './providers.js';
import { getSkill } from './skills.js';
import * as rag from './rag.js';

const ui = { expanded: new Set(), thinkingOpen: new Map(), attachments: [], forceSkills: [], stick: true, planOpen: true, slash: null };
let messagesEl, wrapEl, inputEl, sendBtn;

const STATUS = { queued: 'Queued', pending: 'Needs approval', running: 'Running', done: 'Done', error: 'Error', denied: 'Denied', cancelled: 'Cancelled' };

// ── mounting ─────────────────────────────────────────────────────
export function mountChat() {
  messagesEl = $('#messages'); wrapEl = $('#messages-wrap'); inputEl = $('#input'); sendBtn = $('#btn-send');
  wrapEl.addEventListener('scroll', () => {
    ui.stick = wrapEl.scrollHeight - wrapEl.scrollTop - wrapEl.clientHeight < 90;
    $('#jump').hidden = ui.stick;
  }, { passive: true });
  $('#jump').addEventListener('click', () => scrollBottom(true));
  messagesEl.addEventListener('click', onMessageClick);

  bus.on('convo:switch', () => { ui.attachments = []; ui.forceSkills = []; renderAttachments(); renderAll(); });
  bus.on('convo:render', c => { if (c === activeConvo()) renderAll(); });
  bus.on('convo:msg', ({ convo, msg, added }) => { if (convo === activeConvo()) updateMsg(msg, added); });
  bus.on('plan', c => { if (c === activeConvo()) renderPlan(); });
  bus.on('agent:start', updateComposer);
  bus.on('agent:end', () => { updateComposer(); document.title = 'Agent Harness'; });
  bus.on('agent:approval', ({ call }) => { if (document.hidden) document.title = `Approval needed: ${call.name}`; });
  bus.on('settings', () => { renderChips(); if (messagesEl.querySelector('.welcome')) renderAll(); });
  bus.on('kb', renderChips);
  bus.on('conn', () => { if (messagesEl.querySelector('.welcome')) renderAll(); });
  document.addEventListener('visibilitychange', () => { if (!document.hidden) document.title = 'Agent Harness'; });
  document.addEventListener('keydown', approvalKeys);
  setupComposer();
  renderAll();
}

function scrollBottom(force = false) {
  if (force) ui.stick = true;
  if (ui.stick) requestAnimationFrame(() => { wrapEl.scrollTop = wrapEl.scrollHeight; $('#jump').hidden = true; });
}

export function renderAll() {
  const c = activeConvo();
  messagesEl.replaceChildren();
  if (!c || !c.messages.length) { messagesEl.append(renderWelcome()); renderPlan(); updateComposer(); return; }
  const frag = document.createDocumentFragment();
  for (const m of c.messages) frag.append(renderMsg(m, c));
  messagesEl.append(frag);
  renderPlan(); updateComposer(); scrollBottom(true);
}

function updateMsg(msg, added) {
  const c = activeConvo(); if (!c) return;
  if (messagesEl.querySelector('.welcome')) return renderAll();
  const old = messagesEl.querySelector(`[data-id="${CSS.escape(msg.id)}"]`);
  if (!c.messages.includes(msg)) { old?.remove(); return; }
  const el = renderMsg(msg, c);
  if (old) old.replaceWith(el); else messagesEl.append(el);
  if (added) {
    const prev = c.messages[c.messages.indexOf(msg) - 1];
    const pe = prev && messagesEl.querySelector(`[data-id="${CSS.escape(prev.id)}"]`);
    if (pe) pe.replaceWith(renderMsg(prev, c));
  }
  scrollBottom();
}

// ── welcome ──────────────────────────────────────────────────────
function renderWelcome() {
  const { preset, conf } = activeProvider();
  const conn = state.conn || {};
  const tools = getActiveTools();
  const checks = [
    { ok: !!state.info, label: state.info ? `Workspace: ${state.info.root}` : 'Harness server not reachable', fix: state.info ? null : 'Run start.sh or start.bat, then reload this page.' },
    { ok: conn.ok, warn: conn.ok == null, label: conn.label || `Connecting to ${preset.name}…`, fix: conn.fix, act: conn.ok ? null : ['Open model settings', () => bus.emit('panel:open', { tab: 'model' })] },
    { ok: !!conf.model, label: conf.model ? `Model: ${conf.model}` : 'No model selected', act: conf.model ? null : ['Choose a model', () => bus.emit('panel:open', { tab: 'model', focus: 'model' })] },
    { ok: true, label: settings.agent.toolMode === 'off' ? 'Tools are off' : `${tools.length} tools ready${state.info?.exec === false ? ' (shell disabled)' : ''}` },
  ];
  return h('div', { class: 'welcome' },
    h('div', { class: 'welcome-head' },
      h('h1', {}, 'What should the agent build?'),
      h('p', {}, 'It reads and writes files in your workspace, runs commands with your approval, and uses the skills and knowledge you add.')),
    h('ul', { class: 'checks' }, checks.map(ch => h('li', { class: `check ${ch.ok ? 'ok' : ch.warn ? 'wait' : 'bad'}` },
      h('span', { class: 'check-mark' }, icon(ch.ok ? 'check' : ch.warn ? 'refresh' : 'x', 13)),
      h('span', { class: 'check-text' }, ch.label, ch.fix ? h('small', {}, ch.fix) : null),
      ch.act ? h('button', { class: 'btn btn-sm', type: 'button', onClick: ch.act[1] }, ch.act[0]) : null))),
    h('div', { class: 'starters' }, STARTER_PROMPTS.map(s => h('button', { class: 'starter', type: 'button', onClick: () => { inputEl.value = s.text; autosize(); inputEl.focus(); } },
      h('strong', {}, s.title), h('span', {}, s.text)))));
}

// ── messages ─────────────────────────────────────────────────────
function renderMsg(m, c) {
  if (m.role === 'notice') {
    return h('div', { class: `notice notice-${m.level || 'info'}`, dataset: { id: m.id } }, icon(m.level === 'info' ? 'info' : 'alert', 14), h('span', {}, m.content));
  }
  if (m.role === 'user') return renderUser(m, c);
  return renderAssistant(m, c);
}

const lastRealIdx = c => { for (let i = c.messages.length - 1; i >= 0; i--) if (c.messages[i].role !== 'notice') return i; return -1; };

function actionsFor(m, c) {
  const isLast = c.messages.indexOf(m) === lastRealIdx(c);
  const busy = agent.running;
  const b = [ibtn('copy', 'Copy', null, 'ibtn-sm')];
  b[0].dataset.act = 'copy-msg';
  if (m.role === 'user' && !busy) { const e = ibtn('edit', 'Edit and resend', null, 'ibtn-sm'); e.dataset.act = 'edit-msg'; b.push(e); }
  if (m.role === 'assistant' && isLast && !busy) {
    const r = ibtn('rotate', 'Regenerate', null, 'ibtn-sm'); r.dataset.act = 'regen'; b.push(r);
    const k = h('button', { class: 'btn btn-xs btn-ghost', type: 'button', dataset: { act: 'continue' }, title: 'Run the agent again from here' }, icon('play', 12), 'Continue'); b.push(k);
  }
  if (!busy) { const d = ibtn('trash', 'Delete message', null, 'ibtn-sm'); d.dataset.act = 'delete-msg'; b.push(d); }
  return h('div', { class: 'msg-actions' }, b);
}

function renderUser(m, c) {
  const body = h('div', { class: 'msg-body' }, h('div', { class: 'md', html: renderMarkdown(m.content) }));
  if (m.attachments?.length) body.append(h('div', { class: 'att-list' }, m.attachments.map(a => a.kind === 'image'
    ? h('img', { class: 'att-img', src: a.dataUrl, alt: a.name, title: a.name })
    : h('span', { class: 'att' }, icon('file', 13), a.name, h('small', {}, fmtBytes(a.size))))));
  const chips = [];
  if (m.forceSkills?.length) chips.push(h('span', { class: 'chip chip-static' }, icon('book', 12), `Skill: ${m.forceSkills.join(', ')}`));
  if (m.rag?.length || m.ragNote) chips.push(h('button', { class: 'chip', type: 'button', dataset: { act: 'toggle-rag' } }, icon('database', 12), m.rag?.length ? `${m.rag.length} excerpts from Knowledge` : 'Knowledge', icon(ui.expanded.has('rag:' + m.id) ? 'chevronDown' : 'chevronRight', 12)));
  if (chips.length) body.append(h('div', { class: 'chips' }, chips));
  if (ui.expanded.has('rag:' + m.id)) body.append(h('div', { class: 'rag-list' },
    m.ragNote ? h('p', { class: 'muted' }, m.ragNote) : null,
    (m.rag || []).map((r, i) => h('div', { class: 'rag-item' },
      h('div', { class: 'rag-item-head' }, h('strong', {}, `[${i + 1}] ${r.docName}`), r.line ? h('small', {}, `line ${r.line}`) : null, h('span', { class: 'spacer' }), h('small', { class: 'mono' }, r.score.toFixed(3))),
      h('pre', {}, truncate(r.text, 600))))));
  return h('div', { class: 'msg msg-user', dataset: { id: m.id } }, h('div', { class: 'msg-who' }, 'You'), body, actionsFor(m, c));
}

const stripToolMarkup = t => String(t || '').replace(/<tool_call>[\s\S]*?(<\/tool_call>|$)/g, '').replace(/<(t(o(o(l(_(c(a(l(l)?)?)?)?)?)?)?)?)?$/, '');

function renderAssistant(m, c) {
  const i = c.messages.indexOf(m);
  const cont = i > 0 && c.messages[i - 1].role === 'assistant';
  const el = h('div', { class: `msg msg-assistant${cont ? ' cont' : ''}${m.streaming ? ' streaming' : ''}`, dataset: { id: m.id } });
  if (!cont) el.append(h('div', { class: 'msg-who' }, h('span', { class: 'who-lamp' }), m.meta?.model || 'Assistant', m.meta?.provider ? h('small', {}, m.meta.provider) : null));
  const body = h('div', { class: 'msg-body' });
  if (m.thinking && settings.agent.showThinking) body.append(renderThinking(m));
  const visible = m.streaming ? stripToolMarkup(m.content) : m.content;
  if (visible?.trim()) body.append(h('div', { class: 'md', html: renderMarkdown(visible) }));
  else if (m.streaming && !m.thinking && !m.partialCalls?.length) body.append(h('div', { class: 'typing', 'aria-label': 'Waiting for the model' }, h('i'), h('i'), h('i')));
  for (const p of m.partialCalls || []) body.append(h('div', { class: 'tc tc-preparing' }, h('div', { class: 'tc-head' }, h('span', { class: 'tc-ico' }, icon('tool', 14)), h('span', { class: 'tc-name' }, p.name || 'tool'), h('span', { class: 'tc-sum' }, `writing arguments (${fmtNum(p.argsText.length)} chars)`))));
  if (m.toolCalls?.length) body.append(h('div', { class: 'tcs' }, m.toolCalls.map(call => renderCall(call))));
  if (m.error) body.append(h('div', { class: 'msg-error' }, icon('alert', 16),
    h('div', {}, h('strong', {}, 'The request failed'), h('p', {}, m.error), errorHint(m.error)),
    h('button', { class: 'btn btn-sm', type: 'button', dataset: { act: 'retry' } }, icon('rotate', 13), 'Retry')));
  if (m.stopped) body.append(h('div', { class: 'msg-stopped' }, icon('stop', 12), 'Stopped by you'));
  el.append(body);
  if (!m.streaming) {
    const meta = metaLine(m);
    el.append(h('div', { class: 'msg-foot' }, meta, actionsFor(m, c)));
  }
  return el;
}

function metaLine(m) {
  const u = m.meta?.usage || {};
  const bits = [];
  if (u.input != null || u.output != null) bits.push(`${fmtNum(u.input ?? 0)} in, ${fmtNum(u.output ?? 0)} out`);
  if (u.tps) bits.push(`${u.tps.toFixed(u.tps < 10 ? 1 : 0)} tok/s`);
  if (m.meta?.ttft != null) bits.push(`first token ${fmtDuration(m.meta.ttft)}`);
  if (m.meta?.ms) bits.push(fmtDuration(m.meta.ms));
  if (m.meta?.skills?.length) bits.push(`skills: ${m.meta.skills.join(', ')}`);
  const cut = m.meta?.stopReason && /length|max_tokens/.test(m.meta.stopReason);
  return h('div', { class: 'msg-meta' }, bits.map(b => h('span', {}, b)), cut ? h('span', { class: 'warn-text' }, 'Cut off at the output token limit') : null);
}

function errorHint(msg) {
  let t = '';
  if (/11434|ollama/i.test(msg) && /reach|ECONNREFUSED/i.test(msg)) t = 'Start Ollama with "ollama serve", or check the base URL in the Model panel.';
  else if (/\b(401|403)\b|api key|authentication|unauthorized|x-api-key/i.test(msg)) t = 'Check the API key in the Model panel, or put it in the .env file next to server.js.';
  else if (/not found|\b404\b|does not exist|unknown model/i.test(msg)) t = 'The model name may be wrong. Open the Model panel and fetch the list of models.';
  else if (/context|too long|maximum.*tokens|token limit/i.test(msg)) t = 'The conversation is too long for this model. Start a new chat, or raise the context window.';
  else if (/\b429\b|rate limit|quota/i.test(msg)) t = 'The provider is rate limiting you. Wait a moment and retry.';
  else if (/not responding|harness server/i.test(msg)) t = 'Restart the harness with start.sh or start.bat.';
  return t ? h('p', { class: 'hint' }, t) : null;
}

function renderThinking(m) {
  const live = m.streaming && !m.content;
  const open = ui.thinkingOpen.has(m.id) ? ui.thinkingOpen.get(m.id) : live;
  const d = h('details', { class: `thinking${live ? ' live' : ''}`, open });
  const words = (m.thinking.match(/\S+/g) || []).length;
  const sum = h('summary', {}, icon('bulb', 14), live ? 'Thinking' : 'Thought process', h('small', {}, `${words} words`));
  sum.addEventListener('click', () => ui.thinkingOpen.set(m.id, !d.open));
  d.append(sum, h('div', { class: 'thinking-body' }, m.thinking));
  return d;
}

// ── tool calls ───────────────────────────────────────────────────
function toolMeta(name) {
  const b = BUILTINS.find(t => t.name === name);
  if (b) return b;
  const c = settings.tools.custom.find(t => t.name === name);
  return c ? { category: 'custom' } : null;
}

function argSummary(call) {
  const a = call.args || {};
  const s = a.path ?? a.command ?? a.query ?? a.url ?? a.pattern ?? a.name ?? a.from ?? Object.values(a).find(v => typeof v === 'string');
  if (call.name === 'update_plan' && Array.isArray(a.steps)) return `${a.steps.length} steps`;
  if (call.name === 'move_path') return `${a.from} to ${a.to}`;
  return s != null ? truncate(String(s).replace(/\s+/g, ' '), 90) : '';
}

function renderCall(call) {
  const meta = toolMeta(call.name);
  const cat = CATEGORIES[meta?.category || 'custom'];
  const open = call.status === 'pending' || ui.expanded.has(call.id);
  const dur = call.endedAt && call.startedAt ? fmtDuration(call.endedAt - call.startedAt) : '';
  const el = h('div', { class: `tc tc-${call.status}${open ? ' open' : ''}`, dataset: { call: call.id } });
  el.append(h('button', { class: 'tc-head', type: 'button', dataset: { act: 'toggle-call' }, 'aria-expanded': String(open) },
    h('span', { class: 'tc-ico' }, icon(cat?.icon || 'tool', 14)),
    h('span', { class: 'tc-name' }, call.name),
    h('span', { class: 'tc-sum' }, argSummary(call)),
    h('span', { class: `tc-status st-${call.status}` }, STATUS[call.status] || call.status),
    dur ? h('span', { class: 'tc-time' }, dur) : null,
    icon('chevronDown', 14)));
  if (open) el.append(renderCallBody(call));
  return el;
}

const pre = (html, cls = '') => h('pre', { class: `code ${cls}`, html });

function argsView(call) {
  const a = call.args || {};
  if (call.name === 'edit_file' && typeof a.old_str === 'string') {
    const diff = a.old_str.split('\n').map(l => '- ' + l).join('\n') + '\n' + String(a.new_str ?? '').split('\n').map(l => '+ ' + l).join('\n');
    return [h('div', { class: 'tc-label' }, `Change in ${a.path}${a.replace_all ? ' (every occurrence)' : ''}`), pre(highlight(diff, 'diff'))];
  }
  if (call.name === 'write_file' && typeof a.content === 'string') {
    return [h('div', { class: 'tc-label' }, `${a.path}, ${a.content.split('\n').length} lines`), pre(highlight(a.content, langFromPath(a.path || '')))];
  }
  if (call.name === 'run_command') return [h('div', { class: 'tc-label' }, `Command${a.cwd && a.cwd !== '.' ? ` in ${a.cwd}` : ''}`), h('pre', { class: 'code term', html: `<span class="prompt">$</span> ${esc(a.command)}` })];
  return [h('div', { class: 'tc-label' }, 'Arguments'), pre(highlight(JSON.stringify(a, null, 2), 'json'))];
}

function renderCallBody(call) {
  const body = h('div', { class: 'tc-body' }, argsView(call));
  if (call.status === 'pending') {
    body.append(h('div', { class: 'approve-bar' },
      h('span', { class: 'approve-q' }, icon('shield', 14), `Allow ${call.name}?`),
      h('button', { class: 'btn btn-sm btn-primary', type: 'button', dataset: { act: 'approve' } }, icon('play', 12), 'Run', h('kbd', {}, 'Y')),
      h('button', { class: 'btn btn-sm', type: 'button', dataset: { act: 'approve-always' }, title: `Allow ${call.name} without asking until you reload` }, 'Always allow', h('kbd', {}, 'A')),
      h('button', { class: 'btn btn-sm btn-ghost', type: 'button', dataset: { act: 'edit-args' } }, icon('edit', 12), 'Edit arguments'),
      h('button', { class: 'btn btn-sm btn-danger-ghost', type: 'button', dataset: { act: 'deny' } }, 'Deny', h('kbd', {}, 'N'))));
  }
  if (call.status === 'running') body.append(h('div', { class: 'tc-run-ind' }, h('span', { class: 'spin' }), 'Running'));
  if (call.result != null) {
    const isTerm = call.name === 'run_command';
    body.append(h('div', { class: 'tc-label' }, 'Result', h('button', { class: 'linkbtn', type: 'button', dataset: { act: 'copy-result' } }, 'Copy')),
      h('pre', { class: `code result ${isTerm ? 'term' : ''} ${call.status === 'error' ? 'is-error' : ''}` }, String(call.result)));
  }
  return body;
}

function approvalKeys(e) {
  if (e.ctrlKey || e.metaKey || e.altKey) return;
  const tag = (e.target.tagName || '').toLowerCase();
  if (tag === 'textarea' || tag === 'input' || tag === 'select' || e.target.isContentEditable) return;
  const c = activeConvo(); if (!c || !agent.running) return;
  const call = c.messages.flatMap(m => m.toolCalls || []).find(x => x.status === 'pending');
  if (!call) return;
  const k = e.key.toLowerCase();
  if (k === 'y') { e.preventDefault(); agent.resolveApproval(call.id, { action: 'approve' }); }
  else if (k === 'a') { e.preventDefault(); agent.resolveApproval(call.id, { action: 'always' }); }
  else if (k === 'n') { e.preventDefault(); agent.resolveApproval(call.id, { action: 'deny' }); }
}

// ── click actions ────────────────────────────────────────────────
async function onMessageClick(e) {
  const t = e.target.closest('[data-act]'); if (!t) return;
  const c = activeConvo(); if (!c) return;
  const msgEl = t.closest('[data-id]');
  const m = msgEl && c.messages.find(x => x.id === msgEl.dataset.id);
  const callEl = t.closest('[data-call]');
  const call = callEl && m?.toolCalls?.find(x => x.id === callEl.dataset.call);
  const rerender = () => m && updateMsg(m);
  switch (t.dataset.act) {
    case 'copy-code': return copyText(t.closest('.codeblock').querySelector('code').textContent);
    case 'save-code': return saveCode(t.closest('.codeblock'));
    case 'copy-msg': return copyText(m.role === 'assistant' ? m.content + (m.toolCalls?.length ? '\n\n' + m.toolCalls.map(x => `[${x.name}] ${JSON.stringify(x.args)}`).join('\n') : '') : m.content);
    case 'copy-result': return copyText(String(call?.result ?? ''));
    case 'toggle-call': if (!call || call.status === 'pending') return; ui.expanded.has(call.id) ? ui.expanded.delete(call.id) : ui.expanded.add(call.id); return rerender();
    case 'toggle-rag': { const k = 'rag:' + m.id; ui.expanded.has(k) ? ui.expanded.delete(k) : ui.expanded.add(k); return rerender(); }
    case 'approve': return agent.resolveApproval(call.id, { action: 'approve' });
    case 'approve-always': return agent.resolveApproval(call.id, { action: 'always' });
    case 'deny': {
      const reason = await promptDialog('Optionally tell the agent why, so it can adjust.', { title: `Deny ${call.name}`, placeholder: 'Reason (optional)', okLabel: 'Deny' });
      if (reason === null) return;
      return agent.resolveApproval(call.id, { action: 'deny', reason: reason.trim() });
    }
    case 'edit-args': return editArgs(call);
    case 'regen': return agent.regenerate(c);
    case 'continue': return agent.run(c);
    case 'retry': {
      const i = c.messages.indexOf(m);
      if (i > -1 && m.error) c.messages.splice(i, 1);
      renderAll(); return agent.run(c);
    }
    case 'delete-msg': {
      c.messages.splice(c.messages.indexOf(m), 1); saveConvo(c); return renderAll();
    }
    case 'edit-msg': return startEdit(msgEl, m, c);
  }
}

function startEdit(msgEl, m, c) {
  const md = msgEl.querySelector('.md');
  const ta = h('textarea', { class: 'input edit-area', rows: Math.min(14, m.content.split('\n').length + 1) }, m.content);
  const bar = h('div', { class: 'edit-bar' },
    h('button', { class: 'btn btn-sm btn-ghost', type: 'button', onClick: () => renderAll() }, 'Cancel'),
    h('button', { class: 'btn btn-sm btn-primary', type: 'button', onClick: () => agent.editAndResend(c, m.id, ta.value) }, 'Save and resend'));
  md.replaceWith(h('div', { class: 'editing' }, ta, bar));
  ta.focus(); ta.setSelectionRange(ta.value.length, ta.value.length);
  ta.addEventListener('keydown', e => { if (e.key === 'Enter' && (e.ctrlKey || e.metaKey)) agent.editAndResend(c, m.id, ta.value); if (e.key === 'Escape') renderAll(); });
}

function editArgs(call) {
  const ta = h('textarea', { class: 'input mono', rows: 16, spellcheck: 'false' }, JSON.stringify(call.args || {}, null, 2));
  const err = h('p', { class: 'form-error' });
  modal({
    title: `Edit arguments for ${call.name}`, wide: true,
    body: h('div', { class: 'stack' }, h('p', { class: 'modal-text' }, 'Change the arguments, then run the tool with your version. The model will see the result of your edited call.'), ta, err),
    actions: [{ label: 'Cancel', ghost: true }, { label: 'Run with these arguments', primary: true, onClick: () => {
      const j = safeJSON(ta.value);
      if (!j || typeof j !== 'object') { err.textContent = 'That is not a valid JSON object.'; return false; }
      agent.resolveApproval(call.id, { action: 'approve', args: j });
    } }],
  });
}

async function saveCode(block) {
  const code = block.querySelector('code').textContent;
  const lang = block.dataset.lang || 'txt';
  const first = code.split('\n')[0];
  const guess = (first.match(/^\s*(?:\/\/|#|--|<!--)\s*([\w./-]+\.[a-z0-9]+)/i) || [])[1];
  const ext = { js: 'js', javascript: 'js', ts: 'ts', typescript: 'ts', py: 'py', python: 'py', sh: 'sh', bash: 'sh', html: 'html', css: 'css', json: 'json', md: 'md', go: 'go', rust: 'rs', java: 'java', yaml: 'yml', sql: 'sql' }[lang] || 'txt';
  const path = await promptDialog('Path relative to the workspace. Existing files are overwritten.', { title: 'Save code to workspace', value: guess || `snippet.${ext}`, okLabel: 'Save file' });
  if (!path) return;
  try { const r = await fsApi.write(path.trim(), code.endsWith('\n') ? code : code + '\n'); toast(`Saved ${r.path}`, { type: 'ok' }); bus.emit('workspace:changed', {}); }
  catch (e) { toast(e.message, { type: 'err' }); }
}

// ── plan ─────────────────────────────────────────────────────────
function renderPlan() {
  const el = $('#plan'); const c = activeConvo();
  const steps = c?.plan?.steps || [];
  if (!steps.length) { el.hidden = true; el.replaceChildren(); return; }
  const done = steps.filter(s => s.status === 'done').length;
  el.hidden = false;
  el.replaceChildren(
    h('div', { class: 'plan-head' },
      h('button', { class: 'plan-toggle', type: 'button', 'aria-expanded': String(ui.planOpen), onClick: () => { ui.planOpen = !ui.planOpen; renderPlan(); } },
        icon(ui.planOpen ? 'chevronDown' : 'chevronRight', 14), h('strong', {}, 'Plan'), h('span', { class: 'plan-count' }, `${done} of ${steps.length} done`),
        h('span', { class: 'plan-bar' }, h('span', { style: { width: `${(done / steps.length) * 100}%` } }))),
      ibtn('x', 'Clear plan', () => { c.plan = null; saveConvo(c); renderPlan(); }, 'ibtn-sm')),
    ui.planOpen ? h('ol', { class: 'plan-steps' }, steps.map(s => h('li', { class: `ps ps-${s.status}` }, h('span', { class: 'ps-mark' }, s.status === 'done' ? icon('check', 11) : null), h('span', {}, s.title)))) : null);
}

// ── composer ─────────────────────────────────────────────────────
function autosize() { inputEl.style.height = 'auto'; inputEl.style.height = Math.min(inputEl.scrollHeight, window.innerHeight * 0.4) + 'px'; }

function updateComposer() {
  const running = agent.running;
  sendBtn.classList.toggle('stop', running);
  sendBtn.replaceChildren(icon(running ? 'stop' : 'send', 15), h('span', {}, running ? 'Stop' : 'Send'));
  sendBtn.title = running ? 'Stop the agent (Esc)' : 'Send (Enter)';
  $('#composer').classList.toggle('running', running);
}

function setupComposer() {
  inputEl.addEventListener('input', () => { autosize(); updateSlash(); });
  inputEl.addEventListener('keydown', e => {
    if (ui.slash && slashKey(e)) return;
    if (e.key === 'Enter' && !e.shiftKey && !e.isComposing) { e.preventDefault(); if (!agent.running) send(); }
    if (e.key === 'Escape' && agent.running) { e.preventDefault(); agent.stop(); }
  });
  inputEl.addEventListener('blur', () => setTimeout(closeSlash, 150));
  sendBtn.addEventListener('click', () => (agent.running ? agent.stop() : send()));
  $('#btn-attach').addEventListener('click', async () => addFiles(await pickFiles()));
  const main = $('#main');
  main.addEventListener('dragover', e => { if (e.dataTransfer?.types.includes('Files')) { e.preventDefault(); main.classList.add('drop'); } });
  main.addEventListener('dragleave', e => { if (!main.contains(e.relatedTarget)) main.classList.remove('drop'); });
  main.addEventListener('drop', e => { e.preventDefault(); main.classList.remove('drop'); addFiles([...(e.dataTransfer?.files || [])]); });
  inputEl.addEventListener('paste', e => { const files = [...(e.clipboardData?.files || [])]; if (files.length) { e.preventDefault(); addFiles(files); } });
  updateComposer(); renderChips();
}

export function focusComposer() { inputEl?.focus(); }
export function setComposer(text) { inputEl.value = text; autosize(); inputEl.focus(); }

export async function addFiles(files) {
  for (const f of files) {
    try {
      if (f.type.startsWith('image/')) {
        if (f.size > 8 * 1024 * 1024) { toast(`${f.name} is larger than 8 MB`, { type: 'warn' }); continue; }
        ui.attachments.push({ kind: 'image', name: f.name, size: f.size, mime: f.type, dataUrl: await readFileDataURL(f) });
      } else {
        if (f.size > 1024 * 1024) { toast(`${f.name} is larger than 1 MB; attach a smaller text file or add it to Knowledge`, { type: 'warn' }); continue; }
        const text = await readFileText(f);
        if (text.includes('\u0000')) { toast(`${f.name} looks binary and was skipped`, { type: 'warn' }); continue; }
        ui.attachments.push({ kind: 'text', name: f.name, size: f.size, text });
      }
    } catch (e) { toast(`Could not read ${f.name}: ${e.message}`, { type: 'err' }); }
  }
  renderAttachments();
}
export function attachText(name, text) { ui.attachments.push({ kind: 'text', name, size: text.length, text }); renderAttachments(); inputEl.focus(); }

function renderAttachments() {
  const el = $('#attachments');
  el.replaceChildren(...ui.attachments.map((a, i) => h('span', { class: 'att att-pending' },
    a.kind === 'image' ? h('img', { src: a.dataUrl, alt: '' }) : icon('file', 13), a.name, h('small', {}, fmtBytes(a.size)),
    ibtn('x', `Remove ${a.name}`, () => { ui.attachments.splice(i, 1); renderAttachments(); }, 'ibtn-xs'))),
    ...ui.forceSkills.map((s, i) => h('span', { class: 'att att-skill' }, icon('book', 13), `Skill: ${s}`, ibtn('x', 'Remove skill', () => { ui.forceSkills.splice(i, 1); renderAttachments(); }, 'ibtn-xs'))));
  el.hidden = !el.children.length;
}

function chip(iconName, label, onClick, title) {
  return h('button', { class: 'chip', type: 'button', title: title || label, onClick }, icon(iconName, 12), label);
}

export function renderChips() {
  const el = $('#composer-chips'); if (!el) return;
  const tm = settings.agent.toolMode, n = getActiveTools().length;
  const setAgent = (k, v) => { settings.agent[k] = v; saveSettings('agent'); };
  const items = [
    chip('tool', tm === 'off' ? 'Tools off' : `${n} tools${tm === 'text' ? ', text protocol' : ''}`, e => menu(e.currentTarget, [
      { label: 'Native tool calling', icon: tm === 'native' ? 'check' : null, onClick: () => setAgent('toolMode', 'native') },
      { label: 'Text protocol (any model)', icon: tm === 'text' ? 'check' : null, onClick: () => setAgent('toolMode', 'text') },
      { label: 'No tools (plain chat)', icon: tm === 'off' ? 'check' : null, onClick: () => setAgent('toolMode', 'off') },
      'sep', { label: 'Manage tools', icon: 'sliders', onClick: () => bus.emit('panel:open', { tab: 'tools' }) },
    ]), 'How the model calls tools'),
    chip('shield', { all: 'Ask before every tool', risky: 'Ask before changes', none: 'Never ask' }[settings.agent.approval], e => menu(e.currentTarget, [
      { label: 'Ask before every tool', icon: settings.agent.approval === 'all' ? 'check' : null, onClick: () => setAgent('approval', 'all') },
      { label: 'Ask before writes, shell and network', icon: settings.agent.approval === 'risky' ? 'check' : null, onClick: () => setAgent('approval', 'risky') },
      { label: 'Never ask (run everything)', icon: settings.agent.approval === 'none' ? 'check' : null, onClick: () => setAgent('approval', 'none') },
    ]), 'When to ask for your approval'),
  ];
  if (rag.kb.docs.length) items.push(chip('database', settings.rag.autoInject ? 'Knowledge on' : 'Knowledge off', () => { settings.rag.autoInject = !settings.rag.autoInject; saveSettings('rag'); }, 'Automatically add relevant knowledge excerpts to each message'));
  const { preset, conf } = activeProvider();
  if (preset.type === 'ollama') {
    const th = conf.extra.think;
    items.push(chip('bulb', th === 'default' ? 'Thinking: model default' : `Thinking: ${th}`, e => menu(e.currentTarget, ['default', 'on', 'off', 'low', 'medium', 'high'].map(v => ({
      label: v === 'default' ? 'Model default' : v[0].toUpperCase() + v.slice(1), icon: th === v ? 'check' : null,
      onClick: () => { getConf('ollama').extra.think = v; saveSettings('provider'); },
    }))), 'Ollama think setting (for reasoning models)'));
  }
  el.replaceChildren(...items);
}

// ── slash commands ───────────────────────────────────────────────
const COMMANDS = [
  { cmd: '/new', desc: 'Start a new chat', run: () => newConvo() },
  { cmd: '/clear', desc: 'Remove every message in this chat', run: async () => { const c = activeConvo(); if (c && await confirmDialog('Remove every message in this chat?', { okLabel: 'Clear chat', danger: true })) { c.messages = []; c.plan = null; saveConvo(c); renderAll(); } } },
  { cmd: '/skill', arg: 'name', desc: 'Apply a skill to your next message', complete: () => settings.skills.filter(s => s.enabled).map(s => s.name), run: name => { const s = getSkill(name); if (!s) return toast(`No enabled skill named "${name}"`, { type: 'warn' }); if (!ui.forceSkills.includes(s.name)) ui.forceSkills.push(s.name); renderAttachments(); } },
  { cmd: '/model', arg: 'name', desc: 'Switch the model for the current provider', complete: () => (state.models?.[settings.provider] || []).map(m => m.id), run: name => { if (!name) return; getConf().model = name; saveSettings('provider'); bus.emit('model:changed'); toast(`Model set to ${name}`, { type: 'ok' }); } },
  { cmd: '/rag', arg: 'query', desc: 'Search the knowledge base', run: q => showRagResults(q) },
  { cmd: '/system', desc: 'Edit the system prompt', run: () => bus.emit('panel:open', { tab: 'model', focus: 'system' }) },
  { cmd: '/export', desc: 'Download this chat as Markdown', run: () => exportChat(activeConvo()) },
  { cmd: '/help', desc: 'Show keyboard shortcuts', run: () => bus.emit('help') },
];

function parseSlash(v) {
  const m = v.match(/^(\/\w*)(?:\s+([\s\S]*))?$/);
  return m ? { cmd: m[1], arg: m[2], hasSpace: /\s/.test(v) } : null;
}

function updateSlash() {
  const v = inputEl.value;
  if (!v.startsWith('/') || v.includes('\n')) return closeSlash();
  const p = parseSlash(v); if (!p) return closeSlash();
  let items;
  if (!p.hasSpace) items = COMMANDS.filter(c => c.cmd.startsWith(p.cmd)).map(c => ({ label: c.cmd + (c.arg ? ` <${c.arg}>` : ''), desc: c.desc, value: c.cmd + (c.arg ? ' ' : ''), run: !c.arg ? c : null }));
  else {
    const c = COMMANDS.find(x => x.cmd === p.cmd);
    if (!c?.complete) return closeSlash();
    const q = (p.arg || '').toLowerCase();
    items = c.complete().filter(n => n.toLowerCase().includes(q)).slice(0, 12).map(n => ({ label: n, desc: '', value: `${c.cmd} ${n}`, run: null, final: true }));
  }
  if (!items.length) return closeSlash();
  ui.slash = { items, i: Math.min(ui.slash?.i || 0, items.length - 1) };
  drawSlash();
}
function drawSlash() {
  const pop = $('#slash-pop');
  pop.hidden = false;
  pop.replaceChildren(...ui.slash.items.map((it, i) => h('button', { class: `slash-item ${i === ui.slash.i ? 'on' : ''}`, type: 'button', onMouseDown: e => { e.preventDefault(); ui.slash.i = i; pickSlash(); } },
    h('span', { class: 'slash-cmd' }, it.label), it.desc ? h('span', { class: 'slash-desc' }, it.desc) : null)));
}
function closeSlash() { ui.slash = null; const p = $('#slash-pop'); if (p) p.hidden = true; }
function pickSlash() {
  const it = ui.slash.items[ui.slash.i];
  inputEl.value = it.value; autosize();
  if (it.run || it.final) { closeSlash(); send(); return; }
  updateSlash();
}
function slashKey(e) {
  if (e.key === 'ArrowDown') { e.preventDefault(); ui.slash.i = (ui.slash.i + 1) % ui.slash.items.length; drawSlash(); return true; }
  if (e.key === 'ArrowUp') { e.preventDefault(); ui.slash.i = (ui.slash.i - 1 + ui.slash.items.length) % ui.slash.items.length; drawSlash(); return true; }
  if (e.key === 'Tab' || (e.key === 'Enter' && !e.shiftKey)) { e.preventDefault(); pickSlash(); return true; }
  if (e.key === 'Escape') { e.preventDefault(); closeSlash(); return true; }
  return false;
}

async function send() {
  const text = inputEl.value.trim();
  if (text.startsWith('/') && !text.includes('\n')) {
    const p = parseSlash(text);
    const c = p && COMMANDS.find(x => x.cmd === p.cmd);
    if (c) { inputEl.value = ''; autosize(); closeSlash(); await c.run((p.arg || '').trim()); return; }
  }
  if (!text && !ui.attachments.length) return;
  const convo = activeConvo() || newConvo();
  const attachments = ui.attachments.splice(0), forceSkills = ui.forceSkills.splice(0);
  inputEl.value = ''; autosize(); renderAttachments();
  ui.stick = true;
  agent.send(convo, { text, attachments, forceSkills });
}

async function showRagResults(q) {
  if (!q) return toast('Add a query, like /rag how is auth handled', { type: 'warn' });
  if (!rag.kb.docs.length) return toast('The knowledge base is empty. Add documents in the Knowledge panel.', { type: 'warn' });
  const r = await rag.search(q, { k: 8 });
  modal({
    title: `Knowledge results for "${truncate(q, 40)}"`, wide: true,
    body: h('div', { class: 'stack' }, h('p', { class: 'muted' }, `Mode: ${r.mode}${r.note ? `. ${r.note}` : ''}`),
      r.results.length ? r.results.map((x, i) => h('div', { class: 'rag-item' }, h('div', { class: 'rag-item-head' }, h('strong', {}, `[${i + 1}] ${x.docName}`), x.line ? h('small', {}, `line ${x.line}`) : null, h('span', { class: 'spacer' }), h('small', { class: 'mono' }, x.score.toFixed(3))), h('pre', {}, truncate(x.text, 900))))
        : h('p', {}, 'No matches.')),
    actions: [{ label: 'Close', ghost: true }],
  });
}

export function exportChat(c) {
  if (!c) return;
  const lines = [`# ${c.title}`, '', `Exported ${new Date().toLocaleString()}`, ''];
  for (const m of c.messages) {
    if (m.role === 'user') lines.push('## You', '', m.content, '');
    else if (m.role === 'assistant') {
      lines.push(`## ${m.meta?.model || 'Assistant'}`, '');
      if (m.content) lines.push(m.content, '');
      for (const t of m.toolCalls || []) lines.push(`**Tool: ${t.name}** (${t.status})`, '', '```json', JSON.stringify(t.args, null, 2), '```', '', '```', String(t.result ?? ''), '```', '');
      if (m.error) lines.push(`> Error: ${m.error}`, '');
    } else if (m.role === 'notice') lines.push(`> ${m.content}`, '');
  }
  downloadFile(`${c.title.replace(/[^\w-]+/g, '-').slice(0, 50) || 'chat'}.md`, lines.join('\n'), 'text/markdown');
}
