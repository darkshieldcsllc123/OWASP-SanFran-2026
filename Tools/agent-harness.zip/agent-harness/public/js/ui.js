// ui.js — small form/layout components used by the panels.
import { h, icon, debounce, clamp } from './util.js';

const openState = JSON.parse(sessionStorage.getItem('harness.sections') || '{}');

/** Collapsible section. */
export function section(title, body, { id, open = true, actions = [], count, sub } = {}) {
  const isOpen = id && id in openState ? openState[id] : open;
  const el = h('section', { class: `sect ${isOpen ? 'open' : ''}` });
  const head = h('div', { class: 'sect-head' },
    h('button', { class: 'sect-toggle', type: 'button', 'aria-expanded': String(isOpen), onClick: () => {
      const now = !el.classList.contains('open');
      el.classList.toggle('open', now); head.querySelector('.sect-toggle').setAttribute('aria-expanded', String(now));
      if (id) { openState[id] = now; sessionStorage.setItem('harness.sections', JSON.stringify(openState)); }
    } }, icon('chevronRight', 14), h('span', { class: 'sect-title' }, title), count != null ? h('span', { class: 'count' }, count) : null),
    actions.length ? h('div', { class: 'sect-actions' }, actions) : null);
  el.append(head, h('div', { class: 'sect-body' }, sub ? h('p', { class: 'sect-sub' }, sub) : null, body));
  return el;
}

export function field(label, control, help, { inline = false } = {}) {
  return h('label', { class: `field ${inline ? 'field-inline' : ''}` },
    h('span', { class: 'field-label' }, label), control, help ? h('small', { class: 'help' }, help) : null);
}

export function select(options, value, onChange, attrs = {}) {
  const el = h('select', { class: 'input', ...attrs, onChange: e => onChange(e.target.value) },
    options.map(o => (typeof o === 'object' ? h('option', { value: o.value, selected: String(o.value) === String(value), disabled: o.disabled }, o.label) : h('option', { value: o, selected: String(o) === String(value) }, o))));
  return el;
}

export function input(value, onChange, attrs = {}, wait = 300) {
  const fire = debounce(v => onChange(v), wait);
  return h('input', { class: 'input', value: value ?? '', ...attrs, onInput: e => fire(e.target.value) });
}

export function textarea(value, onChange, attrs = {}, wait = 300) {
  const fire = debounce(v => onChange(v), wait);
  return h('textarea', { class: 'input', ...attrs, onInput: e => fire(e.target.value) }, value ?? '');
}

export function segmented(options, value, onChange, { size = '' } = {}) {
  const wrap = h('div', { class: `seg ${size}`, role: 'radiogroup' });
  for (const o of options) {
    const b = h('button', { type: 'button', class: `seg-btn ${o.value === value ? 'on' : ''}`, role: 'radio', 'aria-checked': String(o.value === value), title: o.title || '', onClick: () => {
      wrap.querySelectorAll('.seg-btn').forEach(x => { x.classList.remove('on'); x.setAttribute('aria-checked', 'false'); });
      b.classList.add('on'); b.setAttribute('aria-checked', 'true'); onChange(o.value);
    } }, o.icon ? icon(o.icon, 14) : null, o.label);
    wrap.appendChild(b);
  }
  return wrap;
}

export const badge = (text, kind = '') => h('span', { class: `badge ${kind}` }, text);

export function empty(iconName, title, text, action) {
  return h('div', { class: 'empty' }, icon(iconName, 22), h('strong', {}, title), text ? h('p', {}, text) : null, action || null);
}

export function btn(label, onClick, { kind = '', iconName, title, size = 'sm', disabled } = {}) {
  return h('button', { type: 'button', class: `btn btn-${size} ${kind ? 'btn-' + kind : ''}`, title, disabled, onClick }, iconName ? icon(iconName, 14) : null, label);
}

/** Slider + number input + enable checkbox for one generation parameter. */
export function paramRow({ label, help, min, max, step, value, on, log, int, noSlider, options, disabledNote, onValue, onToggle }) {
  const toLog = v => Math.round(1000 * Math.log(v / lo) / Math.log(max / lo));
  const fromLog = p => { const v = lo * Math.pow(max / lo, p / 1000); return Math.max(lo, Math.round(v / step) * step); };
  const lo = Math.max(step, min, 1);
  const row = h('div', { class: `param ${on ? 'on' : ''} ${disabledNote ? 'na' : ''}` });
  const check = h('input', { type: 'checkbox', checked: on, disabled: !!disabledNote, 'aria-label': `Override ${label}` });
  let num, slider;
  if (options) {
    num = h('select', { class: 'input input-num', disabled: !on || !!disabledNote }, options.map(o => h('option', { value: o, selected: Number(o) === Number(value) }, String(o))));
    num.addEventListener('change', () => onValue(Number(num.value)));
  } else {
    num = h('input', { class: 'input input-num', type: 'number', min, max, step, value, disabled: !on || !!disabledNote });
    if (!noSlider) {
      slider = h('input', { type: 'range', class: 'slider', min: log ? 0 : min, max: log ? 1000 : max, step: log ? 1 : step, value: log ? toLog(clamp(value, lo, max)) : value, disabled: !on || !!disabledNote, 'aria-label': label });
      slider.addEventListener('input', () => { const v = log ? fromLog(+slider.value) : +slider.value; num.value = int ? Math.round(v) : +v.toFixed(4); onValue(Number(num.value)); paint(); });
    }
    num.addEventListener('input', () => { if (num.value === '' || isNaN(+num.value)) return; const v = int ? Math.round(+num.value) : +num.value; if (slider) slider.value = log ? toLog(clamp(v, lo, max)) : v; onValue(v); paint(); });
  }
  const paint = () => { if (slider) slider.style.setProperty('--fill', `${((+slider.value - +slider.min) / (+slider.max - +slider.min)) * 100}%`); };
  check.addEventListener('change', () => { const o = check.checked; row.classList.toggle('on', o); num.disabled = !o; if (slider) slider.disabled = !o; onToggle(o); });
  row.append(
    h('div', { class: 'param-top' },
      h('label', { class: 'param-label' }, check, h('span', {}, label)),
      help ? h('span', { class: 'tip', tabindex: 0, 'data-tip': help }, icon('info', 13)) : null,
      h('span', { class: 'spacer' }),
      disabledNote ? h('span', { class: 'param-na' }, disabledNote) : num),
    slider && !disabledNote ? slider : null);
  paint();
  return row;
}

/** Tag-style list editor (one value per line in a textarea). */
export function listEditor(values, onChange, placeholder = 'One per line') {
  return textarea((values || []).join('\n'), v => onChange(v.split('\n').map(s => s.replace(/\\n/g, '\n')).filter(s => s.length)), { rows: 3, placeholder, class: 'input mono' });
}
