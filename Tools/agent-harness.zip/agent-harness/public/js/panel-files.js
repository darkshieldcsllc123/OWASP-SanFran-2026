// panel-files.js — browse and edit the workspace, run quick commands, see what the agent changed.
import { state } from './store.js';
import { fsApi } from './api.js';
import * as rag from './rag.js';
import { highlight, langFromPath } from './markdown.js';
import { attachText } from './chat.js';
import { h, icon, ibtn, toast, modal, confirmDialog, promptDialog, bus, fmtBytes, fmtDuration, relTime, downloadFile, esc, copyText } from './util.js';
import { section, btn, empty, badge } from './ui.js';

let root;
const fstate = { expanded: new Set(['.']), cache: new Map(), changes: [], history: [], hi: -1, termOut: null };

bus.on('workspace:changed', ({ tool, args } = {}) => {
  if (args?.path || args?.to) fstate.changes.unshift({ path: args.to || args.path, tool, time: Date.now() });
  else if (tool === 'run_command') fstate.changes.unshift({ path: null, cmd: args.command, tool, time: Date.now() });
  fstate.changes = fstate.changes.slice(0, 30);
  if (root) { const old = root.querySelector('#ws-changes'); if (old) old.replaceWith(changesSection()); refreshTree(); }
});

export default {
  id: 'files', label: 'Files', icon: 'folder',
  mount(el) {
    root = el; render();
  },
  show() { refreshTree(); },
};

function render() {
  const info = state.info;
  if (!info) { root.replaceChildren(empty('alert', 'Server not connected', 'Start the harness with start.sh or start.bat to browse the workspace.')); return; }
  root.replaceChildren(
    h('div', { class: 'ws-head' },
      icon('folder', 15), h('code', { class: 'ws-root', title: info.root }, info.root), h('span', { class: 'spacer' }),
      ibtn('plus', 'New file', newFile, 'ibtn-sm'), ibtn('refresh', 'Refresh', () => refreshTree(), 'ibtn-sm')),
    section('Files', h('div', { class: 'tree', id: 'tree' }), { id: 'ws-tree' }),
    changesSection(),
    terminalSection());
  refreshTree();
}

async function loadDir(path) {
  const r = await fsApi.list(path, 1);
  fstate.cache.set(path, r.entries);
  return r.entries;
}

async function refreshTree() {
  const el = root?.querySelector('#tree'); if (!el) return;
  try {
    for (const p of [...fstate.expanded]) { try { await loadDir(p); } catch { fstate.expanded.delete(p); } }
    drawTree();
  } catch (e) { el.replaceChildren(h('p', { class: 'form-error' }, e.message)); }
}

function drawTree() {
  const el = root.querySelector('#tree'); if (!el) return;
  const rows = [];
  const walk = (path, depth) => {
    for (const e of fstate.cache.get(path) || []) {
      const open = fstate.expanded.has(e.path);
      const changed = fstate.changes.some(c => c.path === e.path);
      rows.push(h('div', { class: `tnode ${e.type} ${changed ? 'changed' : ''} ${e.ignored ? 'ignored' : ''}`, style: { paddingLeft: `${6 + depth * 14}px` } },
        h('button', { class: 'tnode-main', type: 'button', title: e.path, onClick: () => e.type === 'dir' ? toggleDir(e.path) : openFile(e.path) },
          e.type === 'dir' ? icon(open ? 'chevronDown' : 'chevronRight', 12) : h('span', { class: 'tnode-pad' }),
          icon(e.type === 'dir' ? 'folder' : 'file', 14), h('span', { class: 'tnode-name' }, e.name),
          e.type === 'file' ? h('small', {}, fmtBytes(e.size)) : null),
        e.type === 'file' ? h('span', { class: 'tnode-acts' },
          ibtn('clip', 'Attach to message', () => attachFile(e.path), 'ibtn-xs'),
          ibtn('database', 'Add to knowledge', () => addToKB(e.path), 'ibtn-xs'),
          ibtn('trash', 'Delete', () => del(e.path), 'ibtn-xs')) : h('span', { class: 'tnode-acts' }, ibtn('trash', 'Delete folder', () => del(e.path, true), 'ibtn-xs'))));
      if (e.type === 'dir' && open) walk(e.path, depth + 1);
    }
  };
  walk('.', 0);
  el.replaceChildren(...(rows.length ? rows : [h('p', { class: 'muted small' }, 'The workspace is empty. Ask the agent to create something, or add a file.')]));
}

async function toggleDir(path) {
  if (fstate.expanded.has(path)) { fstate.expanded.delete(path); drawTree(); return; }
  fstate.expanded.add(path);
  try { await loadDir(path); } catch (e) { toast(e.message, { type: 'err' }); }
  drawTree();
}

async function attachFile(path) {
  try { const r = await fsApi.read(path); if (r.binary) return toast('Binary files cannot be attached', { type: 'warn' }); attachText(r.path, r.content); toast(`Attached ${r.path}`); }
  catch (e) { toast(e.message, { type: 'err' }); }
}
async function addToKB(path) {
  try { const r = await fsApi.read(path); if (r.binary) return toast('Binary files cannot be added', { type: 'warn' }); const d = await rag.addDocument({ name: r.path, text: r.content, source: 'workspace' }); toast(`Added ${d.name} to knowledge (${d.chunks.length} chunks)`, { type: 'ok' }); }
  catch (e) { toast(e.message, { type: 'err' }); }
}
async function del(path, dir = false) {
  if (!await confirmDialog(`Delete ${dir ? 'the folder' : ''} ${path}${dir ? ' and everything in it' : ''}? This cannot be undone.`, { okLabel: 'Delete', danger: true })) return;
  try { await fsApi.del(path); toast(`Deleted ${path}`); refreshTree(); } catch (e) { toast(e.message, { type: 'err' }); }
}
async function newFile() {
  const path = await promptDialog('Path relative to the workspace. Folders are created as needed.', { title: 'New file', placeholder: 'src/index.js', okLabel: 'Create file' });
  if (!path) return;
  try { await fsApi.write(path.trim(), ''); refreshTree(); openFile(path.trim()); } catch (e) { toast(e.message, { type: 'err' }); }
}

export async function openFile(path) {
  let r;
  try { r = await fsApi.read(path); } catch (e) { return toast(e.message, { type: 'err' }); }
  if (r.binary) return toast(`${r.path} is binary (${fmtBytes(r.size)})`, { type: 'warn' });
  let content = r.content, editing = false;
  const view = h('div', { class: 'file-view' });
  const draw = () => {
    if (editing) {
      const ta = h('textarea', { class: 'input mono file-edit', spellcheck: 'false' }, content);
      ta.addEventListener('input', () => { content = ta.value; });
      ta.addEventListener('keydown', e => {
        if (e.key === 'Tab') { e.preventDefault(); ta.setRangeText('  ', ta.selectionStart, ta.selectionEnd, 'end'); content = ta.value; }
        if (e.key === 's' && (e.ctrlKey || e.metaKey)) { e.preventDefault(); save(); }
      });
      view.replaceChildren(ta); ta.focus();
    } else {
      const lines = highlight(content, langFromPath(r.path)).split('\n');
      view.replaceChildren(h('pre', { class: 'code numbered', html: lines.map((l, i) => `<span class="ln">${i + 1}</span>${l}`).join('\n') }));
    }
  };
  const save = async () => {
    try { await fsApi.write(r.path, content); toast(`Saved ${r.path}`, { type: 'ok' }); editing = false; draw(); setActs(); refreshTree(); }
    catch (e) { toast(e.message, { type: 'err' }); }
  };
  draw();
  const m = modal({
    title: r.path, body: h('div', { class: 'stack' }, h('p', { class: 'muted small' }, `${r.totalLines} lines, ${fmtBytes(r.size)}, modified ${relTime(r.mtime)}`), view), full: true,
    actions: [
      { label: 'Attach to message', ghost: true, icon: 'clip', onClick: () => { attachText(r.path, content); } },
      { label: 'Add to knowledge', ghost: true, icon: 'database', onClick: async () => { await rag.addDocument({ name: r.path, text: content, source: 'workspace' }); toast('Added to knowledge', { type: 'ok' }); return false; } },
      { label: 'Download', ghost: true, icon: 'download', onClick: () => { downloadFile(r.path.split('/').pop(), content, 'text/plain'); return false; } },
      { label: 'Edit', icon: 'edit', onClick: () => { if (editing) { save(); } else { editing = true; draw(); } setActs(); return false; } },
    ],
  });
  const setActs = () => { const b = [...m.box.querySelectorAll('.modal-foot .btn')].pop(); if (b) b.lastChild.textContent = editing ? 'Save' : 'Edit'; b?.classList.toggle('btn-primary', editing); };
}

function changesSection() {
  const list = fstate.changes;
  const el = section('Changed by the agent', list.length ? h('div', { class: 'changes' }, list.map(c => h('div', { class: 'change' },
    icon(c.tool === 'run_command' ? 'terminal' : c.tool === 'delete_path' ? 'trash' : 'edit', 13),
    c.path ? h('button', { class: 'linkbtn mono', type: 'button', onClick: () => c.tool !== 'delete_path' && openFile(c.path) }, c.path) : h('code', { class: 'small' }, c.cmd),
    h('span', { class: 'spacer' }), h('small', { class: 'muted' }, relTime(c.time)))))
    : h('p', { class: 'muted small' }, 'Files the agent writes or edits in this session show up here.'), { id: 'ws-changes', open: true, count: list.length || null });
  el.id = 'ws-changes';
  return el;
}

function terminalSection() {
  if (state.info?.exec === false) return section('Run a command', h('p', { class: 'muted small' }, 'Shell commands are disabled on this server (--no-exec).'), { id: 'ws-term', open: false });
  const out = h('pre', { class: 'code term term-out', hidden: !fstate.termOut, html: fstate.termOut || '' });
  const cmd = h('input', { class: 'input mono', placeholder: 'git status', spellcheck: 'false' });
  const run = async () => {
    const c = cmd.value.trim(); if (!c) return;
    fstate.history.unshift(c); fstate.hi = -1; cmd.value = '';
    out.hidden = false;
    out.innerHTML = (fstate.termOut || '') + `<span class="prompt">$</span> ${esc(c)}\n<span class="muted">running…</span>`;
    try {
      const r = await fsApi.exec(c, { timeout: 120 });
      fstate.termOut = (fstate.termOut || '') + `<span class="prompt">$</span> ${esc(c)}\n${esc(r.stdout)}${r.stderr ? `<span class="hl-del">${esc(r.stderr)}</span>` : ''}<span class="muted">exit ${r.code ?? 'none'}${r.timedOut ? ' (timed out)' : ''}, ${fmtDuration(r.durationMs)}</span>\n\n`;
    } catch (e) { fstate.termOut = (fstate.termOut || '') + `<span class="prompt">$</span> ${esc(c)}\n<span class="hl-del">${esc(e.message)}</span>\n\n`; }
    fstate.termOut = fstate.termOut.slice(-40000);
    out.innerHTML = fstate.termOut; out.scrollTop = out.scrollHeight; refreshTree();
  };
  cmd.addEventListener('keydown', e => {
    if (e.key === 'Enter') run();
    if (e.key === 'ArrowUp' && fstate.history.length) { fstate.hi = Math.min(fstate.hi + 1, fstate.history.length - 1); cmd.value = fstate.history[fstate.hi]; e.preventDefault(); }
    if (e.key === 'ArrowDown') { fstate.hi = Math.max(fstate.hi - 1, -1); cmd.value = fstate.hi < 0 ? '' : fstate.history[fstate.hi]; e.preventDefault(); }
  });
  return section('Run a command', h('div', { class: 'stack' },
    h('div', { class: 'row' }, h('span', { class: 'prompt-sign' }, '$'), cmd, btn('Run', run, { iconName: 'play' })),
    out,
    h('div', { class: 'row' }, h('small', { class: 'muted' }, `Runs in the workspace with ${state.info?.shell || 'the system shell'}. Not sent to the model.`), h('span', { class: 'spacer' }), h('button', { class: 'linkbtn', type: 'button', onClick: () => { fstate.termOut = null; out.hidden = true; out.innerHTML = ''; } }, 'Clear'))),
    { id: 'ws-term', open: false });
}
