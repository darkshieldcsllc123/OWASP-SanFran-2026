// tools.js — tool registry: built-ins (workspace, web, knowledge, plan, skills) + user-defined JS/HTTP tools.
import { settings, state } from './store.js';
import { fsApi, proxyFetch } from './api.js';
import { bus, fmtBytes, fmtDuration, safeJSON, truncate, uid } from './util.js';
import * as rag from './rag.js';
import { getSkill, skillsFor } from './skills.js';

export const CATEGORIES = {
  read: { label: 'Read', icon: 'file', risky: false },
  write: { label: 'Write', icon: 'edit', risky: true },
  exec: { label: 'Shell', icon: 'terminal', risky: true },
  net: { label: 'Network', icon: 'globe', risky: true },
  meta: { label: 'Agent', icon: 'list', risky: false },
  custom: { label: 'Custom', icon: 'tool', risky: true },
};

const S = (description, extra = {}) => ({ type: 'string', description, ...extra });
const I = description => ({ type: 'integer', description });
const B = description => ({ type: 'boolean', description });
const obj = (properties, required = []) => ({ type: 'object', properties, required });

function formatTree(r) {
  if (!r.entries.length) return `${r.root === '.' ? 'The workspace' : r.root} is empty.`;
  const lines = [r.root === '.' ? './' : r.root + '/'];
  for (const e of r.entries) {
    const pad = '  '.repeat(e.depth);
    lines.push(e.type === 'dir' ? `${pad}${e.name}/${e.ignored ? '  (not expanded)' : ''}` : `${pad}${e.name}  ${fmtBytes(e.size)}`);
  }
  if (r.truncated) lines.push('… listing truncated; list a subfolder for more.');
  return lines.join('\n');
}
const prettyJSON = t => { const j = safeJSON(t); return j === null ? t : JSON.stringify(j, null, 2); };

export const BUILTINS = [
  {
    name: 'list_dir', category: 'read',
    description: 'List files and folders in the workspace as an indented tree with file sizes. Big generated folders such as node_modules are shown but not expanded.',
    parameters: obj({ path: S('Folder relative to the workspace root. Use "." for the root.'), depth: I('How many levels to show, 1 to 5. Default 2.') }),
    async run({ path = '.', depth = 2 }) { return formatTree(await fsApi.list(path, Math.max(1, Math.min(depth || 2, 5)))); },
  },
  {
    name: 'read_file', category: 'read',
    description: 'Read a text file from the workspace. Each line is prefixed with its line number and a tab; never include those prefixes when you edit. For large files, read a range with start_line and end_line.',
    parameters: obj({ path: S('File path relative to the workspace root.'), start_line: I('First line to read (1-based). Optional.'), end_line: I('Last line to read, inclusive. Optional.') }, ['path']),
    async run({ path, start_line, end_line }) {
      const r = await fsApi.read(path, start_line, end_line);
      if (r.binary) return `${r.path} is a binary file (${fmtBytes(r.size)}); its contents cannot be shown.`;
      const range = r.startLine > 1 || r.endLine < r.totalLines ? `lines ${r.startLine}-${r.endLine} of ${r.totalLines}` : `${r.totalLines} lines`;
      const body = r.content.split('\n').map((l, k) => `${r.startLine + k}\t${l}`).join('\n');
      return `${r.path} (${range})\n${body}`;
    },
  },
  {
    name: 'write_file', category: 'write',
    description: 'Create a file or overwrite it completely. Parent folders are created automatically. For small changes to an existing file, use edit_file instead.',
    parameters: obj({ path: S('File path relative to the workspace root.'), content: S('The complete file contents.') }, ['path', 'content']),
    async run({ path, content }) {
      const r = await fsApi.write(path, content ?? '');
      return `${r.created ? 'Created' : 'Overwrote'} ${r.path}: ${r.lines} lines, ${fmtBytes(r.bytes)}.`;
    },
  },
  {
    name: 'edit_file', category: 'write',
    description: 'Replace an exact piece of text in a file. old_str must match the file exactly (including indentation) and must be unique unless replace_all is true. Read the file first.',
    parameters: obj({ path: S('File path relative to the workspace root.'), old_str: S('Exact text to find. Include a few surrounding lines so it is unique.'), new_str: S('Replacement text. Use an empty string to delete.'), replace_all: B('Replace every occurrence. Default false.') }, ['path', 'old_str', 'new_str']),
    async run({ path, old_str, new_str, replace_all }) {
      const r = await fsApi.edit(path, old_str, new_str ?? '', !!replace_all);
      return `Edited ${r.path}: replaced ${r.replacements} occurrence${r.replacements > 1 ? 's' : ''}, first at line ${r.line}.`;
    },
  },
  {
    name: 'search_files', category: 'read',
    description: 'Search file contents in the workspace, like grep. Returns path:line: text for each match.',
    parameters: obj({ pattern: S('Text to search for (or a regular expression if regex is true).'), path: S('Folder or file to search in. Default ".".'), glob: S('Only search files matching this glob, for example "**/*.py" or "*.{js,ts}".'), regex: B('Treat pattern as a regular expression.'), case_sensitive: B('Match case exactly. Default false.') }, ['pattern']),
    async run(a) {
      const r = await fsApi.search({ pattern: a.pattern, path: a.path || '.', glob: a.glob, regex: !!a.regex, case_sensitive: !!a.case_sensitive, max_results: 120 });
      if (!r.matches.length) return `No matches for "${a.pattern}" in ${r.filesScanned} files.`;
      return `${r.matches.length}${r.truncated ? '+' : ''} matches in ${r.filesScanned} files scanned:\n` + r.matches.map(m => `${m.path}:${m.line}: ${m.text.trim()}`).join('\n');
    },
  },
  {
    name: 'run_command', category: 'exec',
    description: 'Run a shell command in the workspace and return its exit code, stdout and stderr. Use it to run code, tests, builds, git and package managers. Commands are not interactive; pass flags like -y.',
    parameters: obj({ command: S('The command line to run.'), cwd: S('Working folder relative to the workspace root. Default ".".'), timeout_sec: I('Seconds before the command is killed. Default 60, max 900.') }, ['command']),
    available: () => state.info?.exec !== false,
    async run({ command, cwd = '.', timeout_sec = 60 }, { signal }) {
      const r = await fsApi.exec(command, { cwd, timeout: timeout_sec, signal });
      const parts = [`exit code ${r.code ?? 'none'}${r.timedOut ? ' (timed out and killed)' : ''} in ${fmtDuration(r.durationMs)}`];
      if (r.stdout.trim()) parts.push(`stdout:\n${r.stdout.trimEnd()}`);
      if (r.stderr.trim()) parts.push(`stderr:\n${r.stderr.trimEnd()}`);
      if (!r.stdout.trim() && !r.stderr.trim()) parts.push('(no output)');
      return parts.join('\n\n');
    },
  },
  {
    name: 'delete_path', category: 'write',
    description: 'Delete a file, or a folder and everything in it.',
    parameters: obj({ path: S('File or folder relative to the workspace root.') }, ['path']),
    async run({ path }) { const r = await fsApi.del(path); return `Deleted ${r.type === 'dir' ? 'folder' : 'file'} ${r.path}.`; },
  },
  {
    name: 'move_path', category: 'write',
    description: 'Move or rename a file or folder inside the workspace.',
    parameters: obj({ from: S('Current path.'), to: S('New path.') }, ['from', 'to']),
    async run({ from, to }) { const r = await fsApi.move(from, to); return `Moved ${r.from} to ${r.to}.`; },
  },
  {
    name: 'fetch_url', category: 'net',
    description: 'Download a web page or API response. HTML is converted to readable text; JSON is pretty-printed.',
    parameters: obj({ url: S('Full URL starting with http:// or https://'), max_chars: I('Maximum characters to return. Default 8000.') }, ['url']),
    async run({ url, max_chars = 8000 }, { signal }) {
      if (!/^https?:\/\//i.test(url)) throw new Error('url must start with http:// or https://');
      const res = await proxyFetch(url, { headers: { accept: 'text/html,application/json,text/plain;q=0.9,*/*;q=0.5' }, signal });
      const type = res.headers.get('content-type') || '';
      let text = await res.text();
      if (/html/.test(type)) text = rag.htmlToText(text); else if (/json/.test(type)) text = prettyJSON(text);
      return `HTTP ${res.status} ${type.split(';')[0]}\n\n${truncate(text, max_chars)}`;
    },
  },
  {
    name: 'rag_search', category: 'read',
    description: 'Search the knowledge base the user added (docs, notes, code) and return the most relevant excerpts with their source.',
    parameters: obj({ query: S('What to look for, in natural language or keywords.'), top_k: I('How many excerpts to return. Default 5.') }, ['query']),
    available: () => settings.rag.asTool && rag.kb.docs.length > 0,
    async run({ query, top_k = 5 }) {
      const r = await rag.search(query, { k: Math.min(top_k || 5, 12) });
      if (!r.results.length) return `No knowledge base results for "${query}".`;
      return (r.note ? r.note + '\n\n' : '') + rag.formatResults(r.results);
    },
  },
  {
    name: 'update_plan', category: 'meta',
    description: 'Create or update your step-by-step plan for the current task. Send the complete list every time, with each step marked pending, in_progress or done. The user sees it as a checklist.',
    parameters: obj({ steps: { type: 'array', description: 'All steps, in order.', items: obj({ title: S('Short description of the step.'), status: S('Step status.', { enum: ['pending', 'in_progress', 'done'] }) }, ['title', 'status']) } }, ['steps']),
    async run({ steps }, { convo }) {
      const list = (Array.isArray(steps) ? steps : []).map(s => typeof s === 'string' ? { title: s, status: 'pending' } : { title: String(s.title || s.step || s.description || 'Step'), status: ['pending', 'in_progress', 'done'].includes(s.status) ? s.status : (s.status === 'completed' ? 'done' : 'pending') });
      convo.plan = { steps: list, updated: Date.now() };
      bus.emit('plan', convo);
      return `Plan saved: ${list.filter(s => s.status === 'done').length} of ${list.length} steps done.`;
    },
  },
  {
    name: 'load_skill', category: 'meta',
    description: 'Load the full instructions of a skill listed under "Skills you can load" in your system prompt.',
    parameters: obj({ name: S('Exact skill name.') }, ['name']),
    available: () => skillsFor('').loadable.length > 0,
    async run({ name }) {
      const s = getSkill(name);
      if (!s) return `No enabled skill named "${name}". Available: ${settings.skills.filter(x => x.enabled).map(x => x.name).join(', ') || 'none'}.`;
      return `# Skill: ${s.name}\n\n${s.content}`;
    },
  },
];

// ── custom tools ─────────────────────────────────────────────────
export function schemaFromParams(params = []) {
  const properties = {}, required = [];
  for (const p of params) {
    if (!p.name) continue;
    const prop = { type: p.type || 'string', description: p.description || '' };
    if (p.type === 'array') prop.items = { type: 'string' };
    if (p.enum) prop.enum = String(p.enum).split(',').map(s => s.trim()).filter(Boolean);
    properties[p.name] = prop;
    if (p.required) required.push(p.name);
  }
  return { type: 'object', properties, required };
}
export function customSchema(c) {
  if (c.schemaMode === 'raw' && c.schemaRaw) { const j = safeJSON(c.schemaRaw); if (j) return j; }
  return schemaFromParams(c.params);
}

const AsyncFunction = Object.getPrototypeOf(async function () {}).constructor;

export function makeCtx(signal, logs = []) {
  return {
    fs: {
      read: (p, s, e) => fsApi.read(p, s, e), write: (p, c) => fsApi.write(p, c), list: (p, d) => fsApi.list(p, d),
      edit: (p, a, b, all) => fsApi.edit(p, a, b, all), search: (pattern, o = {}) => fsApi.search({ pattern, ...o }),
    },
    exec: (command, o = {}) => fsApi.exec(command, { ...o, signal }),
    fetch: (url, o = {}) => proxyFetch(url, { ...o, signal }),
    fetchText: async (url, o = {}) => (await proxyFetch(url, { ...o, signal })).text(),
    fetchJSON: async (url, o = {}) => (await proxyFetch(url, { ...o, signal })).json(),
    rag: { search: (q, k = 5) => rag.search(q, { k }) },
    log: (...a) => logs.push(a.map(x => (typeof x === 'string' ? x : JSON.stringify(x))).join(' ')),
    signal,
  };
}

async function runCustomJS(c, args, signal) {
  const logs = [];
  let fn;
  try { fn = new AsyncFunction('args', 'ctx', c.code || 'return "This tool has no code yet.";'); }
  catch (e) { throw new Error(`Syntax error in tool code: ${e.message}`); }
  const result = await fn(args, makeCtx(signal, logs));
  const out = typeof result === 'string' ? result : result === undefined ? '(the tool returned nothing)' : JSON.stringify(result, null, 2);
  return logs.length ? `${out}\n\n[log]\n${logs.join('\n')}` : out;
}

async function runCustomHTTP(c, args, signal) {
  const method = (c.method || 'POST').toUpperCase();
  const used = new Set();
  let url = String(c.url || '').replace(/\{\{(\w+)\}\}/g, (_, k) => { used.add(k); return encodeURIComponent(args[k] ?? ''); });
  if (!/^https?:\/\//i.test(url)) throw new Error('The tool URL must start with http:// or https://');
  const rest = Object.fromEntries(Object.entries(args || {}).filter(([k]) => !used.has(k)));
  const headers = { ...(safeJSON(c.headers || '{}', {}) || {}) };
  let body;
  if (method === 'GET' || method === 'DELETE') {
    const u = new URL(url);
    for (const [k, v] of Object.entries(rest)) u.searchParams.set(k, typeof v === 'object' ? JSON.stringify(v) : v);
    url = u.toString();
  } else { headers['content-type'] ||= 'application/json'; body = JSON.stringify(rest); }
  const res = await proxyFetch(url, { method, headers, body, signal });
  const text = await res.text();
  return `HTTP ${res.status}\n${prettyJSON(text)}`;
}

export function customToTool(c) {
  return {
    id: c.id, name: c.name, description: c.description || '', parameters: customSchema(c), category: 'custom', source: 'custom', type: c.type,
    run: (args, { signal }) => (c.type === 'http' ? runCustomHTTP(c, args, signal) : runCustomJS(c, args, signal)),
  };
}

export function newCustomTool(partial = {}) {
  return { id: uid('t_'), name: 'my_tool', description: '', type: 'js', params: [], schemaMode: 'builder', schemaRaw: '', code: 'return `You said: ${args.text}`;', url: '', method: 'POST', headers: '{}', enabled: true, approval: 'inherit', sample: '{}', ...partial };
}

// ── registry ─────────────────────────────────────────────────────
export const builtinState = name => (settings.tools.builtin[name] ||= { enabled: true, approval: 'inherit' });

export function getActiveTools() {
  const out = [];
  for (const b of BUILTINS) {
    if (builtinState(b.name).enabled === false) continue;
    if (b.available && !b.available()) continue;
    out.push({ ...b, source: 'builtin' });
  }
  const names = new Set(out.map(t => t.name));
  for (const c of settings.tools.custom) if (c.enabled !== false && !names.has(c.name)) { out.push(customToTool(c)); names.add(c.name); }
  return out;
}
export const schemaOf = t => ({ name: t.name, description: t.description, parameters: t.parameters });

export function approvalFor(tool) {
  const o = tool.source === 'builtin' ? builtinState(tool.name).approval : settings.tools.custom.find(c => c.id === tool.id)?.approval;
  if (o === 'ask') return true;
  if (o === 'auto') return false;
  const mode = settings.agent.approval;
  if (mode === 'all') return true;
  if (mode === 'none') return false;
  return !!CATEGORIES[tool.category]?.risky;
}

/** Validate and gently coerce arguments (helps small models). Returns an error string or null. */
export function validateArgs(schema, args) {
  if (!schema || schema.type !== 'object') return null;
  if (!args || typeof args !== 'object' || Array.isArray(args)) return 'Arguments must be a JSON object.';
  if (args._raw !== undefined) return `Arguments were not valid JSON: ${truncate(args._raw, 200)}`;
  const errs = [];
  for (const r of schema.required || []) if (args[r] === undefined || args[r] === null) errs.push(`missing required "${r}"`);
  for (const [k, v] of Object.entries(args)) {
    const p = schema.properties?.[k]; if (!p || v === undefined || v === null) continue;
    const t = p.type;
    if (t === 'integer' || t === 'number') {
      if (typeof v === 'string' && v.trim() !== '' && !isNaN(+v)) args[k] = +v;
      else if (typeof v !== 'number') errs.push(`"${k}" must be a number`);
      if (t === 'integer' && typeof args[k] === 'number') args[k] = Math.trunc(args[k]);
    } else if (t === 'boolean') {
      if (v === 'true' || v === 'false') args[k] = v === 'true'; else if (typeof v !== 'boolean') errs.push(`"${k}" must be true or false`);
    } else if (t === 'string' && typeof v !== 'string') args[k] = typeof v === 'object' ? JSON.stringify(v, null, 2) : String(v);
    else if (t === 'array' && !Array.isArray(v)) {
      const j = typeof v === 'string' ? safeJSON(v) : null;
      if (Array.isArray(j)) args[k] = j; else errs.push(`"${k}" must be an array`);
    }
    if (p.enum && !p.enum.includes(args[k])) errs.push(`"${k}" must be one of: ${p.enum.join(', ')}`);
  }
  return errs.length ? `Invalid arguments: ${errs.join('; ')}.` : null;
}

function withTimeout(promise, ms, signal) {
  return new Promise((resolve, reject) => {
    const t = setTimeout(() => reject(new Error(`Tool timed out after ${fmtDuration(ms)}`)), ms);
    const onAbort = () => { clearTimeout(t); reject(new DOMException('Stopped', 'AbortError')); };
    signal?.addEventListener('abort', onAbort, { once: true });
    promise.then(v => { clearTimeout(t); signal?.removeEventListener('abort', onAbort); resolve(v); },
      e => { clearTimeout(t); signal?.removeEventListener('abort', onAbort); reject(e); });
  });
}

export async function executeTool(tool, args, ctx = {}) {
  let out = await withTimeout(Promise.resolve().then(() => tool.run(args || {}, ctx)), 16 * 60 * 1000, ctx.signal);
  if (typeof out !== 'string') out = JSON.stringify(out, null, 2);
  const limit = Math.max(1000, settings.agent.outputLimit || 12000);
  if (out.length > limit) {
    const head = Math.floor(limit * 0.75), tail = limit - head;
    out = `${out.slice(0, head)}\n\n[… ${out.length - limit} characters cut. Ask for a narrower range, e.g. read_file with start_line/end_line …]\n\n${out.slice(-tail)}`;
  }
  return out;
}
