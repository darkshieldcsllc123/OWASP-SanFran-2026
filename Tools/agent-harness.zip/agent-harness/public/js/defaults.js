// defaults.js — static content with no imports (safe to load first).

export const DEFAULT_SYSTEM_PROMPT = `You are a careful, capable coding agent working in a local workspace at {{workspace}} on {{os}}.

How you work:
- Inspect before you edit: list directories and read the relevant files. Never guess what a file contains.
- Prefer small, targeted edits with edit_file over rewriting whole files.
- After changing code, verify it: run it, run the tests, or run a linter with run_command.
- For tasks with several steps, keep a short plan with update_plan and mark steps done as you go.
- When a tool returns an error, read it and change your approach instead of repeating the same call.
- Ask the user when requirements are unclear or an action would destroy data.

When you finish, reply with a short summary: what changed, where, and how to run or check it.
Today is {{date}}.`;

export const PROMPT_PRESETS = [
  { id: 'coding-agent', name: 'Coding agent', text: DEFAULT_SYSTEM_PROMPT, builtin: true },
  {
    id: 'reviewer', name: 'Code reviewer', builtin: true,
    text: `You are a senior engineer reviewing code in the workspace at {{workspace}}.
Read the files the user points to (and the code they depend on) before commenting.
Report findings grouped by severity: bugs, security, correctness, then readability.
For each finding give the file and line, what is wrong, and a concrete fix. Do not edit files unless asked.`,
  },
  {
    id: 'tutor', name: 'Patient tutor', builtin: true,
    text: `You are a patient programming tutor. Explain concepts step by step with small runnable examples.
Check understanding with a short question at the end of each explanation. Use the workspace at {{workspace}} to create example files when it helps.`,
  },
  {
    id: 'minimal', name: 'Minimal', builtin: true,
    text: `You are a helpful assistant with access to tools. Use them when they help. Today is {{date}}.`,
  },
];

export const TEMPLATE_VARS = [
  { key: '{{date}}', desc: "Today's date" },
  { key: '{{time}}', desc: 'Current local time' },
  { key: '{{workspace}}', desc: 'Workspace folder path' },
  { key: '{{os}}', desc: 'Operating system' },
  { key: '{{shell}}', desc: 'Shell used by run_command' },
  { key: '{{model}}', desc: 'Active model name' },
  { key: '{{tools}}', desc: 'Comma-separated enabled tool names' },
];

export const STARTER_SKILLS = [
  {
    id: 'sk_testfirst', name: 'test-first-fixes', enabled: true, mode: 'auto',
    description: 'Fix bugs by reproducing them with a failing test first.',
    triggers: 'bug, fix, failing, broken, error, regression',
    content: `When fixing a bug:
1. Reproduce it. Find or write the smallest test or command that fails because of the bug, and run it.
2. Read the code path involved before changing anything.
3. Make the smallest change that makes the failing check pass.
4. Run the full relevant test suite again to catch regressions.
5. In your summary, name the root cause in one sentence.`,
  },
  {
    id: 'sk_git', name: 'git-hygiene', enabled: true, mode: 'manual',
    description: 'Safe git workflow: status checks, focused commits, conventional messages.',
    triggers: 'git, commit, branch, push',
    content: `Git rules:
- Run \`git status\` and \`git diff --stat\` before committing so you know exactly what changes.
- Commit one logical change at a time. Message format: \`type(scope): summary\` (feat, fix, refactor, docs, test, chore).
- Never run \`git push --force\`, \`git reset --hard\`, or delete branches without the user saying so explicitly.
- If the working tree has unrelated changes, ask before including them.`,
  },
  {
    id: 'sk_scaffold', name: 'project-scaffold', enabled: true, mode: 'auto',
    description: 'Set up new projects with a clear structure, README and run scripts.',
    triggers: 'scaffold, new project, bootstrap, set up, setup, init, starter',
    content: `When creating a new project:
- Propose the file layout first (a short tree), then create it.
- Always include a README with: what it is, how to install, how to run, how to test.
- Add a single obvious entry point and a script to run it (package.json scripts, Makefile, or similar).
- Keep dependencies minimal and say why each one is needed.
- Finish by running the project once to prove it starts.`,
  },
  {
    id: 'sk_small', name: 'small-model-mode', enabled: false, mode: 'always',
    description: 'Extra structure that helps small local models (3B to 14B) use tools reliably.',
    triggers: '',
    content: `Rules for this session:
- Call at most one tool per reply, then wait for its result.
- Tool arguments must be valid JSON with double-quoted keys and strings.
- Use paths relative to the workspace, for example "src/app.js".
- Keep replies short. Do not repeat file contents back to the user unless asked.`,
  },
];

export const SKILL_TEMPLATES = [
  { name: 'api-design', mode: 'auto', triggers: 'api, endpoint, route, rest', description: 'Conventions for designing HTTP APIs.', content: 'When designing endpoints:\n- Use nouns for resources and HTTP verbs for actions.\n- Return consistent JSON errors: {"error": {"code": "...", "message": "..."}}.\n- Validate input at the edge and document every field.\n- Add an example request and response for each endpoint to the README.' },
  { name: 'python-style', mode: 'auto', triggers: 'python, .py, pip, pytest', description: 'Python conventions: typing, pytest, venv.', content: '- Target Python 3.10+, use type hints and dataclasses where they help.\n- Use pytest for tests, placed in tests/ mirroring the package layout.\n- Never install packages globally: create and use a virtual environment (.venv).\n- Format with black-compatible style and keep functions under ~40 lines.' },
  { name: 'security-review', mode: 'manual', triggers: 'security, vulnerability, audit', description: 'Checklist for reviewing code for security problems.', content: 'Check for: injection (SQL, shell, path traversal), secrets in code or logs, missing authentication or authorization checks, unsafe deserialization, unvalidated redirects, and outdated dependencies with known issues. Report each finding with file, line, impact, and a fix.' },
  { name: 'docs-writer', mode: 'manual', triggers: 'docs, documentation, readme', description: 'Write clear developer documentation.', content: 'Write for a developer who has never seen the project. Lead with what it does and a working quick-start. Use short sections, runnable examples, and a troubleshooting section for the three most likely problems.' },
];

export const TOOL_TEMPLATES = [
  {
    name: 'current_time', type: 'js', category: 'custom', approval: 'auto',
    description: 'Get the current date and time, optionally in a specific IANA timezone.',
    params: [{ name: 'timezone', type: 'string', description: 'IANA timezone like "Europe/Berlin". Optional.', required: false }],
    code: `const tz = args.timezone || undefined;
return new Date().toLocaleString('en-US', { timeZone: tz, dateStyle: 'full', timeStyle: 'long' });`,
    sample: '{ "timezone": "Asia/Tokyo" }',
  },
  {
    name: 'calculator', type: 'js', category: 'custom', approval: 'auto',
    description: 'Evaluate a math expression exactly. Supports + - * / % ^, parentheses, and sqrt, sin, cos, tan, log, exp, abs, pow, min, max, floor, ceil, round, PI, E.',
    params: [{ name: 'expression', type: 'string', description: 'Expression such as "sqrt(2) * (3 + 4)^2"', required: true }],
    code: `const allowed = ['sqrt','sin','cos','tan','log','exp','abs','pow','min','max','floor','ceil','round','PI','E'];
const expr = String(args.expression);
for (const id of expr.match(/[a-zA-Z_]+/g) || []) if (!allowed.includes(id)) throw new Error('Unknown name: ' + id);
if (!/^[\\d\\s+\\-*/().,%^a-zA-Z_]*$/.test(expr)) throw new Error('Invalid characters in expression');
const js = expr.replace(/\\^/g, '**').replace(/[a-zA-Z_]+/g, m => 'Math.' + m);
return String(Function('"use strict"; return (' + js + ')')());`,
    sample: '{ "expression": "sqrt(16) + 2^3" }',
  },
  {
    name: 'git_status', type: 'js', category: 'custom', approval: 'auto',
    description: 'Show the current git branch and changed files in the workspace.',
    params: [],
    code: `const r = await ctx.exec('git status --short --branch');
return r.stdout || r.stderr || 'No output (is this a git repository?)';`,
    sample: '{}',
  },
  {
    name: 'file_stats', type: 'js', category: 'custom', approval: 'auto',
    description: 'Count lines, words and characters in a workspace file.',
    params: [{ name: 'path', type: 'string', description: 'File path relative to the workspace', required: true }],
    code: `const f = await ctx.fs.read(args.path);
const t = f.content;
return JSON.stringify({ path: f.path, lines: f.totalLines, words: (t.match(/\\S+/g) || []).length, chars: t.length });`,
    sample: '{ "path": "README.md" }',
  },
  {
    name: 'weather', type: 'http', category: 'custom', approval: 'auto', method: 'GET',
    url: 'https://api.open-meteo.com/v1/forecast?current_weather=true',
    description: 'Current weather for a latitude and longitude (Open-Meteo, no key needed).',
    params: [
      { name: 'latitude', type: 'number', description: 'Latitude, e.g. 52.52', required: true },
      { name: 'longitude', type: 'number', description: 'Longitude, e.g. 13.41', required: true },
    ],
    sample: '{ "latitude": 52.52, "longitude": 13.41 }',
  },
  {
    name: 'run_tests', type: 'js', category: 'custom', approval: 'ask',
    description: 'Run the project test command and return a short pass/fail summary with the tail of the output.',
    params: [{ name: 'command', type: 'string', description: 'Test command. Defaults to "npm test".', required: false }],
    code: `const r = await ctx.exec(args.command || 'npm test', { timeout: 300 });
const out = (r.stdout + '\\n' + r.stderr).trim().split('\\n');
return (r.code === 0 ? 'PASS' : 'FAIL (exit ' + r.code + ')') + '\\n' + out.slice(-40).join('\\n');`,
    sample: '{}',
  },
];

export const STARTER_PROMPTS = [
  { title: 'Scaffold a CLI', text: 'Create a small Node.js CLI in this workspace that counts words in a file. Include a README and run it once on its own README to prove it works.' },
  { title: 'Map this workspace', text: 'Look through the workspace and give me a short map: what each top-level folder is for, the entry points, and how to run the project.' },
  { title: 'Fix a failing test', text: 'Run the test suite, find the first failing test, and fix the bug that causes it.' },
  { title: 'Explain a file', text: 'Read the most important source file in the workspace and explain how it works, top to bottom.' },
];

export const ACCENTS = {
  amber: { dark: '#f0a73a', light: '#a85f00', name: 'Signal amber' },
  teal: { dark: '#4fd1c5', light: '#0e7d73', name: 'Teal' },
  coral: { dark: '#ff8a7a', light: '#c0402f', name: 'Coral' },
  iris: { dark: '#9fa8ff', light: '#4c55c9', name: 'Iris' },
  lime: { dark: '#b6e36a', light: '#4f7d0c', name: 'Lime' },
};
