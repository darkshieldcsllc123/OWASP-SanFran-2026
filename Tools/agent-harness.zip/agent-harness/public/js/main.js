// main.js — app shell: boot, theme, header, sidebar, signal chain, panel host, command palette, shortcuts.
import { settings, saveSettings, replaceSettings, state, idb, loadConvos, newConvo, switchConvo, activeConvo, deleteConvo, renameConvo, saveConvo, sortConvos } from './store.js';
import { getInfo, serverOK } from './api.js';
import { PRESETS, presetById, getConf, activeProvider, ollama, listModels } from './providers.js';
import { agent, estimateContext } from './agent.js';
import { getActiveTools } from './tools.js';
import * as rag from './rag.js';
import { mountChat, focusComposer, exportChat, renderAll } from './chat.js';
import { ACCENTS } from './defaults.js';
import { h, $, $$, icon, iconSVG, ibtn, toast, modal, confirmDialog, closeTopModal, hasModal, bus, menu, relTime, fmtNum, estimateTokens, fuzzyScore, throttleRAF, downloadFile, pickFiles, readFileText, debounce, toggle } from './util.js';
import { segmented } from './ui.js';
import modelPanel, { fetchModels, setProvider, setModel } from './panel-model.js';
import toolsPanel from './panel-tools.js';
import skillsPanel from './panel-skills.js';
import knowledgePanel from './panel-knowledge.js';
import filesPanel from './panel-files.js';
import inspectorPanel from './panel-inspector.js';

const PANELS = [modelPanel, toolsPanel, skillsPanel, knowledgePanel, filesPanel, inspectorPanel];
const mounted = new Set();
const isMac = /Mac|iPhone|iPad/.test(navigator.platform);
const MOD = isMac ? '⌘' : 'Ctrl';

// ── theme ────────────────────────────────────────────────────────
const darkMQ = matchMedia('(prefers-color-scheme: dark)');
function applyTheme() {
  const resolved = settings.theme === 'system' ? (darkMQ.matches ? 'dark' : 'light') : settings.theme;
  const root = document.documentElement;
  root.dataset.theme = resolved;
  const acc = ACCENTS[settings.accent] || ACCENTS.amber;
  root.style.setProperty('--accent', acc[resolved]);
  root.style.setProperty('--fs', `${settings.fontSize}px`);
  const tb = $('#btn-theme');
  if (tb) { tb.innerHTML = iconSVG(settings.theme === 'system' ? 'monitor' : settings.theme === 'dark' ? 'moon' : 'sun'); tb.title = `Theme: ${settings.theme} (click to change)`; }
}
darkMQ.addEventListener('change', applyTheme);
function cycleTheme() { settings.theme = { system: 'dark', dark: 'light', light: 'system' }[settings.theme]; saveSettings('theme'); applyTheme(); toast(`Theme: ${settings.theme}`, { timeout: 1200 }); }

function openAppearance() {
  const sw = h('div', { class: 'swatches' }, Object.entries(ACCENTS).map(([k, a]) => h('button', {
    class: `swatch ${settings.accent === k ? 'on' : ''}`, type: 'button', title: a.name, 'aria-label': a.name, style: { '--c': a[document.documentElement.dataset.theme] },
    onClick: e => { settings.accent = k; saveSettings('theme'); applyTheme(); sw.querySelectorAll('.swatch').forEach(s => s.classList.remove('on')); e.currentTarget.classList.add('on'); },
  })));
  const size = h('input', { type: 'range', class: 'slider', min: 12, max: 17, step: 1, value: settings.fontSize, onInput: e => { settings.fontSize = +e.target.value; saveSettings('theme'); applyTheme(); } });
  modal({
    title: 'Appearance',
    body: h('div', { class: 'stack' },
      h('div', { class: 'field' }, h('span', { class: 'field-label' }, 'Theme'), segmented([{ value: 'system', label: 'System', icon: 'monitor' }, { value: 'dark', label: 'Dark', icon: 'moon' }, { value: 'light', label: 'Light', icon: 'sun' }], settings.theme, v => { settings.theme = v; saveSettings('theme'); applyTheme(); })),
      h('div', { class: 'field' }, h('span', { class: 'field-label' }, 'Accent'), sw),
      h('div', { class: 'field' }, h('span', { class: 'field-label' }, 'Text size'), size)),
    actions: [{ label: 'Done', primary: true }],
  });
}

// ── layout ───────────────────────────────────────────────────────
function applyLayout() {
  const app = $('#app');
  app.classList.toggle('sidebar-open', settings.sidebarOpen);
  app.classList.toggle('panel-open', settings.panelOpen);
  app.style.setProperty('--panel-w', `${settings.panelWidth}px`);
  $('#btn-sidebar').setAttribute('aria-pressed', String(settings.sidebarOpen));
  $('#btn-panel').setAttribute('aria-pressed', String(settings.panelOpen));
}
const narrow = () => innerWidth < 1100;
function toggleSidebar(force) { settings.sidebarOpen = force ?? !settings.sidebarOpen; if (settings.sidebarOpen && innerWidth < 760) settings.panelOpen = false; saveSettings('layout'); applyLayout(); }
function togglePanel(force) { settings.panelOpen = force ?? !settings.panelOpen; if (settings.panelOpen && narrow()) settings.sidebarOpen = innerWidth >= 760 && settings.sidebarOpen; saveSettings('layout'); applyLayout(); if (settings.panelOpen) showTab(settings.panelTab); }

function setupResize() {
  const handle = $('#panel-resize');
  handle.addEventListener('pointerdown', e => {
    e.preventDefault(); handle.setPointerCapture(e.pointerId); document.body.classList.add('resizing');
    const move = ev => { settings.panelWidth = Math.round(Math.max(320, Math.min(760, innerWidth - ev.clientX))); $('#app').style.setProperty('--panel-w', `${settings.panelWidth}px`); };
    const up = () => { handle.removeEventListener('pointermove', move); document.body.classList.remove('resizing'); saveSettings('layout'); };
    handle.addEventListener('pointermove', move);
    handle.addEventListener('pointerup', up, { once: true });
  });
  handle.addEventListener('dblclick', () => { settings.panelWidth = 400; applyLayout(); saveSettings('layout'); });
}

// ── panels ───────────────────────────────────────────────────────
function mountPanels() {
  const tabs = $('#panel-tabs');
  tabs.replaceChildren(...PANELS.map((p, i) => h('button', { class: 'ptab', type: 'button', role: 'tab', id: `tab-${p.id}`, 'aria-controls': `pane-${p.id}`, title: `${p.label} (Alt+${i + 1})`, onClick: () => showTab(p.id) }, icon(p.icon, 15), h('span', {}, p.label))));
  $('#panel-body').replaceChildren(...PANELS.map(p => h('div', { class: 'pane', id: `pane-${p.id}`, role: 'tabpanel', hidden: true })));
  if (settings.panelOpen) showTab(settings.panelTab);
}
function showTab(id) {
  const p = PANELS.find(x => x.id === id) || PANELS[0];
  settings.panelTab = p.id; saveSettings('layout');
  for (const x of PANELS) { const on = x.id === p.id; $(`#pane-${x.id}`).hidden = !on; $(`#tab-${x.id}`).classList.toggle('on', on); $(`#tab-${x.id}`).setAttribute('aria-selected', String(on)); }
  const pane = $(`#pane-${p.id}`);
  if (!mounted.has(p.id)) { mounted.add(p.id); p.mount(pane); } else p.show?.();
  renderChain();
  return p;
}
function openPanel(tab, focus) {
  if (!settings.panelOpen) togglePanel(true);
  const p = showTab(tab);
  if (focus) setTimeout(() => p.focus?.(focus), 50);
}

// ── header: provider + model ─────────────────────────────────────
function renderModelSwitch() {
  const { preset, conf } = activeProvider();
  const sel = $('#top-provider');
  if (!sel.options.length) {
    for (const [g, list] of [['Local', PRESETS.filter(p => p.local)], ['Cloud', PRESETS.filter(p => !p.local)]]) sel.append(h('optgroup', { label: g }, list.map(p => h('option', { value: p.id }, p.name))));
    sel.addEventListener('change', () => setProvider(sel.value));
    const mi = $('#top-model');
    mi.addEventListener('change', () => setModel(mi.value));
    mi.addEventListener('focus', () => { if (!state.models?.[settings.provider]) fetchModels(settings.provider, { quiet: true }).catch(() => {}); });
    mi.addEventListener('keydown', e => { if (e.key === 'Enter') { mi.blur(); } });
  }
  sel.value = preset.id;
  const mi = $('#top-model');
  if (document.activeElement !== mi) mi.value = conf.model || '';
  mi.placeholder = preset.type === 'ollama' ? 'Pick a model' : 'Model id';
  const list = $('#top-models');
  list.replaceChildren(...(state.models?.[preset.id] || []).map(m => h('option', { value: m.id }, m.detail || '')));
}

async function checkConn() {
  const { preset, conf } = activeProvider();
  let c;
  if (!state.info) c = { ok: false, label: 'Harness server offline', fix: 'Start it with start.sh or start.bat.' };
  else if (preset.type === 'ollama') {
    try { const v = await ollama.version(); c = { ok: true, label: `Ollama ${v.version || ''} connected`.replace('  ', ' ') }; }
    catch { c = { ok: false, label: `Ollama not reachable at ${conf.baseUrl}`, fix: 'Run "ollama serve", or change the base URL in the Model panel.' }; }
  } else if (preset.local) {
    try { await listModels(preset.id); c = { ok: true, label: `${preset.name} connected` }; }
    catch (e) { c = { ok: false, label: `${preset.name} not reachable`, fix: e.message }; }
  } else {
    const env = preset.env && state.info?.envKeys?.[preset.env];
    c = conf.apiKey || env ? { ok: true, label: `${preset.name} key ${conf.apiKey ? 'set' : `from ${preset.env}`}` } : { ok: false, label: `No API key for ${preset.name}`, fix: 'Paste a key in the Model panel or add it to .env.' };
  }
  state.conn = c;
  const el = $('#conn');
  el.className = `conn ${c.ok ? 'ok' : 'bad'}`;
  el.title = c.fix ? `${c.label}. ${c.fix}` : c.label;
  el.querySelector('.conn-text').textContent = c.ok ? (preset.type === 'ollama' || preset.local ? 'Connected' : 'Key set') : (state.info ? 'Not connected' : 'Offline');
  bus.emit('conn', c);
}

const updateMeter = throttleRAF(() => {
  const c = activeConvo(); const el = $('#ctx-meter');
  if (!c) return;
  let ctx; try { ctx = estimateContext(c); } catch { return; }
  const pct = Math.min(100, (ctx.total / ctx.limit) * 100);
  el.querySelector('.ctx-fill').style.width = `${pct}%`;
  el.classList.toggle('hot', pct > 85);
  el.querySelector('.ctx-text').textContent = `${fmtNum(ctx.total)} / ${fmtNum(ctx.limit)}`;
  el.title = `About ${fmtNum(ctx.total)} of ${fmtNum(ctx.limit)} context tokens used. Open the Inspector for a breakdown.`;
});

// ── signal chain ─────────────────────────────────────────────────
const chainState = { phase: 'idle', step: 0, tool: null, category: null, used: new Set() };
function renderChain() {
  const el = $('#chain'); if (!el) return;
  const { preset, conf } = activeProvider();
  const tools = settings.agent.toolMode === 'off' ? [] : getActiveTools();
  const skillsOn = settings.skills.filter(s => s.enabled);
  const docs = rag.kb.docs.length;
  const sysTok = estimateTokens(settings.systemPrompt);
  const nodes = [
    { id: 'system', label: 'System prompt', icon: 'scroll', value: `${fmtNum(sysTok)} tokens`, set: sysTok > 0, tab: 'model', focus: 'system' },
    { id: 'skills', label: 'Skills', icon: 'book', value: skillsOn.length ? `${skillsOn.length} enabled` : 'none', set: skillsOn.length > 0, tab: 'skills' },
    { id: 'knowledge', label: 'Knowledge', icon: 'database', value: docs ? `${docs} doc${docs === 1 ? '' : 's'}${settings.rag.autoInject ? '' : ', paused'}` : 'empty', set: docs > 0 && (settings.rag.autoInject || settings.rag.asTool), tab: 'knowledge' },
    { id: 'model', label: preset.name, icon: 'cpu', value: conf.model || 'no model', set: !!conf.model, tab: 'model', focus: 'model', main: true },
    { id: 'tools', label: 'Tools', icon: 'tool', value: settings.agent.toolMode === 'off' ? 'off' : `${tools.length} on${settings.agent.toolMode === 'text' ? ', text' : ''}`, set: tools.length > 0, tab: 'tools' },
    { id: 'workspace', label: 'Workspace', icon: 'folder', value: state.info?.rootName || 'offline', set: !!state.info, tab: 'files' },
  ];
  const p = chainState.phase;
  const live = { knowledge: ['knowledge'], model: ['model'], approval: ['tools'], tool: ['tools', ...(['read', 'write', 'exec'].includes(chainState.category) ? ['workspace'] : [])] }[p] || [];
  const children = [];
  nodes.forEach((n, i) => {
    if (i) {
      const flowing = p !== 'idle' && (live.includes(n.id) || (p === 'model' && i <= 3) || (p === 'tool' && n.id === 'workspace' && live.includes('workspace')));
      children.push(h('span', { class: `wire ${flowing ? 'flow' : ''} ${nodes[i - 1].set && n.set ? 'lit' : ''}`, 'aria-hidden': 'true' }));
    }
    const isLive = live.includes(n.id);
    const fed = p === 'model' && ['system', 'skills', 'knowledge'].includes(n.id) && n.set;
    children.push(h('button', {
      class: `node ${n.set ? 'set' : 'unset'} ${isLive ? 'live' : ''} ${fed ? 'fed' : ''} ${p === 'approval' && n.id === 'tools' ? 'waiting' : ''} ${n.main ? 'main' : ''} ${settings.panelOpen && settings.panelTab === n.tab && !narrow() ? 'viewing' : ''}`,
      type: 'button', title: `Open ${n.label} settings`, onClick: () => openPanel(n.tab, n.focus),
    }, h('span', { class: 'node-lamp' }), icon(n.icon, 14), h('span', { class: 'node-text' }, h('span', { class: 'node-label' }, n.label), h('span', { class: 'node-value' }, isLive && n.id === 'tools' && chainState.tool ? (p === 'approval' ? `waiting: ${chainState.tool}` : chainState.tool) : n.value))));
  });
  if (p !== 'idle') children.push(h('span', { class: 'chain-step' }, h('span', { class: 'spin' }), { knowledge: 'Retrieving', model: chainState.step > 1 ? `Step ${chainState.step}` : 'Generating', approval: 'Needs approval', tool: 'Running tool' }[p]));
  el.replaceChildren(...children);
}
bus.on('agent:phase', d => { chainState.phase = d.phase; if (d.step) chainState.step = d.step; chainState.tool = d.tool || null; chainState.category = d.category || null; if (d.phase === 'idle') chainState.step = 0; renderChain(); renderSidebarSoon(); });

// ── sidebar ──────────────────────────────────────────────────────
function groupOf(c) {
  if (c.pinned) return 'Pinned';
  const d = new Date(c.updated), now = new Date();
  const day = 86400000, start = new Date(now.getFullYear(), now.getMonth(), now.getDate()).getTime();
  if (d >= start) return 'Today';
  if (d >= start - day) return 'Yesterday';
  if (d >= start - 6 * day) return 'Previous 7 days';
  return 'Older';
}
function renderSidebar() {
  const q = ($('#side-search').value || '').toLowerCase().trim();
  sortConvos();
  const list = state.convos.filter(c => !q || c.title.toLowerCase().includes(q) || c.messages.some(m => (m.content || '').toLowerCase().includes(q)));
  const groups = new Map();
  for (const c of list) { const g = groupOf(c); if (!groups.has(g)) groups.set(g, []); groups.get(g).push(c); }
  const el = $('#convo-list');
  if (!list.length) { el.replaceChildren(h('p', { class: 'side-empty' }, q ? 'No chats match.' : 'No chats yet.')); return; }
  el.replaceChildren(...[...groups].map(([g, cs]) => h('div', { class: 'cgroup' }, h('div', { class: 'cgroup-title' }, g), cs.map(c => {
    const running = agent.running && agent.convoId === c.id;
    const item = h('div', { class: `citem ${c.id === state.activeId ? 'on' : ''}` },
      h('button', { class: 'citem-main', type: 'button', onClick: () => { switchConvo(c.id); if (innerWidth < 760) toggleSidebar(false); }, onDblclick: () => startRename(item, c) },
        running ? h('span', { class: 'lamp on pulse', title: 'Agent running' }) : c.pinned ? icon('pin', 12) : null,
        h('span', { class: 'citem-title' }, c.title || 'Untitled'),
        h('span', { class: 'citem-meta' }, relTime(c.updated))),
      ibtn('dots', 'Chat options', e => menu(e.currentTarget, [
        { label: 'Rename', icon: 'edit', onClick: () => startRename(item, c) },
        { label: c.pinned ? 'Unpin' : 'Pin to top', icon: 'pin', onClick: () => { c.pinned = !c.pinned; saveConvo(c, { touch: false }); renderSidebar(); } },
        { label: 'Export as Markdown', icon: 'download', onClick: () => exportChat(c) },
        { label: 'Duplicate', icon: 'copy', onClick: () => { const d = JSON.parse(JSON.stringify(c)); d.id = 'c_' + Math.random().toString(36).slice(2, 10); d.title = c.title + ' (copy)'; d.updated = Date.now(); state.convos.unshift(d); saveConvo(d, { immediate: true }); switchConvo(d.id); } },
        'sep',
        { label: 'Delete', icon: 'trash', danger: true, onClick: async () => { if (running) return toast('Stop the agent first', { type: 'warn' }); if (!c.messages.length || await confirmDialog(`Delete "${c.title}"?`, { okLabel: 'Delete chat', danger: true })) deleteConvo(c.id); } },
      ], { align: 'right' }), 'ibtn-sm citem-more'));
    return item;
  }))));
}
const renderSidebarSoon = debounce(renderSidebar, 120);
function startRename(item, c) {
  const inp = h('input', { class: 'input input-sm', value: c.title });
  item.querySelector('.citem-main').replaceWith(inp);
  inp.focus(); inp.select();
  const done = save => { if (save) renameConvo(c, inp.value); renderSidebar(); };
  inp.addEventListener('keydown', e => { if (e.key === 'Enter') done(true); if (e.key === 'Escape') done(false); });
  inp.addEventListener('blur', () => done(true));
}
function startNewChat() {
  const cur = activeConvo();
  if (cur && !cur.messages.length) { focusComposer(); return; }
  newConvo(); focusComposer();
}

// ── backup ───────────────────────────────────────────────────────
async function exportAll() {
  const s = JSON.parse(JSON.stringify(settings));
  for (const p of Object.values(s.providers || {})) p.apiKey = '';
  const docs = rag.kb.docs.map(d => ({ ...d, embedModel: null, chunks: d.chunks.map(({ emb, ...c }) => c) }));
  downloadFile(`agent-harness-backup-${new Date().toISOString().slice(0, 10)}.json`, JSON.stringify({ app: 'agent-harness', version: 1, exported: new Date().toISOString(), settings: s, convos: state.convos, docs }, null, 1));
  toast('Backup downloaded. API keys were left out.', { type: 'ok' });
}
async function importAll() {
  const [f] = await pickFiles({ multiple: false, accept: '.json' }); if (!f) return;
  let j; try { j = JSON.parse(await readFileText(f)); } catch { return toast('That file is not valid JSON', { type: 'err' }); }
  if (j.app !== 'agent-harness') return toast('That is not an Agent Harness backup', { type: 'err' });
  if (!await confirmDialog(`Replace your settings and add ${j.convos?.length || 0} chats and ${j.docs?.length || 0} knowledge documents? Your API keys are kept.`, { title: 'Import backup', okLabel: 'Import and reload' })) return;
  const keys = Object.fromEntries(Object.entries(settings.providers).map(([k, v]) => [k, v.apiKey]));
  replaceSettings(j.settings || {});
  for (const [k, v] of Object.entries(keys)) if (settings.providers[k] && v) settings.providers[k].apiKey = v;
  saveSettings();
  for (const c of j.convos || []) await idb.put('convos', c);
  for (const d of j.docs || []) await idb.put('docs', d);
  setTimeout(() => location.reload(), 400);
}

// ── command palette ──────────────────────────────────────────────
function commands() {
  const list = [
    { label: 'New chat', hint: `${MOD}+Shift+O`, icon: 'plus', run: startNewChat },
    { label: 'Stop the agent', icon: 'stop', run: () => agent.stop(), when: () => agent.running },
    { label: 'Toggle sidebar', hint: `${MOD}+B`, icon: 'sidebar', run: () => toggleSidebar() },
    { label: 'Toggle settings panel', hint: `${MOD}+.`, icon: 'panel', run: () => togglePanel() },
    ...PANELS.map((p, i) => ({ label: `Open ${p.label}`, hint: `Alt+${i + 1}`, icon: p.icon, run: () => openPanel(p.id) })),
    { label: 'Edit system prompt', icon: 'scroll', run: () => openPanel('model', 'system') },
    { label: 'Fetch models', icon: 'refresh', run: () => fetchModels() },
    { label: 'Change theme', icon: 'sun', run: cycleTheme },
    { label: 'Appearance', icon: 'sliders', run: openAppearance },
    { label: 'Tool mode: native', icon: 'tool', run: () => { settings.agent.toolMode = 'native'; saveSettings('agent'); } },
    { label: 'Tool mode: text protocol', icon: 'tool', run: () => { settings.agent.toolMode = 'text'; saveSettings('agent'); } },
    { label: 'Tool mode: off', icon: 'tool', run: () => { settings.agent.toolMode = 'off'; saveSettings('agent'); } },
    { label: 'Approval: ask before every tool', icon: 'shield', run: () => { settings.agent.approval = 'all'; saveSettings('agent'); } },
    { label: 'Approval: ask before changes', icon: 'shield', run: () => { settings.agent.approval = 'risky'; saveSettings('agent'); } },
    { label: 'Approval: never ask', icon: 'shield', run: () => { settings.agent.approval = 'none'; saveSettings('agent'); } },
    { label: 'Export this chat as Markdown', icon: 'download', run: () => exportChat(activeConvo()) },
    { label: 'Back up all data', icon: 'download', run: exportAll },
    { label: 'Restore from backup', icon: 'upload', run: importAll },
    { label: 'Keyboard shortcuts', hint: `${MOD}+/`, icon: 'keyboard', run: showHelp },
    ...PRESETS.map(p => ({ label: `Provider: ${p.name}`, icon: 'cpu', run: () => setProvider(p.id) })),
    ...(state.models?.[settings.provider] || []).map(m => ({ label: `Model: ${m.id}`, icon: 'cpu', run: () => setModel(m.id) })),
    ...state.convos.filter(c => c.id !== state.activeId).slice(0, 40).map(c => ({ label: `Chat: ${c.title}`, icon: 'message', run: () => switchConvo(c.id) })),
  ];
  return list.filter(c => !c.when || c.when());
}
function openPalette() {
  if (document.querySelector('.palette')) return;
  const all = commands();
  let items = all, sel = 0;
  const input = h('input', { class: 'palette-input', placeholder: 'Type a command, model or chat name', 'aria-label': 'Command' });
  const listEl = h('div', { class: 'palette-list', role: 'listbox' });
  const draw = () => {
    listEl.replaceChildren(...items.slice(0, 60).map((c, i) => h('button', { class: `palette-item ${i === sel ? 'on' : ''}`, type: 'button', role: 'option', onMouseMove: () => { if (sel !== i) { sel = i; draw(); } }, onClick: () => run(c) }, icon(c.icon, 15), h('span', {}, c.label), c.hint ? h('kbd', {}, c.hint) : null)));
    listEl.querySelector('.on')?.scrollIntoView({ block: 'nearest' });
  };
  const filter = () => {
    const q = input.value.trim();
    items = q ? all.map(c => ({ c, s: fuzzyScore(q, c.label) })).filter(x => x.s >= 0).sort((a, b) => b.s - a.s).map(x => x.c) : all;
    sel = 0; draw();
  };
  const back = h('div', { class: 'palette-back', onMousedown: e => { if (e.target === back) close(); } }, h('div', { class: 'palette', role: 'dialog', 'aria-label': 'Command palette' }, input, listEl));
  const close = () => { back.remove(); };
  const run = c => { close(); c.run(); };
  input.addEventListener('input', filter);
  input.addEventListener('keydown', e => {
    if (e.key === 'ArrowDown') { e.preventDefault(); sel = Math.min(sel + 1, items.length - 1); draw(); }
    else if (e.key === 'ArrowUp') { e.preventDefault(); sel = Math.max(sel - 1, 0); draw(); }
    else if (e.key === 'Enter') { e.preventDefault(); if (items[sel]) run(items[sel]); }
    else if (e.key === 'Escape') { e.preventDefault(); close(); }
  });
  document.body.appendChild(back); draw(); input.focus();
}

function showHelp() {
  const rows = [
    ['Send message', 'Enter'], ['New line', 'Shift+Enter'], ['Stop the agent', 'Esc'], ['Slash commands', '/ in the message box'],
    ['Command palette', `${MOD}+K`], ['New chat', `${MOD}+Shift+O`], ['Toggle sidebar', `${MOD}+B`], ['Toggle settings panel', `${MOD}+.`],
    ['Open a panel', 'Alt+1 to Alt+6'], ['Focus the message box', '/ (outside a text field)'],
    ['Approve a pending tool', 'Y'], ['Always allow that tool', 'A'], ['Deny a pending tool', 'N'], ['Save while editing a file', `${MOD}+S`], ['Shortcuts', `${MOD}+/`],
  ];
  modal({ title: 'Keyboard shortcuts', body: h('table', { class: 'kv shortcuts' }, rows.map(([a, b]) => h('tr', {}, h('th', {}, a), h('td', {}, b.split(' to ').map((k, i) => [i ? ' to ' : '', h('kbd', {}, k)]))))), actions: [{ label: 'Close' }] });
}

function setupShortcuts() {
  document.addEventListener('keydown', e => {
    const mod = e.metaKey || e.ctrlKey;
    const k = e.key.toLowerCase();
    if (mod && k === 'k') { e.preventDefault(); openPalette(); return; }
    if (mod && k === 'b') { e.preventDefault(); toggleSidebar(); return; }
    if (mod && k === '.') { e.preventDefault(); togglePanel(); return; }
    if (mod && k === '/') { e.preventDefault(); showHelp(); return; }
    if (mod && e.shiftKey && k === 'o') { e.preventDefault(); startNewChat(); return; }
    if (e.altKey && /^[1-6]$/.test(e.key)) { e.preventDefault(); openPanel(PANELS[+e.key - 1].id); return; }
    if (e.key === 'Escape') {
      if (closeTopModal()) { e.preventDefault(); return; }
      if (agent.running) { e.preventDefault(); agent.stop(); return; }
      if (narrow() && settings.panelOpen) togglePanel(false);
    }
    const tag = (e.target.tagName || '').toLowerCase();
    if (e.key === '/' && !mod && !['input', 'textarea', 'select'].includes(tag) && !hasModal()) { e.preventDefault(); focusComposer(); }
  });
}

// ── tooltips ─────────────────────────────────────────────────────
function setupTooltips() {
  const tip = h('div', { id: 'tip', role: 'tooltip', hidden: true }); document.body.appendChild(tip);
  const show = el => {
    tip.textContent = el.dataset.tip; tip.hidden = false;
    const r = el.getBoundingClientRect(), w = tip.offsetWidth, ht = tip.offsetHeight;
    tip.style.left = `${Math.max(8, Math.min(innerWidth - w - 8, r.left + r.width / 2 - w / 2))}px`;
    tip.style.top = `${r.top - ht - 8 < 8 ? r.bottom + 8 : r.top - ht - 8}px`;
  };
  const hide = () => { tip.hidden = true; };
  document.addEventListener('mouseover', e => { const t = e.target.closest('[data-tip]'); t ? show(t) : hide(); });
  document.addEventListener('focusin', e => { const t = e.target.closest?.('[data-tip]'); if (t) show(t); });
  document.addEventListener('focusout', hide);
  document.addEventListener('scroll', hide, true);
}

// ── banner ───────────────────────────────────────────────────────
function banner(text, actionLabel, action) {
  const el = $('#banner');
  el.replaceChildren(icon('alert', 15), h('span', {}, text), actionLabel ? h('button', { class: 'btn btn-sm', type: 'button', onClick: action }, actionLabel) : null, ibtn('x', 'Dismiss', () => { el.hidden = true; }, 'ibtn-sm'));
  el.hidden = false;
}
bus.on('server:token', () => banner('The harness server restarted, so this page lost its session.', 'Reload', () => location.reload()));
bus.on('server:down', () => banner('Lost contact with the harness server. Is it still running?', 'Retry', async () => { try { state.info = await getInfo(); $('#banner').hidden = true; checkConn(); toast('Reconnected', { type: 'ok' }); } catch { toast('Still offline', { type: 'err' }); } }));

// ── boot ─────────────────────────────────────────────────────────
async function boot() {
  applyTheme();
  if (!serverOK) banner('This page was opened without the harness server, so files, the shell and the proxy will not work. Run start.sh or start.bat and open the address it prints.');
  else {
    try { state.info = await getInfo(); }
    catch (e) { state.info = null; if (e.status !== 401) banner(`Could not talk to the harness server: ${e.message}`); }
  }
  const oc = getConf('ollama');
  // Follow the server's Ollama address until the user types their own base URL.
  if (state.info?.ollama && (oc.autoBase !== false) && (oc.autoBase || oc.baseUrl === 'http://127.0.0.1:11434')) { oc.baseUrl = state.info.ollama; oc.autoBase = true; }

  await Promise.all([loadConvos(), rag.loadKB()]);
  const last = localStorage.getItem('harness.active');
  const reuse = state.convos.find(c => c.id === last) || state.convos[0];
  if (reuse) state.activeId = reuse.id; else newConvo();

  if (innerWidth < 1100) settings.panelOpen = false;
  if (innerWidth < 760) settings.sidebarOpen = false;
  applyLayout();
  $('#btn-sidebar').addEventListener('click', () => toggleSidebar());
  $('#btn-panel').addEventListener('click', () => togglePanel());
  $('#btn-theme').addEventListener('click', cycleTheme);
  $('#btn-palette').addEventListener('click', openPalette);
  $('#btn-new').addEventListener('click', startNewChat);
  $('#side-search').addEventListener('input', debounce(renderSidebar, 120));
  $('#btn-backup').addEventListener('click', e => menu(e.currentTarget, [
    { label: 'Appearance', icon: 'sliders', onClick: openAppearance },
    { label: 'Keyboard shortcuts', icon: 'keyboard', onClick: showHelp },
    'sep',
    { label: 'Back up all data', icon: 'download', onClick: exportAll },
    { label: 'Restore from backup', icon: 'upload', onClick: importAll },
    'sep',
    { label: 'Reset all settings', icon: 'rotate', danger: true, onClick: async () => { if (await confirmDialog('Reset every setting to its default? Chats and knowledge are kept.', { okLabel: 'Reset settings', danger: true })) { replaceSettings({}); location.reload(); } } },
  ]));
  $('#ctx-meter').addEventListener('click', () => openPanel('inspector'));
  $('#conn').addEventListener('click', () => openPanel('model'));
  $('#scrim').addEventListener('click', () => { if (innerWidth < 760) settings.sidebarOpen = false; if (narrow()) settings.panelOpen = false; applyLayout(); saveSettings('layout'); });
  setupResize(); setupShortcuts(); setupTooltips();

  mountChat(); mountPanels(); renderSidebar(); renderModelSwitch(); renderChain(); updateMeter();

  bus.on('convos', renderSidebarSoon);
  bus.on('convo:switch', () => { renderSidebar(); updateMeter(); renderChain(); });
  bus.on('convo:msg', updateMeter);
  bus.on('agent:end', () => { renderSidebar(); updateMeter(); });
  bus.on('settings', w => { if (w !== 'layout') { renderChain(); updateMeter(); } });
  bus.on('kb', () => { renderChain(); updateMeter(); });
  bus.on('chain', renderChain);
  bus.on('models:loaded', renderModelSwitch);
  bus.on('model:changed', () => { renderModelSwitch(); renderChain(); updateMeter(); bus.emit('settings', 'model'); });
  bus.on('provider:changed', () => { renderModelSwitch(); renderChain(); checkConn(); updateMeter(); bus.emit('settings', 'model'); });
  bus.on('conn:check', checkConn);
  bus.on('help', showHelp);
  bus.on('panel:open', ({ tab, focus }) => openPanel(tab, focus));

  await checkConn();
  setInterval(() => { if (!document.hidden && !agent.running) checkConn(); }, 30000);
  if (state.info) {
    try {
      const list = await fetchModels(settings.provider, { quiet: true });
      const conf = getConf();
      if (!conf.model && list.length) {
        const pick = list.find(m => !/embed|bge|minilm|e5-/i.test(m.id)) || list[0];
        setModel(pick.id); toast(`Using ${pick.id}. Change it in the header.`, { timeout: 4000 });
      }
    } catch {}
  }
  focusComposer();
}

boot().catch(e => { console.error(e); banner(`Startup failed: ${e.message}`); });
window.__harness = { settings, state, agent, rag };
