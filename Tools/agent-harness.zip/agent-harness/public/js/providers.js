// providers.js — one internal message format, three wire formats (Ollama, OpenAI-compatible, Anthropic).
import { settings } from './store.js';
import { proxyFetch, proxyJSON, logRequest, finishLog } from './api.js';
import { uid, safeJSON, deepClone } from './util.js';

export const PRESETS = [
  { id: 'ollama', name: 'Ollama', type: 'ollama', baseUrl: 'http://127.0.0.1:11434', key: false, local: true },
  { id: 'openai', name: 'OpenAI', type: 'openai', baseUrl: 'https://api.openai.com/v1', key: true, env: 'OPENAI_API_KEY', usage: true, maxKey: 'max_completion_tokens' },
  { id: 'anthropic', name: 'Anthropic', type: 'anthropic', baseUrl: 'https://api.anthropic.com/v1', key: true, env: 'ANTHROPIC_API_KEY' },
  { id: 'openrouter', name: 'OpenRouter', type: 'openai', baseUrl: 'https://openrouter.ai/api/v1', key: true, env: 'OPENROUTER_API_KEY', usage: true },
  { id: 'gemini', name: 'Google Gemini', type: 'openai', baseUrl: 'https://generativelanguage.googleapis.com/v1beta/openai', key: true, env: 'GEMINI_API_KEY' },
  { id: 'groq', name: 'Groq', type: 'openai', baseUrl: 'https://api.groq.com/openai/v1', key: true, env: 'GROQ_API_KEY' },
  { id: 'deepseek', name: 'DeepSeek', type: 'openai', baseUrl: 'https://api.deepseek.com/v1', key: true, env: 'DEEPSEEK_API_KEY' },
  { id: 'mistral', name: 'Mistral', type: 'openai', baseUrl: 'https://api.mistral.ai/v1', key: true, env: 'MISTRAL_API_KEY', shortIds: true },
  { id: 'xai', name: 'xAI', type: 'openai', baseUrl: 'https://api.x.ai/v1', key: true, env: 'XAI_API_KEY' },
  { id: 'together', name: 'Together AI', type: 'openai', baseUrl: 'https://api.together.xyz/v1', key: true, env: 'TOGETHER_API_KEY' },
  { id: 'lmstudio', name: 'LM Studio', type: 'openai', baseUrl: 'http://127.0.0.1:1234/v1', key: false, local: true },
  { id: 'custom', name: 'Custom (OpenAI-compatible)', type: 'openai', baseUrl: 'http://127.0.0.1:8000/v1', key: true, local: true },
];
export const presetById = id => PRESETS.find(p => p.id === id) || PRESETS[0];

const ALL = ['ollama', 'openai', 'anthropic'];
export const PARAM_GROUPS = ['Sampling', 'Repetition', 'Length and memory', 'Advanced'];
export const PARAMS = [
  { key: 'temperature', label: 'Temperature', group: 'Sampling', min: 0, max: 2, step: 0.05, def: 0.7, for: ALL, help: 'How random the output is. Lower gives focused, repeatable answers; higher gives more variety.' },
  { key: 'top_p', label: 'Top P', group: 'Sampling', min: 0, max: 1, step: 0.01, def: 0.9, for: ALL, help: 'Only sample from the most likely tokens whose probabilities add up to this value.' },
  { key: 'top_k', label: 'Top K', group: 'Sampling', min: 1, max: 200, step: 1, def: 40, for: ['ollama', 'anthropic'], help: 'Only sample from the K most likely tokens.' },
  { key: 'min_p', label: 'Min P', group: 'Sampling', min: 0, max: 1, step: 0.01, def: 0.05, for: ['ollama'], help: 'Drop tokens whose probability is below this fraction of the most likely token.' },
  { key: 'typical_p', label: 'Typical P', group: 'Sampling', min: 0, max: 1, step: 0.01, def: 1, for: ['ollama'], help: 'Locally typical sampling. 1 turns it off.' },
  { key: 'repeat_penalty', label: 'Repeat penalty', group: 'Repetition', min: 0.5, max: 2, step: 0.01, def: 1.1, for: ['ollama'], help: 'Penalize tokens that already appeared. Above 1 reduces repetition.' },
  { key: 'repeat_last_n', label: 'Repeat window', group: 'Repetition', min: -1, max: 2048, step: 1, def: 64, for: ['ollama'], help: 'How many recent tokens the repeat penalty looks at. 0 turns it off, -1 uses the whole context.' },
  { key: 'presence_penalty', label: 'Presence penalty', group: 'Repetition', min: -2, max: 2, step: 0.05, def: 0, for: ['ollama', 'openai'], help: 'Pushes the model toward tokens it has not used yet.' },
  { key: 'frequency_penalty', label: 'Frequency penalty', group: 'Repetition', min: -2, max: 2, step: 0.05, def: 0, for: ['ollama', 'openai'], help: 'Penalizes tokens in proportion to how often they appeared.' },
  { key: 'num_ctx', label: 'Context window', group: 'Length and memory', min: 512, max: 262144, step: 512, def: 8192, for: ['ollama'], log: true, help: 'Tokens the model can see at once. Ollama defaults are small; agents need 8k or more. Larger values use more memory.' },
  { key: 'num_predict', label: 'Max output tokens', group: 'Length and memory', min: -1, max: 65536, step: 64, def: 4096, for: ALL, log: true, help: 'Upper limit on generated tokens per reply. -1 means no limit (Ollama only).' },
  { key: 'stop', label: 'Stop sequences', group: 'Length and memory', type: 'list', def: [], for: ALL, help: 'Generation stops when any of these strings appears. One per line.' },
  { key: 'seed', label: 'Seed', group: 'Advanced', min: -1, max: 2147483647, step: 1, def: 42, for: ['ollama', 'openai'], int: true, noSlider: true, help: 'Fixed seed for reproducible output. Works best with temperature 0.' },
  { key: 'mirostat', label: 'Mirostat', group: 'Advanced', options: [0, 1, 2], def: 0, for: ['ollama'], help: 'Adaptive sampling that targets steady perplexity. 0 is off; 1 and 2 are versions. Overrides Top K and Top P.' },
  { key: 'mirostat_tau', label: 'Mirostat tau', group: 'Advanced', min: 0, max: 10, step: 0.1, def: 5, for: ['ollama'], help: 'Target surprise. Lower is more focused.' },
  { key: 'mirostat_eta', label: 'Mirostat eta', group: 'Advanced', min: 0, max: 1, step: 0.01, def: 0.1, for: ['ollama'], help: 'How fast Mirostat reacts.' },
  { key: 'num_gpu', label: 'GPU layers', group: 'Advanced', min: -1, max: 256, step: 1, def: -1, for: ['ollama'], int: true, help: 'Layers to offload to the GPU. 0 runs on the CPU.' },
  { key: 'num_thread', label: 'CPU threads', group: 'Advanced', min: 1, max: 128, step: 1, def: 8, for: ['ollama'], int: true, help: 'Threads for CPU inference. Leave off to auto-detect.' },
  { key: 'num_batch', label: 'Batch size', group: 'Advanced', min: 1, max: 4096, step: 1, def: 512, for: ['ollama'], int: true, help: 'Prompt processing batch size.' },
];

export const SAMPLING_PROFILES = {
  Precise: { temperature: 0.1, top_p: 0.9, top_k: 20, repeat_penalty: 1.05 },
  Balanced: { temperature: 0.6, top_p: 0.9, top_k: 40, repeat_penalty: 1.1 },
  Creative: { temperature: 1.0, top_p: 0.95, top_k: 80, repeat_penalty: 1.15 },
};

function defaultGen(type) {
  const g = {};
  for (const p of PARAMS) g[p.key] = { on: false, v: deepClone(p.def) };
  if (type === 'ollama') { g.temperature = { on: true, v: 0.6 }; g.num_ctx = { on: true, v: 16384 }; }
  if (type === 'anthropic') g.num_predict = { on: true, v: 8192 };
  return g;
}
function defaultExtra(type) {
  if (type === 'ollama') return { think: 'default', keep_alive: { on: false, v: '10m' }, format: '' };
  if (type === 'openai') return { reasoning_effort: 'default' };
  return {};
}

/** Per-provider config, created on first use. */
export function getConf(id = settings.provider) {
  const preset = presetById(id);
  let c = settings.providers[id];
  if (!c) c = settings.providers[id] = { baseUrl: preset.baseUrl, apiKey: '', model: '', gen: defaultGen(preset.type), extra: defaultExtra(preset.type) };
  const dg = defaultGen(preset.type);
  c.gen ||= {};
  for (const k in dg) if (!c.gen[k]) c.gen[k] = dg[k];
  c.extra = { ...defaultExtra(preset.type), ...(c.extra || {}) };
  return c;
}
export const activeProvider = () => ({ preset: presetById(settings.provider), conf: getConf(settings.provider) });
export function resetGen(id = settings.provider) { getConf(id).gen = defaultGen(presetById(id).type); }

const join = (base, p) => String(base || '').replace(/\/+$/, '') + p;

export function headersFor(preset, conf) {
  const h = { 'content-type': 'application/json' };
  if (preset.type === 'anthropic') { if (conf.apiKey) h['x-api-key'] = conf.apiKey; h['anthropic-version'] = '2023-06-01'; }
  else if (preset.type === 'openai') {
    if (conf.apiKey) h.authorization = `Bearer ${conf.apiKey}`;
    else if (preset.local) h.authorization = 'Bearer local';
    if (preset.id === 'openrouter') { h['x-title'] = 'Agent Harness'; h['http-referer'] = location.origin; }
  }
  return h;
}

export async function listModels(id = settings.provider) {
  const preset = presetById(id), conf = getConf(id);
  if (preset.type === 'ollama') {
    const j = await proxyJSON(join(conf.baseUrl, '/api/tags'));
    return (j.models || []).map(m => ({ id: m.name, label: m.name, detail: [m.details?.parameter_size, m.details?.quantization_level].filter(Boolean).join(' '), size: m.size, raw: m }));
  }
  const j = await proxyJSON(join(conf.baseUrl, '/models'), { headers: headersFor(preset, conf) });
  return (j.data || j.models || []).map(m => ({ id: String(m.id || m.name).replace(/^models\//, ''), label: m.display_name || String(m.id || m.name).replace(/^models\//, '') }))
    .sort((a, b) => a.id.localeCompare(b.id));
}

// ── message conversion ────────────────────────────────────────────
function userText(m) {
  let t = m.content || '';
  for (const a of m.attachments || []) if (a.kind === 'text') t += `\n\n<attached_file name="${a.name}">\n${a.text}\n</attached_file>`;
  return t;
}
const imagesOf = m => (m.attachments || []).filter(a => a.kind === 'image' && a.dataUrl);
export function resultText(c) {
  if (c.result != null) return typeof c.result === 'string' ? c.result : JSON.stringify(c.result);
  if (c.status === 'denied') return 'The user denied this tool call.';
  return 'No result: this tool call was cancelled before it ran.';
}
function shortId(id) {
  let h = 0; for (const ch of String(id)) h = (h * 31 + ch.charCodeAt(0)) >>> 0;
  return (h.toString(36) + 'a0b1c2d3e4').slice(0, 9);
}
const isEmptyAssistant = m => !m.content?.trim() && !(m.toolCalls || []).length;

function pushTextMode(out, m, mk) {
  const calls = m.toolCalls || [];
  let content = m.content || '';
  if (calls.length) content += (content ? '\n\n' : '') + calls.map(c => `<tool_call>\n${JSON.stringify({ name: c.name, arguments: c.args || {} })}\n</tool_call>`).join('\n');
  out.push(mk('assistant', content));
  if (calls.length) out.push(mk('user', calls.map(c => `<tool_result name="${c.name}">\n${resultText(c)}\n</tool_result>`).join('\n\n')));
}

function toOllama(messages, system, native) {
  const out = system ? [{ role: 'system', content: system }] : [];
  for (const m of messages) {
    if (m.role === 'user') {
      const o = { role: 'user', content: userText(m) };
      const imgs = imagesOf(m); if (imgs.length) o.images = imgs.map(i => i.dataUrl.split(',')[1]);
      out.push(o);
    } else if (m.role === 'assistant' && !isEmptyAssistant(m)) {
      const calls = m.toolCalls || [];
      if (!native) { pushTextMode(out, m, (role, content) => ({ role, content })); continue; }
      const o = { role: 'assistant', content: m.content || '' };
      if (calls.length) o.tool_calls = calls.map(c => ({ function: { name: c.name, arguments: c.args || {} } }));
      out.push(o);
      for (const c of calls) out.push({ role: 'tool', content: resultText(c), tool_name: c.name });
    }
  }
  return out;
}

function toOpenAI(messages, system, native, preset) {
  const out = system ? [{ role: 'system', content: system }] : [];
  const fixId = id => preset.shortIds ? shortId(id) : id;
  for (const m of messages) {
    if (m.role === 'user') {
      const imgs = imagesOf(m);
      out.push({ role: 'user', content: imgs.length ? [{ type: 'text', text: userText(m) }, ...imgs.map(i => ({ type: 'image_url', image_url: { url: i.dataUrl } }))] : userText(m) });
    } else if (m.role === 'assistant' && !isEmptyAssistant(m)) {
      const calls = m.toolCalls || [];
      if (!native) { pushTextMode(out, m, (role, content) => ({ role, content })); continue; }
      const o = { role: 'assistant', content: m.content || (calls.length ? null : '') };
      if (calls.length) o.tool_calls = calls.map(c => ({ id: fixId(c.id), type: 'function', function: { name: c.name, arguments: JSON.stringify(c.args || {}) } }));
      out.push(o);
      for (const c of calls) out.push({ role: 'tool', tool_call_id: fixId(c.id), content: resultText(c) });
    }
  }
  return out;
}

function toAnthropic(messages, native) {
  const out = [];
  const push = (role, blocks) => {
    const last = out[out.length - 1];
    if (last && last.role === role) last.content.push(...blocks); else out.push({ role, content: blocks });
  };
  for (const m of messages) {
    if (m.role === 'user') {
      const imgs = imagesOf(m).map(i => ({ type: 'image', source: { type: 'base64', media_type: i.mime || i.dataUrl.slice(5, i.dataUrl.indexOf(';')), data: i.dataUrl.split(',')[1] } }));
      push('user', [...imgs, { type: 'text', text: userText(m) || '(empty message)' }]);
    } else if (m.role === 'assistant' && !isEmptyAssistant(m)) {
      const calls = m.toolCalls || [];
      if (!native) {
        const tmp = []; pushTextMode(tmp, m, (role, content) => ({ role, content }));
        for (const t of tmp) if (t.content.trim()) push(t.role, [{ type: 'text', text: t.content }]);
        continue;
      }
      const blocks = [];
      if (m.content?.trim()) blocks.push({ type: 'text', text: m.content });
      for (const c of calls) blocks.push({ type: 'tool_use', id: c.id, name: c.name, input: c.args || {} });
      push('assistant', blocks);
      if (calls.length) push('user', calls.map(c => ({ type: 'tool_result', tool_use_id: c.id, content: resultText(c), ...(c.status === 'error' ? { is_error: true } : {}) })));
    }
  }
  if (out[0]?.role !== 'user') out.unshift({ role: 'user', content: [{ type: 'text', text: '(conversation start)' }] });
  return out;
}

function genFor(preset, conf) {
  const g = conf.gen, on = k => g[k]?.on, v = k => g[k]?.v;
  const stops = (v('stop') || []).filter(Boolean);
  if (preset.type === 'ollama') {
    const options = {};
    for (const p of PARAMS) {
      if (!p.for.includes('ollama') || !on(p.key)) continue;
      if (p.key === 'stop') { if (stops.length) options.stop = stops; }
      else options[p.key] = Number(v(p.key));
    }
    return { options };
  }
  if (preset.type === 'openai') {
    const o = {};
    for (const k of ['temperature', 'top_p', 'presence_penalty', 'frequency_penalty']) if (on(k)) o[k] = Number(v(k));
    if (on('seed')) o.seed = Math.trunc(Number(v('seed')));
    if (on('num_predict') && v('num_predict') > 0) o[preset.maxKey || 'max_tokens'] = Number(v('num_predict'));
    if (on('stop') && stops.length) o.stop = stops.slice(0, 4);
    if (conf.extra.reasoning_effort && conf.extra.reasoning_effort !== 'default') o.reasoning_effort = conf.extra.reasoning_effort;
    return o;
  }
  // anthropic: max_tokens is required; temperature and top_p are not combined
  const o = { max_tokens: on('num_predict') && v('num_predict') > 0 ? Number(v('num_predict')) : 8192 };
  if (on('temperature')) o.temperature = Math.min(1, Number(v('temperature')));
  else if (on('top_p')) o.top_p = Number(v('top_p'));
  if (on('top_k')) o.top_k = Number(v('top_k'));
  if (on('stop') && stops.length) o.stop_sequences = stops;
  return o;
}

/** Build the provider request. tools: [{name, description, parameters}] */
export function buildRequest({ presetId = settings.provider, messages, system, tools = [], toolMode = 'native', stream = true }) {
  const preset = presetById(presetId), conf = getConf(presetId);
  const native = toolMode === 'native';
  const useTools = native && tools.length > 0;
  const model = (conf.model || '').trim();
  if (!model) throw new Error(`No model selected for ${preset.name}. Pick one in the header or the Model panel.`);
  let url, body;
  if (preset.type === 'ollama') {
    url = join(conf.baseUrl, '/api/chat');
    body = { model, messages: toOllama(messages, system, native), stream, ...genFor(preset, conf) };
    if (useTools) body.tools = tools.map(t => ({ type: 'function', function: { name: t.name, description: t.description, parameters: t.parameters } }));
    const x = conf.extra;
    if (x.think && x.think !== 'default') body.think = x.think === 'on' ? true : x.think === 'off' ? false : x.think;
    if (x.keep_alive?.on) body.keep_alive = /^-?\d+$/.test(String(x.keep_alive.v)) ? Number(x.keep_alive.v) : x.keep_alive.v;
    if (x.format === 'json') body.format = 'json';
  } else if (preset.type === 'openai') {
    url = join(conf.baseUrl, '/chat/completions');
    body = { model, messages: toOpenAI(messages, system, native, preset), stream, ...genFor(preset, conf) };
    if (stream && preset.usage) body.stream_options = { include_usage: true };
    if (useTools) body.tools = tools.map(t => ({ type: 'function', function: { name: t.name, description: t.description, parameters: t.parameters } }));
  } else {
    url = join(conf.baseUrl, '/messages');
    body = { model, messages: toAnthropic(messages, native), stream, ...genFor(preset, conf) };
    if (system) body.system = system;
    if (useTools) body.tools = tools.map(t => ({ name: t.name, description: t.description, input_schema: t.parameters }));
  }
  return { url, headers: headersFor(preset, conf), body, preset, conf };
}

// ── streaming ─────────────────────────────────────────────────────
async function* rawLines(res) {
  const reader = res.body.getReader(); const dec = new TextDecoder(); let buf = '';
  for (;;) {
    const { value, done } = await reader.read();
    if (done) break;
    buf += dec.decode(value, { stream: true });
    let i;
    while ((i = buf.indexOf('\n')) >= 0) { yield buf.slice(0, i).replace(/\r$/, ''); buf = buf.slice(i + 1); }
  }
  buf += dec.decode();
  if (buf) yield buf.replace(/\r$/, '');
}
export async function* ndjson(res) { for await (const l of rawLines(res)) if (l.trim()) yield JSON.parse(l); }
async function* sse(res) {
  let event = 'message', data = [];
  for await (const line of rawLines(res)) {
    if (line === '') { if (data.length) yield { event, data: data.join('\n') }; event = 'message'; data = []; continue; }
    if (line.startsWith(':')) continue;
    const c = line.indexOf(':');
    const field = c < 0 ? line : line.slice(0, c);
    let val = c < 0 ? '' : line.slice(c + 1);
    if (val.startsWith(' ')) val = val.slice(1);
    if (field === 'event') event = val; else if (field === 'data') data.push(val);
  }
  if (data.length) yield { event, data: data.join('\n') };
}

/** Splits <think>…</think> out of streamed content, even across chunk boundaries. */
export class ThinkSplitter {
  constructor() { this.inThink = false; this.buf = ''; }
  push(text) {
    this.buf += text; let content = '', thinking = '';
    while (this.buf) {
      const tag = this.inThink ? '</think>' : '<think>';
      const i = this.buf.indexOf(tag);
      if (i >= 0) {
        if (this.inThink) thinking += this.buf.slice(0, i); else content += this.buf.slice(0, i);
        this.buf = this.buf.slice(i + tag.length); this.inThink = !this.inThink; continue;
      }
      let keep = 0;
      for (let n = Math.min(tag.length - 1, this.buf.length); n > 0; n--) if (tag.startsWith(this.buf.slice(-n))) { keep = n; break; }
      const emit = this.buf.slice(0, this.buf.length - keep);
      if (this.inThink) thinking += emit; else content += emit;
      this.buf = this.buf.slice(this.buf.length - keep); break;
    }
    return { content, thinking };
  }
  flush() { const r = this.inThink ? { content: '', thinking: this.buf } : { content: this.buf, thinking: '' }; this.buf = ''; return r; }
}

function extractError(text) {
  const j = safeJSON(text);
  if (!j) return text.slice(0, 500);
  const e = j.error ?? j.message ?? j.detail;
  if (typeof e === 'string') return e;
  if (e?.message) return e.message;
  if (Array.isArray(j) && j[0]?.error?.message) return j[0].error.message;
  return text.slice(0, 500);
}

/**
 * Stream one model turn. onDelta(out) fires as tokens arrive.
 * Returns { content, thinking, toolCalls:[{id,name,args}], usage:{input, output, tps}, stopReason, ttft, ms }
 */
export async function streamChat({ request, signal, onDelta = () => {} }) {
  const { url, headers, body, preset } = request;
  const log = logRequest({ provider: preset.name, model: body.model, url, headers, body });
  const t0 = performance.now();
  const out = { content: '', thinking: '', toolCalls: [], partialCalls: [], usage: {}, stopReason: null, ttft: null, ms: 0 };
  const splitter = new ThinkSplitter();
  let firstAt = null;
  const mark = () => { if (firstAt == null) { firstAt = performance.now(); out.ttft = firstAt - t0; } };
  const addText = t => { if (!t) return; mark(); const r = splitter.push(t); out.content += r.content; out.thinking += r.thinking; };
  const addThinking = t => { if (!t) return; mark(); out.thinking += t; };
  const done = (status, extra = {}) => finishLog(log, { status, ms: Math.round(performance.now() - t0), ...extra });

  let res;
  try { res = await proxyFetch(url, { method: 'POST', headers, body: JSON.stringify(body), signal }); }
  catch (e) { done(e.name === 'AbortError' ? 'aborted' : 'error', { response: e.message }); throw e; }
  if (!res.ok) {
    const text = await res.text().catch(() => '');
    const msg = extractError(text) || res.statusText;
    done('error', { code: res.status, response: text.slice(0, 6000) });
    const err = new Error(`${preset.name} returned ${res.status}: ${msg}`);
    err.status = res.status; err.detail = msg; throw err;
  }

  try {
    if (preset.type === 'ollama') {
      for await (const j of ndjson(res)) {
        if (j.error) throw new Error(j.error);
        const m = j.message || {};
        addThinking(m.thinking); addText(m.content);
        for (const tc of m.tool_calls || []) {
          mark();
          const a = tc.function?.arguments;
          out.toolCalls.push({ id: uid('call_'), name: tc.function?.name, args: typeof a === 'string' ? safeJSON(a, { _raw: a }) : (a || {}) });
        }
        if (j.done) {
          out.stopReason = j.done_reason;
          out.usage = { input: j.prompt_eval_count, output: j.eval_count, tps: j.eval_count && j.eval_duration ? j.eval_count / (j.eval_duration / 1e9) : null, loadMs: j.load_duration ? j.load_duration / 1e6 : null };
        }
        onDelta(out);
      }
    } else if (preset.type === 'openai') {
      const acc = [];
      for await (const ev of sse(res)) {
        if (ev.data === '[DONE]') break;
        const j = safeJSON(ev.data); if (!j) continue;
        if (j.error) throw new Error(j.error.message || JSON.stringify(j.error));
        if (j.usage) out.usage = { input: j.usage.prompt_tokens, output: j.usage.completion_tokens };
        const ch = j.choices?.[0]; if (!ch) continue;
        const d = ch.delta || ch.message || {};
        addThinking(typeof d.reasoning_content === 'string' ? d.reasoning_content : typeof d.reasoning === 'string' ? d.reasoning : '');
        addText(d.content);
        for (const tc of d.tool_calls || []) {
          mark();
          let i = tc.index;
          if (i == null) i = tc.id && !acc.some(a => a.id === tc.id) ? acc.length : Math.max(0, acc.length - 1);
          const a = acc[i] ||= { id: '', name: '', args: '' };
          if (tc.id) a.id = tc.id;
          const nm = tc.function?.name;
          if (nm && nm !== a.name) a.name = a.name && !nm.startsWith(a.name) ? a.name + nm : nm;
          if (tc.function?.arguments) a.args += typeof tc.function.arguments === 'string' ? tc.function.arguments : JSON.stringify(tc.function.arguments);
        }
        out.partialCalls = acc.filter(Boolean).map(a => ({ name: a.name, argsText: a.args }));
        if (ch.finish_reason) out.stopReason = ch.finish_reason;
        onDelta(out);
      }
      out.toolCalls = acc.filter(a => a && a.name).map(a => ({ id: a.id || uid('call_'), name: a.name, args: a.args.trim() ? safeJSON(a.args, { _raw: a.args }) : {} }));
    } else {
      const blocks = [];
      for await (const ev of sse(res)) {
        const j = safeJSON(ev.data); if (!j) continue;
        switch (j.type) {
          case 'message_start': out.usage.input = j.message?.usage?.input_tokens; break;
          case 'content_block_start': blocks[j.index] = { ...j.content_block, _json: '' }; if (j.content_block?.type === 'tool_use') mark(); break;
          case 'content_block_delta': {
            const d = j.delta || {};
            if (d.type === 'text_delta') addText(d.text);
            else if (d.type === 'thinking_delta') addThinking(d.thinking);
            else if (d.type === 'input_json_delta' && blocks[j.index]) blocks[j.index]._json += d.partial_json;
            break;
          }
          case 'message_delta': out.stopReason = j.delta?.stop_reason; if (j.usage?.output_tokens != null) out.usage.output = j.usage.output_tokens; break;
          case 'error': throw new Error(j.error?.message || 'Stream error');
        }
        out.partialCalls = blocks.filter(b => b?.type === 'tool_use').map(b => ({ name: b.name, argsText: b._json }));
        onDelta(out);
      }
      out.toolCalls = blocks.filter(b => b?.type === 'tool_use').map(b => ({ id: b.id, name: b.name, args: b._json.trim() ? safeJSON(b._json, { _raw: b._json }) : (b.input || {}) }));
    }
  } catch (e) {
    done(e.name === 'AbortError' ? 'aborted' : 'error', { code: res.status, response: e.message, partial: out.content.slice(0, 2000) });
    if (e.name === 'AbortError') { const f = splitter.flush(); out.content += f.content; out.thinking += f.thinking; e.partial = out; }
    throw e;
  }
  const f = splitter.flush(); out.content += f.content; out.thinking += f.thinking;
  out.content = out.content.replace(/^\s+/, '');
  out.thinking = out.thinking.trim();
  out.partialCalls = [];
  out.ms = performance.now() - t0;
  if (out.usage.tps == null && out.usage.output && firstAt) out.usage.tps = out.usage.output / ((performance.now() - firstAt) / 1000);
  done('ok', { code: res.status, response: { content: out.content.slice(0, 6000), thinking: out.thinking.slice(0, 3000), toolCalls: out.toolCalls, usage: out.usage, stopReason: out.stopReason } });
  onDelta(out);
  return out;
}

// ── text tool protocol (for models without native tool calling) ──
export function textToolPrompt(tools) {
  const list = tools.map(t => `### ${t.name}\n${t.description}\nArguments (JSON Schema): ${JSON.stringify(t.parameters)}`).join('\n\n');
  return `# Tool use
You can call tools. To call one, write a block in exactly this format:

<tool_call>
{"name": "tool_name", "arguments": {"key": "value"}}
</tool_call>

Rules:
- The block must contain one JSON object with "name" and "arguments". Use double quotes.
- You may write a short sentence before the block. You may call several tools by writing several blocks.
- After your tool calls, stop writing. The results arrive in the next message inside <tool_result name="..."> tags.
- When the task is finished, answer normally with no <tool_call> block.

## Available tools

${list}`;
}

function parseCallJSON(s) {
  s = s.trim().replace(/^```(?:json)?\s*/i, '').replace(/```\s*$/, '').trim();
  const a = s.indexOf('{'), b = s.lastIndexOf('}');
  if (a < 0 || b < a) return null;
  const raw = s.slice(a, b + 1);
  let j = safeJSON(raw) || safeJSON(raw.replace(/,\s*([}\]])/g, '$1'));
  if (!j) return null;
  const name = j.name || j.tool || j.function?.name;
  if (!name || typeof name !== 'string') return null;
  let args = j.arguments ?? j.parameters ?? j.args ?? j.input ?? j.function?.arguments ?? {};
  if (typeof args === 'string') args = safeJSON(args, { _raw: args });
  return { id: uid('call_'), name, args, hasArgsKey: 'arguments' in j || 'parameters' in j };
}

/** Pull <tool_call> blocks (and, as a fallback, fenced JSON naming a known tool) out of text. */
export function parseTextToolCalls(text, knownNames = []) {
  const calls = [];
  let clean = String(text || '').replace(/<tool_call>\s*([\s\S]*?)\s*(?:<\/tool_call>|$)/g, (m, body) => {
    const c = parseCallJSON(body); if (c) { calls.push(c); return ''; } return m;
  });
  if (!calls.length && knownNames.length) {
    clean = clean.replace(/```(?:json|tool_call)?\s*(\{[\s\S]*?\})\s*```/g, (m, body) => {
      const c = parseCallJSON(body);
      if (c && c.hasArgsKey && knownNames.includes(c.name)) { calls.push(c); return ''; }
      return m;
    });
  }
  return { clean: clean.replace(/\n{3,}/g, '\n\n').trim(), calls: calls.map(({ hasArgsKey, ...c }) => c) };
}

// ── Ollama management ────────────────────────────────────────────
const ojson = { 'content-type': 'application/json' };
export const ollama = {
  base: () => getConf('ollama').baseUrl,
  version: () => proxyJSON(join(ollama.base(), '/api/version')),
  tags: () => proxyJSON(join(ollama.base(), '/api/tags')),
  ps: () => proxyJSON(join(ollama.base(), '/api/ps')),
  show: model => proxyJSON(join(ollama.base(), '/api/show'), { method: 'POST', headers: ojson, body: JSON.stringify({ model }) }),
  unload: model => proxyJSON(join(ollama.base(), '/api/generate'), { method: 'POST', headers: ojson, body: JSON.stringify({ model, keep_alive: 0 }) }),
  load: model => proxyJSON(join(ollama.base(), '/api/generate'), { method: 'POST', headers: ojson, body: JSON.stringify({ model, keep_alive: '10m' }) }),
  async remove(model) {
    const res = await proxyFetch(join(ollama.base(), '/api/delete'), { method: 'DELETE', headers: ojson, body: JSON.stringify({ model }) });
    if (!res.ok) throw new Error(extractError(await res.text()) || `Delete failed (${res.status})`);
  },
  async pull(model, onProgress, signal) {
    const res = await proxyFetch(join(ollama.base(), '/api/pull'), { method: 'POST', headers: ojson, body: JSON.stringify({ model, stream: true }), signal });
    if (!res.ok) throw new Error(extractError(await res.text()) || `Pull failed (${res.status})`);
    for await (const j of ndjson(res)) { if (j.error) throw new Error(j.error); onProgress(j); }
  },
};

// ── embeddings ───────────────────────────────────────────────────
export async function embed(texts, { signal } = {}) {
  const e = settings.rag.embed;
  if (!e.model) throw new Error('Set an embedding model in the Knowledge panel first.');
  if (e.source === 'ollama') {
    const j = await proxyJSON(join(getConf('ollama').baseUrl, '/api/embed'), { method: 'POST', headers: ojson, body: JSON.stringify({ model: e.model, input: texts, truncate: true }), signal });
    if (!j.embeddings) throw new Error('Ollama returned no embeddings. Is this an embedding model?');
    return j.embeddings;
  }
  const preset = presetById(e.source);
  if (preset.type !== 'openai') throw new Error(`${preset.name} has no OpenAI-compatible embeddings endpoint.`);
  const conf = getConf(preset.id);
  const j = await proxyJSON(join(conf.baseUrl, '/embeddings'), { method: 'POST', headers: headersFor(preset, conf), body: JSON.stringify({ model: e.model, input: texts }), signal });
  return (j.data || []).sort((a, b) => a.index - b.index).map(d => d.embedding);
}
