// panel-inspector.js — see exactly what is sent: context budget, the next request, and a log of raw calls.
import { activeConvo } from './store.js';
import { requestLog } from './api.js';
import { estimateContext, previewRequest } from './agent.js';
import { highlight } from './markdown.js';
import { h, icon, ibtn, modal, bus, fmtNum, fmtDuration, copyText, throttleRAF } from './util.js';
import { section, btn, empty } from './ui.js';

let root;
export default {
  id: 'inspector', label: 'Inspector', icon: 'activity',
  mount(el) {
    root = el; render();
    const redraw = throttleRAF(() => { drawLog(); drawContext(); });
    bus.on('log', redraw); bus.on('convo:switch', redraw); bus.on('agent:end', redraw); bus.on('settings', redraw);
  },
  show() { drawContext(); drawLog(); },
};

function render() {
  root.replaceChildren(
    section('Context budget', h('div', { id: 'ctx-breakdown', class: 'stack-sm' }), { id: 'ins-ctx', sub: 'Estimated at about 4 characters per token. Real counts appear under each reply.' }),
    h('div', { class: 'row' }, btn('Preview the next request', showPreview, { iconName: 'eye', kind: 'primary' }), h('span', { class: 'spacer' })),
    section('Request log', h('div', { id: 'req-log', class: 'req-log' }), { id: 'ins-log', actions: [ibtn('trash', 'Clear log', () => { requestLog.length = 0; drawLog(); }, 'ibtn-sm')] }));
  drawContext(); drawLog();
}

function drawContext() {
  const el = root?.querySelector('#ctx-breakdown'); if (!el) return;
  const c = activeConvo();
  if (!c) { el.replaceChildren(h('p', { class: 'muted small' }, 'No chat selected.')); return; }
  let ctx;
  try { ctx = estimateContext(c); } catch (e) { el.replaceChildren(h('p', { class: 'form-error' }, e.message)); return; }
  const pct = Math.min(100, (ctx.total / ctx.limit) * 100);
  el.replaceChildren(
    h('div', { class: 'ctx-total' }, h('strong', {}, `${fmtNum(ctx.total)} tokens`), h('span', { class: 'muted' }, ` of ${fmtNum(ctx.limit)}`), h('span', { class: 'spacer' }), h('span', { class: pct > 85 ? 'warn-text' : 'muted' }, `${pct.toFixed(0)}%`)),
    h('div', { class: 'meter' }, ctx.parts.map(p => h('span', { style: { width: `${(p.tokens / ctx.limit) * 100}%` }, title: `${p.label}: ${fmtNum(p.tokens)}` }))),
    h('ul', { class: 'ctx-parts' }, ctx.parts.map((p, i) => h('li', {}, h('span', { class: `sw sw-${i % 6}` }), h('span', {}, p.label), h('span', { class: 'spacer' }), h('span', { class: 'mono small' }, fmtNum(p.tokens))))));
}

function showPreview() {
  const c = activeConvo();
  let req;
  try { req = previewRequest(c || { messages: [] }); } catch (e) { return modal({ title: 'Cannot build the request', body: h('p', { class: 'form-error' }, e.message), actions: [{ label: 'Close', ghost: true }] }); }
  const headers = { ...req.headers };
  for (const k of Object.keys(headers)) if (/authorization|api-key/i.test(k)) headers[k] = '(hidden)';
  const json = JSON.stringify({ url: req.url, headers, body: req.body }, null, 2);
  modal({
    title: 'Next request', full: true,
    body: h('div', { class: 'stack' }, h('p', { class: 'muted' }, `What will be sent to ${req.preset.name} when you send your next message (without your new message). About ${fmtNum(Math.ceil(json.length / 4))} tokens.`), h('pre', { class: 'code', html: highlight(json, 'json') })),
    actions: [{ label: 'Copy JSON', ghost: true, icon: 'copy', onClick: () => { copyText(json); return false; } }, { label: 'Close' }],
  });
}

function drawLog() {
  const el = root?.querySelector('#req-log'); if (!el) return;
  if (!requestLog.length) { el.replaceChildren(empty('activity', 'No requests yet', 'Every call to a model appears here with its full payload and response.')); return; }
  el.replaceChildren(...requestLog.map(r => h('button', { class: `req req-${r.status}`, type: 'button', onClick: () => showEntry(r) },
    h('span', { class: `lamp ${r.status === 'ok' ? 'on' : r.status === 'pending' ? 'wait' : r.status === 'error' ? 'err' : ''}` }),
    h('span', { class: 'req-main' }, h('span', { class: 'req-model' }, r.model || 'request'), h('small', {}, `${r.provider}${r.code ? `, HTTP ${r.code}` : ''}, ${new Date(r.time).toLocaleTimeString()}`)),
    h('span', { class: 'req-ms mono' }, r.status === 'pending' ? 'live' : fmtDuration(r.ms)))));
}

function showEntry(r) {
  const reqJson = JSON.stringify({ url: r.url, headers: r.headers, body: r.body }, null, 2);
  const resJson = typeof r.response === 'string' ? r.response : JSON.stringify(r.response, null, 2);
  modal({
    title: `${r.model} via ${r.provider}`, full: true,
    body: h('div', { class: 'split2' },
      h('div', { class: 'stack' }, h('div', { class: 'tc-label' }, 'Request', h('button', { class: 'linkbtn', type: 'button', onClick: () => copyText(reqJson) }, 'Copy')), h('pre', { class: 'code', html: highlight(reqJson, 'json') })),
      h('div', { class: 'stack' }, h('div', { class: 'tc-label' }, `Response (${r.status}${r.ms != null ? `, ${fmtDuration(r.ms)}` : ''})`, h('button', { class: 'linkbtn', type: 'button', onClick: () => copyText(resJson || '') }, 'Copy')), h('pre', { class: 'code', html: highlight(resJson || '(still streaming)', 'json') }))),
    actions: [{ label: 'Close' }],
  });
}
