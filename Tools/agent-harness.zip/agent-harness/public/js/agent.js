// agent.js — the loop: retrieve → ask the model → run tool calls (with approval) → repeat until done.
import { settings, saveSettings, saveConvo, state } from './store.js';
import { buildRequest, streamChat, activeProvider, textToolPrompt, parseTextToolCalls } from './providers.js';
import { getActiveTools, approvalFor, executeTool, validateArgs, schemaOf } from './tools.js';
import { skillsFor } from './skills.js';
import * as rag from './rag.js';
import { bus, uid, throttleRAF, estimateTokens, truncate } from './util.js';

export function renderTemplate(text) {
  const info = state.info || {};
  const now = new Date();
  const vars = {
    date: now.toLocaleDateString(undefined, { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' }),
    time: now.toLocaleTimeString(),
    workspace: info.root || './workspace',
    os: info.os || navigator.platform,
    shell: info.shell || 'sh',
    model: activeProvider().conf.model || 'unknown',
    tools: getActiveTools().map(t => t.name).join(', '),
  };
  return String(text || '').replace(/\{\{(\w+)\}\}/g, (m, k) => (k in vars ? vars[k] : m));
}

const lastUserOf = convo => [...convo.messages].reverse().find(m => m.role === 'user');

/** Assemble the system prompt from its parts. Parts are shown in the Inspector and the signal chain. */
export function buildSystem(convo) {
  const parts = [];
  const lastUser = lastUserOf(convo);
  const base = renderTemplate(settings.systemPrompt);
  if (base.trim()) parts.push({ id: 'system', label: 'System prompt', text: base });

  const { injected, loadable } = skillsFor(lastUser?.content || '', lastUser?.forceSkills || []);
  if (injected.length) parts.push({ id: 'skills', label: `Skills: ${injected.map(s => s.name).join(', ')}`, text: '# Active skills\nFollow these instructions where they apply.\n\n' + injected.map(s => `## ${s.name}\n${s.content.trim()}`).join('\n\n') });

  const toolMode = settings.agent.toolMode;
  const tools = toolMode === 'off' ? [] : getActiveTools();
  if (loadable.length && tools.some(t => t.name === 'load_skill')) parts.push({ id: 'skill-index', label: 'Skill index', text: '# Skills you can load\nWhen a task matches one of these, call load_skill with its name to read the full instructions first.\n' + loadable.map(s => `- ${s.name}: ${s.description}`).join('\n') });
  if (toolMode === 'text' && tools.length) parts.push({ id: 'tools', label: 'Text tool protocol', text: textToolPrompt(tools.map(schemaOf)) });
  if (lastUser?.rag?.length) parts.push({ id: 'rag', label: `Knowledge: ${lastUser.rag.length} excerpts`, text: '# Retrieved context\nThese excerpts from the knowledge base may help with the latest request. Cite them as [1], [2] when you use them, and ignore them if they are not relevant.\n\n' + rag.formatResults(lastUser.rag) });
  return { text: parts.map(p => p.text).join('\n\n'), parts, skills: injected.map(s => s.name), tools };
}

export function historyOf(convo) { return convo.messages.filter(m => m.role === 'user' || m.role === 'assistant'); }

/** Rough token budget for the header meter and the Inspector. */
export function estimateContext(convo) {
  const sys = buildSystem(convo);
  const toolsTok = settings.agent.toolMode === 'native' ? estimateTokens(JSON.stringify(sys.tools.map(schemaOf))) : 0;
  const histTok = estimateTokens(JSON.stringify(historyOf(convo).map(m => [m.content, m.toolCalls?.map(c => [c.args, c.result]), m.attachments?.map(a => a.text)])));
  const { preset, conf } = activeProvider();
  const limit = preset.type === 'ollama' ? (conf.gen.num_ctx?.on ? Number(conf.gen.num_ctx.v) : 4096) : settings.agent.contextLimit;
  const parts = sys.parts.map(p => ({ label: p.label, tokens: estimateTokens(p.text) }));
  if (toolsTok) parts.push({ label: 'Tool definitions', tokens: toolsTok });
  parts.push({ label: 'Conversation', tokens: histTok });
  const total = parts.reduce((n, p) => n + p.tokens, 0);
  return { total, limit, parts };
}

export function previewRequest(convo) {
  const sys = buildSystem(convo);
  return buildRequest({ messages: historyOf(convo), system: sys.text, tools: sys.tools.map(schemaOf), toolMode: settings.agent.toolMode });
}

function abortError() { return new DOMException('Stopped', 'AbortError'); }

export function pushNotice(convo, content, level = 'info') {
  const msg = { id: uid('m_'), role: 'notice', content, level, time: Date.now() };
  convo.messages.push(msg);
  bus.emit('convo:msg', { convo, msg, added: true });
  return msg;
}

const NO_TOOLS_RE = /does not support tools|tool use is not supported|tools? (are|is) not supported|function calling is not (enabled|supported)|tool_choice.*not supported/i;

class Agent {
  constructor() {
    this.running = false; this.controller = null; this.convoId = null;
    this.approvals = new Map(); this.sessionAllow = new Set(); this.phase = 'idle';
  }

  setPhase(phase, detail = {}) { this.phase = phase; bus.emit('agent:phase', { phase, ...detail }); }
  stop() { this.controller?.abort(); }
  resolveApproval(callId, decision) {
    const a = this.approvals.get(callId);
    if (a) { this.approvals.delete(callId); a.resolve(decision); }
  }
  waitApproval(callId, signal) {
    return new Promise((resolve, reject) => {
      if (signal.aborted) return reject(abortError());
      this.approvals.set(callId, { resolve, reject });
      signal.addEventListener('abort', () => { this.approvals.delete(callId); reject(abortError()); }, { once: true });
    });
  }

  async send(convo, { text, attachments = [], forceSkills = [] }) {
    if (this.running) return;
    const user = { id: uid('m_'), role: 'user', content: text, attachments, forceSkills, time: Date.now() };
    convo.messages.push(user);
    if ((!convo.title || convo.title === 'New chat') && text.trim()) { convo.title = truncate(text.trim().split('\n')[0], 60); bus.emit('convos'); }
    saveConvo(convo);
    bus.emit('convo:msg', { convo, msg: user, added: true });
    return this.run(convo);
  }

  /** Remove everything after the last user message and run again. */
  async regenerate(convo) {
    if (this.running) return;
    const i = convo.messages.map(m => m.role).lastIndexOf('user');
    if (i < 0) return;
    convo.messages.splice(i + 1);
    delete convo.messages[i].rag;
    bus.emit('convo:render', convo);
    return this.run(convo);
  }

  async editAndResend(convo, msgId, text) {
    if (this.running) return;
    const i = convo.messages.findIndex(m => m.id === msgId);
    if (i < 0) return;
    convo.messages[i].content = text;
    delete convo.messages[i].rag;
    convo.messages.splice(i + 1);
    bus.emit('convo:render', convo);
    return this.run(convo);
  }

  async run(convo) {
    if (this.running) return;
    this.running = true; this.convoId = convo.id;
    const controller = this.controller = new AbortController();
    const { signal } = controller;
    bus.emit('agent:start', convo);
    try {
      const lastUser = lastUserOf(convo);
      if (lastUser && !lastUser.rag && settings.rag.autoInject && rag.stats().chunks) {
        this.setPhase('knowledge');
        try {
          const r = await rag.search(lastUser.content);
          lastUser.rag = r.results; lastUser.ragNote = r.note || '';
        } catch (e) { lastUser.ragNote = `Retrieval failed: ${e.message}`; }
        bus.emit('convo:msg', { convo, msg: lastUser });
      }
      const max = Math.max(1, settings.agent.maxSteps || 20);
      for (let step = 1; step <= max && !signal.aborted; step++) {
        const again = await this.step(convo, step, signal);
        if (!again) break;
        if (step === max) pushNotice(convo, `Stopped after ${max} steps, the current limit. Press Continue to keep going or raise "Max steps" in the Tools panel.`, 'warn');
      }
    } catch (e) {
      if (e.name !== 'AbortError') { console.error(e); pushNotice(convo, e.message, 'err'); }
    } finally {
      for (const m of convo.messages) {
        if (m.streaming) m.streaming = false;
        for (const c of m.toolCalls || []) if (['queued', 'pending', 'running'].includes(c.status)) { c.status = 'cancelled'; c.result ??= 'Cancelled: the user stopped the agent.'; }
      }
      this.approvals.clear();
      this.running = false; this.controller = null;
      this.setPhase('idle');
      saveConvo(convo, { immediate: true });
      bus.emit('agent:end', convo);
      bus.emit('convo:render', convo);
    }
  }

  /** One model turn plus its tool calls. Returns true if the loop should continue. */
  async step(convo, step, signal) {
    const toolMode = settings.agent.toolMode;
    const sys = buildSystem(convo);
    const tools = sys.tools;
    const { preset, conf } = activeProvider();
    const am = { id: uid('m_'), role: 'assistant', content: '', thinking: '', toolCalls: [], partialCalls: [], streaming: true, time: Date.now(), meta: { provider: preset.name, model: conf.model, step, skills: sys.skills } };
    let request;
    try { request = buildRequest({ messages: historyOf(convo), system: sys.text, tools: tools.map(schemaOf), toolMode }); }
    catch (e) { pushNotice(convo, e.message, 'err'); return false; }
    convo.messages.push(am);
    bus.emit('convo:msg', { convo, msg: am, added: true });
    this.setPhase('model', { step });

    const render = throttleRAF(() => bus.emit('convo:msg', { convo, msg: am }));
    let res;
    try {
      res = await streamChat({ request, signal, onDelta: o => { am.content = o.content; am.thinking = o.thinking; am.partialCalls = o.partialCalls; render(); } });
    } catch (e) {
      am.streaming = false;
      if (e.name === 'AbortError') {
        if (e.partial) { am.content = e.partial.content; am.thinking = e.partial.thinking; }
        am.stopped = true; am.partialCalls = [];
        bus.emit('convo:msg', { convo, msg: am });
        return false;
      }
      if (toolMode === 'native' && tools.length && NO_TOOLS_RE.test(e.message)) {
        convo.messages.splice(convo.messages.indexOf(am), 1);
        bus.emit('convo:render', convo);
        settings.agent.toolMode = 'text'; saveSettings('agent');
        pushNotice(convo, `${conf.model} has no native tool calling, so tool mode was switched to the text protocol. Change it any time in the Tools panel.`, 'info');
        return true;
      }
      am.error = e.message;
      bus.emit('convo:msg', { convo, msg: am });
      return false;
    }

    am.content = res.content; am.thinking = res.thinking; am.partialCalls = [];
    am.meta = { ...am.meta, usage: res.usage, ms: res.ms, ttft: res.ttft, stopReason: res.stopReason };
    let calls = res.toolCalls || [];
    if (toolMode !== 'off' && (toolMode === 'text' || !calls.length) && /<tool_call>|```/.test(am.content)) {
      const parsed = parseTextToolCalls(am.content, tools.map(t => t.name));
      if (parsed.calls.length) { am.content = parsed.clean; calls = parsed.calls; }
    }
    if (toolMode === 'off') calls = [];
    am.toolCalls = calls.map(c => ({ ...c, status: 'queued' }));
    am.streaming = false;
    bus.emit('convo:msg', { convo, msg: am });
    saveConvo(convo);
    if (!am.toolCalls.length) return false;

    for (const call of am.toolCalls) {
      if (signal.aborted) break;
      await this.runCall(convo, am, call, tools, signal);
      saveConvo(convo);
    }
    return !signal.aborted;
  }

  async runCall(convo, am, call, tools, signal) {
    const emit = () => bus.emit('convo:msg', { convo, msg: am });
    const tool = tools.find(t => t.name === call.name);
    if (!tool) { call.status = 'error'; call.result = `Unknown tool "${call.name}". Available tools: ${tools.map(t => t.name).join(', ') || 'none'}.`; emit(); return; }
    const argErr = validateArgs(tool.parameters, call.args);
    if (argErr) { call.status = 'error'; call.result = `${argErr} Fix the arguments and call ${tool.name} again.`; emit(); return; }

    if (approvalFor(tool) && !this.sessionAllow.has(tool.name)) {
      call.status = 'pending'; emit();
      this.setPhase('approval', { tool: tool.name });
      bus.emit('agent:approval', { convo, msg: am, call });
      let decision;
      try { decision = await this.waitApproval(call.id, signal); }
      catch { call.status = 'cancelled'; call.result = 'Cancelled: the user stopped the agent.'; emit(); return; }
      if (decision.args) call.args = decision.args;
      if (decision.action === 'deny') {
        call.status = 'denied';
        call.result = `The user denied this tool call.${decision.reason ? ` Their reason: ${decision.reason}` : ''} Do not repeat the same call; adjust your approach or ask the user.`;
        emit(); return;
      }
      if (decision.action === 'always') this.sessionAllow.add(tool.name);
    }

    call.status = 'running'; call.startedAt = Date.now(); emit();
    this.setPhase('tool', { tool: tool.name, category: tool.category });
    try { call.result = await executeTool(tool, call.args, { signal, convo }); call.status = 'done'; }
    catch (e) {
      if (e.name === 'AbortError') { call.status = 'cancelled'; call.result = 'Cancelled: the user stopped the agent.'; }
      else { call.status = 'error'; call.result = `Error: ${e.message}`; }
    }
    call.endedAt = Date.now(); emit();
    if (call.status === 'done' && ['write', 'exec'].includes(tool.category)) bus.emit('workspace:changed', { tool: tool.name, args: call.args });
  }
}

export const agent = new Agent();
