// api.js — talks to the local Node server: workspace API + CORS proxy.
import { bus, uid } from './util.js';

const TOKEN = document.querySelector('meta[name="harness-token"]')?.content || '';
export const serverOK = TOKEN && TOKEN !== '__HARNESS_TOKEN__';

function authHeaders(extra = {}) { return { 'content-type': 'application/json', 'x-harness-token': TOKEN, ...extra }; }

async function handleError(res) {
  let msg = `${res.status} ${res.statusText}`;
  let body = null;
  try { body = await res.json(); } catch {}
  if (body?.code === 'TOKEN') bus.emit('server:token');
  if (body?.error) msg = typeof body.error === 'string' ? body.error : (body.error.message || JSON.stringify(body.error));
  const err = new Error(msg); err.status = res.status; err.body = body;
  throw err;
}

/** Call a local /api route. */
export async function api(path, body, { method = 'POST', signal } = {}) {
  let res;
  try {
    res = await fetch(path, { method, headers: authHeaders(), body: method === 'GET' ? undefined : JSON.stringify(body || {}), signal });
  } catch (e) {
    if (e.name === 'AbortError') throw e;
    bus.emit('server:down');
    throw new Error('The harness server is not responding. Is "node server.js" still running?');
  }
  if (!res.ok) await handleError(res);
  return res.json();
}

/** Fetch any URL through the local proxy. Returns the raw Response. */
export async function proxyFetch(url, { method = 'GET', headers = {}, body, signal } = {}) {
  let res;
  try {
    res = await fetch('/proxy', { method, headers: { ...headers, 'x-target-url': url, 'x-harness-token': TOKEN }, body, signal });
  } catch (e) {
    if (e.name === 'AbortError') throw e;
    bus.emit('server:down');
    throw new Error('The harness server is not responding. Is "node server.js" still running?');
  }
  return res;
}

/** Proxy helper that throws on HTTP errors and parses JSON. */
export async function proxyJSON(url, opts = {}) {
  const res = await proxyFetch(url, opts);
  if (!res.ok) await handleError(res);
  return res.json();
}

export const fsApi = {
  list: (path = '.', depth = 1) => api('/api/fs/list', { path, depth }),
  read: (path, start, end) => api('/api/fs/read', { path, start, end }),
  write: (path, content, append = false) => api('/api/fs/write', { path, content, append }),
  edit: (path, old_str, new_str, replace_all = false) => api('/api/fs/edit', { path, old_str, new_str, replace_all }),
  del: path => api('/api/fs/delete', { path }),
  move: (from, to) => api('/api/fs/move', { from, to }),
  search: opts => api('/api/fs/search', opts),
  exec: (command, { cwd = '.', timeout = 60, signal } = {}) => api('/api/exec', { command, cwd, timeout }, { signal }),
};

export const getInfo = () => api('/api/info', null, { method: 'GET' });

// ── request log (Inspector panel) ────────────────────────────────
export const requestLog = [];
const REDACT = /^(authorization|x-api-key|api-key)$/i;
export function logRequest({ provider, model, url, headers, body }) {
  const safeHeaders = {};
  for (const [k, v] of Object.entries(headers || {})) safeHeaders[k] = REDACT.test(k) && v ? String(v).slice(0, 10) + '…' : v;
  const entry = { id: uid('r_'), time: Date.now(), provider, model, url, headers: safeHeaders, body, status: 'pending', ms: null, response: null };
  requestLog.unshift(entry);
  if (requestLog.length > 60) requestLog.pop();
  bus.emit('log', entry);
  return entry;
}
export function finishLog(entry, patch) { Object.assign(entry, patch); bus.emit('log', entry); }
