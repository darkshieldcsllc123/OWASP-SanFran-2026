// panel-skills.js — manage skills: reusable instructions the agent applies always, by keyword, or on request.
import { settings, saveSettings } from './store.js';
import { MODE_LABELS, skillsFor, triggerList, newSkill, parseSkillFile, skillToMarkdown, slug } from './skills.js';
import { SKILL_TEMPLATES } from './defaults.js';
import { h, icon, ibtn, toast, modal, confirmDialog, bus, menu, uid, downloadFile, pickFiles, readFileText, deepClone, estimateTokens, fmtNum, toggle } from './util.js';
import { section, field, input, segmented, badge, btn, empty } from './ui.js';
import { renderMarkdown } from './markdown.js';

let root;
export default {
  id: 'skills', label: 'Skills', icon: 'book',
  mount(el) { root = el; render(); bus.on('settings', w => { if (w === 'all' && !root.contains(document.activeElement)) render(); }); },
};

function render() { root.replaceChildren(listSection(), testerSection()); }

function listSection() {
  const skills = settings.skills;
  const importSkills = async () => {
    const files = await pickFiles({ accept: '.md,.markdown,.txt,.json' });
    let n = 0;
    for (const f of files) {
      try { for (const s of parseSkillFile(await readFileText(f), f.name)) { if (skills.some(x => x.name === s.name)) s.name += '-' + Math.random().toString(36).slice(2, 5); skills.push(s); n++; } }
      catch (e) { toast(`${f.name}: ${e.message}`, { type: 'err' }); }
    }
    if (n) { saveSettings('skills'); render(); toast(`Imported ${n} skill${n === 1 ? '' : 's'}`, { type: 'ok' }); bus.emit('chain'); }
  };
  const body = h('div', { class: 'stack' },
    h('p', { class: 'sect-sub' }, 'A skill is a named set of instructions. "Always on" skills join every request. "Auto" skills join when your message contains a trigger word. "On request" skills are listed for the model, which loads one with the load_skill tool when it needs it.'),
    skills.length ? skills.map(s => h('div', { class: `skill ${s.enabled ? '' : 'off'}` },
      toggle(s.enabled, v => { s.enabled = v; saveSettings('skills'); render(); bus.emit('chain'); }),
      h('div', { class: 'skill-main' },
        h('div', { class: 'skill-name' }, h('strong', {}, s.name), badge(MODE_LABELS[s.mode], s.mode === 'always' ? 'info' : s.mode === 'auto' ? 'ok' : '')),
        h('p', { class: 'trow-desc' }, s.description || 'No description'),
        s.mode === 'auto' && triggerList(s).length ? h('div', { class: 'triggers' }, triggerList(s).map(t => h('span', { class: 'trigger' }, t))) : null,
        h('small', { class: 'muted' }, `about ${fmtNum(estimateTokens(s.content))} tokens`)),
      h('div', { class: 'trow-side' },
        ibtn('edit', 'Edit', () => openEditor(deepClone(s)), 'ibtn-sm'),
        ibtn('dots', 'More', e => menu(e.currentTarget, [
          { label: 'Duplicate', icon: 'copy', onClick: () => { skills.push({ ...deepClone(s), id: uid('sk_'), name: s.name + '-copy' }); saveSettings('skills'); render(); } },
          { label: 'Export as SKILL.md', icon: 'download', onClick: () => downloadFile(`${s.name}.md`, skillToMarkdown(s), 'text/markdown') },
          'sep',
          { label: 'Delete', icon: 'trash', danger: true, onClick: async () => { if (await confirmDialog(`Delete the skill "${s.name}"?`, { okLabel: 'Delete skill', danger: true })) { settings.skills = settings.skills.filter(x => x.id !== s.id); saveSettings('skills'); render(); bus.emit('chain'); } } },
        ], { align: 'right' }), 'ibtn-sm'))))
      : empty('book', 'No skills yet', 'Create one, start from a template, or import SKILL.md files.'),
    h('div', { class: 'row wrap' },
      btn('New skill', () => openEditor(newSkill(), true), { iconName: 'plus', kind: 'primary' }),
      btn('From template', e => menu(e.currentTarget, SKILL_TEMPLATES.map(t => ({ label: t.name, hint: MODE_LABELS[t.mode], onClick: () => openEditor(newSkill(deepClone(t)), true) }))), { iconName: 'layers' }),
      btn('Import', importSkills, { iconName: 'upload', kind: 'ghost', title: 'Import SKILL.md or JSON files' }),
      skills.length ? btn('Export all', () => downloadFile('harness-skills.json', JSON.stringify({ skills }, null, 2)), { iconName: 'download', kind: 'ghost' }) : null));
  return section('Skills', body, { id: 'skills', count: `${skills.filter(s => s.enabled).length} on` });
}

function testerSection() {
  const out = h('div', { class: 'stack-sm' });
  const run = text => {
    const { injected, loadable } = skillsFor(text);
    out.replaceChildren(
      h('div', {}, h('span', { class: 'muted small' }, 'Added to the prompt: '), injected.length ? injected.map(s => badge(s.name, 'ok')) : h('span', { class: 'muted small' }, 'none')),
      h('div', {}, h('span', { class: 'muted small' }, 'Loadable on request: '), loadable.length ? loadable.map(s => badge(s.name)) : h('span', { class: 'muted small' }, 'none')));
  };
  run('');
  return section('Try a message', h('div', { class: 'stack' },
    input('', run, { placeholder: 'e.g. fix the failing login test', class: 'input' }, 120), out),
    { id: 'skill-test', open: false, sub: 'See which skills would apply to a message before you send it.' });
}

function openEditor(draft, isNew = false) {
  const err = h('p', { class: 'form-error' });
  const triggersField = field('Trigger words', input(draft.triggers, v => { draft.triggers = v; }, { placeholder: 'comma separated, e.g. test, pytest, failing', class: 'input' }, 0), 'The skill joins the prompt when any of these appear in your message. Short words match whole words only.');
  triggersField.hidden = draft.mode !== 'auto';
  const content = h('textarea', { class: 'input mono', rows: 16, spellcheck: 'false', placeholder: 'Write the instructions the model should follow. Markdown works.', onInput: e => { draft.content = e.target.value; count.textContent = `about ${fmtNum(estimateTokens(draft.content))} tokens`; } }, draft.content);
  const preview = h('div', { class: 'md preview', hidden: true });
  const count = h('small', { class: 'muted' }, `about ${fmtNum(estimateTokens(draft.content))} tokens`);
  const body = h('div', { class: 'stack' },
    h('div', { class: 'grid2' },
      field('Name', input(draft.name, v => { draft.name = v; }, { class: 'input mono', spellcheck: 'false' }, 0), 'Lowercase with dashes. The model uses it with load_skill.'),
      field('When to use it', segmented(Object.entries(MODE_LABELS).map(([value, label]) => ({ value, label: label.replace('Model loads on request', 'On request').replace('Auto by keyword', 'Auto') })), draft.mode, v => { draft.mode = v; triggersField.hidden = v !== 'auto'; }, { size: 'seg-sm' }))),
    field('Description', input(draft.description, v => { draft.description = v; }, { placeholder: 'One line: what this skill is for', class: 'input' }, 0), 'Shown to the model in the skill index, so make it say when the skill applies.'),
    triggersField,
    h('div', { class: 'field' }, h('div', { class: 'row' }, h('span', { class: 'field-label' }, 'Instructions'), h('span', { class: 'spacer' }), count,
      segmented([{ value: 'write', label: 'Write' }, { value: 'preview', label: 'Preview' }], 'write', v => { const p = v === 'preview'; preview.hidden = !p; content.hidden = p; if (p) preview.innerHTML = renderMarkdown(draft.content); }, { size: 'seg-sm' })),
      content, preview),
    err);
  modal({
    title: isNew ? 'New skill' : `Edit ${draft.name}`, body, wide: true,
    actions: [{ label: 'Cancel', ghost: true }, { label: isNew ? 'Create skill' : 'Save skill', primary: true, onClick: () => {
      draft.name = slug(draft.name);
      if (!draft.content.trim()) { err.textContent = 'Write some instructions first.'; return false; }
      if (settings.skills.some(s => s.name === draft.name && s.id !== draft.id)) { err.textContent = `Another skill is already called "${draft.name}".`; return false; }
      const i = settings.skills.findIndex(s => s.id === draft.id);
      if (i > -1) settings.skills[i] = draft; else settings.skills.push(draft);
      saveSettings('skills'); render(); bus.emit('chain'); toast(`${isNew ? 'Created' : 'Saved'} ${draft.name}`, { type: 'ok' });
    } }],
  });
}
