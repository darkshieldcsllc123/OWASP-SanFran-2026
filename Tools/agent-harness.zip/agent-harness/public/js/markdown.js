// markdown.js — small, safe markdown renderer + syntax highlighter (escapes all HTML).
import { esc } from './util.js';

// ── highlighter ──────────────────────────────────────────────────
const R = {
  cComment: /\/\/[^\n]*|\/\*[\s\S]*?(?:\*\/|$)/.source,
  hash: /#[^\n]*/.source,
  dash: /--[^\n]*/.source,
  dq: /"(?:\\.|[^"\\\n])*"/.source,
  sq: /'(?:\\.|[^'\\\n])*'/.source,
  bt: /`(?:\\.|[^`\\])*`/.source,
  tq: /"""[\s\S]*?(?:"""|$)|'''[\s\S]*?(?:'''|$)/.source,
  num: /\b(?:0[xX][\da-fA-F_]+|0[bB][01_]+|\d[\d_]*(?:\.\d+)?(?:[eE][+-]?\d+)?)\b/.source,
  word: /[A-Za-z_$@][\w$-]*/.source,
};
const JS_KW = 'async await break case catch class const continue debugger default delete do else export extends finally for from function if import in instanceof let new of return static super switch this throw try typeof var void while with yield get set';
const LIT = new Set('true false null undefined None True False nil NaN Infinity'.split(' '));
function L(kw, comment, strings, opts = {}) {
  return { kw: new Set(kw.split(/\s+/).filter(Boolean).map(k => (opts.ci ? k.toLowerCase() : k))), re: new RegExp(`(${comment})|(${strings})|(${R.num})|(${opts.word || /[A-Za-z_$][\w$]*/.source})`, 'g'), ...opts };
}
const LANGS = {};
LANGS.js = L(JS_KW, R.cComment, [R.dq, R.sq, R.bt].join('|'), { types: true });
LANGS.ts = L(JS_KW + ' interface type enum implements private public protected readonly declare namespace abstract keyof infer is satisfies', R.cComment, [R.dq, R.sq, R.bt].join('|'), { types: true });
LANGS.py = L('and as assert async await break class continue def del elif else except finally for from global if import in is lambda nonlocal not or pass raise return try while with yield match case self print', R.hash, [R.tq, R.dq, R.sq].join('|'), { types: true });
LANGS.sh = L('if then else elif fi for while do done case esac in function return local export source echo exit set unset cd sudo npm npx node git pip python python3 cargo go make docker curl', R.hash, [R.dq, R.sq].join('|'), { word: /[A-Za-z_$][\w$-]*/.source });
LANGS.go = L('break case chan const continue default defer else fallthrough for func go goto if import interface map package range return select struct switch type var string int bool error byte rune float64 int64', R.cComment, [R.dq, R.bt].join('|'), { types: true });
LANGS.rust = L('as async await break const continue crate dyn else enum extern fn for if impl in let loop match mod move mut pub ref return self Self static struct super trait type unsafe use where while i32 i64 u8 u32 u64 usize f64 bool str String Vec Option Result Some Ok Err', R.cComment, R.dq, { types: true });
LANGS.java = L('abstract boolean break byte case catch char class const continue default do double else enum extends final finally float for if implements import instanceof int interface long new package private protected public return short static super switch synchronized this throw throws try void volatile while var val fun override namespace using string bool async await', R.cComment, [R.dq, R.sq].join('|'), { types: true });
LANGS.c = L('auto break case char const continue default do double else enum extern float for goto if inline int long register return short signed sizeof static struct switch typedef union unsigned void volatile while include define ifdef ifndef endif pragma class public private protected template typename namespace using std nullptr bool virtual', R.cComment, [R.dq, R.sq].join('|'), { types: true, word: /[A-Za-z_#][\w]*/.source });
LANGS.rb = L('def end do if elsif else unless while until class module require return yield self begin rescue ensure then puts attr_accessor', R.hash, [R.dq, R.sq].join('|'), { types: true });
LANGS.sql = L('select from where insert into values update set delete create table drop alter add primary key foreign references join left right inner outer on group by order having limit offset as and or not is in like distinct union all exists case when then else end index view default integer text varchar boolean serial', R.dash, [R.sq, R.dq].join('|'), { ci: true });
LANGS.css = L('', /\/\*[\s\S]*?(?:\*\/|$)/.source, [R.dq, R.sq].join('|'), { css: true, word: /[A-Za-z_-][\w-]*/.source });
LANGS.json = L('', /\/\/[^\n]*/.source, R.dq, { json: true });
LANGS.yaml = L('', R.hash, [R.dq, R.sq].join('|'), { yaml: true, word: /[A-Za-z_][\w.-]*/.source });
const ALIAS = {
  javascript: 'js', jsx: 'js', mjs: 'js', cjs: 'js', node: 'js', php: 'js', typescript: 'ts', tsx: 'ts', python: 'py', py3: 'py',
  bash: 'sh', shell: 'sh', zsh: 'sh', console: 'sh', powershell: 'sh', ps1: 'sh', bat: 'sh', cmd: 'sh', dockerfile: 'sh', make: 'sh', makefile: 'sh',
  golang: 'go', rs: 'rust', kotlin: 'java', kt: 'java', scala: 'java', cs: 'java', csharp: 'java', swift: 'java', dart: 'java',
  cpp: 'c', 'c++': 'c', h: 'c', hpp: 'c', cc: 'c', ruby: 'rb', scss: 'css', less: 'css', jsonc: 'json', json5: 'json',
  yml: 'yaml', toml: 'yaml', ini: 'yaml', env: 'yaml', html: 'html', xml: 'html', svg: 'html', vue: 'html', svelte: 'html', diff: 'diff', patch: 'diff',
};
export const langFromPath = p => {
  const ext = String(p).split('.').pop().toLowerCase();
  const map = { js: 'js', mjs: 'js', cjs: 'js', jsx: 'js', ts: 'ts', tsx: 'ts', py: 'py', sh: 'sh', bash: 'sh', go: 'go', rs: 'rust', java: 'java', kt: 'java', cs: 'java', c: 'c', h: 'c', cpp: 'c', hpp: 'c', rb: 'rb', sql: 'sql', css: 'css', scss: 'css', json: 'json', yml: 'yaml', yaml: 'yaml', toml: 'yaml', html: 'html', htm: 'html', xml: 'html', svg: 'html', vue: 'html', md: 'md', bat: 'sh', ps1: 'sh' };
  return map[ext] || (/(^|\/)(dockerfile|makefile)$/i.test(p) ? 'sh' : '');
};
const span = (c, t) => `<span class="hl-${c}">${esc(t)}</span>`;

function hlMarkup(code) {
  const re = /(<!--[\s\S]*?(?:-->|$))|(<\/?[\w:-]+)|([\w:-]+)(?==)|("[^"]*"|'[^']*')|(\/?>)/g;
  let out = '', last = 0, m;
  while ((m = re.exec(code))) {
    out += esc(code.slice(last, m.index));
    out += m[1] ? span('c', m[0]) : m[2] ? span('k', m[0]) : m[3] ? span('a', m[0]) : m[4] ? span('s', m[0]) : span('k', m[0]);
    last = re.lastIndex;
  }
  return out + esc(code.slice(last));
}

export function highlight(code, lang) {
  lang = String(lang || '').toLowerCase();
  lang = ALIAS[lang] || lang;
  if (lang === 'html') return hlMarkup(code);
  if (lang === 'diff') return code.split('\n').map(l => /^\+(?!\+\+)/.test(l) ? span('add', l) : /^-(?!--)/.test(l) ? span('del', l) : /^@@/.test(l) ? span('meta', l) : esc(l)).join('\n');
  const D = LANGS[lang];
  if (!D) return esc(code);
  const re = new RegExp(D.re.source, 'g');
  let out = '', last = 0, m;
  while ((m = re.exec(code))) {
    if (m[0] === '') { re.lastIndex++; continue; }
    out += esc(code.slice(last, m.index));
    const [tok, cm, st, num, word] = m;
    const after = code.slice(re.lastIndex, re.lastIndex + 40);
    if (cm) out += span('c', tok);
    else if (st) out += (D.json && /^\s*:/.test(after)) ? span('a', tok) : span('s', tok);
    else if (num) out += span('n', tok);
    else if (word) {
      const k = D.ci ? word.toLowerCase() : word;
      if (D.kw.has(k)) out += span('k', tok);
      else if (LIT.has(word)) out += span('b', tok);
      else if ((D.yaml || D.css) && /^\s*:/.test(after)) out += span('a', tok);
      else if (/^\s*\(/.test(after)) out += span('f', tok);
      else if (D.types && /^[A-Z][a-z]/.test(word)) out += span('t', tok);
      else out += esc(tok);
    }
    last = re.lastIndex;
  }
  return out + esc(code.slice(last));
}

// ── markdown ─────────────────────────────────────────────────────
function safeUrl(u) {
  const s = String(u).replace(/&amp;/g, '&').trim();
  return /^(https?:|mailto:|#|\/(?!\/)|\.{1,2}\/)/i.test(s) ? esc(s) : '#';
}

function inline(s) {
  const codes = [];
  s = s.replace(/(`+)([^`]|[^`][\s\S]*?[^`])\1(?!`)/g, (_, t, c) => { codes.push(c.replace(/^ (.*) $/, '$1')); return `\u0001${codes.length - 1}\u0001`; });
  s = esc(s);
  s = s.replace(/!\[([^\]]*)\]\(([^)\s]+)(?:\s+&quot;[^&]*&quot;)?\)/g, (_, alt, url) => `<a href="${safeUrl(url)}" target="_blank" rel="noopener noreferrer">[image: ${alt || 'untitled'}]</a>`);
  s = s.replace(/\[([^\]]+)\]\(([^)\s]+)(?:\s+&quot;[^&]*&quot;)?\)/g, (_, t, url) => `<a href="${safeUrl(url)}" target="_blank" rel="noopener noreferrer">${t}</a>`);
  s = s.replace(/(^|[\s(])(https?:\/\/[^\s<)]+[^\s<).,;:!?'"])/g, (_, pre, url) => `${pre}<a href="${safeUrl(url)}" target="_blank" rel="noopener noreferrer">${url}</a>`);
  s = s.replace(/\*\*\*([^*]+?)\*\*\*/g, '<strong><em>$1</em></strong>');
  s = s.replace(/\*\*([^*]+?)\*\*/g, '<strong>$1</strong>').replace(/(^|[^\w])__([^_]+?)__(?!\w)/g, '$1<strong>$2</strong>');
  s = s.replace(/(^|[^*\w])\*(?!\s)([^*\n]+?)\*(?!\w)/g, '$1<em>$2</em>').replace(/(^|[^_\w])_(?!\s)([^_\n]+?)_(?!\w)/g, '$1<em>$2</em>');
  s = s.replace(/~~([^~]+)~~/g, '<del>$1</del>');
  s = s.replace(/\u0001(\d+)\u0001/g, (_, n) => `<code>${esc(codes[n])}</code>`);
  return s;
}

const LIST_RE = /^(\s*)([-*+]|\d{1,9}[.)])\s+(.*)$/;
const HR_RE = /^\s{0,3}([-*_])(\s*\1){2,}\s*$/;
const TABLE_SEP = /^\s*\|?\s*:?-{2,}:?\s*(\|\s*:?-{2,}:?\s*)*\|?\s*$/;
const CB_RE = /^\u0000CB(\d+)\u0000$/;
const lead = l => l.match(/^\s*/)[0].replace(/\t/g, '    ').length;
const isBlockStart = (l, next) => /^#{1,6}\s/.test(l) || CB_RE.test(l) || HR_RE.test(l) || /^\s*>/.test(l) || LIST_RE.test(l) || (l.includes('|') && next !== undefined && TABLE_SEP.test(next));

function splitRow(l) {
  l = l.trim();
  if (l.startsWith('|')) l = l.slice(1);
  if (l.endsWith('|') && !l.endsWith('\\|')) l = l.slice(0, -1);
  return l.split(/(?<!\\)\|/).map(c => c.trim().replace(/\\\|/g, '|'));
}

function renderCode(b) {
  const lang = (b.lang || '').toLowerCase();
  return `<div class="codeblock${b.closed ? '' : ' streaming'}" data-lang="${esc(lang)}"><div class="cb-head"><span class="cb-lang">${esc(lang || 'text')}</span><span class="cb-actions"><button class="cb-btn" data-act="save-code" title="Save to workspace">Save</button><button class="cb-btn" data-act="copy-code" title="Copy code">Copy</button></span></div><pre><code>${highlight(b.code, lang)}</code></pre></div>`;
}

function blocks(lines, codeBlocks) {
  let html = '', i = 0;
  while (i < lines.length) {
    const line = lines[i];
    if (!line.trim()) { i++; continue; }
    let m;
    if ((m = line.match(CB_RE))) { html += renderCode(codeBlocks[+m[1]]); i++; continue; }
    if ((m = line.match(/^\s{0,3}(#{1,6})\s+(.*?)\s*#*\s*$/))) { const n = m[1].length; html += `<h${n}>${inline(m[2])}</h${n}>`; i++; continue; }
    if (HR_RE.test(line)) { html += '<hr>'; i++; continue; }
    if (/^\s*>/.test(line)) {
      const q = [];
      while (i < lines.length && lines[i].trim() && (/^\s*>/.test(lines[i]) || !isBlockStart(lines[i]))) { q.push(lines[i].replace(/^\s*>\s?/, '')); i++; }
      html += `<blockquote>${blocks(q, codeBlocks)}</blockquote>`; continue;
    }
    if (line.includes('|') && i + 1 < lines.length && TABLE_SEP.test(lines[i + 1])) {
      const head = splitRow(line);
      const al = splitRow(lines[i + 1]).map(c => (c.startsWith(':') && c.endsWith(':') ? 'center' : c.endsWith(':') ? 'right' : ''));
      i += 2; const rows = [];
      while (i < lines.length && lines[i].trim() && lines[i].includes('|')) { rows.push(splitRow(lines[i])); i++; }
      const td = (tag, c, j) => `<${tag}${al[j] ? ` style="text-align:${al[j]}"` : ''}>${inline(c || '')}</${tag}>`;
      html += `<div class="table-wrap"><table><thead><tr>${head.map((c, j) => td('th', c, j)).join('')}</tr></thead><tbody>${rows.map(r => `<tr>${head.map((_, j) => td('td', r[j], j)).join('')}</tr>`).join('')}</tbody></table></div>`;
      continue;
    }
    if (LIST_RE.test(line)) { const r = list(lines, i, codeBlocks); html += r.html; i = r.i; continue; }
    const para = [];
    while (i < lines.length && lines[i].trim() && !(para.length && isBlockStart(lines[i], lines[i + 1])) && !CB_RE.test(lines[i])) { para.push(lines[i].trim()); i++; }
    if (!para.length) { para.push(lines[i].trim()); i++; }
    html += `<p>${para.map(inline).join('<br>')}</p>`;
  }
  return html;
}

function list(lines, i, codeBlocks) {
  const first = lines[i].match(LIST_RE);
  const indent = lead(first[1]);
  const ordered = /\d/.test(first[2]);
  const start = ordered ? parseInt(first[2], 10) : 1;
  const items = [];
  while (i < lines.length) {
    const m = lines[i].match(LIST_RE);
    if (!m || lead(m[1]) !== indent || /\d/.test(m[2]) !== ordered) break;
    const contentIndent = lead(m[1]) + m[2].length + 1;
    const item = [m[3]]; i++;
    while (i < lines.length) {
      const l = lines[i];
      if (!l.trim()) {
        const nx = lines[i + 1];
        if (nx !== undefined && nx.trim() && lead(nx) > indent) { item.push(''); i++; continue; }
        break;
      }
      const lm = l.match(LIST_RE);
      if (lm && lead(lm[1]) <= indent) break;
      if (lead(l) > indent) { item.push(l.replace(new RegExp(`^\\s{0,${contentIndent}}`), '')); i++; continue; }
      if (CB_RE.test(l) || isBlockStart(l, lines[i + 1])) break;
      item.push(l.trim()); i++;
    }
    items.push(item);
  }
  const tag = ordered ? 'ol' : 'ul';
  const lis = items.map(it => {
    let pre = '', cls = '';
    const tm = it[0].match(/^\[([ xX])\]\s+(.*)$/);
    if (tm) { it[0] = tm[2]; cls = ' class="task"'; pre = `<span class="task-box${tm[1] !== ' ' ? ' done' : ''}" aria-hidden="true"></span>`; }
    const simple = it.length === 1 || it.every((l, k) => k === 0 || (l.trim() && !isBlockStart(l, it[k + 1]) && !CB_RE.test(l)));
    return `<li${cls}>${pre}${simple ? it.map(inline).join('<br>') : blocks(it, codeBlocks)}</li>`;
  }).join('');
  return { html: `<${tag}${ordered && start !== 1 ? ` start="${start}"` : ''}>${lis}</${tag}>`, i };
}

export function renderMarkdown(src) {
  const lines = String(src || '').replace(/\r\n?/g, '\n').split('\n');
  const out = [], codeBlocks = [];
  for (let i = 0; i < lines.length; i++) {
    const m = lines[i].match(/^(\s*)(`{3,}|~{3,})\s*([^\s`]*)[^`]*$/);
    if (m) {
      const fence = m[2], ind = m[1].length, body = [];
      let closed = false; i++;
      for (; i < lines.length; i++) {
        const t = lines[i].trim();
        if (t[0] === fence[0] && /^(`{3,}|~{3,})$/.test(t) && t.length >= fence.length) { closed = true; break; }
        body.push(ind ? lines[i].replace(new RegExp(`^\\s{0,${ind}}`), '') : lines[i]);
      }
      codeBlocks.push({ lang: m[3], code: body.join('\n'), closed });
      out.push(`\u0000CB${codeBlocks.length - 1}\u0000`);
      continue;
    }
    out.push(lines[i]);
  }
  return blocks(out, codeBlocks);
}
