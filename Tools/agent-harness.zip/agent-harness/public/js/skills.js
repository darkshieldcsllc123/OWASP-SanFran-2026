// skills.js — reusable instruction packs injected into the system prompt.
// Modes: always (every turn), auto (when a trigger word appears), manual (model loads it with load_skill).
import { settings } from './store.js';
import { uid } from './util.js';

export const MODE_LABELS = { always: 'Always on', auto: 'Auto by keyword', manual: 'Model loads on request' };

const escapeRe = s => s.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
export const triggerList = s => String(s.triggers || '').split(',').map(x => x.trim().toLowerCase()).filter(Boolean);

export function triggerMatch(skill, text) {
  const t = String(text || '').toLowerCase();
  return triggerList(skill).some(k => (k.length <= 4 ? new RegExp(`(^|\\W)${escapeRe(k)}(\\W|$)`).test(t) : t.includes(k)));
}

/** Which skills apply to a user message. */
export function skillsFor(text, forced = []) {
  const enabled = settings.skills.filter(s => s.enabled);
  const forcedSkills = forced.map(getSkill).filter(Boolean);
  const injected = [];
  for (const s of enabled) if (s.mode === 'always' || (s.mode === 'auto' && triggerMatch(s, text))) injected.push(s);
  for (const s of forcedSkills) if (!injected.includes(s)) injected.push(s);
  const loadable = enabled.filter(s => !injected.includes(s) && s.mode !== 'always');
  return { injected, loadable };
}

export function getSkill(name) {
  const n = String(name || '').toLowerCase().trim();
  return settings.skills.find(s => s.enabled && s.name.toLowerCase() === n);
}

export const slug = s => String(s).toLowerCase().trim().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '').slice(0, 48) || 'skill';

export function newSkill(partial = {}) {
  return { id: uid('sk_'), name: 'new-skill', description: '', triggers: '', mode: 'auto', enabled: true, content: '', ...partial };
}

/** Parse a SKILL.md (YAML frontmatter + markdown body) or a JSON export. */
export function parseSkillFile(text, filename = 'skill.md') {
  if (/\.json$/i.test(filename)) {
    const j = JSON.parse(text);
    const arr = Array.isArray(j) ? j : j.skills || [j];
    return arr.map(s => newSkill({ ...s, id: uid('sk_'), name: slug(s.name || 'skill') }));
  }
  let meta = {}, body = text;
  const m = text.match(/^---\s*\n([\s\S]*?)\n---\s*\n?([\s\S]*)$/);
  if (m) {
    body = m[2];
    for (const line of m[1].split('\n')) {
      const kv = line.match(/^([\w-]+)\s*:\s*(.*)$/);
      if (kv) meta[kv[1].toLowerCase()] = kv[2].trim().replace(/^["']|["']$/g, '');
    }
  }
  const base = filename.replace(/\.(md|markdown|txt)$/i, '');
  const name = slug(meta.name || (/^skill$/i.test(base) ? 'imported-skill' : base));
  const firstLine = body.trim().split('\n').find(l => l.trim() && !l.startsWith('#')) || '';
  return [newSkill({
    name,
    description: meta.description || firstLine.slice(0, 140),
    triggers: meta.triggers || meta.keywords || '',
    mode: ['always', 'auto', 'manual'].includes(meta.mode) ? meta.mode : (meta.triggers || meta.keywords ? 'auto' : 'manual'),
    content: body.trim(),
  })];
}

export function skillToMarkdown(s) {
  return `---\nname: ${s.name}\ndescription: ${s.description}\nmode: ${s.mode}\ntriggers: ${s.triggers || ''}\n---\n\n${s.content.trim()}\n`;
}
