// store.js — settings (localStorage) + conversations and knowledge base (IndexedDB).
import { bus, uid, debounce, toast, deepClone } from './util.js';
import { DEFAULT_SYSTEM_PROMPT, PROMPT_PRESETS, STARTER_SKILLS } from './defaults.js';

const LS_KEY = 'harness.settings.v1';

export const DEFAULTS = {
  version: 1,
  theme: 'system',            // system | dark | light
  accent: 'amber',
  fontSize: 14,
  sidebarOpen: true,
  panelOpen: true,
  panelTab: 'model',
  panelWidth: 400,
  provider: 'ollama',
  providers: {},              // presetId -> { baseUrl, apiKey, model, gen, extra }
  systemPrompt: DEFAULT_SYSTEM_PROMPT,
  promptPresets: PROMPT_PRESETS.filter(p => !p.builtin),
  activePreset: 'coding-agent',
  agent: {
    toolMode: 'native',       // native | text | off
    approval: 'risky',        // all | risky | none
    maxSteps: 20,
    outputLimit: 12000,
    showThinking: true,
    contextLimit: 128000,     // for cloud models; Ollama uses num_ctx
    autoTitle: true,
  },
  tools: { builtin: {}, custom: [] },
  skills: STARTER_SKILLS,
  rag: {
    chunkSize: 1200, overlap: 150, topK: 4, mode: 'hybrid',
    autoInject: true, asTool: true, minScore: 0,
    embed: { enabled: false, source: 'ollama', model: 'nomic-embed-text' },
  },
  recentModels: [],
  onboarded: false,
};

function isObj(v) { return v && typeof v === 'object' && !Array.isArray(v); }
function merge(base, over) {
  if (!isObj(over)) return deepClone(base);
  const out = deepClone(base);
  for (const [k, v] of Object.entries(over)) out[k] = isObj(v) && isObj(base[k]) ? merge(base[k], v) : v;
  return out;
}

function loadSettings() {
  try { return merge(DEFAULTS, JSON.parse(localStorage.getItem(LS_KEY) || '{}')); }
  catch { return deepClone(DEFAULTS); }
}

export const settings = loadSettings();

const persist = debounce(() => {
  try { localStorage.setItem(LS_KEY, JSON.stringify(settings)); }
  catch (e) { toast(`Could not save settings: ${e.message}`, { type: 'err' }); }
}, 250);

/** Call after mutating settings. `what` lets listeners filter. */
export function saveSettings(what = 'all') { persist(); bus.emit('settings', what); }

export function replaceSettings(next) {
  const merged = merge(DEFAULTS, next);
  for (const k of Object.keys(settings)) delete settings[k];
  Object.assign(settings, merged);
  localStorage.setItem(LS_KEY, JSON.stringify(settings));
  bus.emit('settings', 'all');
}

// ── IndexedDB ─────────────────────────────────────────────────────
let dbPromise;
function openDB() {
  if (dbPromise) return dbPromise;
  dbPromise = new Promise((resolve, reject) => {
    const req = indexedDB.open('agent-harness', 1);
    req.onupgradeneeded = () => {
      const db = req.result;
      for (const s of ['convos', 'docs']) if (!db.objectStoreNames.contains(s)) db.createObjectStore(s, { keyPath: 'id' });
    };
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error);
  });
  return dbPromise;
}
function tx(store, mode, fn) {
  return openDB().then(db => new Promise((resolve, reject) => {
    const t = db.transaction(store, mode);
    const r = fn(t.objectStore(store));
    t.oncomplete = () => resolve(r && 'result' in r ? r.result : undefined);
    t.onerror = () => reject(t.error);
    t.onabort = () => reject(t.error);
  }));
}
export const idb = {
  all: store => tx(store, 'readonly', s => s.getAll()),
  get: (store, key) => tx(store, 'readonly', s => s.get(key)),
  put: (store, val) => tx(store, 'readwrite', s => { s.put(val); }),
  del: (store, key) => tx(store, 'readwrite', s => { s.delete(key); }),
  clear: store => tx(store, 'readwrite', s => { s.clear(); }),
};

// ── conversations ─────────────────────────────────────────────────
export const state = { convos: [], activeId: null, info: null };

export async function loadConvos() {
  try { state.convos = (await idb.all('convos')) || []; }
  catch (e) { console.error(e); state.convos = []; toast('Could not open browser storage. Chats will not be saved.', { type: 'err' }); }
  for (const c of state.convos) for (const m of c.messages) if (m.streaming) { m.streaming = false; m.error ||= 'Interrupted (page was reloaded)'; }
  sortConvos();
}
export function sortConvos() { state.convos.sort((a, b) => (b.pinned - a.pinned) || (b.updated - a.updated)); }

export const activeConvo = () => state.convos.find(c => c.id === state.activeId) || null;

export function newConvo() {
  const c = { id: uid('c_'), title: 'New chat', created: Date.now(), updated: Date.now(), messages: [], plan: null, pinned: false };
  state.convos.unshift(c);
  state.activeId = c.id;
  bus.emit('convos'); bus.emit('convo:switch', c);
  return c;
}

export function switchConvo(id) {
  if (!state.convos.find(c => c.id === id)) return;
  state.activeId = id;
  localStorage.setItem('harness.active', id);
  bus.emit('convo:switch', activeConvo()); bus.emit('convos');
}

const timers = new Map();
export function saveConvo(c, { immediate = false, touch = true } = {}) {
  if (!c) return;
  if (touch) c.updated = Date.now();
  clearTimeout(timers.get(c.id));
  const run = () => { timers.delete(c.id); idb.put('convos', JSON.parse(JSON.stringify(c))).catch(e => toast(`Could not save chat: ${e.message}`, { type: 'err' })); };
  if (immediate) run(); else timers.set(c.id, setTimeout(run, 500));
}

export async function deleteConvo(id) {
  state.convos = state.convos.filter(c => c.id !== id);
  await idb.del('convos', id);
  if (state.activeId === id) {
    if (state.convos[0]) switchConvo(state.convos[0].id); else newConvo();
  }
  bus.emit('convos');
}

export function renameConvo(c, title) {
  c.title = title.trim() || 'Untitled'; saveConvo(c, { touch: false }); bus.emit('convos');
}
