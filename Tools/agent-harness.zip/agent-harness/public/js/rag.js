// rag.js — local knowledge base: chunking, BM25 keyword search, optional embeddings, hybrid ranking.
import { settings, idb } from './store.js';
import { embed } from './providers.js';
import { proxyFetch, fsApi } from './api.js';
import { uid, bus } from './util.js';

export const kb = { docs: [], ready: false, embedding: false };
let index = { entries: [], df: new Map(), N: 0, avgdl: 1 };

export async function loadKB() {
  try { kb.docs = (await idb.all('docs')) || []; } catch { kb.docs = []; }
  kb.docs.sort((a, b) => a.added - b.added);
  rebuild(); kb.ready = true; bus.emit('kb');
}

// ── text processing ──────────────────────────────────────────────
const STOP = new Set('a an and are as at be but by for from has have i if in into is it its of on or that the their then there these this to was were will with you your we our can do does not no so than too very what which who how when where why me my'.split(' '));

export function tokenize(text) {
  const out = [];
  for (const w of String(text).match(/[\p{L}\p{N}_]+/gu) || []) {
    const lw = w.toLowerCase();
    if (lw.length > 1 && !STOP.has(lw)) out.push(lw);
    if (/[a-z][A-Z]|_/.test(w)) {
      for (const p of w.split(/_|(?<=[a-z])(?=[A-Z])/)) {
        const lp = p.toLowerCase();
        if (lp.length > 1 && lp !== lw && !STOP.has(lp)) out.push(lp);
      }
    }
  }
  return out;
}

/** Line-aware chunking that prefers paragraph, heading and definition boundaries. */
export function chunkText(text, { chunkSize = 1200, overlap = 150 } = {}) {
  const size = Math.max(200, chunkSize), ov = Math.max(0, Math.min(overlap, size / 2));
  const lines = String(text).replace(/\r\n?/g, '\n').split('\n');
  const chunks = [];
  let cur = [], curLen = 0, startLine = 1;
  const flush = () => { const t = cur.join('\n').trim(); if (t) chunks.push({ text: t, line: startLine }); };
  for (let i = 0; i < lines.length; i++) {
    let l = lines[i];
    while (l.length > size) {
      if (cur.length) { flush(); cur = []; curLen = 0; }
      chunks.push({ text: l.slice(0, size), line: i + 1 });
      l = l.slice(size - ov);
    }
    const boundary = !l.trim() || /^#{1,6}\s/.test(l) || /^(export |def |class |function |async function |pub fn |fn |func |public |private |interface |type )/.test(l);
    if (cur.length && (curLen + l.length > size || (boundary && curLen > size * 0.6))) {
      flush();
      const carry = []; let cl = 0;
      for (let j = cur.length - 1; j >= 0 && cl + cur[j].length + 1 <= ov; j--) { carry.unshift(cur[j]); cl += cur[j].length + 1; }
      cur = carry; curLen = cl; startLine = i + 1 - carry.length;
    }
    if (!cur.length) startLine = i + 1;
    cur.push(l); curLen += l.length + 1;
  }
  flush();
  return chunks;
}

export function htmlToText(html) {
  const doc = new DOMParser().parseFromString(html, 'text/html');
  doc.querySelectorAll('script,style,noscript,svg,iframe,nav,footer,form,template').forEach(n => n.remove());
  doc.querySelectorAll('br').forEach(b => b.replaceWith('\n'));
  doc.querySelectorAll('h1,h2,h3,h4').forEach(n => n.prepend('\n\n' + '#'.repeat(+n.tagName[1]) + ' '));
  doc.querySelectorAll('li').forEach(n => n.prepend('\n- '));
  doc.querySelectorAll('p,div,tr,section,article,pre,blockquote,table,ul,ol').forEach(n => n.append('\n'));
  const body = (doc.body?.textContent || '').replace(/[ \t\u00a0]+/g, ' ').replace(/ *\n */g, '\n').replace(/\n{3,}/g, '\n\n').trim();
  return (doc.title ? `# ${doc.title.trim()}\n\n` : '') + body;
}

// ── index ────────────────────────────────────────────────────────
function rebuild() {
  const entries = []; const df = new Map(); let total = 0;
  for (const doc of kb.docs) for (const chunk of doc.chunks) {
    const toks = tokenize(doc.name + ' ' + chunk.text);
    const tf = new Map();
    for (const t of toks) tf.set(t, (tf.get(t) || 0) + 1);
    for (const t of tf.keys()) df.set(t, (df.get(t) || 0) + 1);
    total += toks.length;
    entries.push({ doc, chunk, tf, len: toks.length });
  }
  index = { entries, df, N: entries.length, avgdl: total / (entries.length || 1) };
}

function bm25(query, k1 = 1.2, b = 0.75) {
  const q = [...new Set(tokenize(query))];
  if (!q.length || !index.N) return [];
  const out = [];
  for (const e of index.entries) {
    let s = 0;
    for (const t of q) {
      const f = e.tf.get(t); if (!f) continue;
      const df = index.df.get(t);
      const idf = Math.log(1 + (index.N - df + 0.5) / (df + 0.5));
      s += idf * (f * (k1 + 1)) / (f + k1 * (1 - b + b * e.len / index.avgdl));
    }
    if (s > 0) out.push({ entry: e, score: s });
  }
  return out.sort((a, b2) => b2.score - a.score);
}

function cosine(a, b) {
  let d = 0, na = 0, nb = 0;
  for (let i = 0; i < a.length; i++) { d += a[i] * b[i]; na += a[i] * a[i]; nb += b[i] * b[i]; }
  return d / (Math.sqrt(na * nb) || 1);
}

async function vectorSearch(query) {
  const [qv] = await embed([query]);
  return index.entries.filter(e => e.chunk.emb?.length === qv.length)
    .map(e => ({ entry: e, score: cosine(qv, e.chunk.emb) }))
    .sort((a, b) => b.score - a.score);
}

export const hasVectors = () => index.entries.some(e => e.chunk.emb);

/** Search the knowledge base. Returns { results:[{docName, line, text, score, parts}], mode, note } */
export async function search(query, { k = settings.rag.topK, mode = settings.rag.mode } = {}) {
  if (!index.N || !String(query || '').trim()) return { results: [], mode: 'none' };
  const vectorsOn = settings.rag.embed.enabled && hasVectors();
  let used = mode, note = '', ranked;
  if (mode === 'bm25' || !vectorsOn) {
    used = 'bm25';
    if (mode !== 'bm25') note = 'No embeddings yet, so keyword search was used.';
    ranked = bm25(query).map(r => ({ ...r, parts: { bm25: r.score } }));
  } else {
    let vec = null;
    try { vec = await vectorSearch(query); } catch (e) { note = `Embedding failed (${e.message}); used keyword search.`; }
    if (!vec) { used = 'bm25'; ranked = bm25(query).map(r => ({ ...r, parts: { bm25: r.score } })); }
    else if (mode === 'vector') ranked = vec.map(r => ({ ...r, parts: { vector: r.score } }));
    else {
      const fused = new Map();
      [['bm25', bm25(query)], ['vector', vec]].forEach(([name, list]) => list.slice(0, 60).forEach((r, rank) => {
        const cur = fused.get(r.entry) || { entry: r.entry, score: 0, parts: {} };
        cur.score += 1 / (60 + rank + 1); cur.parts[name] = r.score; fused.set(r.entry, cur);
      }));
      ranked = [...fused.values()].sort((a, b) => b.score - a.score);
    }
  }
  const results = ranked.slice(0, k).map(r => ({ id: r.entry.chunk.id, docId: r.entry.doc.id, docName: r.entry.doc.name, line: r.entry.chunk.line, text: r.entry.chunk.text, score: r.score, parts: r.parts }));
  return { results, mode: used, note };
}

export function formatResults(results) {
  return results.map((r, i) => `[${i + 1}] ${r.docName}${r.line ? ` (line ${r.line})` : ''}\n${r.text}`).join('\n\n---\n\n');
}

// ── documents ────────────────────────────────────────────────────
export async function addDocument({ name, text, source = 'paste' }) {
  text = String(text || '');
  if (!text.trim()) throw new Error(`"${name}" is empty.`);
  const existing = kb.docs.find(d => d.name === name && d.source === source);
  if (existing) await removeDocument(existing.id, { silent: true });
  const doc = { id: uid('d_'), name, source, text, size: text.length, added: Date.now(), embedModel: null, chunks: chunkText(text, settings.rag).map((c, i) => ({ id: uid('ch_'), i, ...c })) };
  kb.docs.push(doc);
  await idb.put('docs', doc);
  rebuild(); bus.emit('kb');
  return doc;
}

export async function removeDocument(id, { silent = false } = {}) {
  kb.docs = kb.docs.filter(d => d.id !== id);
  await idb.del('docs', id);
  rebuild(); if (!silent) bus.emit('kb');
}

export async function clearKB() { kb.docs = []; await idb.clear('docs'); rebuild(); bus.emit('kb'); }

export async function rechunkAll() {
  for (const d of kb.docs) {
    d.chunks = chunkText(d.text, settings.rag).map((c, i) => ({ id: uid('ch_'), i, ...c }));
    d.embedModel = null;
    await idb.put('docs', d);
  }
  rebuild(); bus.emit('kb');
}

export const needsEmbedding = d => d.embedModel !== settings.rag.embed.model || d.chunks.some(c => !c.emb);

export async function embedPending(onProgress, signal) {
  const docs = kb.docs.filter(needsEmbedding);
  const total = docs.reduce((n, d) => n + d.chunks.length, 0);
  let done = 0; kb.embedding = true; bus.emit('kb');
  try {
    for (const d of docs) {
      for (let i = 0; i < d.chunks.length; i += 16) {
        if (signal?.aborted) throw new DOMException('Stopped', 'AbortError');
        const batch = d.chunks.slice(i, i + 16);
        const vecs = await embed(batch.map(c => `${d.name}\n${c.text}`), { signal });
        batch.forEach((c, j) => { c.emb = vecs[j]; });
        done += batch.length; onProgress?.(done, total);
      }
      d.embedModel = settings.rag.embed.model;
      await idb.put('docs', d);
    }
  } finally { kb.embedding = false; rebuild(); bus.emit('kb'); }
  return { docs: docs.length, chunks: total };
}

export function stats() {
  const chunks = kb.docs.reduce((n, d) => n + d.chunks.length, 0);
  const embedded = kb.docs.reduce((n, d) => n + d.chunks.filter(c => c.emb).length, 0);
  const chars = kb.docs.reduce((n, d) => n + d.size, 0);
  return { docs: kb.docs.length, chunks, embedded, chars, pending: kb.docs.filter(needsEmbedding).length };
}

// ── importers ────────────────────────────────────────────────────
export async function importURL(url) {
  const res = await proxyFetch(url, { headers: { accept: 'text/html,text/plain,application/json;q=0.9,*/*;q=0.5' } });
  if (!res.ok) throw new Error(`Fetching ${url} failed with HTTP ${res.status}`);
  const type = res.headers.get('content-type') || '';
  if (!/text|json|xml|javascript|markdown/.test(type)) throw new Error(`${url} is ${type.split(';')[0] || 'binary'}; only text pages can be added.`);
  const raw = await res.text();
  const text = /html/.test(type) ? htmlToText(raw) : raw;
  return addDocument({ name: url.replace(/^https?:\/\//, '').slice(0, 120), text, source: 'url' });
}

const TEXT_EXT = /\.(md|mdx|txt|rst|adoc|js|mjs|cjs|jsx|ts|tsx|py|rb|go|rs|java|kt|cs|c|h|cpp|hpp|swift|php|sh|bash|ps1|sql|css|scss|html|vue|svelte|json|yaml|yml|toml|ini|cfg|env\.example|xml|csv|tsv|gradle|tf|lua|r|dart|ex|exs|clj|scala|proto|graphql)$/i;
export async function importWorkspace({ path = '.', depth = 6, exts = TEXT_EXT, onProgress } = {}) {
  const list = await fsApi.list(path, depth);
  const files = list.entries.filter(e => e.type === 'file' && e.size < 400 * 1024 && exts.test(e.name) && !/(^|\/)(package-lock\.json|yarn\.lock|pnpm-lock\.yaml)$/.test(e.path));
  let added = 0, skipped = 0;
  for (const f of files) {
    try {
      const r = await fsApi.read(f.path);
      if (r.binary || !r.content.trim()) { skipped++; continue; }
      await addDocument({ name: f.path, text: r.content, source: 'workspace' }); added++;
    } catch { skipped++; }
    onProgress?.(added + skipped, files.length);
  }
  return { added, skipped, total: files.length };
}
