// util.js — DOM helpers, icons, toasts, modals, event bus. No dependencies.

// append / prepend / replaceChildren skip null, undefined and false, the same way h() does,
// so conditional children like `cond ? h(...) : null` never render the text "null".
for (const proto of [Element.prototype, DocumentFragment.prototype]) {
  for (const name of ['append', 'prepend', 'replaceChildren']) {
    const orig = proto[name];
    proto[name] = function (...nodes) { return orig.apply(this, nodes.filter(n => n != null && n !== false)); };
  }
}

export const $ = (sel, root = document) => root.querySelector(sel);
export const $$ = (sel, root = document) => [...root.querySelectorAll(sel)];

/** Hyperscript: h('div', {class:'x', onClick: fn}, 'text', child, [more]) */
export function h(tag, attrs = {}, ...children) {
  const el = document.createElement(tag);
  for (const [k, v] of Object.entries(attrs || {})) {
    if (v === undefined || v === null || v === false) continue;
    if (k === 'class' || k === 'className') el.className = v;
    else if (k === 'style' && typeof v === 'object') Object.assign(el.style, v);
    else if (k === 'html') el.innerHTML = v;
    else if (k.startsWith('on') && typeof v === 'function') el.addEventListener(k.slice(2).toLowerCase(), v);
    else if (k === 'dataset') Object.assign(el.dataset, v);
    else if (k === 'value' && 'value' in el) el.value = v;
    else if (k === 'checked' || k === 'disabled' || k === 'selected' || k === 'open') el[k] = !!v;
    else el.setAttribute(k, v === true ? '' : v);
  }
  append(el, children);
  return el;
}
function append(el, children) {
  for (const c of children.flat(Infinity)) {
    if (c === null || c === undefined || c === false) continue;
    el.appendChild(c instanceof Node ? c : document.createTextNode(String(c)));
  }
}

export const uid = (p = '') => p + Math.random().toString(36).slice(2, 9) + Date.now().toString(36).slice(-5);
export const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
export const sleep = ms => new Promise(r => setTimeout(r, ms));
export const clamp = (n, a, b) => Math.min(b, Math.max(a, n));
export const estimateTokens = s => Math.ceil(String(s || '').length / 3.8);

export function debounce(fn, ms = 250) {
  let t; return (...a) => { clearTimeout(t); t = setTimeout(() => fn(...a), ms); };
}
export function throttleRAF(fn) {
  let queued = false; return () => { if (queued) return; queued = true; requestAnimationFrame(() => { queued = false; fn(); }); };
}
export function safeJSON(str, fallback = null) { try { return JSON.parse(str); } catch { return fallback; } }
export const deepClone = o => (typeof structuredClone === 'function' ? structuredClone(o) : JSON.parse(JSON.stringify(o)));

export function fmtBytes(n) {
  if (!n && n !== 0) return '';
  const u = ['B', 'KB', 'MB', 'GB', 'TB']; let i = 0;
  while (n >= 1024 && i < u.length - 1) { n /= 1024; i++; }
  return `${n < 10 && i ? n.toFixed(1) : Math.round(n)} ${u[i]}`;
}
export function fmtDuration(ms) {
  if (ms == null) return '';
  if (ms < 1000) return `${Math.round(ms)}ms`;
  if (ms < 60000) return `${(ms / 1000).toFixed(1)}s`;
  return `${Math.floor(ms / 60000)}m ${Math.round((ms % 60000) / 1000)}s`;
}
export function fmtNum(n) { return n == null ? '' : n >= 1000 ? (n / 1000).toFixed(n >= 10000 ? 0 : 1) + 'k' : String(n); }
export function relTime(ts) {
  const d = (Date.now() - ts) / 1000;
  if (d < 45) return 'just now';
  if (d < 3600) return `${Math.round(d / 60)} min ago`;
  if (d < 86400) return `${Math.round(d / 3600)} h ago`;
  return new Date(ts).toLocaleDateString(undefined, { month: 'short', day: 'numeric' });
}
export function truncate(s, n = 200) { s = String(s ?? ''); return s.length > n ? s.slice(0, n - 1) + '…' : s; }

export function downloadFile(name, text, type = 'application/json') {
  const blob = text instanceof Blob ? text : new Blob([text], { type });
  const a = h('a', { href: URL.createObjectURL(blob), download: name });
  document.body.appendChild(a); a.click(); a.remove();
  setTimeout(() => URL.revokeObjectURL(a.href), 2000);
}
export function pickFiles({ multiple = true, accept = '' } = {}) {
  return new Promise(resolve => {
    const input = h('input', { type: 'file', multiple, accept, style: { display: 'none' } });
    input.addEventListener('change', () => { resolve([...input.files]); input.remove(); });
    document.body.appendChild(input); input.click();
  });
}
export const readFileText = f => new Promise((res, rej) => { const r = new FileReader(); r.onload = () => res(r.result); r.onerror = rej; r.readAsText(f); });
export const readFileDataURL = f => new Promise((res, rej) => { const r = new FileReader(); r.onload = () => res(r.result); r.onerror = rej; r.readAsDataURL(f); });

export async function copyText(text) {
  try { await navigator.clipboard.writeText(text); }
  catch {
    const ta = h('textarea', { style: { position: 'fixed', opacity: 0 } }, text);
    document.body.appendChild(ta); ta.select(); document.execCommand('copy'); ta.remove();
  }
  toast('Copied to clipboard', { type: 'ok', timeout: 1400 });
}

/** Simple subsequence fuzzy score; -1 = no match. */
export function fuzzyScore(q, text) {
  q = q.toLowerCase(); text = text.toLowerCase();
  if (!q) return 0;
  if (text.includes(q)) return 100 - text.indexOf(q);
  let ti = 0, score = 0, streak = 0;
  for (const ch of q) {
    const i = text.indexOf(ch, ti);
    if (i < 0) return -1;
    streak = i === ti ? streak + 1 : 0; score += 1 + streak; ti = i + 1;
  }
  return score;
}

// ── event bus ─────────────────────────────────────────────────────
const listeners = new Map();
export const bus = {
  on(ev, fn) { if (!listeners.has(ev)) listeners.set(ev, new Set()); listeners.get(ev).add(fn); return () => bus.off(ev, fn); },
  off(ev, fn) { listeners.get(ev)?.delete(fn); },
  emit(ev, data) { listeners.get(ev)?.forEach(fn => { try { fn(data); } catch (e) { console.error(`[bus:${ev}]`, e); } }); },
};

// ── icons (24×24 stroke) ─────────────────────────────────────────
const P = {
  plus: '<path d="M12 5v14M5 12h14"/>',
  x: '<path d="M18 6 6 18M6 6l12 12"/>',
  check: '<path d="M20 6 9 17l-5-5"/>',
  trash: '<path d="M3 6h18M8 6V4h8v2M19 6l-1 14H6L5 6M10 11v6M14 11v6"/>',
  edit: '<path d="M12 20h9"/><path d="M16.5 3.5a2.1 2.1 0 0 1 3 3L7 19l-4 1 1-4Z"/>',
  copy: '<rect x="9" y="9" width="13" height="13" rx="2"/><path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"/>',
  play: '<path d="M7 4.5v15l12-7.5Z"/>',
  stop: '<rect x="6" y="6" width="12" height="12" rx="2"/>',
  send: '<path d="M12 19V5M5 12l7-7 7 7"/>',
  sliders: '<path d="M4 21v-7M4 10V3M12 21v-9M12 8V3M20 21v-5M20 12V3M1 14h6M9 8h6M17 16h6"/>',
  sun: '<circle cx="12" cy="12" r="4"/><path d="M12 2v2M12 20v2M4.9 4.9l1.4 1.4M17.7 17.7l1.4 1.4M2 12h2M20 12h2M4.9 19.1l1.4-1.4M17.7 6.3l1.4-1.4"/>',
  moon: '<path d="M21 12.8A9 9 0 1 1 11.2 3a7 7 0 0 0 9.8 9.8Z"/>',
  monitor: '<rect x="2" y="3" width="20" height="14" rx="2"/><path d="M8 21h8M12 17v4"/>',
  search: '<circle cx="11" cy="11" r="7"/><path d="m21 21-4.3-4.3"/>',
  file: '<path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8Z"/><path d="M14 2v6h6"/>',
  folder: '<path d="M3 7a2 2 0 0 1 2-2h4l2 2h8a2 2 0 0 1 2 2v8a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2Z"/>',
  chevronRight: '<path d="m9 18 6-6-6-6"/>',
  chevronDown: '<path d="m6 9 6 6 6-6"/>',
  refresh: '<path d="M21 12a9 9 0 1 1-2.6-6.4L21 8"/><path d="M21 3v5h-5"/>',
  download: '<path d="M12 3v12M7 10l5 5 5-5M5 21h14"/>',
  upload: '<path d="M12 21V9M7 14l5-5 5 5M5 3h14"/>',
  tool: '<path d="M14.7 6.3a1 1 0 0 0 0 1.4l1.6 1.6a1 1 0 0 0 1.4 0l3.77-3.77a6 6 0 0 1-7.94 7.94l-6.91 6.91a2.12 2.12 0 0 1-3-3l6.91-6.91a6 6 0 0 1 7.94-7.94l-3.76 3.76z"/>',
  book: '<path d="M4 19.5A2.5 2.5 0 0 1 6.5 17H20V3H6.5A2.5 2.5 0 0 0 4 5.5Z"/><path d="M4 19.5A2.5 2.5 0 0 0 6.5 22H20v-5"/>',
  cpu: '<rect x="5" y="5" width="14" height="14" rx="2"/><rect x="9" y="9" width="6" height="6"/><path d="M9 2v3M15 2v3M9 19v3M15 19v3M2 9h3M2 15h3M19 9h3M19 15h3"/>',
  terminal: '<path d="m4 17 6-6-6-6M12 19h8"/>',
  link: '<path d="M10 13a5 5 0 0 0 7.5.5l3-3a5 5 0 0 0-7-7l-1.7 1.7"/><path d="M14 11a5 5 0 0 0-7.5-.5l-3 3a5 5 0 0 0 7 7l1.7-1.7"/>',
  eye: '<path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8Z"/><circle cx="12" cy="12" r="3"/>',
  layers: '<path d="m12 2 10 5-10 5L2 7Z"/><path d="m2 17 10 5 10-5M2 12l10 5 10-5"/>',
  database: '<ellipse cx="12" cy="5" rx="9" ry="3"/><path d="M21 12c0 1.7-4 3-9 3s-9-1.3-9-3"/><path d="M3 5v14c0 1.7 4 3 9 3s9-1.3 9-3V5"/>',
  message: '<path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2Z"/>',
  alert: '<path d="M10.3 3.9 1.8 18a2 2 0 0 0 1.7 3h17a2 2 0 0 0 1.7-3L13.7 3.9a2 2 0 0 0-3.4 0Z"/><path d="M12 9v4M12 17h.01"/>',
  info: '<circle cx="12" cy="12" r="10"/><path d="M12 16v-4M12 8h.01"/>',
  zap: '<path d="M13 2 3 14h9l-1 8 10-12h-9Z"/>',
  menu: '<path d="M3 6h18M3 12h18M3 18h18"/>',
  sidebar: '<rect x="3" y="3" width="18" height="18" rx="2"/><path d="M9 3v18"/>',
  panel: '<rect x="3" y="3" width="18" height="18" rx="2"/><path d="M15 3v18"/>',
  command: '<path d="M18 3a3 3 0 0 0-3 3v12a3 3 0 1 0 3-3H6a3 3 0 1 0 3 3V6a3 3 0 1 0-3 3h12a3 3 0 0 0 0-6Z"/>',
  clip: '<path d="m21.4 11-9.2 9.2a6 6 0 0 1-8.5-8.5l9.2-9.2a4 4 0 0 1 5.7 5.7l-9.2 9.2a2 2 0 0 1-2.8-2.8l8.5-8.5"/>',
  rotate: '<path d="M1 4v6h6"/><path d="M3.5 15a9 9 0 1 0 2.1-9.4L1 10"/>',
  bulb: '<path d="M9 18h6M10 22h4"/><path d="M12 2a7 7 0 0 0-4 12.7V17h8v-2.3A7 7 0 0 0 12 2Z"/>',
  globe: '<circle cx="12" cy="12" r="10"/><path d="M2 12h20M12 2a15 15 0 0 1 0 20 15 15 0 0 1 0-20Z"/>',
  list: '<path d="M8 6h13M8 12h13M8 18h13M3 6h.01M3 12h.01M3 18h.01"/>',
  activity: '<path d="M22 12h-4l-3 9L9 3l-3 9H2"/>',
  dots: '<circle cx="5" cy="12" r="1.2"/><circle cx="12" cy="12" r="1.2"/><circle cx="19" cy="12" r="1.2"/>',
  shield: '<path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10Z"/>',
  box: '<path d="M21 16V8a2 2 0 0 0-1-1.7l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.7l7 4a2 2 0 0 0 2 0l7-4a2 2 0 0 0 1-1.7Z"/><path d="M3.3 7 12 12l8.7-5M12 22V12"/>',
  scroll: '<path d="M8 21h12a2 2 0 0 0 2-2v-2H10v2a2 2 0 1 1-4 0V5a2 2 0 1 0-4 0v3h4"/><path d="M19 17V5a2 2 0 0 0-2-2H4"/>',
  branch: '<circle cx="6" cy="6" r="3"/><circle cx="6" cy="18" r="3"/><circle cx="18" cy="8" r="3"/><path d="M6 9v6M18 11a6 6 0 0 1-6 6H9"/>',
  pin: '<path d="M12 17v5M9 3h6l-1 7 4 3v2H6v-2l4-3Z"/>',
  keyboard: '<rect x="2" y="5" width="20" height="14" rx="2"/><path d="M6 9h.01M10 9h.01M14 9h.01M18 9h.01M6 13h.01M18 13h.01M8 16h8M10 13h4"/>',
  wand: '<path d="m15 4 5 5L9 20H4v-5Z"/><path d="m13 6 5 5"/>',
};
export function iconSVG(name, size = 16) {
  return `<svg class="i" width="${size}" height="${size}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${P[name] || P.dots}</svg>`;
}
export function icon(name, size = 16) { const s = h('span', { class: 'ico', html: iconSVG(name, size) }); return s; }

/** Icon button helper */
export function ibtn(name, title, onClick, cls = '') {
  return h('button', { class: `ibtn ${cls}`, title, 'aria-label': title, type: 'button', onClick }, icon(name));
}

// ── toasts ────────────────────────────────────────────────────────
export function toast(message, { type = 'info', timeout = 3200, action } = {}) {
  let host = $('#toasts');
  if (!host) { host = h('div', { id: 'toasts', role: 'status', 'aria-live': 'polite' }); document.body.appendChild(host); }
  const ico = { ok: 'check', err: 'alert', warn: 'alert', info: 'info' }[type] || 'info';
  const el = h('div', { class: `toast toast-${type}` }, icon(ico), h('span', { class: 'toast-msg' }, message));
  if (action) el.appendChild(h('button', { class: 'btn btn-sm btn-ghost', onClick: () => { action.onClick(); close(); } }, action.label));
  el.appendChild(ibtn('x', 'Dismiss', () => close(), 'ibtn-sm'));
  host.appendChild(el);
  requestAnimationFrame(() => el.classList.add('in'));
  let t = timeout ? setTimeout(close, timeout) : null;
  function close() { clearTimeout(t); el.classList.remove('in'); setTimeout(() => el.remove(), 200); }
  return close;
}

// ── modals ────────────────────────────────────────────────────────
const modalStack = [];
export function modal({ title, body, actions = [], wide = false, full = false, onClose, className = '' }) {
  const prevFocus = document.activeElement;
  const backdrop = h('div', { class: 'modal-backdrop' });
  const footer = actions.length ? h('div', { class: 'modal-foot' }, actions.map(a => h('button', {
    class: `btn ${a.primary ? 'btn-primary' : ''} ${a.danger ? 'btn-danger' : ''} ${a.ghost ? 'btn-ghost' : ''}`, type: 'button',
    onClick: async () => { const r = a.onClick ? await a.onClick() : undefined; if (r !== false) close(); },
  }, a.icon ? icon(a.icon) : null, a.label))) : null;
  const box = h('div', { class: `modal ${wide ? 'modal-wide' : ''} ${full ? 'modal-full' : ''} ${className}`, role: 'dialog', 'aria-modal': 'true', 'aria-label': title },
    h('div', { class: 'modal-head' }, h('h2', {}, title), ibtn('x', 'Close', () => close())),
    h('div', { class: 'modal-body' }, body),
    footer);
  backdrop.appendChild(box);
  backdrop.addEventListener('mousedown', e => { if (e.target === backdrop) close(); });
  document.body.appendChild(backdrop);
  requestAnimationFrame(() => backdrop.classList.add('in'));
  const entry = { close, box }; modalStack.push(entry);
  setTimeout(() => (box.querySelector('[autofocus], input, textarea, select') || box.querySelector('.modal-foot .btn-primary') || box).focus?.(), 30);
  let closed = false;
  function close() {
    if (closed) return; closed = true;
    modalStack.splice(modalStack.indexOf(entry), 1);
    backdrop.classList.remove('in'); setTimeout(() => backdrop.remove(), 160);
    onClose?.(); prevFocus?.focus?.();
  }
  return entry;
}
export function closeTopModal() { const m = modalStack[modalStack.length - 1]; if (m) { m.close(); return true; } return false; }
export const hasModal = () => modalStack.length > 0;

export function confirmDialog(message, { title = 'Are you sure?', okLabel = 'Confirm', danger = false } = {}) {
  return new Promise(resolve => {
    let done = false;
    modal({
      title, body: h('p', { class: 'modal-text' }, message),
      actions: [{ label: 'Cancel', ghost: true, onClick: () => { done = true; resolve(false); } }, { label: okLabel, primary: !danger, danger, onClick: () => { done = true; resolve(true); } }],
      onClose: () => { if (!done) resolve(false); },
    });
  });
}
export function promptDialog(message, { title = 'Enter a value', value = '', placeholder = '', multiline = false, okLabel = 'Save' } = {}) {
  return new Promise(resolve => {
    let done = false;
    const input = multiline ? h('textarea', { class: 'input', rows: 8, placeholder }, value) : h('input', { class: 'input', value, placeholder, autofocus: true });
    if (!multiline) input.addEventListener('keydown', e => { if (e.key === 'Enter') { done = true; resolve(input.value); m.close(); } });
    const m = modal({
      title, body: h('div', { class: 'stack' }, message ? h('p', { class: 'modal-text' }, message) : null, input),
      actions: [{ label: 'Cancel', ghost: true, onClick: () => { done = true; resolve(null); } }, { label: okLabel, primary: true, onClick: () => { done = true; resolve(input.value); } }],
      onClose: () => { if (!done) resolve(null); },
    });
  });
}

/** Popover menu anchored to an element. items: [{label, icon, onClick, danger, hint}] or 'sep' */
export function menu(anchor, items, { align = 'left' } = {}) {
  document.querySelectorAll('.menu-pop').forEach(m => m.remove());
  const pop = h('div', { class: 'menu-pop', role: 'menu' }, items.map(it => it === 'sep' ? h('div', { class: 'menu-sep' }) :
    h('button', { class: `menu-item ${it.danger ? 'danger' : ''}`, role: 'menuitem', type: 'button', onClick: () => { close(); it.onClick?.(); } },
      it.icon ? icon(it.icon) : h('span', { class: 'ico' }), h('span', {}, it.label), it.hint ? h('kbd', {}, it.hint) : null)));
  document.body.appendChild(pop);
  const r = anchor.getBoundingClientRect();
  const pw = pop.offsetWidth, ph = pop.offsetHeight;
  let left = align === 'right' ? r.right - pw : r.left;
  let top = r.bottom + 4;
  if (top + ph > innerHeight - 8) top = r.top - ph - 4;
  pop.style.left = clamp(left, 8, innerWidth - pw - 8) + 'px';
  pop.style.top = clamp(top, 8, innerHeight - ph - 8) + 'px';
  const onDoc = e => { if (!pop.contains(e.target)) close(); };
  const onKey = e => { if (e.key === 'Escape') close(); };
  setTimeout(() => { document.addEventListener('mousedown', onDoc); document.addEventListener('keydown', onKey); });
  function close() { pop.remove(); document.removeEventListener('mousedown', onDoc); document.removeEventListener('keydown', onKey); }
  pop.querySelector('button')?.focus();
  return close;
}

/** Labeled toggle switch */
export function toggle(checked, onChange, label = '') {
  const input = h('input', { type: 'checkbox', checked, onChange: e => onChange(e.target.checked) });
  return h('label', { class: 'switch', title: label }, input, h('span', { class: 'switch-track' }, h('span', { class: 'switch-thumb' })), label ? h('span', { class: 'switch-label' }, label) : null);
}
