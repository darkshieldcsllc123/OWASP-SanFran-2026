// panel-tools.js — agent loop settings, built-in tools, and the custom tool builder.
import { settings, saveSettings, state, activeConvo } from './store.js';
import { BUILTINS, CATEGORIES, builtinState, customToTool, customSchema, newCustomTool, executeTool, schemaFromParams, validateArgs } from './tools.js';
import { TOOL_TEMPLATES } from './defaults.js';
import { h, icon, ibtn, toast, modal, confirmDialog, bus, menu, uid, safeJSON, downloadFile, pickFiles, readFileText, deepClone, fmtDuration, toggle } from './util.js';
import { section, field, select, input, segmented, badge, btn, empty } from './ui.js';
import { highlight } from './markdown.js';

let root;
const NAME_RE = /^[a-zA-Z_][a-zA-Z0-9_-]{0,63}$/;
const APPROVAL_OPTS = [{ value: 'inherit', label: 'Use policy' }, { value: 'ask', label: 'Always ask' }, { value: 'auto', label: 'Never ask' }];

export default {
  id: 'tools', label: 'Tools', icon: 'tool',
  mount(el) {
    root = el; render();
    bus.on('settings', what => { if (['agent', 'all'].includes(what) && !root.contains(document.activeElement)) render(); });
    bus.on('kb', () => { if (!root.contains(document.activeElement)) render(); });
  },
};

function render() {
  root.replaceChildren(behaviourSection(), builtinSection(), customSection());
}

function behaviourSection() {
  const a = settings.agent;
  const set = (k, v) => { a[k] = v; saveSettings('agent'); };
  const modeHelp = {
    native: 'The provider\'s own tool calling. Best with models that support it (most cloud models; Ollama models tagged "tools").',
    text: 'Tools are described in the system prompt and the model writes <tool_call> blocks. Works with any model, including ones without native support.',
    off: 'Plain chat. The model cannot use tools.',
  };
  const help = h('small', { class: 'help' }, modeHelp[a.toolMode]);
  return section('Agent behaviour', h('div', { class: 'stack' },
    field('Tool calling', h('div', { class: 'stack-sm' }, segmented([{ value: 'native', label: 'Native' }, { value: 'text', label: 'Text protocol' }, { value: 'off', label: 'Off' }], a.toolMode, v => { set('toolMode', v); help.textContent = modeHelp[v]; }), help)),
    field('Approval', select([{ value: 'all', label: 'Ask before every tool' }, { value: 'risky', label: 'Ask before writes, shell and network' }, { value: 'none', label: 'Never ask (run everything)' }], a.approval, v => set('approval', v)),
      'You can override this per tool below. "Always allow" on an approval card lasts until you reload.'),
    h('div', { class: 'grid2' },
      field('Max steps per message', input(a.maxSteps, v => set('maxSteps', Math.max(1, Math.min(200, +v || 20))), { type: 'number', min: 1, max: 200, class: 'input input-num' }), 'Model turns before the agent pauses.'),
      field('Tool output limit', input(a.outputLimit, v => set('outputLimit', Math.max(1000, +v || 12000)), { type: 'number', min: 1000, step: 1000, class: 'input input-num' }), 'Characters kept from each tool result.')),
    h('div', { class: 'row' }, toggle(a.showThinking, v => { set('showThinking', v); bus.emit('convo:render', activeConvo()); }, 'Show the model\'s thinking'))),
    { id: 'behaviour' });
}

function availabilityNote(t) {
  if (t.name === 'run_command' && state.info?.exec === false) return 'Disabled on the server (--no-exec)';
  if (t.name === 'rag_search' && !(settings.rag.asTool)) return 'Turned off in Knowledge settings';
  if (t.name === 'rag_search') return 'Active when Knowledge has documents';
  if (t.name === 'load_skill') return 'Active when a skill can be loaded on request';
  return null;
}

function builtinSection() {
  const byCat = {};
  for (const t of BUILTINS) (byCat[t.category] ||= []).push(t);
  const enabledCount = BUILTINS.filter(t => builtinState(t.name).enabled !== false).length;
  const body = h('div', { class: 'stack' }, Object.entries(byCat).map(([cat, list]) => h('div', { class: 'tgroup' },
    h('div', { class: 'pgroup-title' }, icon(CATEGORIES[cat].icon, 13), CATEGORIES[cat].label, CATEGORIES[cat].risky ? h('small', {}, 'asks first under the default policy') : null),
    list.map(t => {
      const st = builtinState(t.name);
      const note = availabilityNote(t);
      return h('div', { class: `trow ${st.enabled === false ? 'off' : ''}` },
        toggle(st.enabled !== false, v => { st.enabled = v; saveSettings('tools'); render(); }),
        h('div', { class: 'trow-main' },
          h('div', { class: 'trow-name' }, h('code', {}, t.name), note ? h('small', { class: 'muted' }, note) : null),
          h('p', { class: 'trow-desc' }, t.description)),
        h('div', { class: 'trow-side' },
          select(APPROVAL_OPTS, st.approval || 'inherit', v => { st.approval = v; saveSettings('tools'); }, { class: 'input input-xs', title: 'Approval for this tool' }),
          ibtn('eye', 'View schema', () => showSchema(t.name, t.parameters), 'ibtn-sm')));
    }))));
  return section('Built-in tools', body, { id: 'builtin', count: `${enabledCount}/${BUILTINS.length}` });
}

function showSchema(name, schema) {
  modal({ title: `${name} schema`, body: h('pre', { class: 'code', html: highlight(JSON.stringify({ name, parameters: schema }, null, 2), 'json') }), actions: [{ label: 'Close', ghost: true }], wide: true });
}

function customSection() {
  const list = settings.tools.custom;
  const templatesMenu = e => menu(e.currentTarget, TOOL_TEMPLATES.map(t => ({ label: t.name, hint: t.type === 'http' ? 'HTTP' : 'JS', icon: t.type === 'http' ? 'globe' : 'tool', onClick: () => {
    const draft = newCustomTool({ ...deepClone(t), id: uid('t_'), params: deepClone(t.params) });
    if (list.some(x => x.name === draft.name)) draft.name += '_' + Math.random().toString(36).slice(2, 5);
    openEditor(draft, true);
  } })));
  const importTools = async () => {
    const [f] = await pickFiles({ multiple: false, accept: '.json' }); if (!f) return;
    try {
      const j = JSON.parse(await readFileText(f));
      const arr = Array.isArray(j) ? j : j.tools || [j];
      let n = 0;
      for (const t of arr) { if (!t.name) continue; settings.tools.custom.push(newCustomTool({ ...t, id: uid('t_') })); n++; }
      saveSettings('tools'); render(); toast(`Imported ${n} tool${n === 1 ? '' : 's'}`, { type: 'ok' });
    } catch (e) { toast(`Could not import: ${e.message}`, { type: 'err' }); }
  };
  const body = h('div', { class: 'stack' },
    list.length ? list.map(c => h('div', { class: `trow ${c.enabled === false ? 'off' : ''}` },
      toggle(c.enabled !== false, v => { c.enabled = v; saveSettings('tools'); render(); }),
      h('div', { class: 'trow-main' },
        h('div', { class: 'trow-name' }, h('code', {}, c.name), badge(c.type === 'http' ? `HTTP ${c.method || 'POST'}` : 'JavaScript'), c.approval !== 'inherit' ? badge(c.approval === 'ask' ? 'asks' : 'auto', c.approval === 'auto' ? 'warn' : '') : null),
        h('p', { class: 'trow-desc' }, c.description || 'No description. Models use the description to decide when to call a tool.')),
      h('div', { class: 'trow-side' },
        ibtn('edit', 'Edit', () => openEditor(deepClone(c)), 'ibtn-sm'),
        ibtn('dots', 'More', e => menu(e.currentTarget, [
          { label: 'Test', icon: 'play', onClick: () => openEditor(deepClone(c), false, true) },
          { label: 'Duplicate', icon: 'copy', onClick: () => { settings.tools.custom.push({ ...deepClone(c), id: uid('t_'), name: c.name + '_copy' }); saveSettings('tools'); render(); } },
          { label: 'Export as JSON', icon: 'download', onClick: () => downloadFile(`${c.name}.tool.json`, JSON.stringify(c, null, 2)) },
          'sep',
          { label: 'Delete', icon: 'trash', danger: true, onClick: async () => { if (await confirmDialog(`Delete the tool "${c.name}"?`, { okLabel: 'Delete tool', danger: true })) { settings.tools.custom = settings.tools.custom.filter(x => x.id !== c.id); saveSettings('tools'); render(); } } },
        ], { align: 'right' }), 'ibtn-sm'))))
      : empty('tool', 'No custom tools yet', 'Write a tool in JavaScript (runs in this page with access to the workspace, shell and network helpers) or wrap any HTTP API.'),
    h('div', { class: 'row wrap' },
      btn('New tool', () => openEditor(newCustomTool(), true), { iconName: 'plus', kind: 'primary' }),
      btn('From template', templatesMenu, { iconName: 'layers' }),
      btn('Import', importTools, { iconName: 'upload', kind: 'ghost' }),
      list.length ? btn('Export all', () => downloadFile('harness-tools.json', JSON.stringify({ tools: list }, null, 2)), { iconName: 'download', kind: 'ghost' }) : null));
  return section('Custom tools', body, { id: 'custom', count: list.length });
}

// ── tool editor ──────────────────────────────────────────────────
const TYPES = ['string', 'number', 'integer', 'boolean', 'array', 'object'];

function openEditor(draft, isNew = false, focusTest = false) {
  draft.params ||= [];
  const err = h('p', { class: 'form-error' });
  const nameIn = h('input', { class: 'input mono', value: draft.name, spellcheck: 'false', onInput: e => { draft.name = e.target.value.trim(); } });
  const descIn = h('textarea', { class: 'input', rows: 3, placeholder: 'What the tool does and when to use it. The model reads this.', onInput: e => { draft.description = e.target.value; } }, draft.description);

  const paramsWrap = h('div', { class: 'stack-sm' });
  const drawParams = () => {
    if (draft.schemaMode === 'raw') {
      const ta = h('textarea', { class: 'input mono', rows: 10, spellcheck: 'false', onInput: e => { draft.schemaRaw = e.target.value; } }, draft.schemaRaw || JSON.stringify(schemaFromParams(draft.params), null, 2));
      draft.schemaRaw = ta.value;
      paramsWrap.replaceChildren(ta, h('small', { class: 'help' }, 'A JSON Schema object with type "object", properties and required.'));
      return;
    }
    paramsWrap.replaceChildren(
      draft.params.length ? h('div', { class: 'ptable' }, h('div', { class: 'ptable-head' }, h('span', {}, 'Name'), h('span', {}, 'Type'), h('span', {}, 'Description'), h('span', {}, 'Req.'), h('span')),
        draft.params.map((p, i) => h('div', { class: 'ptable-row' },
          h('input', { class: 'input input-sm mono', value: p.name, placeholder: 'name', onInput: e => { p.name = e.target.value.trim(); } }),
          h('select', { class: 'input input-sm', onChange: e => { p.type = e.target.value; } }, TYPES.map(t => h('option', { value: t, selected: t === (p.type || 'string') }, t))),
          h('input', { class: 'input input-sm', value: p.description || '', placeholder: 'What to pass', onInput: e => { p.description = e.target.value; } }),
          h('input', { type: 'checkbox', checked: !!p.required, 'aria-label': 'Required', onChange: e => { p.required = e.target.checked; } }),
          ibtn('x', 'Remove parameter', () => { draft.params.splice(i, 1); drawParams(); }, 'ibtn-sm'))))
        : h('p', { class: 'muted small' }, 'No parameters. The tool will be called with an empty object.'),
      h('button', { class: 'linkbtn', type: 'button', onClick: () => { draft.params.push({ name: '', type: 'string', description: '', required: true }); drawParams(); paramsWrap.querySelector('.ptable-row:last-child input')?.focus(); } }, icon('plus', 12), 'Add parameter'));
  };
  drawParams();

  const implWrap = h('div', { class: 'stack' });
  const drawImpl = () => {
    if (draft.type === 'http') {
      implWrap.replaceChildren(
        h('div', { class: 'row' },
          select(['GET', 'POST', 'PUT', 'PATCH', 'DELETE'], draft.method || 'POST', v => { draft.method = v; }, { class: 'input input-num' }),
          h('input', { class: 'input mono', value: draft.url, placeholder: 'https://api.example.com/items/{{id}}', spellcheck: 'false', onInput: e => { draft.url = e.target.value.trim(); } })),
        h('small', { class: 'help' }, 'Use {{param}} in the URL to insert an argument. Other arguments go in the query string (GET, DELETE) or a JSON body (POST, PUT, PATCH). Requests go through the local proxy.'),
        field('Headers (JSON)', h('textarea', { class: 'input mono', rows: 3, spellcheck: 'false', placeholder: '{ "Authorization": "Bearer ..." }', onInput: e => { draft.headers = e.target.value; } }, draft.headers || '{}')));
    } else {
      const code = h('textarea', { class: 'input mono code-editor', rows: 12, spellcheck: 'false', onInput: e => { draft.code = e.target.value; } }, draft.code || '');
      code.addEventListener('keydown', e => { if (e.key === 'Tab') { e.preventDefault(); code.setRangeText('  ', code.selectionStart, code.selectionEnd, 'end'); draft.code = code.value; } });
      implWrap.replaceChildren(code, h('details', { class: 'api-help' }, h('summary', {}, 'What the code can use'),
        h('pre', { class: 'code small', html: highlight(`// Body of: async function (args, ctx) { ... }
// Return a string or any JSON-serialisable value.
args.myParam
await ctx.fs.read(path, startLine?, endLine?)  // { content, totalLines, ... }
await ctx.fs.write(path, content)
await ctx.fs.list(path, depth)                // { entries: [...] }
await ctx.fs.search(pattern, { glob, regex })
await ctx.exec('npm test', { timeout: 120 })  // { code, stdout, stderr }
await ctx.fetchJSON(url, { method, headers, body })
await ctx.fetchText(url)
await ctx.rag.search('query', 5)
ctx.log('debug info')                         // appended to the result`, 'js') })));
    }
  };
  drawImpl();

  const sample = h('textarea', { class: 'input mono', rows: 3, spellcheck: 'false', onInput: e => { draft.sample = e.target.value; } }, draft.sample || '{}');
  const out = h('pre', { class: 'code result', hidden: true });
  const runTest = async () => {
    const args = safeJSON(sample.value || '{}');
    if (!args || typeof args !== 'object') { out.hidden = false; out.className = 'code result is-error'; out.textContent = 'Test arguments must be a JSON object.'; return; }
    const tool = customToTool(draft);
    const v = validateArgs(tool.parameters, args);
    out.hidden = false; out.className = 'code result'; out.textContent = 'Running…';
    const t0 = performance.now();
    try { const r = await executeTool(tool, args, { signal: new AbortController().signal }); out.textContent = `${v ? `Warning: ${v}\n\n` : ''}${r}\n\n(${fmtDuration(performance.now() - t0)})`; }
    catch (e) { out.className = 'code result is-error'; out.textContent = `Error: ${e.message}`; }
  };

  const body = h('div', { class: 'editor-grid' },
    h('div', { class: 'stack' },
      h('div', { class: 'grid2' }, field('Name', nameIn, 'Letters, digits, _ and -. Shown to the model.'), field('Approval', select(APPROVAL_OPTS, draft.approval || 'inherit', v => { draft.approval = v; }), 'Custom tools ask first under the default policy.')),
      field('Description', descIn),
      field('Implementation', h('div', { class: 'stack-sm' }, segmented([{ value: 'js', label: 'JavaScript', icon: 'tool' }, { value: 'http', label: 'HTTP request', icon: 'globe' }], draft.type, v => { draft.type = v; drawImpl(); }), implWrap))),
    h('div', { class: 'stack' },
      h('div', { class: 'field' }, h('div', { class: 'row' }, h('span', { class: 'field-label' }, 'Parameters'), h('span', { class: 'spacer' }),
        segmented([{ value: 'builder', label: 'Builder' }, { value: 'raw', label: 'JSON Schema' }], draft.schemaMode || 'builder', v => {
          if (v === 'raw') draft.schemaRaw = JSON.stringify(schemaFromParams(draft.params), null, 2);
          else { const j = safeJSON(draft.schemaRaw); if (j?.properties) draft.params = Object.entries(j.properties).map(([name, p]) => ({ name, type: p.type || 'string', description: p.description || '', required: (j.required || []).includes(name) })); }
          draft.schemaMode = v; drawParams();
        }, { size: 'seg-sm' })), paramsWrap),
      h('div', { class: 'test-box' }, h('div', { class: 'row' }, h('strong', {}, 'Try it'), h('span', { class: 'spacer' }), btn('Run test', runTest, { iconName: 'play' })), sample, out)),
    err);

  modal({
    title: isNew ? 'New tool' : `Edit ${draft.name}`, body, full: true, className: 'tool-editor',
    actions: [{ label: 'Cancel', ghost: true }, { label: isNew ? 'Create tool' : 'Save tool', primary: true, onClick: () => {
      if (!NAME_RE.test(draft.name)) { err.textContent = 'Name must start with a letter or underscore and contain only letters, digits, _ or -.'; return false; }
      if (BUILTINS.some(b => b.name === draft.name)) { err.textContent = `"${draft.name}" is a built-in tool name. Pick another.`; return false; }
      if (settings.tools.custom.some(c => c.name === draft.name && c.id !== draft.id)) { err.textContent = `Another custom tool is already called "${draft.name}".`; return false; }
      if (draft.schemaMode === 'raw') { const j = safeJSON(draft.schemaRaw); if (!j || j.type !== 'object') { err.textContent = 'The JSON Schema must be an object with "type": "object".'; return false; } }
      if (draft.type === 'http' && !/^https?:\/\//.test(draft.url || '')) { err.textContent = 'HTTP tools need a URL starting with http:// or https://'; return false; }
      if (draft.type === 'http' && draft.headers && safeJSON(draft.headers) === null) { err.textContent = 'Headers must be valid JSON.'; return false; }
      draft.params = draft.params.filter(p => p.name);
      const i = settings.tools.custom.findIndex(c => c.id === draft.id);
      if (i > -1) settings.tools.custom[i] = draft; else settings.tools.custom.push(draft);
      saveSettings('tools'); render(); toast(`${isNew ? 'Created' : 'Saved'} ${draft.name}`, { type: 'ok' });
    } }],
  });
  if (focusTest) setTimeout(() => sample.focus(), 60);
}
