// panel-knowledge.js — RAG: add documents, tune chunking and retrieval, embeddings, test searches.
import { settings, saveSettings } from './store.js';
import * as rag from './rag.js';
import { PRESETS } from './providers.js';
import { h, icon, ibtn, toast, modal, confirmDialog, bus, fmtBytes, fmtNum, readFileText, pickFiles, truncate, relTime, toggle } from './util.js';
import { section, field, select, input, segmented, badge, btn, empty } from './ui.js';

let root;
const kstate = { addMode: 'paste', filter: '', embedCtrl: null, progress: null, query: '' };

export default {
  id: 'knowledge', label: 'Knowledge', icon: 'database',
  mount(el) { root = el; render(); bus.on('kb', () => { if (!root.contains(document.activeElement) || kstate.progress) render(); }); },
};

function render() {
  root.replaceChildren(overview(), addSection(), docsSection(), searchSection(), settingsSection());
}

function overview() {
  const s = rag.stats();
  const r = settings.rag;
  return h('div', { class: 'kb-overview' },
    h('div', { class: 'gauges' },
      gauge(fmtNum(s.docs), 'documents'), gauge(fmtNum(s.chunks), 'chunks'),
      gauge(r.embed.enabled ? `${s.chunks ? Math.round((s.embedded / s.chunks) * 100) : 0}%` : 'off', 'embedded'),
      gauge(fmtBytes(s.chars), 'text')),
    h('div', { class: 'row wrap' },
      toggle(r.autoInject, v => { r.autoInject = v; saveSettings('rag'); }, 'Add excerpts to each message'),
      toggle(r.asTool, v => { r.asTool = v; saveSettings('rag'); }, 'Let the model search (rag_search)')),
    kstate.progress ? h('div', { class: 'pull-progress' }, h('div', { class: 'bar' }, h('span', { style: { width: `${kstate.progress.pct}%` } })), h('small', {}, kstate.progress.label)) : null);
}
const gauge = (v, label) => h('div', { class: 'gauge' }, h('span', { class: 'gauge-v' }, v), h('span', { class: 'gauge-l' }, label));

function setProgress(label, done, total) { kstate.progress = total ? { label, pct: Math.round((done / total) * 100) } : null; const o = root.querySelector('.kb-overview'); o?.replaceWith(overview()); }

async function addFiles(files) {
  let n = 0;
  for (const f of files) {
    try {
      if (f.size > 5 * 1024 * 1024) { toast(`${f.name} is over 5 MB and was skipped`, { type: 'warn' }); continue; }
      if (/\.(pdf|docx?|xlsx?|pptx?|zip|png|jpe?g|gif|webp)$/i.test(f.name)) { toast(`${f.name}: only text files can be added. Convert it to text or Markdown first.`, { type: 'warn' }); continue; }
      const text = await readFileText(f);
      if (text.includes('\u0000')) { toast(`${f.name} looks binary and was skipped`, { type: 'warn' }); continue; }
      await rag.addDocument({ name: f.name, text, source: 'file' }); n++;
    } catch (e) { toast(`${f.name}: ${e.message}`, { type: 'err' }); }
  }
  if (n) { toast(`Added ${n} document${n === 1 ? '' : 's'}`, { type: 'ok' }); autoEmbed(); }
}

function autoEmbed() { if (settings.rag.embed.enabled && rag.stats().pending) runEmbed(); }

async function runEmbed() {
  if (kstate.embedCtrl) return;
  kstate.embedCtrl = new AbortController();
  try {
    const r = await rag.embedPending((d, t) => setProgress(`Embedding ${d} of ${t} chunks`, d, t), kstate.embedCtrl.signal);
    if (r.chunks) toast(`Embedded ${r.chunks} chunks`, { type: 'ok' });
  } catch (e) { if (e.name !== 'AbortError') toast(`Embedding failed: ${e.message}`, { type: 'err', timeout: 7000 }); }
  finally { kstate.embedCtrl = null; kstate.progress = null; render(); }
}

function addSection() {
  const modes = [{ value: 'paste', label: 'Paste', icon: 'edit' }, { value: 'files', label: 'Files', icon: 'file' }, { value: 'url', label: 'URL', icon: 'globe' }, { value: 'workspace', label: 'Workspace', icon: 'folder' }];
  const pane = h('div', { class: 'stack' });
  const draw = () => {
    if (kstate.addMode === 'paste') {
      const title = h('input', { class: 'input', placeholder: 'Title, e.g. API conventions' });
      const text = h('textarea', { class: 'input', rows: 6, placeholder: 'Paste notes, docs, specs or code here.' });
      pane.replaceChildren(title, text, h('div', { class: 'row' }, h('span', { class: 'spacer' }), btn('Add to knowledge', async () => {
        try { await rag.addDocument({ name: title.value.trim() || truncate(text.value.trim().split('\n')[0], 50) || 'Pasted note', text: text.value, source: 'paste' }); toast('Added', { type: 'ok' }); autoEmbed(); }
        catch (e) { toast(e.message, { type: 'err' }); }
      }, { kind: 'primary', iconName: 'plus' })));
    } else if (kstate.addMode === 'files') {
      const zone = h('div', { class: 'dropzone', tabindex: 0, role: 'button', onClick: async () => addFiles(await pickFiles()), onKeydown: async e => { if (e.key === 'Enter') addFiles(await pickFiles()); } },
        icon('upload', 20), h('strong', {}, 'Drop text files here or choose files'), h('small', {}, 'Markdown, text, code, JSON, CSV. Up to 5 MB each.'));
      zone.addEventListener('dragover', e => { e.preventDefault(); e.stopPropagation(); zone.classList.add('over'); });
      zone.addEventListener('dragleave', () => zone.classList.remove('over'));
      zone.addEventListener('drop', e => { e.preventDefault(); e.stopPropagation(); zone.classList.remove('over'); addFiles([...e.dataTransfer.files]); });
      pane.replaceChildren(zone);
    } else if (kstate.addMode === 'url') {
      const url = h('input', { class: 'input mono', placeholder: 'https://docs.example.com/guide', spellcheck: 'false' });
      const go = async () => {
        if (!/^https?:\/\//.test(url.value.trim())) return toast('Enter a full URL starting with http:// or https://', { type: 'warn' });
        try { const d = await rag.importURL(url.value.trim()); toast(`Added ${d.name}: ${d.chunks.length} chunks`, { type: 'ok' }); url.value = ''; autoEmbed(); }
        catch (e) { toast(e.message, { type: 'err', timeout: 6000 }); }
      };
      url.addEventListener('keydown', e => { if (e.key === 'Enter') go(); });
      pane.replaceChildren(h('div', { class: 'row' }, url, btn('Fetch and add', go, { kind: 'primary', iconName: 'download' })), h('small', { class: 'help' }, 'The page is fetched through the local proxy and converted to text.'));
    } else {
      const folder = h('input', { class: 'input mono', value: '.', spellcheck: 'false' });
      pane.replaceChildren(h('div', { class: 'row' }, folder, btn('Index folder', async () => {
        try {
          const r = await rag.importWorkspace({ path: folder.value.trim() || '.', onProgress: (d, t) => setProgress(`Reading ${d} of ${t} files`, d, t) });
          toast(`Indexed ${r.added} files${r.skipped ? `, skipped ${r.skipped}` : ''}`, { type: 'ok' }); kstate.progress = null; render(); autoEmbed();
        } catch (e) { kstate.progress = null; toast(e.message, { type: 'err' }); render(); }
      }, { kind: 'primary', iconName: 'database' })), h('small', { class: 'help' }, 'Adds text and source files under this workspace folder (skips node_modules, .git, build output and lock files). Re-indexing a file replaces its old copy.'));
    }
  };
  draw();
  return section('Add knowledge', h('div', { class: 'stack' }, segmented(modes, kstate.addMode, v => { kstate.addMode = v; draw(); }), pane), { id: 'kb-add' });
}

function docsSection() {
  const docs = rag.kb.docs;
  const listEl = h('div', { class: 'doc-list' });
  const srcIcon = { paste: 'edit', file: 'file', url: 'globe', workspace: 'folder' };
  const draw = () => {
    const q = kstate.filter.toLowerCase();
    const shown = docs.filter(d => d.name.toLowerCase().includes(q));
    listEl.replaceChildren(...(shown.length ? shown.slice().reverse().map(d => h('div', { class: 'doc' },
      icon(srcIcon[d.source] || 'file', 14),
      h('button', { class: 'doc-main', type: 'button', onClick: () => viewDoc(d), title: 'View chunks' }, h('span', { class: 'doc-name' }, d.name), h('small', {}, `${d.chunks.length} chunks, ${fmtBytes(d.size)}, ${relTime(d.added)}`)),
      settings.rag.embed.enabled ? h('span', { class: `lamp ${rag.needsEmbedding(d) ? '' : 'on'}`, title: rag.needsEmbedding(d) ? 'Not embedded' : `Embedded with ${d.embedModel}` }) : null,
      ibtn('trash', `Remove ${d.name}`, async () => { await rag.removeDocument(d.id); }, 'ibtn-sm'))) : [h('p', { class: 'muted small' }, q ? 'No documents match.' : '')]));
  };
  draw();
  const body = docs.length ? h('div', { class: 'stack' },
    docs.length > 5 ? h('input', { class: 'input', placeholder: 'Filter documents', value: kstate.filter, onInput: e => { kstate.filter = e.target.value; draw(); } }) : null,
    listEl,
    h('div', { class: 'row' }, h('span', { class: 'spacer' }), btn('Remove all', async () => { if (await confirmDialog(`Remove all ${docs.length} documents from the knowledge base?`, { okLabel: 'Remove all', danger: true })) rag.clearKB(); }, { kind: 'danger-ghost', iconName: 'trash' })))
    : empty('database', 'The knowledge base is empty', 'Add docs, notes or code above. Relevant excerpts are retrieved for each message.');
  return section('Documents', body, { id: 'kb-docs', count: docs.length });
}

function viewDoc(d) {
  modal({
    title: d.name, wide: true,
    body: h('div', { class: 'stack' }, h('p', { class: 'muted' }, `${d.chunks.length} chunks from ${d.source}. Chunk size ${settings.rag.chunkSize}, overlap ${settings.rag.overlap}.`),
      d.chunks.map(c => h('div', { class: 'rag-item' }, h('div', { class: 'rag-item-head' }, h('strong', {}, `Chunk ${c.i + 1}`), h('small', {}, `line ${c.line}, ${c.text.length} chars`), h('span', { class: 'spacer' }), c.emb ? badge('embedded', 'ok') : null), h('pre', {}, c.text)))),
    actions: [{ label: 'Close', ghost: true }],
  });
}

function searchSection() {
  const out = h('div', { class: 'stack-sm' });
  const run = async q => {
    kstate.query = q;
    if (!q.trim()) { out.replaceChildren(); return; }
    const r = await rag.search(q, { k: settings.rag.topK });
    out.replaceChildren(h('small', { class: 'muted' }, `${r.mode === 'bm25' ? 'Keyword' : r.mode === 'vector' ? 'Vector' : 'Hybrid'} search${r.note ? `. ${r.note}` : ''}`),
      ...(r.results.length ? r.results.map((x, i) => h('div', { class: 'rag-item' },
        h('div', { class: 'rag-item-head' }, h('strong', {}, `[${i + 1}] ${x.docName}`), x.line ? h('small', {}, `line ${x.line}`) : null, h('span', { class: 'spacer' }),
          Object.entries(x.parts || {}).map(([k, v]) => h('small', { class: 'mono score' }, `${k === 'bm25' ? 'kw' : 'vec'} ${v.toFixed(3)}`))),
        h('pre', {}, truncate(x.text, 500)))) : [h('p', { class: 'muted small' }, 'No matches.')]));
  };
  if (kstate.query) setTimeout(() => run(kstate.query));
  return section('Test a search', h('div', { class: 'stack' }, input(kstate.query, run, { placeholder: 'Ask something your documents answer', class: 'input' }, 250), out), { id: 'kb-search', open: false });
}

function settingsSection() {
  const r = settings.rag, e = r.embed;
  const s = rag.stats();
  const rechunk = h('div', { class: 'row', hidden: true }, h('small', { class: 'muted' }, 'Chunk settings changed.'), h('span', { class: 'spacer' }), btn('Re-chunk all documents', async () => { await rag.rechunkAll(); toast('Re-chunked', { type: 'ok' }); autoEmbed(); }, { kind: 'primary' }));
  const sources = [{ value: 'ollama', label: 'Ollama' }, ...PRESETS.filter(p => p.type === 'openai').map(p => ({ value: p.id, label: p.name }))];
  return section('Retrieval settings', h('div', { class: 'stack' },
    field('Search mode', segmented([{ value: 'bm25', label: 'Keyword' }, { value: 'hybrid', label: 'Hybrid' }, { value: 'vector', label: 'Vector' }], r.mode, v => { r.mode = v; saveSettings('rag'); }), 'Keyword (BM25) needs no model. Hybrid and vector need embeddings and fall back to keyword search without them.'),
    h('div', { class: 'grid3' },
      field('Excerpts per message', input(r.topK, v => { r.topK = Math.max(1, Math.min(20, +v || 4)); saveSettings('rag'); }, { type: 'number', min: 1, max: 20, class: 'input input-num' })),
      field('Chunk size', input(r.chunkSize, v => { r.chunkSize = Math.max(200, +v || 1200); saveSettings('rag'); rechunk.hidden = !rag.kb.docs.length; }, { type: 'number', min: 200, step: 100, class: 'input input-num' }), 'characters'),
      field('Overlap', input(r.overlap, v => { r.overlap = Math.max(0, +v || 0); saveSettings('rag'); rechunk.hidden = !rag.kb.docs.length; }, { type: 'number', min: 0, step: 50, class: 'input input-num' }), 'characters')),
    rechunk,
    h('div', { class: 'pgroup-title' }, 'Embeddings'),
    toggle(e.enabled, v => { e.enabled = v; saveSettings('rag'); render(); if (v) autoEmbed(); }, 'Use an embedding model'),
    e.enabled ? h('div', { class: 'stack' },
      h('div', { class: 'grid2' },
        field('Provider', select(sources, e.source, v => { e.source = v; saveSettings('rag'); })),
        field('Model', input(e.model, v => { e.model = v.trim(); saveSettings('rag'); render(); }, { class: 'input mono', placeholder: 'nomic-embed-text', spellcheck: 'false' }, 600))),
      h('small', { class: 'help' }, e.source === 'ollama' ? 'Pull one first, e.g. "ollama pull nomic-embed-text" or "ollama pull mxbai-embed-large".' : 'Uses the base URL and key from that provider\'s settings, e.g. text-embedding-3-small on OpenAI.'),
      h('div', { class: 'row' }, h('small', { class: 'muted' }, s.pending ? `${s.pending} documents need embedding` : 'All documents are embedded'), h('span', { class: 'spacer' }),
        kstate.embedCtrl ? btn('Stop', () => kstate.embedCtrl?.abort(), { kind: 'ghost', iconName: 'stop' }) : btn('Embed now', runEmbed, { iconName: 'zap', disabled: !s.pending }))) : null),
    { id: 'kb-settings', open: false });
}
