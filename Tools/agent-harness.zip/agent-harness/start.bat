@echo off
setlocal
title Agent Harness
rem Agent Harness launcher for Windows.
rem Usage: start.bat [workspace-folder] [--port 8787] [--no-exec] [--host 0.0.0.0] [--ollama http://host:11434]
cd /d "%~dp0"

where node >nul 2>nul
if errorlevel 1 (
  echo Node.js 18 or newer is required. Install it from https://nodejs.org and run this again.
  pause
  exit /b 1
)
for /f "tokens=1 delims=." %%v in ('node -p "process.versions.node"') do set NODE_MAJOR=%%v
if %NODE_MAJOR% LSS 18 (
  echo Found Node.js %NODE_MAJOR%. Version 18 or newer is required.
  pause
  exit /b 1
)
if not exist .env if exist .env.example echo Tip: copy .env.example to .env to keep API keys out of the browser.

node server.js --open %*
if errorlevel 1 pause
