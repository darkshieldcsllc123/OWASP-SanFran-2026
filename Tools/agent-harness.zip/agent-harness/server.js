#!/usr/bin/env node
'use strict';
/**
 * Agent Harness server (zero dependencies, Node 18+)
 *
 *   /            static SPA from ./public (session token injected into index.html)
 *   /proxy       streaming relay to Ollama or any cloud model API (removes CORS issues)
 *   /api/info    environment info for the UI
 *   /api/fs/*    sandboxed file tools confined to the workspace folder
 *   /api/exec    shell commands inside the workspace (disable with --no-exec)
 *
 * Usage: node server.js [workspaceDir] [--port 8787] [--host 127.0.0.1] [--no-exec] [--open]
 */
const http = require('http');
const https = require('https');
const fs = require('fs');
const fsp = fs.promises;
const path = require('path');
const crypto = require('crypto');
const os = require('os');
const { spawn } = require('child_process');

const VERSION = '1.0.0';

// ───────────────────────── config ─────────────────────────
loadDotEnv(path.join(__dirname, '.env'));
const args = parseArgs(process.argv.slice(2));
let PORT = Number(args.port || process.env.PORT || 8787);
const HOST = args.host || process.env.HOST || '127.0.0.1';
const ROOT = path.resolve(args._[0] || args.workspace || process.env.HARNESS_WORKSPACE || path.join(__dirname, 'workspace'));
const ALLOW_EXEC = !(args['no-exec'] || process.env.HARNESS_NO_EXEC === '1');
const OLLAMA_URL = normalizeOllama(args.ollama || process.env.OLLAMA_HOST || 'http://127.0.0.1:11434');
const PUBLIC = path.join(__dirname, 'public');
const TOKEN = crypto.randomBytes(18).toString('hex');
const MAX_JSON_BODY = 25 * 1024 * 1024;
const MAX_EXEC_OUTPUT = 256 * 1024;

fs.mkdirSync(ROOT, { recursive: true });
const REAL_ROOT = fs.realpathSync(ROOT);

const IGNORED_DIRS = new Set([
  'node_modules', '.git', '.hg', '.svn', '__pycache__', '.venv', 'venv', '.next', '.nuxt',
  'dist', 'build', 'target', 'coverage', '.cache', '.parcel-cache', '.turbo', '.gradle',
]);

// Keys the proxy can inject from .env / environment when the browser sends none.
const ENV_KEYS = [
  { host: 'api.openai.com', env: 'OPENAI_API_KEY', header: 'authorization', bearer: true },
  { host: 'api.anthropic.com', env: 'ANTHROPIC_API_KEY', header: 'x-api-key' },
  { host: 'openrouter.ai', env: 'OPENROUTER_API_KEY', header: 'authorization', bearer: true },
  { host: 'api.groq.com', env: 'GROQ_API_KEY', header: 'authorization', bearer: true },
  { host: 'generativelanguage.googleapis.com', env: 'GEMINI_API_KEY', header: 'authorization', bearer: true },
  { host: 'api.deepseek.com', env: 'DEEPSEEK_API_KEY', header: 'authorization', bearer: true },
  { host: 'api.mistral.ai', env: 'MISTRAL_API_KEY', header: 'authorization', bearer: true },
  { host: 'api.x.ai', env: 'XAI_API_KEY', header: 'authorization', bearer: true },
  { host: 'api.together.xyz', env: 'TOGETHER_API_KEY', header: 'authorization', bearer: true },
];

const MIME = {
  '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.mjs': 'text/javascript; charset=utf-8',
  '.css': 'text/css; charset=utf-8', '.json': 'application/json; charset=utf-8', '.svg': 'image/svg+xml',
  '.png': 'image/png', '.jpg': 'image/jpeg', '.jpeg': 'image/jpeg', '.gif': 'image/gif', '.webp': 'image/webp',
  '.ico': 'image/x-icon', '.txt': 'text/plain; charset=utf-8', '.md': 'text/markdown; charset=utf-8',
  '.woff2': 'font/woff2', '.map': 'application/json',
};

// ───────────────────────── helpers ─────────────────────────
function parseArgs(argv) {
  const out = { _: [] };
  for (let i = 0; i < argv.length; i++) {
    const a = argv[i];
    if (a.startsWith('--')) {
      const eq = a.indexOf('=');
      if (eq > -1) { out[a.slice(2, eq)] = a.slice(eq + 1); continue; }
      const key = a.slice(2);
      const next = argv[i + 1];
      if (next !== undefined && !next.startsWith('--') && !['open', 'no-exec'].includes(key)) { out[key] = next; i++; }
      else out[key] = true;
    } else out._.push(a);
  }
  return out;
}

function loadDotEnv(file) {
  let text;
  try { text = fs.readFileSync(file, 'utf8'); } catch { return; }
  for (const line of text.split(/\r?\n/)) {
    const m = line.match(/^\s*(?:export\s+)?([A-Za-z_][A-Za-z0-9_]*)\s*=\s*(.*)\s*$/);
    if (!m || line.trim().startsWith('#')) continue;
    let v = m[2];
    if ((v.startsWith('"') && v.endsWith('"')) || (v.startsWith("'") && v.endsWith("'"))) v = v.slice(1, -1);
    else v = v.replace(/\s+#.*$/, '');
    if (process.env[m[1]] === undefined) process.env[m[1]] = v;
  }
}

function normalizeOllama(u) {
  let s = String(u).trim();
  if (!/^https?:\/\//i.test(s)) s = 'http://' + s;
  try {
    const url = new URL(s);
    if (url.hostname === '0.0.0.0') url.hostname = '127.0.0.1';
    if (!url.port) url.port = '11434';
    return url.origin;
  } catch { return 'http://127.0.0.1:11434'; }
}

class HttpError extends Error { constructor(status, msg) { super(msg); this.status = status; } }

function sendJSON(res, status, obj) {
  const body = JSON.stringify(obj);
  res.writeHead(status, { 'content-type': 'application/json; charset=utf-8', 'cache-control': 'no-store', 'content-length': Buffer.byteLength(body) });
  res.end(body);
}

function readJSON(req) {
  return new Promise((resolve, reject) => {
    let size = 0; const chunks = [];
    req.on('data', c => {
      size += c.length;
      if (size > MAX_JSON_BODY) { reject(new HttpError(413, 'Request body too large')); req.destroy(); return; }
      chunks.push(c);
    });
    req.on('end', () => {
      if (!chunks.length) return resolve({});
      try { resolve(JSON.parse(Buffer.concat(chunks).toString('utf8'))); }
      catch { reject(new HttpError(400, 'Body must be valid JSON')); }
    });
    req.on('error', reject);
  });
}

function tokenOk(req) {
  const t = String(req.headers['x-harness-token'] || '');
  const a = Buffer.from(t), b = Buffer.from(TOKEN);
  return a.length === b.length && crypto.timingSafeEqual(a, b);
}

// Blocks DNS-rebinding: only answer to localhost names unless bound to all interfaces.
function hostOk(req) {
  if (HOST === '0.0.0.0' || HOST === '::') return true;
  const h = String(req.headers.host || '').replace(/:\d+$/, '').toLowerCase();
  return ['localhost', '127.0.0.1', '[::1]', '::1', HOST.toLowerCase()].includes(h);
}

const isInside = (p, root) => p === root || p.startsWith(root + path.sep);

/** Resolve a user/model supplied path to an absolute path inside the workspace or throw. */
function safePath(p = '.') {
  if (typeof p !== 'string') throw new HttpError(400, 'path must be a string');
  p = p.trim() || '.';
  let abs;
  if (path.isAbsolute(p) && isInside(path.resolve(p), ROOT)) abs = path.resolve(p);
  else abs = path.resolve(ROOT, p.replace(/^([a-zA-Z]:)?[\\/]+/, ''));
  if (!isInside(abs, ROOT)) throw new HttpError(403, `Path "${p}" is outside the workspace`);
  // follow symlinks on the nearest existing ancestor
  let probe = abs;
  while (!fs.existsSync(probe) && probe !== ROOT) probe = path.dirname(probe);
  const real = fs.realpathSync(probe);
  if (!isInside(real, REAL_ROOT)) throw new HttpError(403, `Path "${p}" resolves outside the workspace`);
  return abs;
}

const relPath = abs => path.relative(ROOT, abs).split(path.sep).join('/') || '.';

function isBinary(buf) {
  const n = Math.min(buf.length, 8000);
  for (let i = 0; i < n; i++) if (buf[i] === 0) return true;
  return false;
}

function escapeRe(s) { return s.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'); }

function globToRegex(glob) {
  let re = '';
  for (let i = 0; i < glob.length; i++) {
    const c = glob[i];
    if (c === '*') {
      if (glob[i + 1] === '*') { re += '.*'; i++; if (glob[i + 1] === '/') i++; }
      else re += '[^/]*';
    } else if (c === '?') re += '[^/]';
    else if (c === '{') {
      const end = glob.indexOf('}', i);
      if (end > i) { re += '(' + glob.slice(i + 1, end).split(',').map(escapeRe).join('|') + ')'; i = end; }
      else re += '\\{';
    } else re += escapeRe(c);
  }
  return new RegExp('^' + re + '$', 'i');
}

// ───────────────────────── workspace API ─────────────────────────
async function fsList({ path: p = '.', depth = 1, max = 800 }) {
  const base = safePath(p);
  const st = await fsp.stat(base).catch(() => null);
  if (!st) throw new HttpError(404, `Not found: ${p}`);
  if (!st.isDirectory()) throw new HttpError(400, `${p} is a file, not a directory`);
  depth = Math.max(1, Math.min(Number(depth) || 1, 8));
  const entries = []; let truncated = false;
  async function walk(dir, level) {
    let list;
    try { list = await fsp.readdir(dir, { withFileTypes: true }); } catch { return; }
    list.sort((a, b) => (b.isDirectory() - a.isDirectory()) || a.name.localeCompare(b.name));
    for (const d of list) {
      if (entries.length >= max) { truncated = true; return; }
      const abs = path.join(dir, d.name);
      const isDir = d.isDirectory() || (d.isSymbolicLink() && fs.statSync(abs, { throwIfNoEntry: false })?.isDirectory());
      const ignored = isDir && IGNORED_DIRS.has(d.name);
      let size = 0, mtime = 0;
      try { const s = await fsp.stat(abs); size = s.size; mtime = s.mtimeMs; } catch {}
      entries.push({ path: relPath(abs), name: d.name, type: isDir ? 'dir' : 'file', size, mtime, depth: level, ignored });
      if (isDir && !ignored && level < depth) await walk(abs, level + 1);
    }
  }
  await walk(base, 1);
  return { root: relPath(base), entries, truncated };
}

async function fsRead({ path: p, start, end }) {
  if (!p) throw new HttpError(400, 'path is required');
  const abs = safePath(p);
  const st = await fsp.stat(abs).catch(() => null);
  if (!st) throw new HttpError(404, `File not found: ${p}`);
  if (st.isDirectory()) throw new HttpError(400, `${p} is a directory. Use list_dir instead.`);
  if (st.size > 8 * 1024 * 1024) throw new HttpError(413, `${p} is ${(st.size / 1048576).toFixed(1)} MB, too large to read`);
  const buf = await fsp.readFile(abs);
  if (isBinary(buf)) return { path: relPath(abs), binary: true, size: st.size, content: '' };
  const lines = buf.toString('utf8').split(/\r?\n/);
  const s = Math.max(1, Number(start) || 1);
  const e = Math.min(lines.length, Number(end) || lines.length);
  return { path: relPath(abs), content: lines.slice(s - 1, e).join('\n'), startLine: s, endLine: e, totalLines: lines.length, size: st.size, mtime: st.mtimeMs };
}

async function fsWrite({ path: p, content = '', append = false }) {
  if (!p) throw new HttpError(400, 'path is required');
  if (typeof content !== 'string') content = JSON.stringify(content, null, 2);
  const abs = safePath(p);
  if (abs === ROOT) throw new HttpError(400, 'Cannot write to the workspace root');
  const existed = fs.existsSync(abs);
  if (existed && fs.statSync(abs).isDirectory()) throw new HttpError(400, `${p} is a directory`);
  await fsp.mkdir(path.dirname(abs), { recursive: true });
  if (append) await fsp.appendFile(abs, content, 'utf8'); else await fsp.writeFile(abs, content, 'utf8');
  return { path: relPath(abs), bytes: Buffer.byteLength(content), lines: content.split('\n').length, created: !existed, appended: !!append };
}

async function fsEdit({ path: p, old_str, new_str = '', replace_all = false }) {
  if (!p) throw new HttpError(400, 'path is required');
  if (typeof old_str !== 'string' || !old_str.length) throw new HttpError(400, 'old_str must be a non-empty string');
  const abs = safePath(p);
  const text = await fsp.readFile(abs, 'utf8').catch(() => { throw new HttpError(404, `File not found: ${p}`); });
  let find = old_str, repl = String(new_str);
  if (!text.includes(find) && text.includes('\r\n')) { find = find.replace(/\r?\n/g, '\r\n'); repl = repl.replace(/\r?\n/g, '\r\n'); }
  const count = text.split(find).length - 1;
  if (count === 0) throw new HttpError(422, `old_str was not found in ${p}. Read the file again and copy the exact text, including whitespace.`);
  if (count > 1 && !replace_all) throw new HttpError(422, `old_str appears ${count} times in ${p}. Include more surrounding lines to make it unique, or set replace_all to true.`);
  const line = text.slice(0, text.indexOf(find)).split('\n').length;
  const out = replace_all ? text.split(find).join(repl) : text.replace(find, () => repl);
  await fsp.writeFile(abs, out, 'utf8');
  return { path: relPath(abs), replacements: replace_all ? count : 1, line };
}

async function fsDelete({ path: p }) {
  if (!p) throw new HttpError(400, 'path is required');
  const abs = safePath(p);
  if (abs === ROOT) throw new HttpError(400, 'Refusing to delete the workspace root');
  const st = await fsp.stat(abs).catch(() => null);
  if (!st) throw new HttpError(404, `Not found: ${p}`);
  await fsp.rm(abs, { recursive: true, force: false });
  return { path: relPath(abs), deleted: true, type: st.isDirectory() ? 'dir' : 'file' };
}

async function fsMove({ from, to }) {
  if (!from || !to) throw new HttpError(400, 'from and to are required');
  const a = safePath(from), b = safePath(to);
  if (fs.existsSync(b)) throw new HttpError(409, `${to} already exists`);
  await fsp.mkdir(path.dirname(b), { recursive: true });
  await fsp.rename(a, b);
  return { from: relPath(a), to: relPath(b) };
}

async function fsSearch({ pattern, path: p = '.', glob, regex = false, case_sensitive = false, max_results = 100 }) {
  if (!pattern) throw new HttpError(400, 'pattern is required');
  const base = safePath(p);
  let re;
  try { re = new RegExp(regex ? pattern : escapeRe(pattern), case_sensitive ? '' : 'i'); }
  catch (e) { throw new HttpError(400, `Invalid regex: ${e.message}`); }
  const globRe = glob ? globToRegex(glob) : null;
  const limit = Math.min(Number(max_results) || 100, 500);
  const matches = []; let filesScanned = 0, truncated = false;
  async function walk(dir) {
    let list;
    try { list = await fsp.readdir(dir, { withFileTypes: true }); } catch { return; }
    for (const d of list) {
      if (matches.length >= limit) { truncated = true; return; }
      const abs = path.join(dir, d.name);
      if (d.isDirectory()) { if (!IGNORED_DIRS.has(d.name)) await walk(abs); continue; }
      if (!d.isFile()) continue;
      const rel = relPath(abs);
      if (globRe && !globRe.test(glob.includes('/') ? rel : d.name)) continue;
      const st = await fsp.stat(abs).catch(() => null);
      if (!st || st.size > 1024 * 1024) continue;
      const buf = await fsp.readFile(abs).catch(() => null);
      if (!buf || isBinary(buf)) continue;
      filesScanned++;
      const lines = buf.toString('utf8').split(/\r?\n/);
      for (let i = 0; i < lines.length; i++) {
        if (re.test(lines[i])) {
          matches.push({ path: rel, line: i + 1, text: lines[i].length > 300 ? lines[i].slice(0, 300) + '…' : lines[i] });
          if (matches.length >= limit) { truncated = true; return; }
        }
      }
    }
  }
  const st = await fsp.stat(base).catch(() => null);
  if (!st) throw new HttpError(404, `Not found: ${p}`);
  if (st.isDirectory()) await walk(base); else {
    const lines = (await fsp.readFile(base, 'utf8')).split(/\r?\n/); filesScanned = 1;
    lines.forEach((l, i) => { if (re.test(l) && matches.length < limit) matches.push({ path: relPath(base), line: i + 1, text: l }); });
  }
  return { matches, filesScanned, truncated };
}

function killTree(child) {
  if (!child || child.exitCode !== null) return;
  try {
    if (process.platform === 'win32') spawn('taskkill', ['/pid', String(child.pid), '/T', '/F'], { windowsHide: true });
    else process.kill(-child.pid, 'SIGKILL');
  } catch { try { child.kill('SIGKILL'); } catch {} }
}

function runExec({ command, cwd = '.', timeout = 60 }, res) {
  return new Promise((resolve, reject) => {
    if (!ALLOW_EXEC) return reject(new HttpError(403, 'Shell commands are disabled on this server (started with --no-exec).'));
    if (!command || typeof command !== 'string') return reject(new HttpError(400, 'command is required'));
    const dir = safePath(cwd);
    const secs = Math.max(1, Math.min(Number(timeout) || 60, 900));
    const started = Date.now();
    const child = spawn(command, { cwd: dir, shell: true, env: { ...process.env, FORCE_COLOR: '0', NO_COLOR: '1' }, windowsHide: true, detached: process.platform !== 'win32' });
    let stdout = '', stderr = '', timedOut = false, finished = false;
    const cap = (buf, add) => buf.length >= MAX_EXEC_OUTPUT ? buf : (buf + add).slice(0, MAX_EXEC_OUTPUT);
    child.stdout.on('data', d => { stdout = cap(stdout, d.toString()); });
    child.stderr.on('data', d => { stderr = cap(stderr, d.toString()); });
    const timer = setTimeout(() => { timedOut = true; killTree(child); }, secs * 1000);
    res.on('close', () => { if (!finished) killTree(child); });
    child.on('error', err => { finished = true; clearTimeout(timer); reject(new HttpError(500, `Failed to start command: ${err.message}`)); });
    child.on('close', (code, signal) => {
      finished = true; clearTimeout(timer);
      if (stdout.length >= MAX_EXEC_OUTPUT) stdout += '\n[output truncated]';
      if (stderr.length >= MAX_EXEC_OUTPUT) stderr += '\n[output truncated]';
      resolve({ command, cwd: relPath(dir), code, signal, stdout, stderr, timedOut, durationMs: Date.now() - started });
    });
  });
}

function info() {
  const envKeys = {};
  for (const k of ENV_KEYS) envKeys[k.env] = !!process.env[k.env];
  return {
    version: VERSION, root: ROOT, rootName: path.basename(ROOT), platform: process.platform,
    os: `${os.type()} ${os.release()}`, arch: process.arch, node: process.version, exec: ALLOW_EXEC,
    shell: process.platform === 'win32' ? (process.env.ComSpec || 'cmd.exe') : (process.env.SHELL || '/bin/sh'),
    ollama: OLLAMA_URL, envKeys,
  };
}

const API = {
  'GET /api/info': () => info(),
  'POST /api/fs/list': fsList,
  'POST /api/fs/read': fsRead,
  'POST /api/fs/write': fsWrite,
  'POST /api/fs/edit': fsEdit,
  'POST /api/fs/delete': fsDelete,
  'POST /api/fs/move': fsMove,
  'POST /api/fs/search': fsSearch,
  'POST /api/exec': runExec,
};

// ───────────────────────── proxy ─────────────────────────
const DROP_REQ = new Set(['host', 'connection', 'keep-alive', 'proxy-connection', 'transfer-encoding', 'upgrade', 'origin', 'referer', 'cookie', 'accept-encoding', 'te', 'trailer', 'x-target-url', 'x-harness-token']);
const DROP_RES = new Set(['connection', 'keep-alive', 'transfer-encoding', 'set-cookie', 'access-control-allow-origin', 'access-control-allow-credentials', 'access-control-allow-headers', 'access-control-allow-methods', 'access-control-expose-headers', 'content-security-policy']);

function handleProxy(req, res) {
  let url;
  try { url = new URL(String(req.headers['x-target-url'] || '')); } catch { return sendJSON(res, 400, { error: 'Missing or invalid x-target-url header' }); }
  if (!/^https?:$/.test(url.protocol)) return sendJSON(res, 400, { error: 'Only http and https targets are supported' });

  const headers = {};
  for (const [k, v] of Object.entries(req.headers)) if (!DROP_REQ.has(k) && !k.startsWith('sec-')) headers[k] = v;
  headers.host = url.host;
  headers['accept-encoding'] = 'identity';
  headers['user-agent'] = headers['user-agent'] || `agent-harness/${VERSION}`;

  const ek = ENV_KEYS.find(e => url.hostname === e.host || url.hostname.endsWith('.' + e.host));
  if (ek && process.env[ek.env] && !headers[ek.header]) headers[ek.header] = ek.bearer ? `Bearer ${process.env[ek.env]}` : process.env[ek.env];

  const started = Date.now();
  const lib = url.protocol === 'https:' ? https : http;
  const up = lib.request(url, { method: req.method, headers }, upRes => {
    const out = {};
    for (const [k, v] of Object.entries(upRes.headers)) if (!DROP_RES.has(k)) out[k] = v;
    out['cache-control'] = 'no-cache';
    out['x-accel-buffering'] = 'no';
    out['x-upstream-ttfb'] = String(Date.now() - started);
    res.writeHead(upRes.statusCode || 502, out);
    upRes.pipe(res);
    upRes.on('end', () => log(`${req.method} ${url.host}${url.pathname} ${upRes.statusCode} ${Date.now() - started}ms`));
  });
  up.setTimeout(0);
  up.on('error', err => {
    log(`${req.method} ${url.host}${url.pathname} failed: ${err.code || err.message}`);
    if (res.headersSent) return res.destroy();
    const hint = err.code === 'ECONNREFUSED'
      ? (url.port === '11434' || /ollama/i.test(url.host) ? ' Is Ollama running? Start it with "ollama serve".' : ' Is the server running?')
      : err.code === 'ENOTFOUND' ? ' Check the base URL.' : '';
    sendJSON(res, 502, { error: `Could not reach ${url.origin} (${err.code || err.message}).${hint}` });
  });
  res.on('close', () => { if (!res.writableEnded) up.destroy(); });
  req.pipe(up);
}

// ───────────────────────── static ─────────────────────────
let indexCache = null;
async function serveStatic(req, res, pathname) {
  let rel;
  try { rel = decodeURIComponent(pathname); } catch { return sendJSON(res, 400, { error: 'Bad path' }); }
  if (rel === '/' || rel === '') rel = '/index.html';
  const file = path.join(PUBLIC, path.normalize(rel).replace(/^([\\/]\.\.)+/, ''));
  if (!isInside(file, PUBLIC)) return sendJSON(res, 403, { error: 'Forbidden' });
  const st = await fsp.stat(file).catch(() => null);
  if (!st || !st.isFile()) { res.writeHead(404, { 'content-type': 'text/plain' }); return res.end('Not found'); }
  const headers = { 'content-type': MIME[path.extname(file).toLowerCase()] || 'application/octet-stream', 'cache-control': 'no-cache', 'x-content-type-options': 'nosniff', 'referrer-policy': 'no-referrer' };
  if (file.endsWith('index.html')) {
    if (!indexCache || indexCache.mtime !== st.mtimeMs) indexCache = { mtime: st.mtimeMs, html: await fsp.readFile(file, 'utf8') };
    const html = indexCache.html.replace('__HARNESS_TOKEN__', TOKEN);
    headers['content-length'] = Buffer.byteLength(html);
    res.writeHead(200, headers); return res.end(html);
  }
  headers['content-length'] = st.size;
  res.writeHead(200, headers);
  fs.createReadStream(file).pipe(res);
}

// ───────────────────────── server ─────────────────────────
function log(msg) { if (!args.quiet) console.log(`  ${new Date().toLocaleTimeString()}  ${msg}`); }

const server = http.createServer(async (req, res) => {
  try {
    if (!hostOk(req)) return sendJSON(res, 403, { error: 'Host not allowed' });
    const { pathname } = new URL(req.url, 'http://x');
    if (req.method === 'OPTIONS') { res.writeHead(204); return res.end(); }

    if (pathname === '/proxy' || pathname.startsWith('/api/')) {
      if (!tokenOk(req)) return sendJSON(res, 401, { error: 'Session token missing or expired. Reload the page.', code: 'TOKEN' });
      if (pathname === '/proxy') return handleProxy(req, res);
      const handler = API[`${req.method} ${pathname}`];
      if (!handler) return sendJSON(res, 404, { error: `No route ${req.method} ${pathname}` });
      const body = req.method === 'GET' ? {} : await readJSON(req);
      const result = await handler(body, res);
      if (!res.writableEnded && !res.destroyed) sendJSON(res, 200, result);
      return;
    }
    if (req.method !== 'GET' && req.method !== 'HEAD') return sendJSON(res, 405, { error: 'Method not allowed' });
    await serveStatic(req, res, pathname);
  } catch (err) {
    const status = err.status || (err.code === 'ENOENT' ? 404 : err.code === 'EACCES' ? 403 : 500);
    if (status >= 500) console.error(err);
    if (!res.headersSent) sendJSON(res, status, { error: err.message || String(err) });
    else res.destroy();
  }
});
server.requestTimeout = 0;
server.headersTimeout = 0;
server.keepAliveTimeout = 65_000;

function openBrowser(url) {
  const cmd = process.platform === 'win32' ? 'cmd' : process.platform === 'darwin' ? 'open' : 'xdg-open';
  const a = process.platform === 'win32' ? ['/c', 'start', '""', url] : [url];
  try { spawn(cmd, a, { detached: true, stdio: 'ignore', windowsHide: true }).unref(); } catch {}
}

function checkOllama() {
  return new Promise(resolve => {
    const req = http.get(OLLAMA_URL + '/api/version', { timeout: 1500 }, r => {
      let d = ''; r.on('data', c => d += c); r.on('end', () => { try { resolve(JSON.parse(d).version || 'ok'); } catch { resolve('ok'); } });
    });
    req.on('error', () => resolve(null));
    req.on('timeout', () => { req.destroy(); resolve(null); });
  });
}

let attempts = 0;
server.on('error', err => {
  if (err.code === 'EADDRINUSE' && attempts < 10 && !args.port) { attempts++; PORT++; return server.listen(PORT, HOST); }
  console.error(`\n  Could not start server: ${err.message}\n`);
  process.exit(1);
});

server.listen(PORT, HOST, async () => {
  const shown = HOST === '0.0.0.0' || HOST === '::' ? 'localhost' : HOST;
  const url = `http://${shown}:${PORT}`;
  const ollama = await checkOllama();
  const keys = ENV_KEYS.filter(k => process.env[k.env]).map(k => k.env);
  const c = (n, s) => process.stdout.isTTY ? `\x1b[${n}m${s}\x1b[0m` : s;
  console.log(`\n  ${c('1;33', 'Agent Harness')} ${c('2', 'v' + VERSION)}\n`);
  console.log(`  App         ${c('1;36', url)}`);
  console.log(`  Workspace   ${ROOT}`);
  console.log(`  Shell       ${ALLOW_EXEC ? 'enabled (approval required by default in the UI)' : 'disabled (--no-exec)'}`);
  console.log(`  Ollama      ${OLLAMA_URL} ${ollama ? c('32', `reachable, v${ollama}`) : c('31', 'not reachable')}`);
  console.log(`  Env keys    ${keys.length ? keys.join(', ') : 'none (add them to .env or paste keys in the UI)'}`);
  if (HOST === '0.0.0.0') console.log(c('33', '\n  Warning: listening on all interfaces. Anyone on your network with the page token can run commands.'));
  console.log(`\n  ${c('2', 'Press Ctrl+C to stop.')}\n`);
  if (args.open) openBrowser(url);
});

process.on('SIGINT', () => { console.log('\n  Stopped.'); process.exit(0); });
