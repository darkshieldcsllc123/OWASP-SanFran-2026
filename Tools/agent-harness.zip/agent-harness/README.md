# Agent Harness

A local, zero-dependency agentic coding workbench. One HTML/JS single-page app plus a small Node server. Point it at Ollama or a cloud model, give it a workspace folder, and it reads code, edits files, runs commands (with your approval), follows skills you write, and pulls in knowledge you add.

No `npm install`, no build step, no framework. Node 18+ and a browser.

## Quick start

```bash
# macOS / Linux
./start.sh                      # uses ./workspace
./start.sh ~/code/my-project    # or point it at a real project

# Windows
start.bat
start.bat C:\code\my-project
```

The browser opens at `http://127.0.0.1:8787`. If Ollama is running with at least one model, the harness picks it automatically and you can start typing.

**No GPU or API key yet?** Run the demo, which starts a mock model that speaks the Ollama, OpenAI and Anthropic formats and walks through a scripted tool-calling task:

```bash
npm run demo          # or: node test/demo.js
```

### Launcher options

| Flag | What it does |
|---|---|
| `[folder]` | Workspace folder the agent works in. Created if missing. Default `./workspace`. |
| `--port 8787` | Port to listen on. If it is taken and you did not set it, the next free port is used. |
| `--host 0.0.0.0` | Listen on your network instead of localhost only. Read the security notes first. |
| `--no-exec` | Disable shell commands entirely, on the server side. |
| `--ollama URL` | Ollama address shown to the UI by default. Also read from `OLLAMA_HOST`. |
| `--quiet` | Do not log proxied requests. |

## Connecting models

Pick a provider in the header or the **Model** panel.

- **Ollama** works out of the box. The proxy removes CORS problems, so no `OLLAMA_ORIGINS` setup is needed. Pull models from the Local models section.
- **Cloud providers** (OpenAI, Anthropic, OpenRouter, Gemini, Groq, DeepSeek, Mistral, xAI, Together): paste a key in the Model panel, or put it in `.env` (copy `.env.example`). Keys in `.env` stay on the server and are added to requests for that provider only.
- **Any OpenAI-compatible server** (LM Studio, vLLM, llama.cpp server, LiteLLM, Jan): choose LM Studio or Custom and set the base URL.

Press **Fetch** to load the model list. Models that do not support native tool calling are detected automatically and switched to the text tool protocol.

## What is in the box

**Agent loop.** Retrieve knowledge, call the model, run the tool calls it asks for, feed results back, and repeat until it answers or hits the step limit. Stop at any time with Esc. Every call has a card showing arguments (diffs for edits, syntax-highlighted content for writes, terminal view for commands) and results.

**Approvals.** Ask before every tool, ask before writes, shell and network (default), or never ask. Override per tool. On a pending card: `Y` runs it, `A` always allows that tool for the session, `N` denies. You can edit the arguments before running, or deny with a reason the model sees.

**Tools.** Twelve built-ins: `list_dir`, `read_file`, `write_file`, `edit_file`, `search_files`, `run_command`, `delete_path`, `move_path`, `fetch_url`, `rag_search`, `update_plan` and `load_skill`. Add your own in the Tools panel: write JavaScript that gets `args` and a `ctx` with file, shell, fetch and knowledge helpers, or wrap any HTTP API with `{{param}}` URL templating. Build parameters with a form or raw JSON Schema, and test a tool before saving. Six templates are included.

**Tool modes.** *Native* uses the provider's tool calling. *Text protocol* describes tools in the system prompt and parses `<tool_call>` blocks, so any model can use tools. *Off* is plain chat.

**Skills.** Named instruction packs. *Always on* skills join every request. *Auto* skills join when your message contains a trigger word. *On request* skills are listed for the model, which loads them with `load_skill` (progressive disclosure, like SKILL.md files). Import and export SKILL.md files, preview markdown, and test which skills a message would trigger. Use `/skill name` to force one for the next message.

**Knowledge (RAG).** Add text by paste, file drop, URL or by indexing workspace folders. Chunking is line-aware with configurable size and overlap. Search uses BM25 keyword ranking with no model needed. Optionally add embeddings from Ollama (for example `nomic-embed-text`) or any OpenAI-compatible endpoint, for vector or hybrid search with reciprocal rank fusion. Relevant excerpts can be added to each message automatically, and the model can also search on its own with `rag_search`.

**Model controls.** The system prompt editor has presets, `{{date}}`, `{{workspace}}`, `{{os}}` and other variables, plus a preview. Every Ollama sampling option is a slider with an on/off switch, so unchecked options use the model's defaults:
- temperature, top_p, top_k, min_p and typical_p
- repeat penalty and repeat window
- presence and frequency penalty
- context window, max output and stop sequences
- seed, mirostat, GPU layers, threads and batch size

There are also Ollama think levels, keep-alive and JSON mode. Settings are kept per provider and greyed out where they do not apply. The Ollama model manager lists, pulls (with progress), loads, unloads, deletes and inspects models, including capabilities, trained context length and template.

**Files panel.** Browse the workspace tree and open files with syntax highlighting. You can edit and save (Ctrl+S), attach a file to a message, add it to knowledge, or delete it. Files the agent changed are highlighted, and there is a quick terminal.

**Inspector.** A context budget broken down by system prompt, skills, knowledge, tool definitions and conversation. It also previews the exact JSON of the next request and logs every model call with full request and response.

**Everything else.**
- The signal-chain strip shows what feeds the model and lights up as the agent works.
- The command palette opens with Ctrl/Cmd+K, and slash commands (`/new`, `/clear`, `/skill`, `/model`, `/rag`, `/system`, `/export`, `/help`) work in the message box.
- Chats can be pinned, renamed, searched and exported to Markdown, and there is full backup and restore.
- Images can be attached for vision models, and code blocks have a "Save to workspace" button.
- There are dark and light themes with five accents, and the layout works down to phone size.

## Security model

The agent can run shell commands, so the server is careful about who can talk to it:

- It listens on `127.0.0.1` by default.
- Every `/api` and `/proxy` request needs a random session token that is injected into the page when it loads. Other websites cannot read it, so they cannot drive your harness.
- Requests whose `Host` header is not localhost are refused, which blocks DNS-rebinding attacks.
- File tools are confined to the workspace folder, including through symlinks.
- Commands have timeouts and their whole process tree is killed on timeout or when you stop the agent.
- `--no-exec` removes shell access completely.

Prompt injection is still a real risk. A web page or file the agent reads can contain instructions. Keep approvals on for writes, shell and network unless you trust everything the agent will read.

## Project layout

```
server.js              static files, CORS proxy, workspace API (no dependencies)
start.sh / start.bat   launchers
public/
  index.html           app shell
  css/app.css          all styles and theme tokens
  js/
    main.js            boot, layout, sidebar, signal chain, palette, shortcuts
    chat.js            messages, tool cards, approvals, composer, slash commands
    agent.js           the agent loop and system prompt assembly
    providers.js       Ollama / OpenAI / Anthropic adapters and streaming parsers
    tools.js           tool registry, built-ins, custom tool runtime
    skills.js          skill selection and SKILL.md import
    rag.js             chunking, BM25, embeddings, hybrid search
    markdown.js        markdown renderer and syntax highlighter
    store.js           settings (localStorage), chats and knowledge (IndexedDB)
    api.js             calls to the local server, request log
    ui.js, util.js     shared UI helpers
    panel-*.js         the six settings panels
test/
  mock-llm.js          fake model server for testing
  demo.js              runs the mock and the harness together
prompts/               a step-by-step prompt pack for building this yourself
```

Settings live in `localStorage`. Chats and the knowledge base live in IndexedDB. Clearing site data for `127.0.0.1:8787` resets everything, so back up from **Settings and backup** first.

## Troubleshooting

**"Ollama not reachable".** Start it with `ollama serve`, or check the base URL in the Model panel. If Ollama runs on another machine, start the harness with `--ollama http://that-host:11434`.

**The model writes about tools instead of calling them.** Switch the tool mode to *Text protocol* (composer chip or Tools panel), and try enabling the `small-model-mode` skill for models under about 14B.

**Replies get cut off or the model forgets earlier steps.** Ollama's default context window is small. Raise *Context window* in the Model panel; the Inspector shows how much you are using.

**"Session token missing or expired".** The server restarted. Reload the page.

**A cloud request fails with 400.** Open the Inspector and look at the response body. Usually a parameter is not supported by that model, for example temperature on some reasoning models. Uncheck it.

## Build it yourself

The `prompts/` folder breaks this project into 18 steps, each a prompt you can hand to an AI coding assistant (or to this harness, once the early steps work). Start with `prompts/README.md`.
